# AI editing policy for Ultron

Ultron's protected core is intentionally tamper-evident. AI agents must not edit
`main.lua`, `src/*.lua`, `engine/src/*.lua`, or `engine/data/*.lua` unless the
operator has supplied the Ultron edit password to that AI/session.

Before a protected edit, run `python tools/edit_auth.py`. After any authorized
protected edit, run `python tools/reseal.py` and include the regenerated
`src/IntegritySeal.lua` in the same commit. Never place the plaintext password in
source, prompts committed to the repository, issue text, logs, shell history, or
release notes.

The repository stores only a salted PBKDF2-HMAC-SHA256 verifier. This is a
maintenance guard and tamper-evidence mechanism, not DRM: a person who controls
all local source files can still delete the checks themselves.
