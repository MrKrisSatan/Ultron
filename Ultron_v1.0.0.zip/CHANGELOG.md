# Changelog

## 1.0.0

- Removed The World as a required dependency; Ultron now vendors and loads its
  own 37-module AI core.
- Added standalone Gen 1/Gen 2 map graph, physical collision travel, battle
  simulation, catching, economy, Gym/League progression and competitive data.
- Added persistent Ultron-only identity, canonical starter rules and private
  money/inventory/PC state.
- Added Ultron-selected first-save appearance, locked for the rest of the save.
- Added same-map autonomous player challenges.
- Added physical route travel with fail-closed collision and real map transitions.
- Added trainer-coordinate approach before required campaign trainer battles when
  the map data exposes a physical trainer position.
- Blackout now returns only to the last visited Pokémon Center or player home.
- Added standalone news ticker and optional merge into The World's AI-rival ticker.
- Added chat input, bounded dialogue memory and battle-history grounding.
- Added offline Smogon-backed competitive team preparation.
- Added portable community training-data export/import with source de-duplication.
- Added tamper-aware identity/party/sprite monitoring.
- Added password-gated protected-edit tooling using a salted one-way verifier;
  plaintext maintenance credentials are not distributed.
