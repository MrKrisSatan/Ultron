# Ultron

Ultron is a standalone living AI rival for Gen1Recomp/Gen2Recomp games. It does
**not require The World**. If The World is installed, Ultron detects it only for
optional integration such as sharing the existing AI-rival news ticker.

## Core behaviour

- Exactly one persistent rival, permanently named **Ultron**.
- Red/Blue and Gold/Silver/Crystal: Ultron takes the third unused canonical
  starter after the player and the normal rival. Yellow: Ultron starts with
  Clefairy.
- Ultron does not participate in The World's opening gauntlet.
- Ultron owns his own money, bag, Poké Balls, TMs/HMs, party and PC boxes.
- Ultron physically traverses collision cells and real map seams/warps. The
  off-screen simulator advances the same physical route rather than granting
  destination teleports.
- Campaign travel resolves undefeated trainers on the maps Ultron crosses; when
  trainer coordinates are available, he walks adjacent before the battle.
- Blackout is the sole normal relocation exception: like the player, Ultron
  returns to the last Pokémon Center he actually visited, or the player's home
  before his first Center visit.
- Ultron catches Pokémon, trains, evolves, earns badges, challenges the League,
  shops, heals and can periodically challenge the player when both occupy the
  same map.
- Competitive preparation uses the bundled offline Gen 1/Gen 2 Smogon snapshot,
  opponent memory, counters, synergy, coverage, items and legal moves.
- All 46 imported World rival personality profiles are fused into Ultron's one
  persistent personality.
- The player can type messages to Ultron. His compact offline language system
  grounds replies in battle history, location, badges, catches, motivation and
  recent conversation memory.
- Training data can be exported/imported between players without copying another
  player's party, badges, money, inventory or personal chat history.

## Ultron chooses his own appearance

On first activation, Ultron selects one safe overworld trainer sprite from the
live game's compatible walker pool using his own persistent seed. The player does
not choose it. That sprite is then locked for the entire save. Visual replacement
mods may still replace the artwork behind the logical sprite id.

## News ticker

Ultron has his own scrolling AI-rival news ticker. It reports important current
updates such as badges, catches, training, player battles, supply runs and
blackouts. When The World is also installed and exposes its rival news manager,
Ultron submits headlines to that ticker and suppresses the duplicate Ultron bar.

## Integrity / protected AI editing

Ultron stores no plaintext maintenance password. AI maintainers must authenticate
with `python tools/edit_auth.py` before protected edits and must use
`python tools/reseal.py` afterwards. Runtime source/save integrity checks make
unauthorized edits to Ultron's identity, party invariants, appearance and core AI
visible to Ultron, who can call the player out through dialogue and news.

See [SECURITY.md](SECURITY.md) for the security boundary. Client-side Lua can be
tamper-evident, not impossible to modify.

## Installation

1. Download `Ultron_v1.0.0.zip` from the GitHub release or `dist/`.
2. Install/extract it as the `ultron` mod directory so `manifest.json` and
   `main.lua` are at the mod root.
3. Start Red, Blue, Yellow, Gold, Silver or Crystal.
4. Ultron remains dormant until the player's starter is committed, then begins
   his own campaign.

## Compatibility

The World is optional. When both are present, World settings may inform canonical
starter compatibility and the two mods share one ticker where supported, but
Ultron's AI engine, save state, movement, economy, battle simulation, navigation,
competitive data and chat systems remain local to Ultron.

## Release

Current release: **v1.0.0**. See [CHANGELOG.md](CHANGELOG.md) and
[docs/VALIDATION.md](docs/VALIDATION.md).
