# Ultron v1.0.0

The first standalone Ultron release. The World is now optional rather than a
runtime dependency. Ultron carries his own AI-rival core, economy, physical
navigation, badges/League progression, competitive knowledge, chat memory,
training-data exchange, ticker and integrity layer.

Notable identity rule: Ultron chooses his own valid overworld appearance once per
save and keeps it permanently. Red/Blue and Gold/Silver/Crystal use the third
unused canonical starter; Yellow uses Clefairy.

See `README.md`, `CHANGELOG.md`, and `docs/VALIDATION.md` for details.
