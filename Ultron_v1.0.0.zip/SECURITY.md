# Security and integrity model

Ultron uses two complementary integrity mechanisms.

1. **Protected-edit authorization.** `tools/edit_auth.py` verifies an externally
   supplied password against a salted PBKDF2-HMAC-SHA256 verifier. The plaintext
   password is not stored in this repository. `tools/reseal.py` refuses to
   regenerate the integrity manifest without successful authorization.
2. **Runtime tamper evidence.** `src/Integrity.lua` checks the protected source
   set against `src/IntegritySeal.lua`, while `src/Tamper.lua` also watches
   Ultron's saved identity, chosen appearance and party fingerprints. Detected
   changes become persistent integrity events that Ultron can mention in-game.

This is not unbreakable client-side protection. Anyone with full write access to
all local Lua files can remove a verifier. The goal is to make accidental and
unauthorized AI edits detectable while keeping the actual maintenance password
out of the distributed code.
