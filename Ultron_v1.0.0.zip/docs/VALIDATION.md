# Ultron v1.0.0 validation

Validated on 2026-08-27 before packaging.

- Manifest JSON parsed successfully.
- The World is not a required dependency; it is listed only as optional integration.
- 55 protected source/data files match the generated integrity seal.
- Plaintext maintenance password is absent from distributable source.
- One-time autonomous sprite selection is persisted through `appearanceChosen` / `appearanceSprite` and reapplied on load.
- Ultron identity remains fixed to `Ultron`; player mutation routes remain protected by the integrity/tamper layer.
- Physical-world contract is present: ordinary route progress is tile-by-tile, real seams/warps are required for map changes, and unknown collision fails closed.
- Blackout uses the last actually visited Pokémon Center, falling back to player home before the first Center visit.
- Standalone news ticker includes optional The World integration rather than a hard runtime dependency.
- No hard-coded `require("mods.the_world...")` dependency appears in Ultron's standalone manager/core.
- Red/Blue/Yellow/Gold/Silver/Crystal are all declared in the manifest.

## Runtime caveat

This environment does not include a Gen1Recomp/Gen2Recomp executable or Lua interpreter, so final in-engine behavior still requires live game testing. Static integrity and packaging checks passed.
