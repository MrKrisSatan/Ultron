return function(mod)
  local Util=require("mods.ultron.src.Util")
  local Engine=require("mods.ultron.src.Engine")
  local Fusion=require("mods.ultron.src.PersonalityFusion")
  local Motivation=require("mods.ultron.src.Motivation")
  local Atlas=require("mods.ultron.src.Atlas")
  local Brain=require("mods.ultron.src.ChampionshipBrain")
  local Micro=require("mods.ultron.src.MicroLLM")
  local Identity=require("mods.ultron.src.Identity")
  local Challenge=require("mods.ultron.src.Challenge")
  local Exchange=require("mods.ultron.src.TrainingExchange")
  local News=require("mods.ultron.src.News")
  local Tamper=require("mods.ultron.src.Tamper")
  local Integrity=require("mods.ultron.src.Integrity")
  local UI=require("mods.ultron.src.UI")
  local Gen2Talk=require("mods.ultron.src.Gen2Talk")

  local game,engine,news
  local chatPending,chatOpening=false,false
  local pulse=0
  local state={}

  local function log(level,msg)
    local l=mod.log and mod.log[level or "info"]; if l then pcall(l,mod.log,"[Ultron] "..tostring(msg)) end
  end
  local function normalise(saved)
    saved=type(saved)=="table" and saved or {}
    return {version=100,rival=saved.rival,motivation=Motivation.new(saved.motivation),atlas=Atlas.new(saved.atlas),brain=Brain.new(saved.brain),chat=Micro.new(saved.chat),identity=Identity.new(saved.identity),challenge=Challenge.new(saved.challenge),training=Exchange.new(saved.training),tamper=Tamper.new(saved.tamper),news=saved.news}
  end
  local function loadState() local s; pcall(function() s=mod.save:get("state") end); state=normalise(s); news=News.new(mod,state.news) end
  local function saveState()
    if engine and engine.rival then state.rival=engine:serializeRival(); state.identity=Identity.snapshot(state.identity,engine.rival); state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity) end
    if news then state.news=news:serialize() end
    pcall(function() mod.save:set("state",state) end)
  end
  local function say(text) return UI.say(mod,game,Util.cleanText(text,260)) end
  local function rewardHappiness(changes)
    local H=engine and engine.modules and engine.modules.Happiness; local r=engine and engine.rival
    if not(H and H.adjust and r) then return end
    for _,c in ipairs(changes or {}) do local d=0
      if c.kind=="badge" then d=4*(c.amount or 1) elseif c.kind=="catch" then d=math.min(3,c.amount or 1) elseif c.kind=="training" then d=math.min(2,c.amount or 1) elseif c.kind=="beat_player" then d=2*(c.amount or 1) elseif c.kind=="lost_to_player" then d=1 end
      if d>0 then pcall(H.adjust,r,d,"Ultron drive",{kind="ULTRON_DRIVE"}) end
    end
  end
  local function announceChanges(changes)
    if not news then return end
    for _,c in ipairs(changes or {}) do
      if c.kind=="badge" then news:add("Ultron earned a badge. Drive increased.","badge")
      elseif c.kind=="catch" then news:add("Ultron expanded his roster with a new catch.","catch")
      elseif c.kind=="training" and (c.amount or 0)>=2 then news:add("Ultron completed another training cycle.","train")
      elseif c.kind=="beat_player" then news:add("Ultron defeated the player and updated his battle model.","battle")
      elseif c.kind=="lost_to_player" then news:add("Ultron lost to the player and began counter-analysis.","battle") end
    end
  end
  local function tamperCallout()
    local line; state.tamper,line=Tamper.callout(state.tamper); if line then if news then news:add("INTEGRITY ALERT: "..line,"integrity") end; say("Ultron: "..line); saveState(); return true end
    return false
  end
  local function latest() return news and news:latest() or (engine and engine:latestNews()) or "No update." end
  local function integrityText() return state.tamper and state.tamper.detected and ("TAMPER EVENTS: "..tostring(state.tamper.count)..". Ultron remembers unauthorised changes.") or "CORE INTEGRITY: VERIFIED" end

  local function openChat() chatPending=true end
  local function actuallyOpenChat()
    if not(chatPending and game and engine and engine.rival) or chatOpening then return end
    chatPending=false
    if tamperCallout() then return end
    chatOpening=true; local okS,Screens=pcall(require,"src.ui.Screens")
    if not(okS and Screens and Screens.push) then chatOpening=false; say("Ultron: Text input is unavailable on this host build."); return end
    local screen=engine.generation==2 and "Gen2NamingScreen" or "NamingScreen"
    local ok=pcall(function() Screens.push(game,screen,{title="MESSAGE ULTRON",maxLen=72,default="",onDone=function(value)
      chatOpening=false; local response; state.chat,response=Micro.respond(state.chat,value,engine.rival,engine,state.motivation,state.brain,state.atlas); saveState(); say("Ultron: "..tostring(response))
    end}) end)
    if not ok then chatOpening=false; say("Ultron: This build refused the text keyboard.") end
  end
  local function exportTraining()
    if not(engine and engine.rival) then return end; local ok,msg; state.training,ok,msg=Exchange.exportFile(state.training,engine.rival,state.atlas,engine,game); saveState(); say(msg)
  end
  local function importTraining()
    if not(engine and engine.rival) then return end; local ok,msg; state.training,state.atlas,ok,msg=Exchange.importFile(state.training,engine.rival,state.atlas,engine,game)
    if ok then state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"shared training import",state.training); if news then news:add("Ultron imported collective training knowledge.","training") end end
    saveState(); say(msg)
  end
  local uiCtx={}
  uiCtx.badges=function() return engine and Util.badgeCount(engine.rival) or 0 end
  uiCtx.drive=function() return state.motivation and state.motivation.drive or 0 end
  uiCtx.latest=latest; uiCtx.chat=openChat; uiCtx.export=exportTraining; uiCtx.import=importTraining; uiCtx.integrity=integrityText
  setmetatable(uiCtx,{__index=function(_,k) if k=="engine" then return engine end end})

  local function registerInteraction()
    if not engine then return end
    if engine.generation==2 then
      Gen2Talk.register("ultron:talk",function(world,npc)
        if Gen2Talk.npcKey(npc)~="ULTRON" then return false end
        game=(world and world.game) or game or mod.game; if not tamperCallout() then UI.open(mod,game,uiCtx) end; return true
      end,20); Gen2Talk.install(); return
    end
    if not(mod.content and mod.content.map_scripts) then return end
    engine._talkMaps=engine._talkMaps or {}
    for id in pairs(engine.graph and engine.graph.nodes or {}) do if not engine._talkMaps[id] then
      local ok=pcall(function() mod.content.map_scripts:register(id,{priority=-7,talk={ULTRON_TALK=function(g,world,obj,done)
        game=g or game; if not tamperCallout() then UI.open(mod,game,uiCtx) end; if done then done() end
      end}}) end); if ok then engine._talkMaps[id]=true end
    end end
  end

  local function build()
    if not(game and game.data) then return false end
    if not news then news=News.new(mod,state.news) end
    -- Audit the serialized state BEFORE Rival.restore reasserts immutable fields.
    if type(state.rival)=="table" then state.tamper=Tamper.auditLoaded(state.tamper,state.rival,state.identity) end
    local core=Engine.loadCore(mod); local fused=Fusion.build(core.personalities)
    engine=Engine.new(mod,fused,state.rival,{news=function(line) if news then news:add(line,"progress") end end,error=function(e) log("warn",e) end})
    if not engine:isReady() then return false end
    state.identity=Identity.initialiseEconomy(state.identity,engine.rival,engine.restored)
    local okIntegrity,bad=Integrity.check(mod); if not okIntegrity then for _,row in ipairs(bad or {}) do state.tamper=Tamper.flag(state.tamper,"protected file "..tostring(row.path)) end end
    state.identity=Identity.ensure(state.identity,engine.rival,game,engine,mod)
    state.training=Exchange.ensureSource(state.training,engine.rival,engine,game); state.atlas=Atlas.index(state.atlas,engine.graph); engine.atlas=state.atlas
    local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes)
    engine.rival.competitiveLiteracy=100; Fusion.motivate(engine.rival.personality,state.motivation.drive,Util.badgeCount(engine.rival),#(engine.rival.party or {}))
    state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"load",state.training); registerInteraction(); engine:spawnIfPresent(); state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity)
    if news and #news.history==0 then news:add("Ultron is online and pursuing the Pokemon League.","boot") end
    saveState(); log("info","standalone engine active; maps="..tostring(state.atlas.graphCount)); return true
  end

  UI.installStartMenu(mod,uiCtx)
  mod.hooks:wrap("trainer.party",function(next,oppClass,partyIndex,party)
    local vanilla=next(oppClass,partyIndex,party); if engine and engine:trainerClassMatches(oppClass) and engine.rival then engine.pending=engine.rival; return engine.rival:battleParty() end; return vanilla
  end)
  mod.hooks:wrap("input.step",function(next,g,dt)
    local result=next(g,dt); game=game or g or mod.game; if news then news:update(dt) end
    if not engine then if game and game.data then build() end; return result end
    pulse=pulse+(tonumber(dt) or 0); engine:update(dt)
    if pulse>=0.50 then local step=pulse; pulse=0
      state.tamper=Tamper.auditLive(state.tamper,engine.rival)
      state.identity=Identity.ensure(state.identity,engine.rival,game,engine,mod)
      if state.identity.starterAssigned then
        local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes); announceChanges(changes); state.motivation=Motivation.tick(state.motivation,engine.rival)
        Fusion.motivate(engine.rival.personality,state.motivation.drive,Util.badgeCount(engine.rival),#(engine.rival.party or {})); state.atlas=Atlas.observe(state.atlas,engine.rival,engine,step); engine.atlas=state.atlas
        state.challenge=Challenge.tick(state.challenge,engine.rival,engine,step,state.motivation,state.chat,engine.modules)
        if Brain.shouldPrepare(state.brain,engine.rival,changes) then state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"progress",state.training) end
      end
      state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity)
    end
    actuallyOpenChat(); return result
  end)
  mod.hooks:wrap("render.hud",function(next,g,viewport) local result=next(g,viewport); return news and news:draw(g,result) or result end)

  mod.events:on("game.ready",function(ev) game=type(ev)=="table" and (ev.game or ev) or mod.game or game; loadState(); build() end)
  mod.events:on("save.loaded",function() game=game or mod.game; loadState(); build() end)
  mod.events:on("save.created",function() state=normalise(nil); news=News.new(mod,nil); engine=nil; if game or mod.game then game=game or mod.game; build() end end)
  mod.events:on("save.writing",saveState)
  mod.events:on("battle.ended",function(ev)
    if not engine then return end; local outcome=engine:settleBattle(ev); if not outcome then return end
    local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes); announceChanges(changes)
    state.challenge=Challenge.new(state.challenge); state.challenge.remaining=math.max(state.challenge.remaining,90); state.challenge.pursuing=false; engine.rival._ultronPursuit=nil
    state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,outcome.playerWon and "loss to player" or "victory over player",state.training); saveState()
  end)
  mod.events:on("world.interacted",function(ev)
    if not(engine and ev and ev.target) then return end; local n=ev.target; local name=n.name or (n.def and n.def.name) or n.id
    if tostring(name)=="ULTRON" then if not tamperCallout() then UI.open(mod,game or mod.game,uiCtx) end end
  end)

  mod.exports.status=function() return {version="1.0.0",standalone=true,worldOptional=true,integrity=not(state.tamper and state.tamper.detected),latest=latest(),rival=engine and engine.rival or nil} end
  mod.exports.rival=function() return engine and engine.rival or nil end
  mod.exports.latestNews=latest
end
