local Util = require("mods.ultron.src.Util")
local Challenge = {}

function Challenge.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    remaining = math.max(0, tonumber(saved.remaining) or 120),
    pursuing = saved.pursuing == true,
    challenges = math.max(0, tonumber(saved.challenges) or 0),
    sameMapSeconds = math.max(0, tonumber(saved.sameMapSeconds) or 0),
  }
end

local function busy(manager)
  if not manager then return true end
  if manager.gauntletActive and manager:gauntletActive() then return true end
  if manager.rivalBattleSequenceActive or manager.pendingRivalBattleLaunch
      or manager.pendingTournamentMatch or manager.worldChallenge then return true end
  if manager.overworldIdle then
    local ok, idle = pcall(function() return manager:overworldIdle() end)
    if ok and not idle then return true end
  end
  return false
end

local function healthyPlayer(manager)
  if manager and manager.playerHealthyCount then
    local ok, n = pcall(function() return manager:playerHealthyCount() end)
    return ok and (tonumber(n) or 0) > 0
  end
  return true
end

local function healthyUltron(rival)
  if not rival then return false end
  for _, mon in ipairs(rival.party or {}) do
    if (tonumber(mon.hp) or (rival.maxHpOf and rival:maxHpOf(mon)) or 1) > 0 then return true end
  end
  return false
end

local function nextDelay(motivation, chat)
  local drive = tonumber(motivation and motivation.drive) or 50
  local rivalry = tonumber(chat and chat.rivalry) or 25
  -- 90-240 seconds of actual co-location. More driven/competitive Ultrons
  -- challenge more often without becoming a battle popup machine.
  return Util.clamp(240 - drive * 0.7 - rivalry * 0.7, 90, 240)
end

function Challenge.tick(state, rival, manager, dt, motivation, chat, modules)
  state = Challenge.new(state)
  if not (rival and manager and rival.map and #(rival.party or {}) > 0) then
    state.pursuing = false
    return state
  end
  local world
  pcall(function() world = manager:worldView() end)
  local same = world and world.playerMap and rival.map == world.playerMap
  if not same or busy(manager) or not healthyPlayer(manager) or not healthyUltron(rival) then
    state.pursuing = false
    if not same then state.sameMapSeconds = 0 end
    rival._ultronPursuit = nil
    return state
  end

  dt = math.max(0, tonumber(dt) or 0)
  state.sameMapSeconds = state.sameMapSeconds + dt
  state.remaining = math.max(0, state.remaining - dt)
  if state.remaining > 0 then
    state.pursuing = false
    rival._ultronPursuit = nil
    return state
  end

  state.pursuing = true
  rival._ultronPursuit = true
  rival.objective = "CHALLENGE_PLAYER"
  local px, py = world.playerX, world.playerY
  if px and py and rival.x and rival.y then
    local dist = math.abs(rival.x - px) + math.abs(rival.y - py)
    if dist <= 2 then
      local ok, accepted = pcall(function() return manager:startRivalChallenge(rival, "SINGLE") end)
      if ok and accepted then
        state.challenges = state.challenges + 1
        state.remaining = nextDelay(motivation, chat)
        state.pursuing = false
        rival._ultronPursuit = nil
        rival.encounterCooldown = math.max(tonumber(rival.encounterCooldown) or 0, 18)
      end
    elseif not rival.walking and modules and modules.Pathfinder and manager.moveRivalNpc then
      -- Give Ultron a dedicated pursuit step instead of waiting for World's
      -- crowd round-robin. This matters with 100 rivals: periodic challenges
      -- should not become one movement pulse every several minutes.
      local cache=manager.walkMapCache
      local overview=cache and cache.mapId==world.playerMap and cache.overview or nil
      local grid=cache and cache.mapId==world.playerMap and cache.grid or nil
      if grid and overview then
        local candidates={{px,py+1},{px-1,py},{px+1,py},{px,py-1}}
        local target,bestD
        for _,c in ipairs(candidates) do
          local ok,valid=pcall(function() return manager:validRivalCell(rival,overview,c[1],c[2],false) end)
          if ok and valid then
            local d=math.abs(rival.x-c[1])+math.abs(rival.y-c[2])
            if not bestD or d<bestD then target,bestD=c,d end
          end
        end
        if target then
          local blocked={[px..","..py]=true}
          for _,other in ipairs(manager.rivals or {}) do
            if other~=rival and other.map==rival.map and other.x and other.y then blocked[other.x..","..other.y]=true end
          end
          local path
          pcall(function() path=modules.Pathfinder.find(grid,rival.x,rival.y,target[1],target[2],{budget=180,blocked=blocked}) end)
          local one=type(path)=="table" and path[1] or nil
          if one then pcall(function() manager:moveRivalNpc(rival,one.x,one.y,one.dir) end) end
        end
      end
    end
  end
  return state
end

return Challenge
