local U = require("mods.ultron.src.Util")
local PhysicalWorld = require("mods.ultron.src.PhysicalWorld")
local Engine = {}
Engine.__index = Engine

local function compileModule(mod, cache, loading, name)
  if cache[name] ~= nil then return cache[name] end
  if loading[name] then error("Ultron core circular require: " .. tostring(name), 0) end
  loading[name] = true
  local path = "engine/" .. name .. ".lua"
  local source = mod:read(path)
  if not source then error("Ultron core missing " .. path, 0) end
  local chunk, err
  if type(loadstring) == "function" then
    local ok, c, e = pcall(loadstring, source, "@ultron/" .. path)
    if ok then chunk, err = c, e else err = c end
  end
  if not chunk and type(load) == "function" then
    local ok, c, e = pcall(load, source, "@ultron/" .. path)
    if ok then chunk, err = c, e or err else err = c end
  end
  if not chunk then error("Ultron core compile failed: " .. tostring(err), 0) end
  local function req(child) return compileModule(mod, cache, loading, child) end
  local value = chunk(req, mod)
  loading[name] = nil
  cache[name] = value == nil and true or value
  return cache[name]
end

local function loadCore(mod)
  local cache, loading = {}, {}
  local function req(name) return compileModule(mod, cache, loading, name) end
  return {
    req=req,
    Util=req("src/Util"), MapGraph=req("src/MapGraph"), Pathfinder=req("src/Pathfinder"),
    BattleSim=req("src/BattleSim"), Rival=req("src/Rival"), AI=req("src/AI"),
    Simulation=req("src/Simulation"), EncounterData=req("src/EncounterData"),
    Sprites=req("src/Sprites"), Happiness=req("src/Happiness"),
    Competitive=req("src/Competitive"), League=req("src/League"),
    Version=req("src/Version"), TrainerClasses=req("src/TrainerClasses"),
    personalities=req("data/personalities"), rawGyms=req("data/gyms"),
  }
end

Engine.loadCore=loadCore

local function mapsTable(data, versionKey)
  if versionKey == "gen2" then return data and (data.gen2Maps or data.maps) or {} end
  return data and (data.maps or data.gen2Maps) or {}
end

local function hasMap(graph, id)
  return id and graph and graph.has and graph:has(id) or false
end

local function buildGyms(raw, versionKey, graph)
  local src = versionKey == "gen2" and raw.gen2 or raw
  local out = {order={},byBadge={},centers={},training={},trainingPrefixes=U.copy(src.trainingPrefixes or {})}
  for _, badge in ipairs(src.order or {}) do
    local row = src.byBadge and src.byBadge[badge]
    if row and (hasMap(graph,row.map) or hasMap(graph,row.city)) then
      out.order[#out.order+1] = badge
      out.byBadge[badge] = U.copy(row)
    end
  end
  if src.league and (hasMap(graph,src.league.map) or hasMap(graph,src.league.city)) then
    out.league = U.copy(src.league)
  end
  for _, id in ipairs(src.centers or {}) do if hasMap(graph,id) then out.centers[#out.centers+1]=id end end
  local seen = {}
  for _, prefix in ipairs(src.trainingPrefixes or {}) do
    local matches = graph.matching and graph:matching({prefix}) or {}
    for _, id in ipairs(matches or {}) do if not seen[id] then seen[id]=true; out.training[#out.training+1]=id end end
  end
  if #out.training==0 then
    for id in pairs(graph.nodes or {}) do
      if tostring(id):find("ROUTE",1,true) then out.training[#out.training+1]=id end
    end
    table.sort(out.training)
  end
  return out
end

local function serviceMaps(graph, token)
  local out={}
  for id in pairs(graph and graph.nodes or {}) do
    if tostring(id):find(token,1,true) then out[#out+1]=id end
  end
  table.sort(out); return out
end

local function hashText(text)
  local h = 2166136261
  for i=1,#tostring(text or "") do
    h = (h + text:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

local function makeCompat(mod)
  local C = {}
  local positive = {}
  local function findAny(ids)
    if not mod or not mod.find then return nil end
    for _,id in ipairs(ids) do
      if positive[id] then return positive[id] end
      local ok,h = pcall(function() return mod:find(id) end)
      if ok and h then positive[id]=h; return h end
    end
  end
  function C:krAllows() return true end
  function C:silph() return false end
  function C:ghosts() return nil end
  function C:girlMode() return false end
  function C:weather()
    return findAny({"weather_fx","weather-fx","WeatherFx"}) ~= nil
  end
  local function weatherExports()
    local h=findAny({"weather_fx","weather-fx","WeatherFx"}); return h and h.exports or nil
  end
  function C:weatherId()
    local e=weatherExports(); if not(e and type(e.weather)=="function") then return nil end
    local ok,v=pcall(e.weather); return ok and v or nil
  end
  function C:battleWeather()
    local e=weatherExports(); if not(e and type(e.battleWeather)=="function") then return nil end
    local ok,v=pcall(e.battleWeather); return ok and v or nil
  end
  return C
end

local function choosePlayerHome(graph, versionKey)
  local candidates
  if versionKey=="gen2" then
    candidates={"PLAYERS_HOUSE_2F","J2_PLAYERS_HOUSE_2F","KRIS_HOUSE_2F","PLAYERS_HOUSE_1F","J2_PLAYERS_HOUSE_1F","KRIS_HOUSE_1F","NEW_BARK_TOWN","J2_NEW_BARK_TOWN"}
  else
    candidates={"REDS_HOUSE_2F","REDS_HOUSE_2","REDS_HOUSE_1F","REDS_HOUSE_1","PALLET_TOWN"}
  end
  for _,id in ipairs(candidates) do if hasMap(graph,id) then return id,candidates end end
  return nil,candidates
end

local function coreDef(versionKey)
  return {
    id="ultron", slot=997, trainerClass="OPP_ULTRON", name="Ultron", fixedName=true,
    gender="male", personality="ULTRON", seed=0x554C5452,
    fallbackSprite="SPRITE_COOLTRAINER_M", basePic="OPP_COOLTRAINER_M",
    aiClass="OPP_COOLTRAINER_M", baseMoney=80,
    homeMaps={
      default={"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"},
      yellow={"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"},
      gen2={"ROUTE_29","NEW_BARK_TOWN","CHERRYGROVE_CITY"},
    },
  }
end

local function chooseShellSpecies(data, versionKey)
  local reg = (versionKey=="gen2" and data and data.gen2Pokemon) or (data and data.pokemon) or {}
  local list = versionKey=="gen2" and {"TOTODILE","CHIKORITA","CYNDAQUIL","PIKACHU"}
    or {"CLEFAIRY","SQUIRTLE","CHARMANDER","BULBASAUR","PIKACHU"}
  for _,id in ipairs(list) do if reg[id] then return id end end
  return next(reg)
end

local function safeListCopy(party)
  local out={}
  for _,slot in ipairs(type(party)=="table" and party or {}) do
    if type(slot)=="table" then out[#out+1]=U.copy(slot) end
  end
  return out
end

function Engine.new(mod, fusedPersonality, savedRival, callbacks)
  local self=setmetatable({},Engine)
  self.mod=mod; self.game=mod and mod.game or nil; self.modules=loadCore(mod); self.callbacks=callbacks or {}
  self.data=self.game and self.game.data or nil
  if type(self.data)~="table" then return self end
  self.versionKey=self.modules.Version.starterKey(self.data)
  self.generation=self.versionKey=="gen2" and 2 or 1
  self.graph=self.modules.MapGraph.build(mapsTable(self.data,self.versionKey))
  self.gyms=buildGyms(self.modules.rawGyms,self.versionKey,self.graph)
  self.marts=serviceMaps(self.graph,"MART")
  self.compat=makeCompat(mod)
  self.news={}; self.tick=0; self.accumulator=0; self.walkAccumulator=0; self.spawned={}
  self.pending=nil; self.pendingBattle=false; self.pendingBattleStartParty=nil; self.walkMapCache=nil
  self.sprites=self.modules.Sprites.new(mod)
  self.modules.personalities.ULTRON=fusedPersonality
  local seed=self:worldSeed()
  local playerHome,playerHomeFallbacks=choosePlayerHome(self.graph,self.versionKey)
  self.rivalContext={
    data=self.data, personalities=self.modules.personalities, generation=self.generation,
    graph=self.graph, gyms=self.gyms, trainingMaps=self.gyms.training, healingMaps=self.gyms.centers,
    playerHomeMap=playerHome, playerHomeFallbacks=playerHomeFallbacks,
    versionKey=self.versionKey, compat=self.compat, save=mod.save, mod=mod,
    starterSeed=seed, roster={}, assignedNames={ultron="Ultron"}, manager=self,
    relationships=false, badgePacingEnabled=false,
    speciesAllowed=function(species)
      local reg=(self.data.gen2Pokemon or self.data.pokemon or {})
      if reg[species] then return true end
      return self.data.pokemon and self.data.pokemon[species] ~= nil or false
    end,
    encounterCandidates=function(mapId) return self:encounterCandidatesForMap(mapId) end,
    simulateUnvisitedRegions=function() return true end,
    startingRegion=function() return self.versionKey=="gen2" and "johto" or "kanto" end,
    newGamePlusActive=function() return false end, newGamePlusCycle=function() return 1 end,
  }
  local def=coreDef(self.versionKey)
  self.rival=self.modules.Rival.new(def,self.rivalContext)
  self.rival.personality=fusedPersonality; self.rival.personalityId="ULTRON"; self.rival.competitiveLiteracy=100
  self.rival.def=def; self.rival.name="Ultron"; self.rival.id="ultron"
  local restored=false
  if type(savedRival)=="table" and self.rival.restore then
    local ok,res=pcall(function() return self.rival:restore(savedRival) end)
    restored=ok and res~=false
    self.rival.ctx=self.rivalContext; self.rival.def=def; self.rival.name="Ultron"; self.rival.id="ultron"
    self.rival.personality=fusedPersonality; self.rival.personalityId="ULTRON"; self.rival.competitiveLiteracy=100
  end
  self.rivals={self.rival}; self.byId={ultron=self.rival}; self.restored=restored
  self:registerTrainerShell()
  PhysicalWorld.attach(self,nil)
  return self
end

function Engine:isReady() return self.rival~=nil and self.graph~=nil end

function Engine:worldSeed()
  local save=self.game and self.game.save or {}
  local player=save.player or {}
  local raw=table.concat({tostring(save.trainerId or save.trainerID or save.tid or player.trainerId or 0),
    tostring(save.playerName or player.name or "PLAYER"), tostring(self.versionKey or "gen1")},":")
  return 1 + (hashText(raw) % 2147483646)
end

function Engine:gauntletDone() return true end
function Engine:gauntletActive() return false end
function Engine:relationshipsEnabled() return false end
function Engine:fullNameOf(r) return (r and r.name) or "Ultron" end

function Engine:playerBadgeCount()
  local save=self.game and self.game.save or {}
  local n=0
  local badges=save.badges
  if type(badges)=="table" then for _,v in pairs(badges) do if v==true or tonumber(v)==1 then n=n+1 end end end
  if n>0 then return n end
  local flags=save.flags
  if type(flags)=="table" then
    local order=self.gyms and self.gyms.order or {}
    for _,id in ipairs(order) do if flags[id] or flags["BADGE_"..id] then n=n+1 end end
  end
  return n
end

function Engine:playerHealthyCount()
  local n=0
  for _,m in ipairs(self.game and self.game.save and self.game.save.party or {}) do
    if type(m)=="table" and (tonumber(m.hp) or 1)>0 then n=n+1 end
  end
  return n
end

function Engine:playerMapId()
  local where
  pcall(function() if self.mod.world and self.mod.world.current then where=self.mod.world:current() end end)
  if where and where.mapId then return where.mapId end
  local ow=self.game and (self.game.world or self.game.overworld)
  local map=ow and ow.map
  return (map and (map.id or map.mapId)) or (ow and ow.mapId) or nil
end

function Engine:worldView()
  local where
  pcall(function() if self.mod.world and self.mod.world.current then where=self.mod.world:current() end end)
  if not(where and where.mapId) then
    local ow=self.game and (self.game.world or self.game.overworld); local map=ow and ow.map; local p=ow and ow.player
    local id=(map and (map.id or map.mapId)) or (ow and ow.mapId)
    if id then where={mapId=id,x=(p and (p.cellX or p.x)) or ow.playerX,y=(p and (p.cellY or p.y)) or ow.playerY} end
  end
  return {playerMap=where and where.mapId or nil,playerX=where and where.x,playerY=where and where.y,
    playerParty=self.game and self.game.save and self.game.save.party or {},playerBadges=self:playerBadgeCount(),
    compat=self.compat,rivals=self.rivals,companionId=nil,relationships=false,playerChampion=false,tick=self.tick,
    log=function(r,e) self:addNews(r,e) end}
end

function Engine:encounterCandidatesForMap(mapId)
  local rows={}; local total,n=0,0
  self.modules.EncounterData.each(self.data,mapId,function(species,level,weight)
    if type(species)=="string" then
      level=math.max(2,math.floor(tonumber(level) or 5)); weight=math.max(1,tonumber(weight) or 1)
      rows[#rows+1]={species=species,level=level,weight=weight}; total=total+level; n=n+1
    end
  end)
  if #rows==0 then return rows end
  table.sort(rows,function(a,b) if a.species~=b.species then return a.species<b.species end return a.level<b.level end)
  return rows
end

local function newsLine(rival,event)
  local name="Ultron"; event=event or {}; local kind=event.kind
  if event.text then return tostring(event.text) end
  if event.gym then return event.won and (name.." beat "..tostring(event.gym.leader or "a Gym Leader").."!")
    or (name.." lost to "..tostring(event.gym.leader or "a Gym Leader")..".") end
  if kind=="caught" or kind=="catch" then return name.." caught "..tostring(event.species or "a Pokemon").."." end
  if kind=="level" then return name.." trained "..tostring(event.species or "a Pokemon").." to Lv"..tostring(event.level or "?").."." end
  if kind=="evolve" then return name.." evolved "..tostring(event.from or "a Pokemon").." into "..tostring(event.into or "something").."." end
  if kind=="league" then return event.won and (name.." conquered the Pokemon League!") or (name.." fell short at the Pokemon League.") end
  if kind=="champion" then return name.." became Champion." end
  if kind=="trainer" then return event.won and (name.." defeated a trainer.") or (name.." lost a trainer battle.") end
  if kind=="career" or kind=="chapter" or kind=="milestone" then return name.." learned from another stage of the journey." end
  if kind=="hm" or kind=="hm_hunt" then return name.." is working on "..tostring(event.move or "field progress").."." end
  return name.." update: "..tostring(kind or "progress").."."
end

function Engine:addNews(rival,event)
  local line=newsLine(rival,event)
  local entry={text=line,tick=self.tick,kind=event and event.kind or "news"}
  self.news[#self.news+1]=entry; while #self.news>48 do table.remove(self.news,1) end
  if self.callbacks and self.callbacks.news then pcall(self.callbacks.news,line,entry) end
end

function Engine:latestNews() return self.news[#self.news] and self.news[#self.news].text or "Ultron is calculating his next move." end

function Engine:registerTrainerShell()
  local mod,data=self.mod,self.data
  if not(mod and mod.content and mod.content.trainers and data) then return nil end
  local species=chooseShellSpecies(data,self.versionKey); if not species then return nil end
  local id="OPP_ULTRON"
  if self.generation==2 and data.gen2Trainers and type(data.gen2Trainers.classes)=="table" then
    local classes=data.gen2Trainers.classes
    if classes[id] then self.gen2Class=tonumber(classes[id].index); return self.gen2Class end
    local used={}; for _,c in pairs(classes) do if type(c)=="table" and tonumber(c.index) then used[math.floor(c.index)]=true end end
    local idx; for i=255,1,-1 do if not used[i] then idx=i break end end; if not idx then return nil end
    local record={id=id,name="Ultron",index=idx,baseMoney=80,trainers={{index=1,id="ultron1",name="Ultron",party={{species=species,level=5}}}}}
    pcall(function() mod.content.trainers:register(id,record) end); self.gen2Class=idx; return idx
  end
  local trainers=data.trainers or {}; if trainers[id] then return id end
  local record={id=id,name="Ultron",parties={{{species=species,level=5}}},baseMoney=80}
  if trainers.OPP_COOLTRAINER_M then record.basePic="OPP_COOLTRAINER_M" end
  if data.ai_classes and data.ai_classes.OPP_COOLTRAINER_M then record.aiClass="OPP_COOLTRAINER_M" end
  pcall(function() mod.content.trainers:register(id,record) end); return id
end

function Engine:trainerClassMatches(oppClass)
  if self.generation==2 and type(oppClass)=="number" and self.gen2Class then return tonumber(oppClass)==tonumber(self.gen2Class) end
  return tostring(oppClass)=="OPP_ULTRON"
end

function Engine:gen2BattleParty()
  local okMon,Mon=pcall(require,"src.battle.gen2.Mon")
  if not(okMon and Mon and type(Mon.new)=="function") then return {} end
  local out={}
  for _,slot in ipairs(self.rival.party or {}) do
    local species=slot.species or slot.speciesId
    if species then
      local dvs=slot.dvs and U.copy(slot.dvs) or {attack=10,defense=10,speed=10,special=10}
      local opts={dvs=dvs,item=slot.heldItem or slot.item,shiny=slot.shiny==true,happiness=tonumber(slot.happiness) or 70}
      local ok,m=pcall(Mon.new,self.data,species,math.max(1,math.min(100,math.floor(tonumber(slot.level) or 5))),opts)
      if ok and type(m)=="table" then out[#out+1]=m end
    end
  end
  return out
end

local function battleStateFactory()
  for _,name in ipairs({"src.battle.BattleState","battle.BattleState","BattleState"}) do
    local ok,v=pcall(require,name); if ok and v then return v end
  end
end

function Engine:pushBattle()
  local r=self.rival; if not r or self.pendingBattle then return false end
  r:prepareForBattle(); self.pending=r; self.pendingBattle=true; self.pendingBattleStartParty=safeListCopy(self.game and self.game.save and self.game.save.party)
  if self.generation==2 then
    local world=self.mod.world; local ow
    pcall(function() ow=world and world.overworld and world:overworld() end)
    local party=self:gen2BattleParty()
    if not(ow and type(ow.startBattle)=="function" and #party>0) then self.pendingBattle=false; self.pending=nil; return false end
    local ok=pcall(function() ow:startBattle({trainer={name="Ultron",class="OPP_ULTRON",classId="OPP_ULTRON",index=1,memberId=1,party=party,worldPreferVoxelBattleUI=true}},function() end) end)
    if not ok then self.pendingBattle=false; self.pending=nil end
    return ok
  end
  local controller=(self.game and self.game.overworld) or nil; local BS=battleStateFactory()
  if not(controller and type(controller.pushBattle)=="function" and BS and type(BS.newTrainer)=="function") then self.pendingBattle=false; self.pending=nil; return false end
  local ok=pcall(function()
    local battle=BS.newTrainer(self.game,"OPP_ULTRON",1); if not battle or battle.dead then error("trainer battle refused") end
    if not battle.onFinish then battle.onFinish=function(value) if controller.afterBattle then controller:afterBattle(value,battle) end end end
    controller:pushBattle(battle)
  end)
  if not ok then self.pendingBattle=false; self.pending=nil end
  return ok
end

function Engine:startRivalChallenge(rival)
  if rival~=self.rival or self.pendingBattle or self:playerHealthyCount()<=0 then return false end
  return self:pushBattle()
end

function Engine:settleBattle(ev)
  local r=self.pending; if not r then return nil end
  local playerWon=ev and ev.result=="win"
  local tick=self.tick
  if playerWon then
    r.playerLosses=(r.playerLosses or 0)+1
    if r.recordPlayerBattle then pcall(function() r:recordPlayerBattle(false,tick) end) end
    if r.noteDefeat then pcall(function() r:noteDefeat("player",tick) end) end
    if r.forfeit then pcall(function() r:forfeit(math.max(20,math.floor((tonumber(r.money) or 0)*0.05))) end) end
    local target,kind
    if r.blackoutToNearestPokemonCenter then pcall(function() local _,c,k=r:blackoutToNearestPokemonCenter("lost to player",true); target,kind=c,k end) end
    local where=(kind=="Pokemon Center" and U.spaced(target or "the last Pokemon Center")) or "the player's home"
    self:addNews(r,{kind="blackout",text="Ultron blacked out after losing to the player and returned to "..where.."."})
  else
    r.playerWins=(r.playerWins or 0)+1
    if r.recordPlayerBattle then pcall(function() r:recordPlayerBattle(true,tick) end) end
    if r.noteVictory then pcall(function() r:noteVictory("player",tick) end) end
    if r.earn then pcall(function() r:earn(250) end) end
    self:addNews(r,{kind="news",text="Ultron defeated the player."})
  end
  if r.rememberOpponent and type(self.pendingBattleStartParty)=="table" then
    pcall(function() r:rememberOpponent("player",self.pendingBattleStartParty,not playerWon,tick,false) end)
  end
  r.encounterCooldown=math.max(tonumber(r.encounterCooldown) or 0,18)
  if not playerWon then pcall(function() r:setState("IDLE","player battle complete") end) end
  self.pending=nil; self.pendingBattle=false; self.pendingBattleStartParty=nil
  return {playerWon=playerWon,rivalWon=not playerWon}
end

function Engine:activeMap()
  local ow; pcall(function() if self.mod.world and self.mod.world.overworld then ow=self.mod.world:overworld() end end)
  return ow or (self.game and self.game.overworld)
end

function Engine:liveEntity()
  local ow=self:activeMap(); local wanted="ULTRON"; local handle=self.spawned.ultron
  for _,list in ipairs({(ow and ow.npcs) or {},(ow and ow.entities) or {}}) do
    for _,npc in ipairs(list) do
      local id=npc.id or npc.index; local name=npc.name or (npc.def and npc.def.name)
      if npc==handle or tostring(id)==tostring(handle) or name==wanted or name=="AIR_ultron" then return npc end
    end
  end
end

function Engine:despawn()
  local h=self.spawned.ultron
  if h then pcall(function() if self.mod.world and self.mod.world.removeNpc then self.mod.world:removeNpc(h) end end) end
  self.spawned.ultron=nil; self.rival.spawnedAt=nil; self.rival.walking=false
end

function Engine:overview()
  local o; pcall(function() if self.mod.world and self.mod.world.mapOverview then o=self.mod.world:mapOverview() end end); return o
end

function Engine:isTransitCell(mapId,overview,x,y)
  if not(x and y) then return false end
  for _,m in ipairs((overview and overview.markers) or {}) do if m.kind=="warp" and m.x==x and m.y==y then return true end end
  local def=mapsTable(self.data,self.versionKey)[mapId]
  for _,w in ipairs((def and def.warps) or {}) do if w.x==x and w.y==y then return true end end
  return false
end

function Engine:validRivalCell(rival,overview,x,y,allowTransit)
  local grid=self.modules.Pathfinder.grid(overview); if not grid or not self.modules.Pathfinder.walkable(grid,x,y) then return false end
  if not allowTransit and self:isTransitCell(rival.map,overview,x,y) then return false end
  local ow=self:activeMap(); local selfEntity=self:liveEntity()
  for _,npc in ipairs((ow and ow.npcs) or {}) do
    if npc~=selfEntity and npc.cellX==x and npc.cellY==y then return false end
  end
  local w=self:worldView(); if w.playerMap==rival.map and w.playerX==x and w.playerY==y then return false end
  return true
end

function Engine:safePlacement(overview)
  local grid=self.modules.Pathfinder.grid(overview); if not grid then return nil end
  local w=self:worldView(); local sx=self.rival.rng:int(0,math.max(0,(grid.w or 1)-1)); local sy=self.rival.rng:int(0,math.max(0,(grid.h or 1)-1))
  for dy=0,(grid.h or 1)-1 do for dx=0,(grid.w or 1)-1 do
    local x=(sx+dx)%(grid.w or 1); local y=(sy+dy)%(grid.h or 1)
    local d=w.playerX and w.playerY and math.abs(x-w.playerX)+math.abs(y-w.playerY) or 4
    if d>=2 and self:validRivalCell(self.rival,overview,x,y,false) then return x,y end
  end end
end

function Engine:spawnIfPresent()
  local r=self.rival; local w=self:worldView(); if not(r and w.playerMap and r.map==w.playerMap) then if self.spawned.ultron then self:despawn() end; return false end
  if self.spawned.ultron and self:liveEntity() then return true end
  self.spawned.ultron=nil
  local overview=self:overview(); local x,y=r.x,r.y
  if not(x and y and self:validRivalCell(r,overview,x,y,false)) then x,y=self:safePlacement(overview) end
  if not(x and y) then return false end
  local sprite=r.appearanceSprite or r.spriteOverride
  if not(sprite and self.sprites:exists(sprite,self.data)) then
    -- This fallback is only for legacy/corrupt saves before Identity has chosen.
    -- A normal save reaches here with Ultron's persisted first-choice sprite.
    sprite=self.sprites:walkerFor(r.def,self.data,{"SPRITE_COOLTRAINER_M","SPRITE_BLUE","SPRITE_SILVER","SPRITE_YOUNGSTER"})
  end
  if not sprite then return false end
  local obj={index=247,name="ULTRON",sprite=sprite,x=x,y=y,movement=self.generation==2 and 6 or "STAY",range="DOWN",solid=false,passable=true,through=true,text=self.generation==1 and "ULTRON_TALK" or nil}
  local ok,h=pcall(function() return self.mod.world and self.mod.world.spawnNpc and self.mod.world:spawnNpc(r.map,obj) end)
  if ok and h then self.spawned.ultron=h; r.x,r.y=x,y; r.spawnedAt={x,y}; return true end
  return false
end

function Engine:moveRivalNpc(rival,x,y,facing,onDone)
  if rival.walking then return false end
  local entity=self:liveEntity()
  local ex=entity and math.abs((entity.cellX or rival.x or x)-x) or 0; local ey=entity and math.abs((entity.cellY or rival.y or y)-y) or 0
  if entity and ex+ey==1 then
    rival.walking=true; rival.walkAge=0; rival.facing=facing or rival.facing
    entity.facing=facing or entity.facing; entity.targetX=x; entity.targetY=y; entity.moving=true; entity.progress=0
    rival.walkTarget={x=x,y=y,onDone=onDone}; return true
  end
  -- No setPosition/teleport fallback. If the live engine cannot animate one
  -- adjacent step, Ultron waits and replans rather than cheating across cells.
  return false
end

local function adjacentTargets(px,py) return {{px,py+1},{px-1,py},{px+1,py},{px,py-1}} end

function Engine:travelTarget(overview,world)
  local r=self.rival
  if r._ultronPursuit and world.playerX and world.playerY then
    local best,dist
    for _,c in ipairs(adjacentTargets(world.playerX,world.playerY)) do if self:validRivalCell(r,overview,c[1],c[2],false) then
      local d=math.abs((r.x or c[1])-c[1])+math.abs((r.y or c[2])-c[2]); if not dist or d<dist then best,dist=c,d end
    end end
    if best then return best[1],best[2],nil end
  end
  if r.destination and r.map~=r.destination then
    if not r.route then r.route=r:routeTo(r.destination) end
    local nextMap=r:nextHop(); if nextMap then
      local edge=self.graph:edgeBetween(r.map,nextMap)
      if edge and edge.x~=nil and edge.y~=nil then
        local best,dist
        for _,c in ipairs(adjacentTargets(edge.x,edge.y)) do if self:validRivalCell(r,overview,c[1],c[2],false) then
          local d=math.abs(r.x-c[1])+math.abs(r.y-c[2]); if not dist or d<dist then best,dist=c,d end
        end end
        if best then return best[1],best[2],nextMap end
      end
    end
  end
  local goal=r.localWalkGoal
  if goal and self:validRivalCell(r,overview,goal[1],goal[2],false) then return goal[1],goal[2],nil end
  local grid=self.modules.Pathfinder.grid(overview); if not grid then return nil end
  for _=1,48 do local x=r.rng:int(0,math.max(0,grid.w-1)); local y=r.rng:int(0,math.max(0,grid.h-1)); local d=math.abs(r.x-x)+math.abs(r.y-y)
    if d>=2 and d<=8 and self:validRivalCell(r,overview,x,y,false) then r.localWalkGoal={x,y}; return x,y,nil end end
end

function Engine:walk(dt)
  self.walkAccumulator=self.walkAccumulator+(tonumber(dt) or 0); if self.walkAccumulator<0.30 then return end; self.walkAccumulator=self.walkAccumulator-0.30
  local r=self.rival; local world=self:worldView(); if not(r and r.map==world.playerMap and self:spawnIfPresent()) then return end
  if r.walking then
    r.walkAge=(tonumber(r.walkAge) or 0)+0.30; local e=self:liveEntity()
    if e and not e.moving then
      r.x,r.y=e.cellX or r.x,e.cellY or r.y; local t=r.walkTarget; r.walking=false; r.walkTarget=nil; r.walkAge=0
      if t and t.onDone and r.x==t.x and r.y==t.y then pcall(t.onDone) end
    elseif r.walkAge>1.4 then r.walking=false; r.walkTarget=nil; r.walkAge=0 end
    return
  end
  local overview=self:overview(); local grid=self.modules.Pathfinder.grid(overview); if not grid or not(r.x and r.y) then return end
  local tx,ty,nextMap=self:travelTarget(overview,world); if not(tx and ty) then return end
  if r.x==tx and r.y==ty and nextMap then
    self:despawn(); r.arrivedFrom=r.map; r.map,r.x,r.y=nextMap,nil,nil; r.spawnedAt=nil; r.localWalkGoal=nil; r.hopClock=nil
    if r.useHMsForMap then pcall(function() r:useHMsForMap(nextMap) end) end; if r.visitMap then pcall(function() r:visitMap(nextMap) end) end
    if r.map==r.destination then pcall(function() self.modules.AI.onArrive(r,world) end) end; return
  end
  local blocked={}; if world.playerX and world.playerY then blocked[world.playerX..","..world.playerY]=true end
  local path=self.modules.Pathfinder.find(grid,r.x,r.y,tx,ty,{budget=180,blocked=blocked}); local one=type(path)=="table" and path[1] or nil
  if one then self:moveRivalNpc(r,one.x,one.y,one.dir) else
    r._ultronPathFails=(r._ultronPathFails or 0)+1; r.localWalkGoal=nil
    if r._ultronPathFails>=5 then r.route=nil; r.path=nil; r._ultronPathFails=0 end
  end
end

function Engine:nearestMart(from)
  return self.graph and self.graph.nearest and self.graph:nearest(from,self.marts or {}) or nil
end

function Engine:serviceTick(world)
  local r=self.rival; if not r or r._ultronDormant then return end
  -- Emergency blackout route always has priority and can never be interrupted by shopping.
  if r._ultronBlackout then return end
  local balls=(r.itemCount and (r:itemCount("POKE_BALL")+r:itemCount("GREAT_BALL")+r:itemCount("ULTRA_BALL"))) or tonumber(r.balls) or 0
  local atMart=tostring(r.map or ""):find("MART",1,true)~=nil
  if r.objective=="SHOP" and r.map==r.destination and atMart then
    local bought=r.restockBalls and r:restockBalls() or 0
    local tm=r.buyTms and r:buyTms() or nil
    if bought>0 or tm then
      local extra=tm and (" and bought TM "..tostring(tm)) or ""
      self:addNews(r,{kind="shop",text="Ultron visited the Pokemart, bought "..tostring(bought).." Poke Balls"..extra.."."})
    end
    local resume=r._ultronResume or {}; r.objective=resume.objective or "IDLE"; r.destination=resume.destination; r.state=resume.state or "IDLE"; r.route=nil; r.routeIndex=1; r._ultronResume=nil
    return
  end
  if balls<=1 and not atMart and r.objective~="HEAL" and r.state~="HEALING" then
    local mart=self:nearestMart(r.map)
    if mart and mart~=r.map then
      r._ultronResume={objective=r.objective,destination=r.destination,state=r.state}
      r.objective="SHOP"; r.destination=mart; r.route=nil; r.routeIndex=1; r:setState("TRAVELLING","walking to a Pokemart for supplies")
      self:addNews(r,{kind="shop",text="Ultron is walking to a Pokemart to restock."})
    end
  end
end

function Engine:physicalTravelTick(rival,ctx)
  return PhysicalWorld.step(self,rival,ctx)
end

function Engine:physicalTrainerTick(rival,foe,ctx)
  if not(rival and foe and foe.x~=nil and foe.y~=nil) then return true end
  if not PhysicalWorld.ensurePosition(self,rival) then return false end
  local distance=math.abs((rival.x or 0)-foe.x)+math.abs((rival.y or 0)-foe.y)
  if distance==1 then return true end
  local world=self:worldView()
  if world.playerMap==rival.map and self:spawnIfPresent() then
    if rival.walking then return false end
    local overview=self:overview(); local grid=self.modules.Pathfinder.grid(overview)
    if not grid then return false end
    local blocked={}; if world.playerX and world.playerY then blocked[world.playerX..","..world.playerY]=true end
    local candidates={{foe.x,foe.y-1},{foe.x,foe.y+1},{foe.x-1,foe.y},{foe.x+1,foe.y}}
    local bestPath
    for _,c in ipairs(candidates) do
      if self:validRivalCell(rival,overview,c[1],c[2],false) then
        local path=self.modules.Pathfinder.find(grid,rival.x,rival.y,c[1],c[2],{budget=240,blocked=blocked})
        if type(path)=="table" and #path>0 and (not bestPath or #path<#bestPath) then bestPath=path end
      end
    end
    local one=bestPath and bestPath[1]
    if one then self:moveRivalNpc(rival,one.x,one.y,one.dir) end
    return false
  end
  local arrived=PhysicalWorld.stepTo(self,rival,foe.x,foe.y,{adjacent=true})
  return arrived==true
end

function Engine:update(dt)
  if not self:isReady() then return end
  self:spawnIfPresent(); self:walk(dt)
  self.accumulator=self.accumulator+(tonumber(dt) or 0); if self.accumulator<1.5 then return end; self.accumulator=self.accumulator-1.5; self.tick=self.tick+1
  if self.rival._ultronDormant or self.rival.map=="__ULTRON_STAGING__" then return end
  local world=self:worldView(); self:serviceTick(world)
  local ctx={playerMap=world.playerMap,playerParty=world.playerParty,playerBadges=world.playerBadges,compat=self.compat,rivals=self.rivals,tick=self.tick,companionId=nil,log=world.log,ecology=nil,allowGymBattle=true,gymBattleUsed=false,near=world.playerMap~=nil and self.rival.map==world.playerMap}
  ctx.physicalTravelTick=function(r,c) return self:physicalTravelTick(r,c) end
  ctx.physicalTrainerTick=function(r,foe,c) return self:physicalTrainerTick(r,foe,c) end
  local ok,res=pcall(self.modules.Simulation.tickRival,self.rival,ctx)
  if self.rival._ultronBlackout and not self.rival:isFainted() then
    self.rival._ultronBlackout=nil
    self.rival.objective="IDLE"
    self.rival:setState("IDLE","recovered from blackout")
  end
  if not ok and self.callbacks and self.callbacks.error then pcall(self.callbacks.error,tostring(res)) end
end

function Engine:overworldIdle()
  if self.pendingBattle then return false end
  local top=self.game and self.game.stack and self.game.stack.top and self.game.stack:top()
  if self.generation==1 then return top==nil or top.isOverworld==true end
  local w=self.game and self.game.world
  return w~=nil and not w.transitioning and not w.mapSetup and not w.textbox and not w.choicebox
end

function Engine:repairRivalPosition(rival,reason)
  if not rival then return false end
  -- Historical API retained for Atlas callers, but repair is now a pure replan.
  -- It never moves Ultron to a different coordinate.
  rival.localWalkGoal=nil; rival.path=nil; rival.walkTarget=nil; rival.route=nil
  rival.stuckTicks=(rival.stuckTicks or 0)+1
  return true
end

function Engine:serializeRival() return self.rival and self.rival.serialize and self.rival:serialize() or nil end

return Engine
