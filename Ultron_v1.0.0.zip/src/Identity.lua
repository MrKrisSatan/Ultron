local Util = require("mods.ultron.src.Util")
local Identity = {}

local GEN1={"BULBASAUR","CHARMANDER","SQUIRTLE"}
local GEN2={"CHIKORITA","CYNDAQUIL","TOTODILE"}
local STARTER_KEYS={"world_player_starter_base_choice","world_wx_starter_post_gift_base","world_wx_starter_variant_base"}

local function speciesDef(data,species)
  if not(data and species) then return nil end
  return (data.gen2Pokemon and data.gen2Pokemon[species]) or (data.pokemon and data.pokemon[species])
end
local function normaliseSpecies(data,species)
  if type(species)=="table" then species=species.id or species.species or species.name end
  local s=tostring(species or ""):upper():gsub("[^A-Z0-9_]","_")
  if s=="" then return nil end
  local seen={}
  for _=1,4 do
    if seen[s] then break end; seen[s]=true
    local d=speciesDef(data,s); local base=d and (d.baseSpecies or d.base_species or d.base or d.originalSpecies)
    if type(base)=="table" then base=base.id or base.species or base.name end
    if type(base)~="string" or base=="" then break end
    s=tostring(base):upper():gsub("[^A-Z0-9_]","_")
  end
  for _,id in ipairs({"BULBASAUR","CHARMANDER","SQUIRTLE","CHIKORITA","CYNDAQUIL","TOTODILE","PIKACHU","CLEFAIRY"}) do
    if s==id or s:find(id,1,true) then return id end
  end
  return s
end
local function inList(id,list) for i,v in ipairs(list) do if id==v then return i end end end
local function optionalWorldSave(mod,key)
  if not(mod and mod.find) then return nil end
  local ok,h=pcall(function() return mod:find("the_world") end)
  if not(ok and h and h.save and type(h.save.get)=="function") then return nil end
  local ok2,v=pcall(function() return h.save:get(key) end); return ok2 and v or nil
end

function Identity.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {starterRuleVersion=tonumber(saved.starterRuleVersion) or 0,starterSpecies=saved.starterSpecies,
    starterAssigned=saved.starterAssigned==true,firstEconomyInitialised=saved.firstEconomyInitialised==true,
    staged=saved.staged~=false,partySnapshot=type(saved.partySnapshot)=="table" and Util.copy(saved.partySnapshot) or nil,
    appearanceSprite=type(saved.appearanceSprite)=="string" and saved.appearanceSprite or nil,
    appearanceChosen=saved.appearanceChosen==true}
end

function Identity.playerStarter(game,engine,mod)
  local data=game and game.data or engine and engine.data
  -- Optional World compatibility: if World replaced the lab balls, use its saved
  -- canonical choice without making World a dependency.
  for _,key in ipairs(STARTER_KEYS) do
    local id=normaliseSpecies(data,optionalWorldSave(mod,key))
    if inList(id,GEN1) or inList(id,GEN2) then return id end
  end
  local layout=optionalWorldSave(mod,"world_alternative_starter_ball_layout")
  local chosen=normaliseSpecies(data,optionalWorldSave(mod,"world_player_starter_base_choice"))
  if chosen and type(layout)=="table" then
    for canonical,mapped in pairs(layout) do
      if normaliseSpecies(data,mapped)==chosen then
        local c=normaliseSpecies(data,canonical); if inList(c,GEN1) or inList(c,GEN2) then return c end
      end
    end
  end
  for _,mon in ipairs(game and game.save and game.save.party or {}) do
    local id=normaliseSpecies(data,mon and (mon.species or mon.speciesId or mon.id))
    if inList(id,GEN1) or inList(id,GEN2) then return id end
  end
end

function Identity.playerHasStarter(game,engine,mod)
  if engine and engine.versionKey=="yellow" then
    local flags=game and game.save and game.save.flags
    if type(flags)=="table" and flags.EVENT_GOT_STARTER then return true end
    for _,mon in ipairs(game and game.save and game.save.party or {}) do
      if normaliseSpecies(game and game.data,mon and (mon.species or mon.speciesId))=="PIKACHU" then return true end
    end
    return false
  end
  return Identity.playerStarter(game,engine,mod)~=nil
end

function Identity.expectedStarter(game,engine,mod)
  if not engine then return nil end
  if engine.versionKey=="yellow" then return "CLEFAIRY" end
  local player=Identity.playerStarter(game,engine,mod); if not player then return nil end
  local trio=engine.versionKey=="gen2" and GEN2 or GEN1; local idx=inList(player,trio); if not idx then return nil end
  return trio[((idx+1)%3)+1]
end

local function safeStartMap(engine)
  local candidates=engine and engine.versionKey=="gen2" and {"ROUTE_29","NEW_BARK_TOWN","CHERRYGROVE_CITY"}
    or {"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"}
  for _,id in ipairs(candidates) do if engine.graph and engine.graph.has and engine.graph:has(id) then return id end end
  return engine and engine.graph and engine.graph.nodes and next(engine.graph.nodes) or nil
end

function Identity.stage(rival)
  if not rival then return end
  rival._ultronDormant=true; rival.map="__ULTRON_STAGING__"; rival.x,rival.y=nil,nil
  rival.destination,rival.route,rival.path=nil,nil,nil; rival.routeIndex=1; rival.localWalkGoal,rival.walkTarget=nil,nil
  if rival.setState then pcall(function() rival:setState("IDLE","waiting for player starter") end) end
end

local function replaceStarter(rival,expected,modules)
  if not(rival and expected) then return false end
  local slot,index
  for i,m in ipairs(rival.party or {}) do if type(m)=="table" and m.origin=="starter" then slot,index=m,i break end end
  if not slot and #(rival.party or {})>0 then slot,index=rival.party[1],1 end
  if not slot then
    local ok,m=pcall(function() return rival:addPokemon(expected,5) end)
    if not(ok and type(m)=="table") then return false end
    m.origin="starter"; if rival.markStarter then pcall(function() rival:markStarter(m) end) end; return true
  end
  if slot.species==expected then slot.origin="starter"; return false end
  local level=math.max(5,math.min(100,tonumber(slot.level) or 5)); slot.species=expected; slot.level=level
  slot.moves=rival:movesFor(expected,level); slot.hp=rival:maxHpOf(slot); slot.origin="starter"
  local R=modules and modules.Rival
  if R and R.expForLevel then local ok,e=pcall(R.expForLevel,rival:speciesDef(expected),level); if ok and e then slot.exp=e end end
  rival.party[index]=slot
  if rival.registerDex then pcall(function() rival:registerDex(expected) end) end
  if rival.refreshAce then pcall(function() rival:refreshAce() end) end
  return true
end


local function chooseAppearance(state,rival,engine)
  if state.appearanceChosen and state.appearanceSprite and state.appearanceSprite~="" then
    rival.appearanceSprite=state.appearanceSprite
    rival.spriteOverride=state.appearanceSprite
    return false
  end
  if not(engine and engine.sprites and rival) then return false end
  -- Ultron chooses from the live game's safe male walker pool using his own
  -- persistent world seed. No player menu is involved. The result is written
  -- into Ultron's save identity and is never rolled again for this save.
  local def=Util.copy(rival.def or {})
  def.overworldSprite=nil; def.sprite=nil; def.spriteId=nil; def.fallbackSprite=nil
  local sprite=engine.sprites:assignWalker(def,engine.data,(engine.worldSeed and engine:worldSeed() or 1)+0x554C5452)
  if not sprite then
    sprite=engine.sprites:walkerFor(def,engine.data,{"SPRITE_COOLTRAINER_M","SPRITE_BLUE","SPRITE_SILVER","SPRITE_YOUNGSTER"})
  end
  if not sprite then return false end
  state.appearanceSprite=tostring(sprite); state.appearanceChosen=true
  rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite
  return true
end

function Identity.initialiseEconomy(state,rival,restored)
  state=Identity.new(state); if not rival or restored or state.firstEconomyInitialised then return state end
  rival.money=3000; rival.inventory={}; rival.balls=0; rival.tms={}; rival.hms={}; rival.hmUses={}; rival.pcBoxes={{}}
  if rival.ensureInventory then pcall(function() rival:ensureInventory() end) end
  state.firstEconomyInitialised=true; return state
end

function Identity.ensure(state,rival,game,engine,mod)
  state=Identity.new(state); if not(rival and engine) then return state,false end
  rival.id="ultron"; rival.name="Ultron"; rival.personalityId="ULTRON"; rival.competitiveLiteracy=100
  if rival.def then rival.def.id="ultron"; rival.def.name="Ultron"; rival.def.fixedName=true end
  if not Identity.playerHasStarter(game,engine,mod) then if not state.starterAssigned then Identity.stage(rival); state.staged=true end; return state,false end
  local expected=Identity.expectedStarter(game,engine,mod); if not expected then return state,false end
  local changed=false
  if state.starterRuleVersion<2 or not state.starterAssigned or state.starterSpecies~=expected or #(rival.party or {})==0 then
    changed=replaceStarter(rival,expected,engine.modules) or changed; state.starterRuleVersion=2; state.starterSpecies=expected; state.starterAssigned=true
  end
  if state.staged or rival.map=="__ULTRON_STAGING__" or not rival.map then
    local start=safeStartMap(engine); if start then rival.map=start; rival.x,rival.y=nil,nil; rival.destination,rival.route,rival.path=nil,nil,nil; rival.routeIndex=1
      rival._ultronDormant=false; rival._ultronNeedsInitialPlacement=true; state.staged=false; changed=true; if rival.visitMap then pcall(function() rival:visitMap(start) end) end end
  else rival._ultronDormant=false end
  changed=chooseAppearance(state,rival,engine) or changed
  if state.appearanceSprite then rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite end
  if #(rival.party or {})>0 then state.partySnapshot=Util.copy(rival.party) end
  return state,changed
end

function Identity.snapshot(state,rival)
  state=Identity.new(state)
  if rival then
    if #(rival.party or {})>0 then state.partySnapshot=Util.copy(rival.party) end
    if state.appearanceChosen and state.appearanceSprite then rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite end
  end
  return state
end
return Identity
