local News={}; News.__index=News

local function findWorld(mod)
  if not(mod and mod.find) then return nil end
  local ok,h=pcall(function() return mod:find("the_world") end); return ok and h or nil
end
local function worldManager(mod)
  local h=findWorld(mod); local e=h and h.exports
  if type(e)=="table" then return e.manager or e.aiManager or e.rivals end
end

function News.new(mod,saved)
  saved=type(saved)=="table" and saved or {}
  return setmetatable({mod=mod,history=type(saved.history)=="table" and saved.history or {},
    ticker={text=nil,age=0,duration=8,offset=0},queue={},merged=false,lastMerged=nil},News)
end
function News:serialize() return {history=self.history} end
function News:latest() local r=self.history[#self.history]; return r and r.text or "Ultron is calculating his next move." end
function News:tryMerge(text)
  local m=worldManager(self.mod); if not m then self.merged=false; return false end
  if self.lastMerged==text then self.merged=true; return true end
  local ok=false
  if type(m.addNews)=="function" then ok=pcall(function() m:addNews({id="ultron",name="Ultron"},{kind="news",text="ULTRON  •  "..text}) end) end
  if not ok and type(m.pushTicker)=="function" then ok=pcall(function() m:pushTicker("ULTRON  •  "..text) end) end
  if ok then self.merged=true; self.lastMerged=text; return true end
  self.merged=false; return false
end
function News:add(text,kind)
  text=tostring(text or ""):gsub("[%c]+"," "):sub(1,220); if text=="" then return end
  self.history[#self.history+1]={text=text,kind=kind or "news"}; while #self.history>64 do table.remove(self.history,1) end
  if self:tryMerge(text) then return end
  local headline="ULTRON  •  "..text
  if self.ticker.text then if self.queue[#self.queue]~=headline then self.queue[#self.queue+1]=headline end; while #self.queue>8 do table.remove(self.queue,1) end
  else self.ticker={text=headline,age=0,duration=8,offset=0} end
end
function News:update(dt)
  if self.merged and not worldManager(self.mod) then self.merged=false end
  local t=self.ticker; if not(t and t.text) then return end
  t.age=(t.age or 0)+(tonumber(dt) or 0); t.offset=(t.offset or 0)+32*(tonumber(dt) or 0)
  if t.age>=(t.duration or 8) then local n=table.remove(self.queue,1); if n then self.ticker={text=n,age=0,duration=8,offset=0} else t.text=nil end end
end
function News:draw(game,result)
  if self.merged then return result end
  local t=self.ticker; local top=game and game.stack and game.stack.top and game.stack:top()
  local gen1=top and top.isOverworld; local gw=game and game.world; local gen2=gw and gw.map and top==nil and not gw.transitioning and not gw.mapSetup and not gw.textbox and not gw.choicebox
  if not(t and t.text and (gen1 or gen2) and love and love.graphics) then return result end
  local g=love.graphics; local ww=g.getWidth and g.getWidth() or 160; local font=g.getFont and g.getFont(); local fh=font and font:getHeight() or 8; local h=math.max(18,fh+8)
  local alpha=.88; local left=math.max(0,(t.duration or 8)-(t.age or 0)); if left<1 then alpha=alpha*left end
  local or_,og,ob,oa=g.getColor(); local sx,sy,sw,sh=g.getScissor(); g.push(); g.setColor(.02,.04,.08,alpha); g.rectangle("fill",0,0,ww,h); g.setColor(.25,.75,1,alpha); g.rectangle("fill",0,h-2,ww,2); g.setScissor(5,0,math.max(1,ww-10),h)
  local tw=font and font:getWidth(t.text) or #t.text*6; local x=8; if tw>ww-16 then x=ww-(t.offset%(tw+ww)) end
  g.setColor(1,1,1,alpha); g.print(t.text,x,math.max(2,math.floor((h-fh)/2)-1)); g.pop(); g.setScissor(sx,sy,sw,sh); g.setColor(or_,og,ob,oa); return result
end
return News
