local PhysicalWorld={}

-- Ultron's physical-world contract:
--   * ordinary travel advances one collision cell at a time;
--   * a map can only change while Ultron is standing on a real seam/warp;
--   * unknown collision is NEVER treated as open floor;
--   * the only instant relocation permitted elsewhere is Rival's player-style
--     blackout return to the last visited Pokemon Center / player home.

local function abs(v) return v<0 and -v or v end
local DIRS={{0,-1,"up"},{0,1,"down"},{-1,0,"left"},{1,0,"right"}}

local function maps(engine)
  local d=engine and engine.data or {}
  if engine and engine.generation==2 and type(d.gen2Maps)=="table" then return d.gen2Maps end
  return d.maps or {}
end

local function def(engine,id) return maps(engine)[id] end

local function tilesetFor(engine,mapDef)
  if type(mapDef)~="table" then return nil end
  local d=engine and engine.data or {}
  local id=mapDef.tileset
  for _,pool in ipairs({d.gen2Tilesets,d.tilesets,d.gen1Tilesets}) do
    if type(pool)=="table" and type(pool[id])=="table" then return pool[id] end
  end
end

local function canSurf(rival)
  if not rival then return false end
  if rival.canUseHM then
    local ok,v=pcall(function() return rival:canUseHM("SURF") end)
    if ok and v then return true end
  end
  local h=rival.hms or {}
  return h.SURF==true or h.HM_SURF==true or (tonumber(h.SURF) or 0)>0 or (tonumber(h.HM_SURF) or 0)>0
end

local function snapshotGrid(atlas,id)
  local snap=atlas and atlas.mapGrids and atlas.mapGrids[id]
  if not(snap and type(snap.rows)=="table" and #snap.rows>0) then return nil end
  local cells={}; local h=#snap.rows; local w=tonumber(snap.width) or #snap.rows[1]
  for y=1,h do
    cells[y]={}; local row=snap.rows[y]
    for x=1,w do
      local c=row:sub(x,x)
      -- mapOverview uses ~ for water. Keep it in a second channel so a Surf-
      -- capable Ultron may use it without teaching a non-Surf Ultron to swim.
      cells[y][x]=(c=="." or c=="+")
    end
  end
  return {w=w,h=h,cells=cells,mapId=id,authoritative=true,source="live-overview"}
end

local function objectBlocks(obj)
  if type(obj)~="table" or obj.x==nil or obj.y==nil then return false end
  if obj.passable==true or obj.through==true or obj.solid==false then return false end
  local kind=tostring(obj.kind or obj.type or ""):upper()
  if kind:find("WARP",1,true) or kind:find("DOOR",1,true) then return false end
  return true
end

local function forceTransitCells(g,mapDef)
  if not(g and mapDef) then return end
  for _,w in ipairs(mapDef.warps or {}) do
    local x,y=tonumber(w.x),tonumber(w.y)
    if x and y and x>=0 and y>=0 and x<g.w and y<g.h then
      g.cells[y+1]=g.cells[y+1] or {}; g.cells[y+1][x+1]=true
    end
  end
end

local function staticGrid(engine,id,rival)
  engine._ultronStaticGridCache=engine._ultronStaticGridCache or {}
  local surf=canSurf(rival) and "surf" or "land"
  local key=tostring(id)..":"..surf
  local hit=engine._ultronStaticGridCache[key]
  if hit then return hit end
  local m=def(engine,id); local ts=tilesetFor(engine,m)
  if not(m and ts) then return nil end

  local Map
  if engine.generation==2 then
    local ok,v=pcall(require,"src.world.gen2.Map"); if ok then Map=v end
  else
    local ok,v=pcall(require,"src.world.Map"); if ok then Map=v end
  end
  if not(Map and type(Map.new)=="function") then return nil end
  local ok,map=pcall(Map.new,m,ts)
  if not(ok and type(map)=="table") then return nil end

  local w=math.floor(tonumber(map.widthCells) or (tonumber(m.width) or 0)*2)
  local h=math.floor(tonumber(map.heightCells) or (tonumber(m.height) or 0)*2)
  if w<=0 or h<=0 then return nil end
  local cells={}; local surfing=canSurf(rival)
  for y=0,h-1 do
    cells[y+1]={}
    for x=0,w-1 do
      local pass=false
      if type(map.isPassableCell)=="function" then
        local rok,v=pcall(map.isPassableCell,map,x,y,surfing); pass=rok and v==true
      elseif type(map.isWalkableCell)=="function" then
        local rok,v=pcall(map.isWalkableCell,map,x,y); pass=rok and v==true
      elseif type(map.isWalkable)=="function" then
        local rok,v=pcall(map.isWalkable,map,x,y); pass=rok and v==true
      end
      cells[y+1][x+1]=pass
    end
  end
  local g={w=w,h=h,cells=cells,mapId=id,authoritative=true,source="engine-collision"}
  forceTransitCells(g,m)
  -- Static NPC/object coordinates are real physical blockers. Trainers are not
  -- deleted from collision; Ultron approaches an adjacent cell before battling.
  for _,obj in ipairs(m.objects or {}) do
    if objectBlocks(obj) then
      local x,y=math.floor(tonumber(obj.x) or -1),math.floor(tonumber(obj.y) or -1)
      if x>=0 and y>=0 and x<w and y<h then g.cells[y+1][x+1]=false end
    end
  end
  forceTransitCells(g,m)
  engine._ultronStaticGridCache[key]=g
  return g
end

local function gridFor(engine,atlas,id,rival)
  -- The static engine collision can represent every loaded map, including maps
  -- the player has not personally visited. A live snapshot wins for dynamic
  -- collision only when Ultron cannot Surf through water the player sees as ~.
  local snap=snapshotGrid(atlas,id)
  local static=staticGrid(engine,id,rival)
  if snap and not canSurf(rival) then return snap end
  return static or snap -- nil is deliberate: unknown geometry is fail-closed.
end

local function walkable(g,x,y)
  if not g or x==nil or y==nil or x<0 or y<0 or x>=g.w or y>=g.h then return false end
  return g.cells[y+1] and g.cells[y+1][x+1] or false
end

local function nearest(g,x,y)
  if not g then return nil end
  x=math.max(0,math.min(g.w-1,math.floor(tonumber(x) or math.floor(g.w/2))))
  y=math.max(0,math.min(g.h-1,math.floor(tonumber(y) or math.floor(g.h/2))))
  if walkable(g,x,y) then return x,y end
  for r=1,math.max(g.w,g.h) do
    for dy=-r,r do
      local span=r-abs(dy)
      for _,dx in ipairs({-span,span}) do
        local nx,ny=x+dx,y+dy; if walkable(g,nx,ny) then return nx,ny end
      end
    end
  end
end

local function pathfind(g,sx,sy,tx,ty,blocked,adjacent)
  if not(g and sx and sy and tx and ty) then return nil end
  local function isTarget(x,y)
    if adjacent then return abs(x-tx)+abs(y-ty)==1 end
    return x==tx and y==ty
  end
  if isTarget(sx,sy) then return {} end
  if not adjacent and not walkable(g,tx,ty) then return nil end
  local q={{sx,sy}}; local head=1; local prev={}; local seen={[sx..","..sy]=true}
  while head<=#q do
    local c=q[head]; head=head+1
    for _,d in ipairs(DIRS) do
      local nx,ny=c[1]+d[1],c[2]+d[2]; local k=nx..","..ny
      if not seen[k] and walkable(g,nx,ny) and not(blocked and blocked[k]) then
        seen[k]=true; prev[k]={c[1],c[2],d[3]}
        if isTarget(nx,ny) then
          local out={}; local x,y=nx,ny
          while not(x==sx and y==sy) do
            local p=prev[x..","..y]; if not p then return nil end
            table.insert(out,1,{x=x,y=y,dir=p[3]}); x,y=p[1],p[2]
          end
          return out
        end
        q[#q+1]={nx,ny}
      end
    end
  end
end

local function exactOrNearestTransit(g,x,y)
  x,y=tonumber(x),tonumber(y)
  if not(x and y) then return nil end
  x,y=math.floor(x),math.floor(y)
  if x>=0 and y>=0 and x<g.w and y<g.h then
    -- Declared warp/seam cells are traversal targets even if a map adapter calls
    -- the immediate transition class non-walkable.
    g.cells[y+1]=g.cells[y+1] or {}; g.cells[y+1][x+1]=true
    return x,y
  end
end

local function edgeTarget(engine,rival,edge,g)
  if not g then return nil end
  if edge and tonumber(edge.x) and tonumber(edge.y) then return exactOrNearestTransit(g,edge.x,edge.y) end
  local m=def(engine,rival.map) or {}
  if edge and edge.kind=="warp" then
    for _,w in ipairs(m.warps or {}) do
      if w.destMap==edge.to or (w.destMap=="LAST_MAP" and rival.arrivedFrom==edge.to) then
        return exactOrNearestTransit(g,w.x,w.y)
      end
    end
  end
  local dir=edge and edge.dir
  local off=math.floor(tonumber(edge and edge.offset) or 0)
  if dir=="north" or dir=="up" then return nearest(g,math.floor(g.w/2)+off,0) end
  if dir=="south" or dir=="down" then return nearest(g,math.floor(g.w/2)+off,g.h-1) end
  if dir=="west" or dir=="left" then return nearest(g,0,math.floor(g.h/2)+off) end
  if dir=="east" or dir=="right" then return nearest(g,g.w-1,math.floor(g.h/2)+off) end
  for _,w in ipairs(m.warps or {}) do
    if w.destMap=="LAST_MAP" or (edge and w.destMap==edge.to) then return exactOrNearestTransit(g,w.x,w.y) end
  end
  return nil -- never invent a center-of-map exit.
end

local function entryPoint(engine,rival,from,to)
  local m=def(engine,to) or {}; local g=gridFor(engine,engine.atlas,to,rival)
  if not g then return nil end
  for _,w in ipairs(m.warps or {}) do if w.destMap==from then return exactOrNearestTransit(g,w.x,w.y) end end
  local back=engine.graph and engine.graph:edgeBetween(to,from)
  if back and tonumber(back.x) and tonumber(back.y) then return exactOrNearestTransit(g,back.x,back.y) end
  local dir=back and back.dir
  if dir=="north" or dir=="up" then return nearest(g,math.floor(g.w/2),0) end
  if dir=="south" or dir=="down" then return nearest(g,math.floor(g.w/2),g.h-1) end
  if dir=="west" or dir=="left" then return nearest(g,0,math.floor(g.h/2)) end
  if dir=="east" or dir=="right" then return nearest(g,g.w-1,math.floor(g.h/2)) end
  return nil
end

local function spawnPoint(engine,rival)
  local g=gridFor(engine,engine.atlas,rival.map,rival); if not g then return nil end
  local m=def(engine,rival.map) or {}
  -- Player-style respawn/home maps usually expose an exit warp. Starting at a
  -- walkable cell beside the first real object/warp is deterministic, never RNG.
  local preferred={}
  for _,w in ipairs(m.warps or {}) do preferred[#preferred+1]={w.x,w.y} end
  for _,o in ipairs(m.objects or {}) do if o.x~=nil and o.y~=nil then preferred[#preferred+1]={o.x,o.y} end end
  preferred[#preferred+1]={math.floor(g.w/2),math.floor(g.h/2)}
  for _,p in ipairs(preferred) do local x,y=nearest(g,p[1],p[2]); if x then return x,y end end
end

function PhysicalWorld.attach(engine,atlas) engine.atlas=atlas end
function PhysicalWorld.grid(engine,id,rival) return gridFor(engine,engine and engine.atlas,id,rival) end
function PhysicalWorld.walkable(g,x,y) return walkable(g,x,y) end
function PhysicalWorld.spawnPoint(engine,rival) return spawnPoint(engine,rival) end

function PhysicalWorld.ensurePosition(engine,rival)
  if not(rival and rival.map) then return false end
  local g=gridFor(engine,engine.atlas,rival.map,rival); if not g then return false end
  if rival.x~=nil and rival.y~=nil and walkable(g,rival.x,rival.y) then return true end
  if not(rival._ultronNeedsInitialPlacement or rival._ultronRespawnPlacement or rival._ultronBlackout) then
    return false -- missing coordinates during ordinary travel are corruption, not permission to teleport.
  end
  local x,y=spawnPoint(engine,rival); if not x then return false end
  rival.x,rival.y=x,y; rival._ultronNeedsInitialPlacement=nil; rival._ultronRespawnPlacement=nil
  return true
end

function PhysicalWorld.nextExit(engine,rival)
  if not(rival.destination and rival.map~=rival.destination) then return nil end
  if not rival.route then rival.route=rival:routeTo(rival.destination) end
  local nextMap=rival:nextHop(); if not nextMap then return nil end
  local edge=engine.graph:edgeBetween(rival.map,nextMap); if not edge then return nil end
  local g=gridFor(engine,engine.atlas,rival.map,rival)
  if not(g and PhysicalWorld.ensurePosition(engine,rival)) then return nil end
  local tx,ty=edgeTarget(engine,rival,edge,g); return nextMap,edge,g,tx,ty
end

function PhysicalWorld.stepTo(engine,rival,tx,ty,opts)
  opts=opts or {}
  if not(rival and rival.map and tx~=nil and ty~=nil) then return false,"bad target" end
  local g=gridFor(engine,engine.atlas,rival.map,rival)
  if not g then return false,"collision unavailable" end
  if not PhysicalWorld.ensurePosition(engine,rival) then return false,"position unavailable" end
  tx,ty=math.floor(tonumber(tx) or -999),math.floor(tonumber(ty) or -999)
  local adjacent=opts.adjacent==true
  if adjacent and abs(rival.x-tx)+abs(rival.y-ty)==1 then return true,"arrived" end
  if not adjacent and rival.x==tx and rival.y==ty then return true,"arrived" end
  local path=pathfind(g,rival.x,rival.y,tx,ty,opts.blocked,adjacent)
  local one=path and path[1]
  if not one then rival.stuckTicks=(rival.stuckTicks or 0)+1; return false,"blocked" end
  rival.x,rival.y=one.x,one.y; rival.facing=one.dir or rival.facing
  rival.virtualSteps=(tonumber(rival.virtualSteps) or 0)+1; rival.stuckTicks=0
  return false,"physical tile"
end

function PhysicalWorld.step(engine,rival,ctx)
  if not(rival and rival.destination and rival.map~=rival.destination) then return "idle" end
  local nextMap,edge,g,tx,ty=PhysicalWorld.nextExit(engine,rival)
  if not(nextMap and g and tx and ty) then
    rival.route=nil; rival.stuckTicks=(rival.stuckTicks or 0)+1
    return "collision/exit unavailable; no movement"
  end
  if rival.canEnterMap and not rival:canEnterMap(nextMap) then
    rival.destination,rival.route,rival.routeIndex=nil,nil,1; rival:setState("IDLE","progression gate blocked route"); return "route gated"
  end
  if rival.x==tx and rival.y==ty then
    local from=rival.map; local ex,ey=entryPoint(engine,rival,from,nextMap)
    if ex==nil or ey==nil then rival.route=nil; return "entry unavailable; no map hop" end
    -- This is a real warp/seam transition, equivalent to the player's map load.
    rival.arrivedFrom=from; rival.map=nextMap; rival.x,rival.y=ex,ey
    rival.virtualSteps=(tonumber(rival.virtualSteps) or 0)+1
    rival.path=nil; rival.localWalkGoal=nil; rival.hopClock=nil; rival.stuckTicks=0
    if rival.useHMsForMap then pcall(function() rival:useHMsForMap(nextMap) end) end
    if rival.visitMap then pcall(function() rival:visitMap(nextMap) end) end
    if rival.map==rival.destination then pcall(function() engine.modules.AI.onArrive(rival,ctx or {}) end) end
    return "crossed real transition"
  end
  local arrived,why=PhysicalWorld.stepTo(engine,rival,tx,ty)
  if arrived then return "at transition" end
  return why
end

return PhysicalWorld
