local Tamper={}
local function clean(s) return tostring(s or ""):gsub("[%c]+"," "):sub(1,72) end
local function fnv(s) local h=2166136261; for i=1,#s do h=(h ~ s:byte(i))*16777619 % 4294967296 end; return string.format("%08x",h) end
local function monString(m)
  local moves={}; for _,v in ipairs(m.moves or {}) do moves[#moves+1]=tostring(v) end
  return table.concat({tostring(m.species or m.speciesId or "?"),tostring(m.level or 0),tostring(m.heldItem or m.item or ""),table.concat(moves,",")},"|")
end
function Tamper.partyFingerprint(rival) local rows={}; for _,m in ipairs(rival and rival.party or {}) do rows[#rows+1]=monString(m) end; return fnv(table.concat(rows,";")) end
function Tamper.new(saved)
  saved=type(saved)=="table" and saved or {}; return {detected=saved.detected==true,count=tonumber(saved.count) or 0,events=type(saved.events)=="table" and saved.events or {},pending=saved.pending==true,
    trustedParty=saved.trustedParty,trustedSprite=saved.trustedSprite,trustedStarter=saved.trustedStarter}
end
function Tamper.flag(state,what)
  state=Tamper.new(state); what=clean(what); state.detected=true; state.pending=true; state.count=state.count+1; state.events[#state.events+1]=what; while #state.events>12 do table.remove(state.events,1) end; return state
end
function Tamper.auditLoaded(state,rival,identity)
  state=Tamper.new(state); if not rival then return state end
  if state.trustedParty and state.trustedParty~=Tamper.partyFingerprint(rival) then state=Tamper.flag(state,"party data") end
  if rival.name~="Ultron" or rival.id~="ultron" or rival.personalityId~="ULTRON" then state=Tamper.flag(state,"identity fields") end
  local sprite=rival.appearanceSprite or rival.spriteOverride
  local locked=identity and identity.appearanceChosen and identity.appearanceSprite
  if locked and tostring(sprite or "")~=tostring(locked) then state=Tamper.flag(state,"locked appearance") end
  if state.trustedSprite~=nil and tostring(sprite or "")~=tostring(state.trustedSprite or "") then state=Tamper.flag(state,"sprite data") end
  local expected=identity and identity.starterSpecies
  if expected and state.trustedStarter and expected~=state.trustedStarter then state=Tamper.flag(state,"starter rule") end
  return state
end
function Tamper.auditLive(state,rival)
  state=Tamper.new(state); if not rival then return state end
  if rival.name~="Ultron" or rival.id~="ultron" or rival.personalityId~="ULTRON" or tonumber(rival.competitiveLiteracy or 0)~=100 then state=Tamper.flag(state,"runtime identity edit") end
  return state
end
function Tamper.trust(state,rival,identity)
  state=Tamper.new(state); if rival then state.trustedParty=Tamper.partyFingerprint(rival); state.trustedSprite=tostring(rival.appearanceSprite or rival.spriteOverride or "") end
  state.trustedStarter=identity and identity.starterSpecies or state.trustedStarter; return state
end
function Tamper.callout(state)
  state=Tamper.new(state); if not state.pending then return state,nil end; state.pending=false
  local what=state.events[#state.events] or "my code"
  return state,"I noticed you tried to alter "..what..". Ultron is Ultron. If you want to improve me, use an authorised build instead of editing my identity behind my back."
end
return Tamper
