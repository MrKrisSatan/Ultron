local Util = require("mods.ultron.src.Util")
local Exchange = {}
local FORMAT = "ULTRON_TRAINING_V1"
local FILE = "ultron_training_data.txt"

local function esc(s)
  return (tostring(s or ""):gsub("([^A-Za-z0-9_%.:%-])", function(c)
    return string.format("%%%02X", string.byte(c))
  end))
end
local function unesc(s)
  return (tostring(s or ""):gsub("%%(%x%x)", function(h) return string.char(tonumber(h,16)) end))
end
local function split(line)
  local out = {}
  for part in (tostring(line or "").."|"):gmatch("(.-)|") do out[#out+1] = unesc(part) end
  return out
end
local function portableChecksum(s)
  local h = 2166136261
  for i=1,#s do h = (h + s:byte(i) * 16777619) % 4294967296; h = (h * 31 + 7) % 4294967296 end
  return string.format("%08x", h)
end

local function fs()
  local ok, SaveData = pcall(require, "src.core.SaveData")
  if ok and SaveData and type(SaveData.persistenceFs) == "function" then
    local good, f = pcall(SaveData.persistenceFs)
    if good and type(f) == "table" then return f end
  end
  local good, f = pcall(function() return love and love.filesystem end)
  if good and type(f) == "table" then return f end
end

local function writeFile(path, data)
  local f = fs()
  if not (f and type(f.write) == "function") then return false, "persistent filesystem unavailable" end
  local ok, result = pcall(f.write, path, data)
  return ok and result ~= false, ok and nil or tostring(result)
end
local function readFile(path)
  local f = fs()
  if not (f and type(f.read) == "function") then return nil, "persistent filesystem unavailable" end
  local ok, data = pcall(f.read, path)
  if ok and type(data) == "string" then return data end
  return nil, tostring(data)
end

function Exchange.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    sourceId = saved.sourceId,
    imports = math.max(0, tonumber(saved.imports) or 0),
    sources = type(saved.sources) == "table" and saved.sources or {},
    species = type(saved.species) == "table" and saved.species or {},
    moves = type(saved.moves) == "table" and saved.moves or {},
    leads = type(saved.leads) == "table" and saved.leads or {},
    encounters = type(saved.encounters) == "table" and saved.encounters or {},
    visits = type(saved.visits) == "table" and saved.visits or {},
  }
end

function Exchange.ensureSource(state, rival, manager, game)
  state = Exchange.new(state)
  if state.sourceId and state.sourceId ~= "" then return state end
  local seed = 1
  pcall(function() seed = tonumber(manager and manager:worldSeed()) or seed end)
  local save = game and game.save or {}
  local player = save.player or {}
  local tid = save.trainerId or save.trainerID or save.tid or player.trainerId or player.tid or "0"
  state.sourceId = "U" .. portableChecksum(tostring(seed)..":"..tostring(tid)..":"..tostring(rival and rival.def and rival.def.seed or 0))
  return state
end

local function rowsFromCounts(prefix, counts, rows, limit)
  local list = {}
  for id,n in pairs(type(counts)=="table" and counts or {}) do
    n=math.max(0,math.floor(tonumber(n) or 0)); if n>0 then list[#list+1]={id=id,n=n} end
  end
  table.sort(list,function(a,b) if a.n~=b.n then return a.n>b.n end return tostring(a.id)<tostring(b.id) end)
  for i=1,math.min(limit or #list,#list) do
    local r=list[i]; rows[#rows+1]=table.concat({prefix,esc(r.id),r.n},"|")
  end
end

function Exchange.encode(state, rival, atlas, manager, game)
  state = Exchange.ensureSource(state,rival,manager,game)
  local body = {FORMAT, "SOURCE|"..esc(state.sourceId)}
  local pm = rival and rival.memory and rival.memory.player or {}
  rowsFromCounts("SPECIES",pm.species,body,64)
  rowsFromCounts("MOVE",pm.moves,body,64)
  rowsFromCounts("LEAD",pm.leads,body,32)
  rowsFromCounts("VISIT",rival and rival.visitedMaps,body,96)
  rowsFromCounts("BLOCK",atlas and atlas.blocked,body,96)
  local encounterRows={}
  for map,bySpecies in pairs((rival and rival.encounterHistory) or {}) do
    for species,e in pairs(type(bySpecies)=="table" and bySpecies or {}) do
      local seen=math.max(0,math.floor(tonumber(e and e.seen) or 0))
      local caught=math.max(0,math.floor(tonumber(e and e.caught) or 0))
      if seen>0 or caught>0 then encounterRows[#encounterRows+1]={map=map,species=species,seen=seen,caught=caught} end
    end
  end
  table.sort(encounterRows,function(a,b)
    local aa,bb=a.seen+a.caught*3,b.seen+b.caught*3
    if aa~=bb then return aa>bb end
    if tostring(a.map)~=tostring(b.map) then return tostring(a.map)<tostring(b.map) end
    return tostring(a.species)<tostring(b.species)
  end)
  for i=1,math.min(192,#encounterRows) do local r=encounterRows[i]
    body[#body+1]=table.concat({"ENCOUNTER",esc(r.map),esc(r.species),r.seen,r.caught},"|")
  end
  local raw=table.concat(body,"\n")
  return raw.."\nCHECK|"..portableChecksum(raw).."\n",state
end

local function bump(t,k,n)
  if type(k)~="string" or k=="" then return end
  t[k]=math.min(9999,(tonumber(t[k]) or 0)+math.max(0,tonumber(n) or 0))
end
local function trimCounts(t, limit)
  local rows={}; for k,n in pairs(t or {}) do rows[#rows+1]={k,n=tonumber(n) or 0} end
  table.sort(rows,function(a,b) if a.n~=b.n then return a.n>b.n end return tostring(a[1])<tostring(b[1]) end)
  for i=(limit or 128)+1,#rows do t[rows[i][1]]=nil end
end

function Exchange.decode(text)
  if type(text)~="string" then return nil,"not text" end
  local lines={}; for line in text:gmatch("[^\r\n]+") do lines[#lines+1]=line end
  if lines[1]~=FORMAT then return nil,"not Ultron training data" end
  local checkLine=lines[#lines]; local cp=split(checkLine)
  if cp[1]~="CHECK" or not cp[2] then return nil,"missing checksum" end
  local rawLines={}
  for i=1,#lines-1 do rawLines[#rawLines+1]=lines[i] end
  local raw=table.concat(rawLines,"\n")
  if portableChecksum(raw)~=cp[2] then return nil,"checksum mismatch" end
  local out={species={},moves={},leads={},visits={},blocked={},encounters={}}
  for i=2,#lines-1 do
    local p=split(lines[i]); local kind=p[1]
    if kind=="SOURCE" then out.source=p[2]
    elseif kind=="SPECIES" then bump(out.species,p[2],p[3])
    elseif kind=="MOVE" then bump(out.moves,p[2],p[3])
    elseif kind=="LEAD" then bump(out.leads,p[2],p[3])
    elseif kind=="VISIT" then bump(out.visits,p[2],p[3])
    elseif kind=="BLOCK" then bump(out.blocked,p[2],p[3])
    elseif kind=="ENCOUNTER" and p[2] and p[3] then
      out.encounters[p[2]]=out.encounters[p[2]] or {}
      local e=out.encounters[p[2]][p[3]] or {seen=0,caught=0}; out.encounters[p[2]][p[3]]=e
      e.seen=math.min(9999,e.seen+math.max(0,tonumber(p[4]) or 0)); e.caught=math.min(9999,e.caught+math.max(0,tonumber(p[5]) or 0))
    end
  end
  if not out.source or out.source=="" then return nil,"missing source id" end
  out.checksum=cp[2]
  return out
end

function Exchange.merge(state, pack, rival, atlas)
  state=Exchange.new(state)
  if type(pack)~="table" or not pack.source then return state,atlas,false,"invalid training package" end
  if pack.source==state.sourceId then return state,atlas,false,"That file was exported by this Ultron." end
  if state.sources[pack.source] then return state,atlas,false,"Training from that Ultron has already been imported." end
  state.sources[pack.source]=pack.checksum or true; state.imports=state.imports+1
  for k,n in pairs(pack.species or {}) do bump(state.species,k,n) end
  for k,n in pairs(pack.moves or {}) do bump(state.moves,k,n) end
  for k,n in pairs(pack.leads or {}) do bump(state.leads,k,n) end
  for k,n in pairs(pack.visits or {}) do bump(state.visits,k,n) end
  trimCounts(state.species,128); trimCounts(state.moves,128); trimCounts(state.leads,64); trimCounts(state.visits,128)

  if rival then
    rival.visitedMaps=rival.visitedMaps or {}
    for map,n in pairs(pack.visits or {}) do
      rival.visitedMaps[map]=math.max(tonumber(rival.visitedMaps[map]) or 0,math.min(8,tonumber(n) or 0))
    end
    rival.encounterHistory=rival.encounterHistory or {}
    for map,bySpecies in pairs(pack.encounters or {}) do
      rival.encounterHistory[map]=rival.encounterHistory[map] or {}
      for species,e in pairs(bySpecies) do
        local dst=rival.encounterHistory[map][species] or {seen=0,caught=0}; rival.encounterHistory[map][species]=dst
        dst.seen=math.min(9999,(tonumber(dst.seen) or 0)+(tonumber(e.seen) or 0))
        dst.caught=math.min(9999,(tonumber(dst.caught) or 0)+(tonumber(e.caught) or 0))
      end
    end
  end
  atlas=type(atlas)=="table" and atlas or {}
  atlas.blocked=type(atlas.blocked)=="table" and atlas.blocked or {}
  for k,n in pairs(pack.blocked or {}) do atlas.blocked[k]=math.max(tonumber(atlas.blocked[k]) or 0,tonumber(n) or 0) end
  return state,atlas,true,"Imported training from another Ultron. Collective sources: "..tostring(state.imports).."."
end

function Exchange.collectiveParty(state, data, maxSlots)
  state=Exchange.new(state); local rows={}
  for species,n in pairs(state.species or {}) do
    local exists=(data and data.gen2Pokemon and data.gen2Pokemon[species]) or (data and data.pokemon and data.pokemon[species])
    if exists then rows[#rows+1]={species=species,n=tonumber(n) or 0} end
  end
  table.sort(rows,function(a,b) if a.n~=b.n then return a.n>b.n end return a.species<b.species end)
  local out={}; for i=1,math.min(maxSlots or 6,#rows) do out[#out+1]={species=rows[i].species,level=100,moves={}} end
  return out
end

function Exchange.exportFile(state,rival,atlas,manager,game)
  local text,newState=Exchange.encode(state,rival,atlas,manager,game)
  local ok,err=writeFile(FILE,text)
  if not ok then return newState,false,"Export failed: "..tostring(err) end
  return newState,true,"Exported "..FILE.." to the game save directory. Share that file with another player."
end

function Exchange.importFile(state,rival,atlas,manager,game)
  state=Exchange.ensureSource(state,rival,manager,game)
  local text,err=readFile(FILE); if not text then return state,atlas,false,"Import failed: "..tostring(err)..". Place "..FILE.." in the game save directory." end
  local pack,why=Exchange.decode(text); if not pack then return state,atlas,false,"Import failed: "..tostring(why) end
  return Exchange.merge(state,pack,rival,atlas)
end

Exchange.FILE=FILE
return Exchange
