local UI={}
local function closeStart(game) local s=game and game.stack; if s and type(s.pop)=="function" then pcall(s.pop,s) end end
local function pushText(mod,game,text)
  text=tostring(text or "")
  local world; pcall(function() world=mod.world and mod.world.overworld and mod.world:overworld() end)
  if world and type(world.showText)=="function" then local ok=pcall(world.showText,world,text); if ok then return true end end
  if mod.ui and mod.ui.TextBox and game and game.stack then local ok,b=pcall(mod.ui.TextBox.new,game,text); if ok and b then game.stack:push(b); return true end end
  return false
end
local function partyText(r)
  local out={}; for i,m in ipairs(r and r.party or {}) do out[#out+1]=string.format("%d. %s Lv%d",i,tostring(m.species or "?"):gsub("_"," "),tonumber(m.level) or 0) end
  return #out>0 and table.concat(out,"\n") or "Ultron has no active Pokemon yet."
end
function UI.open(mod,game,ctx)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  local r=ctx.engine and ctx.engine.rival; if not r then return false end
  closeStart(game)
  local rows={
    {label="LOCATION",right=tostring(r.map or "PENDING"):gsub("_"," "),value="line"},
    {label="BADGES",right=tostring(ctx.badges and ctx.badges() or 0),value="line"},
    {label="DRIVE",right=tostring(math.floor(ctx.drive and ctx.drive() or 0)).."/100",value="line"},
    {label="MONEY",right="P"..tostring(math.floor(tonumber(r.money) or 0)),value="line"},
    {label="PARTY",value="party"},{label="LATEST UPDATE",value="news"},{label="MESSAGE",value="chat"},
    {label="EXPORT DATA",value="export"},{label="IMPORT DATA",value="import"},{label="INTEGRITY",value="integrity"},
    {label="CLOSE",value="close"},
  }
  local menu
  menu=mod.ui.ListMenu.new(game,"ULTRON",rows,{onChoose=function(item,m)
    if not item then return end; local v=item.value
    if v=="close" then if m and m.close then m:close() end; return end
    if v=="line" then return end
    if m and m.close then m:close() end
    if v=="party" then pushText(mod,game,partyText(r))
    elseif v=="news" then pushText(mod,game,"Ultron: "..tostring(ctx.latest and ctx.latest() or "No update."))
    elseif v=="chat" and ctx.chat then ctx.chat()
    elseif v=="export" and ctx.export then ctx.export()
    elseif v=="import" and ctx.import then ctx.import()
    elseif v=="integrity" then pushText(mod,game,ctx.integrity and ctx.integrity() or "Integrity status unavailable.") end
  end})
  if not menu then return false end; game.stack:push(menu); return true
end
function UI.installStartMenu(mod,ctx)
  if not(mod and mod.hooks and mod.hooks.wrap) then return false end
  mod.hooks:wrap("ui.start_menu.items",function(next,game,items)
    local out=next(game,items); if type(out)~="table" then return out end
    for _,it in ipairs(out) do if type(it)=="table" and it._ultronMenu then return out end end
    local row={label="ULTRON",desc={"Living AI rival","Status / message"},_ultronMenu=true,onSelect=function(selected) UI.open(mod,selected or game,ctx) end}
    local at=#out+1; for i,it in ipairs(out) do if type(it)=="table" and (it.label=="SAVE" or it.label=="OPTION") then at=i; break end end
    table.insert(out,at,row); return out
  end); return true
end
UI.say=pushText
return UI
