#!/usr/bin/env python3
"""Ultron protected-edit authorization helper.

The plaintext edit password is intentionally not stored in the repository.
Provide it through ULTRON_EDIT_PASSWORD or the hidden prompt. The verifier is
PBKDF2-HMAC-SHA256 and therefore one-way; a successful check only authorizes the
current maintenance operation.
"""
from __future__ import annotations
import getpass, hashlib, hmac, os, sys

SALT = bytes.fromhex("4e9b8d2a7c51f306a18d7e49c2b64591")
ROUNDS = 240000
EXPECTED = bytes.fromhex("35738eb2686ce4006dffa6b88938ff61fd287e07ec47a5c01322e7fe5926a067")

def supplied_password() -> str:
    value = os.environ.get("ULTRON_EDIT_PASSWORD")
    if value is not None:
        return value
    return getpass.getpass("Ultron protected-edit password: ")

def derive(value: str) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", value.encode("utf-8"), SALT, ROUNDS)

def authorized(value: str | None = None) -> bool:
    if value is None:
        value = supplied_password()
    return hmac.compare_digest(derive(value), EXPECTED)

def require() -> None:
    if not authorized():
        print("Ultron edit authorization denied.", file=sys.stderr)
        raise SystemExit(77)
    print("Ultron edit authorization accepted for this operation.")

if __name__ == "__main__":
    require()
