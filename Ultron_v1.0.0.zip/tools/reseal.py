#!/usr/bin/env python3
"""Regenerate Ultron's runtime integrity seal after an authorized source edit."""
from __future__ import annotations
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from edit_auth import require

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {
    "src/IntegritySeal.lua",
}

def checksum(data: bytes) -> str:
    # Exact byte-level equivalent of src/Integrity.lua.
    h = 2166136261
    for b in data:
        h = (h + b * 16777619) % 4294967296
        h = (h * 31 + 7) % 4294967296
    return f"{h:08x}"

def protected_files():
    paths = [ROOT / "main.lua"]
    paths += sorted((ROOT / "src").glob("*.lua"))
    paths += sorted((ROOT / "engine" / "src").glob("*.lua"))
    paths += sorted((ROOT / "engine" / "data").glob("*.lua"))
    for p in paths:
        rel = p.relative_to(ROOT).as_posix()
        if rel not in EXCLUDE:
            yield p, rel

def main():
    require()
    rows=[]
    for p,rel in protected_files():
        raw=p.read_bytes()
        rows.append((rel,checksum(raw),len(raw)))
    lines=["-- Generated only by tools/reseal.py after protected-edit authorization.",
           "-- Do not hand-edit this file.",
           "return {version=1,files={"]
    for rel,cs,size in rows:
        lines.append(f'  ["{rel}"]={{sum="{cs}",size={size}}},')
    lines.append("}}")
    (ROOT / "src" / "IntegritySeal.lua").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(f"Resealed {len(rows)} protected files.")

if __name__ == "__main__":
    main()
