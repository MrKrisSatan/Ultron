local NameTag={}

-- render.hud draws in window units while overworld entities/cameras use the
-- Game Boy's 160x144 logical pixel space. Never treat drawX/drawY as screen
-- coordinates: on current Gen1Recomp builds those values are still world
-- pixels and doing so leaves the plaque floating near the top-left corner.
local function cameraOf(ow)
  if type(ow)~="table" then return 0,0 end
  local cam=ow.camera or ow.cam or ow.scroll
  if type(cam)=="table" then
    return tonumber(cam.x or cam.scrollX or cam[1]) or 0,
      tonumber(cam.y or cam.scrollY or cam[2]) or 0
  end
  return tonumber(ow.cameraX or ow.scrollX) or 0,
    tonumber(ow.cameraY or ow.scrollY) or 0
end

local function visualWorldPixel(engine,entity)
  if not(entity and engine) then return nil end
  -- px/py are the renderer's live interpolated overworld coordinates on both
  -- Gen1 and Gen2 hosts. drawPx/drawPy are used by a few compatibility layers.
  local wx=tonumber(entity.px or entity.drawPx or entity.pixelX)
  local wy=tonumber(entity.py or entity.drawPy or entity.pixelY)
  local cellX=tonumber(entity.cellX or entity.x or (engine.rival and engine.rival.x))
  local cellY=tonumber(entity.cellY or entity.y or (engine.rival and engine.rival.y))
  if not wx and cellX then wx=cellX*16 end
  if not wy and cellY then wy=cellY*16 end
  if not(wx and wy) then return nil end
  return wx,wy
end

local function project(engine,entity,viewport)
  local wx,wy=visualWorldPixel(engine,entity); if not wx then return nil end
  local ow=engine:activeMap(); if not ow then return nil end
  local cx,cy=cameraOf(ow)
  -- Anchor at the horizontal centre of the 16px walker and just above the
  -- sprite's head. py is the top of the logical 16px tile on stock walkers.
  local logicalX=(wx-cx)+8
  local logicalY=(wy-cy)-3
  local vp=type(viewport)=="table" and viewport or {}
  local rect=type(vp.gameRect)=="table" and vp.gameRect or type(vp.game)=="table" and vp.game or {}
  local ox=tonumber(vp.gameX or vp.x or rect.x)
  local oy=tonumber(vp.gameY or vp.y or rect.y)
  local gw=tonumber(vp.gameWidth or vp.width or vp.w or rect.width or rect.w)
  local gh=tonumber(vp.gameHeight or vp.height or vp.h or rect.height or rect.h)
  local dpiX=tonumber(vp.dpiX) or 1
  local dpiY=tonumber(vp.dpiY) or dpiX
  local sx,sy
  if gw and gh and gw>0 and gh>0 then
    ox,oy=ox or 0,oy or 0; sx,sy=gw/160,gh/144
  elseif tonumber(vp.scale) and vp.scale>0 then
    ox,oy=ox or 0,oy or 0; sx,sy=vp.scale/dpiX,vp.scale/dpiY
  elseif love and love.graphics and love.graphics.getDimensions then
    -- Colosseum UI owns its final HUD canvas and may not populate Gen1Recomp's
    -- usual gameX/gameWidth viewport fields. Reconstruct the centered 160x144
    -- game rectangle from the actual output window rather than treating logical
    -- pixels as window pixels (the old top-left floating-name failure).
    local ww,wh=love.graphics.getDimensions()
    local sc=math.min((tonumber(ww) or 160)/160,(tonumber(wh) or 144)/144)
    sx,sy=sc,sc; gw,gh=160*sc,144*sc
    ox=((tonumber(ww) or gw)-gw)/2; oy=((tonumber(wh) or gh)-gh)/2
  else
    ox,oy=ox or 0,oy or 0; sx,sy=1,1
  end
  return ox+logicalX*sx,oy+logicalY*sy
end

function NameTag.draw(engine,enabled,result,viewport)
  if enabled==false or not(engine and engine.rival and love and love.graphics) then return result end
  local w=engine:worldView(); if not(w and w.playerMap and engine.rival.map==w.playerMap) then return result end
  local entity=engine:liveEntity(); local x,y=project(engine,entity,viewport); if not(x and y) then return result end
  local g=love.graphics; local font=g.getFont and g.getFont(); if not font then return result end
  local text="Ultron"; local tw=font:getWidth(text); local th=font:getHeight()
  local px=math.floor(x-tw/2+0.5); local py=math.floor(y-th-4+0.5)
  local or_,og,ob,oa=g.getColor(); local scx,scy,scw,sch=g.getScissor()
  g.push()
  g.setColor(0,0,0,.76); g.rectangle("fill",px-3,py-2,tw+6,th+4)
  g.setColor(1,1,1,1); g.print(text,px,py)
  g.pop()
  g.setScissor(scx,scy,scw,sch); g.setColor(or_,og,ob,oa)
  return result
end

NameTag._project=project
return NameTag
