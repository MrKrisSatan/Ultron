# Existing-save activation audit

## Symptom
Ultron can appear to be absent on a save that predates installation.

## Findings
1. **Expected off-map behaviour:** a new Ultron starts on Route 1 (Gen 1/Yellow) or Route 29 (Gen 2) and physically travels. He is rendered only when the player is on the same map. This is intentional.
2. **Bootstrap host-shape bug:** v1.2.0 inherited a `game.stack` requirement in `Util.resolveGame`. Valid hosts exposing `game.world` could therefore never build the standalone engine. Fixed in v1.2.1.
3. **Standalone materialisation gap:** v1.2.0 preferred `mod.world.spawnNpc` and `OverworldState.addRuntimeObject`. Some standalone hosts expose the corresponding runtime API on `game.world`; that path is now supported.
4. **MapOverview dependency:** visible placement could fail if the current host did not expose MapOverview even though authoritative map collision was available. v1.2.1 falls back to the same static physical grid used by off-screen travel. It does not guess walkable cells.
5. **Save retrofit:** starter detection already checks explicit starter fields, rival-starter information, party/PC, Pokédex, badges and generic post-starter progression. A progressed existing save therefore activates even when old save decoders omit `EVENT_GOT_STARTER`.
6. **No catch-up teleport:** no fix moves Ultron directly to the player's current location. On an old save the ticker and Diagnostics are the authoritative way to confirm he is active while still travelling from the start.

## Diagnostic interpretation
- `Engine: NOT ACTIVE` means bootstrap failed or has not received a valid live Game object.
- `Dormant: true` means starter/progression has not been accepted yet.
- `Same map: false` with `Activation: active:*` means Ultron exists and is travelling elsewhere.
- `Physical position: false` with a Position error means physical geometry is unavailable and Ultron refuses to cheat.
- `Same map: true`, `Visible NPC: false`, and both spawn APIs false means the host lacks a usable runtime NPC materialisation path.
- A `Spawn error` names the runtime call that refused the NPC.
