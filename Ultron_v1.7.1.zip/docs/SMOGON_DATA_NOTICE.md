# Smogon competitive-data snapshot

The generated files `data/SmogonGen1.lua` and `data/SmogonGen2.lua` contain a
local, offline snapshot built on 21 August 2026 from:

- Smogon usage statistics for July 2026, Gen 1 OU and Gen 2 OU at the 1760
  cutoff: usage, moves, items and teammates.
- Pokémon Showdown Random Battle option data exposed by `pkmn/randbats` for
  Gen 1 and Gen 2: species levels, viable move pools and Gen 2 roles/items.

No Strategy Pokédex analysis prose is bundled. The importer normalises display
names to engine IDs and retains only the factual fields used by the AI.

Pokémon Showdown and the `pkmn/randbats` software/data pipeline are available
under the MIT License. Copyright (c) 2020-2024 pkmn contributors. Permission is
granted, free of charge, to use, copy, modify, merge, publish, distribute,
sublicense and/or sell copies, subject to retaining the copyright and
permission notice. The software is provided without warranty.

Sources:

- https://www.smogon.com/stats/2026-07/chaos/
- https://data.pkmn.cc/randbats/
- https://github.com/smogon/pokemon-showdown
- https://github.com/pkmn/randbats
