# Ultron v1.4.0 UI Navigation Audit

## Reported failure

User feedback reported a white screen after leaving the Ultron Settings page.

## Root cause

`UI.open()` in v1.3.0 always popped the game stack because it assumed every invocation was replacing the native Start menu. Settings had already closed and popped itself before returning to the parent Ultron page. The additional unconditional pop could therefore remove `OverworldState`, leaving the renderer with the white background and no gameplay screen beneath the menu.

The same lifecycle error was reachable from Training Data -> Back and could occur when Ultron's root menu was opened directly by talking to him rather than from the Start menu.

## Fix

- Only `UI.openStart()` is permitted to pop the native Start menu, and only on its first entry.
- Child pages return with an explicit parent callback and never pop the overworld.
- Settings refresh closes/reopens only Settings.
- Training Data, Settings and root menu now use close-then-push ordering.
- Text pages prefer a TextBox completion callback so they can rebuild their parent after the text box itself has closed.
- Alternate hosts without callback-capable TextBox safely fall back to overworld text and return to the overworld rather than manipulating the stack speculatively.

## Audited paths

The automated page audit exercises every root Ultron menu row, every quick Start -> ULTRON row, Settings toggle refresh, Settings Back, Settings B/Cancel, Training Sources, Training Back, Training B/Cancel, direct NPC interaction and text-page completion. Every path asserts that the original overworld screen remains the bottom stack entry.

See `tests/ui_navigation_smoke.lua` and `tests/ui_page_audit.lua`.
