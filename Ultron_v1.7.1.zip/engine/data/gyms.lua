-- Gym metadata for the rival ladder.
--
-- The badge ORDER is deliberately NOT restated here: src/inventory/Badges.lua
-- reads constants.badges, so a mod that reorders or extends the gym ladder
-- moves the rivals' ladder with it.  What this file adds is the three things
-- the constant does not carry -- which map a badge is won on, which trainer
-- class defends it, and roughly what level the defender fields -- keyed by
-- badge id so the join is on the engine's own key.
--
-- `party` is the index into the trainer record's `parties` list.  `level` is
-- only a hint used before the real party is resolvable (a cache with no
-- trainer table, a Gen 2 boot whose class names differ); the simulator
-- prefers the actual party whenever it can read one.
--
-- `cities` is the town the gym sits in, which is what the rival routes to
-- first: gyms are separate maps reached by a warp, so the strategic route is
-- town-then-door rather than one hop.

return {
  order = {
    "BOULDERBADGE", "CASCADEBADGE", "THUNDERBADGE", "RAINBOWBADGE",
    "SOULBADGE", "MARSHBADGE", "VOLCANOBADGE", "EARTHBADGE",
  },

  byBadge = {
    BOULDERBADGE = { map = "PEWTER_GYM",    city = "PEWTER_CITY",
                     leader = "BROCK",      class = "OPP_BROCK",
                     party = 1, level = 14, types = { "ROCK", "GROUND" } },
    CASCADEBADGE = { map = "CERULEAN_GYM",  city = "CERULEAN_CITY",
                     leader = "MISTY",      class = "OPP_MISTY",
                     party = 1, level = 21, types = { "WATER" } },
    THUNDERBADGE = { map = "VERMILION_GYM", city = "VERMILION_CITY",
                     leader = "LT.SURGE",   class = "OPP_LT_SURGE",
                     party = 1, level = 24, types = { "ELECTRIC" } },
    RAINBOWBADGE = { map = "CELADON_GYM",   city = "CELADON_CITY",
                     leader = "ERIKA",      class = "OPP_ERIKA",
                     party = 1, level = 29, types = { "GRASS", "POISON" } },
    SOULBADGE    = { map = "FUCHSIA_GYM",   city = "FUCHSIA_CITY",
                     leader = "KOGA",       class = "OPP_KOGA",
                     party = 1, level = 43, types = { "POISON" } },
    MARSHBADGE   = { map = "SAFFRON_GYM",   city = "SAFFRON_CITY",
                     leader = "SABRINA",    class = "OPP_SABRINA",
                     party = 1, level = 43, types = { "PSYCHIC" } },
    VOLCANOBADGE = { map = "CINNABAR_GYM",  city = "CINNABAR_ISLAND",
                     leader = "BLAINE",     class = "OPP_BLAINE",
                     party = 1, level = 47, types = { "FIRE" } },
    EARTHBADGE   = { map = "VIRIDIAN_GYM",  city = "VIRIDIAN_CITY",
                     leader = "GIOVANNI",   class = "OPP_GIOVANNI",
                     party = 1, level = 50, types = { "GROUND" } },
  },

  -- Where a rival goes once it holds every badge.  Nothing warps there; it is
  -- the routing destination for LEAGUE_READY and the anchor for the endgame
  -- dialogue set.
  league = { map = "INDIGO_PLATEAU_LOBBY", city = "INDIGO_PLATEAU" },

  -- Healing stops.  A rival routes to the nearest of these when HEALING.
  -- Names that the loaded game does not have are dropped at build time.
  centers = {
    "VIRIDIAN_POKECENTER", "PEWTER_POKECENTER", "CERULEAN_POKECENTER",
    "VERMILION_POKECENTER", "LAVENDER_POKECENTER", "CELADON_POKECENTER",
    "FUCHSIA_POKECENTER", "SAFFRON_POKECENTER", "CINNABAR_POKECENTER",
    "ROUTE_4_POKECENTER", "ROUTE_10_POKECENTER", "MT_MOON_POKECENTER",
    "ROCK_TUNNEL_POKECENTER", "INDIGO_PLATEAU_LOBBY",
  },

  -- Maps a rival is happy to grind on.  Routes only: a rival that trained in
  -- a Poke Center lobby would read as broken even though nothing stops it.
  -- Matched by prefix so a mod's ROUTE_23_EXTRA counts too.
  trainingPrefixes = { "ROUTE_", "VIRIDIAN_FOREST", "MT_MOON", "ROCK_TUNNEL" },

  -- GOLD (GEN 2): the Johto ladder.  Same shape, keyed by badge id so the
  -- join is on FieldMoves' JOHTO_BADGES names.  `class` is the Gold trainer
  -- class that defends the gym; `party` is that class's MEMBER number, because
  -- a Gen 2 class carries a `trainers` member list rather than a `parties`
  -- list -- src/BattleSim.lua:leaderParty reads whichever shape the game has.
  -- `level` stays a hint: the simulator prefers the real party.
  gen2 = {
    order = {
      "ZEPHYR", "HIVE", "PLAIN", "FOG", "MINERAL", "STORM", "GLACIER",
      "RISING",
    },

    byBadge = {
      ZEPHYR   = { map = "VIOLET_GYM",     city = "VIOLET_CITY",
                   leader = "FALKNER",     class = "FALKNER",
                   party = 1, level = 9,  types = { "FLYING" } },
      HIVE     = { map = "AZALEA_GYM",     city = "AZALEA_TOWN",
                   leader = "BUGSY",       class = "BUGSY",
                   party = 1, level = 16, types = { "BUG", "POISON" } },
      PLAIN    = { map = "GOLDENROD_GYM",  city = "GOLDENROD_CITY",
                   leader = "WHITNEY",     class = "WHITNEY",
                   party = 1, level = 20, types = { "NORMAL" } },
      FOG      = { map = "ECRUTEAK_GYM",   city = "ECRUTEAK_CITY",
                   leader = "MORTY",       class = "MORTY",
                   party = 1, level = 25, types = { "GHOST" } },
      MINERAL  = { map = "OLIVINE_GYM",    city = "OLIVINE_CITY",
                   leader = "JASMINE",     class = "JASMINE",
                   party = 1, level = 30, types = { "STEEL" } },
      STORM    = { map = "CIANWOOD_GYM",   city = "CIANWOOD_CITY",
                   leader = "CHUCK",       class = "CHUCK",
                   party = 1, level = 33, types = { "FIGHTING" } },
      GLACIER  = { map = "MAHOGANY_GYM",   city = "MAHOGANY_TOWN",
                   leader = "PRYCE",       class = "PRYCE",
                   party = 1, level = 37, types = { "ICE" } },
      RISING   = { map = "BLACKTHORN_GYM", city = "BLACKTHORN_CITY",
                   leader = "CLAIR",       class = "CLAIR",
                   party = 1, level = 41, types = { "DRAGON" } },
    },

    league = { map = "INDIGO_PLATEAU", city = "INDIGO_PLATEAU" },

    -- Gold's PokeCenters are the <TOWN>_POKECENTER_1F maps.  Names the loaded
    -- game does not have are dropped at build time either way.
    centers = {
      "NEW_BARK_TOWN_POKECENTER_1F", "CHERRYGROVE_CITY_POKECENTER_1F",
      "VIOLET_POKECENTER_1F", "AZALEA_POKECENTER_1F",
      "GOLDENROD_POKECENTER_1F", "ECRUTEAK_POKECENTER_1F",
      "OLIVINE_POKECENTER_1F", "CIANWOOD_POKECENTER_1F",
      "MAHOGANY_POKECENTER_1F", "BLACKTHORN_POKECENTER_1F",
      "INDIGO_PLATEAU_POKECENTER_1F",
    },

    trainingPrefixes = { "ROUTE_", "ILEX_FOREST", "UNION_CAVE", "DARK_CAVE",
                         "MT_MORTAR", "BURNED_TOWER" },
  },
}
