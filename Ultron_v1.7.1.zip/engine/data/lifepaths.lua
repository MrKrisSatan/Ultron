-- LIFE PATHS AS DATA (4.7.0).
--
-- Until now a path existed in four places: `LifePath.PATHS`, `LifePath.LABELS`,
-- a hand-written line inside `LifePath.compatibility`, and `Career.DEFS` — plus
-- a `TRANSITIONS` row and a headline. Sixteen paths meant sixteen of each and
-- that was liveable. A hundred does not: it is four hundred edits, four places
-- to disagree, and one function with a hundred arithmetic lines in it.
--
-- So a path is now ONE ROW HERE, and the modules read it. Adding a path is a
-- data edit, exactly as adding a rival became a data edit in 3.3.
--
-- ------------------------------------------------------------------
-- THE FACT VOCABULARY
-- ------------------------------------------------------------------
-- `weights` may only name facts from this list. src/LifePath.lua normalises
-- each to 0..1 from the rival's real history and multiplies. A row naming a
-- fact that does not exist is a LOADING ERROR, not a silent zero: a weight
-- that quietly never fires is the "guard that can never be true" failure, and
-- with a hundred rows nobody would ever notice by reading.
--
--   catch       how readily this rival catches things
--   fight       how readily it picks battles        notFight  the inverse
--   wander      how far it strays from the ladder
--   collection  how much it has caught (of 60)
--   seen        how much it has seen (of 120)
--   badges      badge case (of 8)                   notBadges the inverse
--   maps        how much of the region it knows (of 64)
--   defeats     League failures (of 6)
--   poverty     1 when nearly broke, else 0
--   wealth      money (of 20000)
--   ghost       ghost affinity
--   hostile     grievance against ANYONE (player or rival)
--
-- 4.7.0 adds the relationship facts, so that who a rival knows changes what
-- they become — which is the point of asking for them:
--
--   betrayal    an ally or devoted bond that turned
--   jealousy    someone they were level with is now clearly ahead
--   fear        a bond they have lost to repeatedly and badly
--   kinship     a declared family tie in the roster
--   mentorship  they teach someone, or are taught
--   devotion    a mutual, settled attachment
--
-- ------------------------------------------------------------------
-- WHAT A ROW MEANS
-- ------------------------------------------------------------------
--   id        stable save key. NEVER renamed: a committed path is stored by id
--   label     what the player reads
--   blurb     "<name> is now <blurb>"
--   weights   fact -> coefficient. Compatibility is these, normalised
--   style     optional team-style bonus, e.g. { EVOLUTION = 0.4 }
--   requires  optional gate: every named fact must be at least this high, or
--             the path scores its floor and cannot be dealt. This is how
--             TEAM_ROCKET's "grievance and hardship, not just ruthlessness"
--             is expressed, and how the rarest paths stay rare WITHOUT a die
--   transition "return" (may go back to the Gym Challenge), "defection", or
--             nil for a path nobody leaves
--   career    the working life: priorities over existing AI objectives (never
--             a second AI), the metrics it counts, its four ranks and the
--             totals between them, party size and catch bias, plus an optional
--             home (map-name substrings) and how much of the time it is out
--
-- The first sixteen rows carry the pre-4.7 numbers, transcribed mechanically
-- from the 4.6 tables rather than retyped (see the note above them), with TWO
-- deliberate exceptions, both recorded here because an undocumented tweak to a
-- balance number is indistinguishable from a mistake:
--
--   TYPE_SPECIALIST gained `style = { MONO_TYPE = 0.9 }`. Without it the row
--   was a strictly weaker GYM_ASSISTANT -- same two facts, less of both -- so
--   it could never be offered to anybody, and had not been since 2.4.
--   tests/lifepath_reach_test.lua is what found it.
--
--   AUCTIONEER, GAMBLER, INNKEEPER, CHEF, FARMER, MECHANIC, NURSE, ITEM_MAKER,
--   LIGHTHOUSE_KEEPER and APPRENTICE_SMITH are 4.7.0 rows that were written as
--   nine versions of one idea and crowded the legacy MART_WORKER out of its own
--   corner. They now each name a fact that says what the life is actually
--   about, rather than competing on the same axis.

local ROWS = {}

local function add(row) ROWS[#ROWS + 1] = row end

-- ------------------------------------------------------------------
-- The original sixteen (1.x-4.6). Numbers are load-bearing; do not tidy.
-- ------------------------------------------------------------------

-- These sixteen rows are TRANSCRIBED MECHANICALLY from the 4.6 tables, not
-- retyped. My first pass wrote them by hand from what I had read on screen and
-- got twelve of them wrong -- homes dropped, metrics renamed (which would have
-- orphaned every saved progress counter), promotion thresholds moved. Nobody
-- would have noticed from reading the file; the comparison script did. This is
-- lesson 14 pointed inward: do not hand-mirror a table you can generate.

add{ id = "BREEDER", label = "Breeder", blurb = "raising Pokemon",
  weights = { catch = 0.9, collection = 0.8 },
  style = { EVOLUTION = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "TRAIN", "EXPLORE" },
    metrics = { "raised", "caught", "evolved", "traded" },
    ranks = { "Novice Breeder", "Experienced Breeder", "Expert Breeder", "Master Breeder" },
    steps = { 8, 24, 60 }, partyTarget = 4, catchBias = 2.2 } }

add{ id = "RESEARCHER", label = "Researcher", blurb = "studying Pokemon",
  weights = { seen = 0.9, collection = 0.4 },
  style = { WEATHER = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "SEEK_GHOST", "EXPLORE", "TRAIN" },
    metrics = { "studied", "rare", "weatherSeen", "papers" },
    ranks = { "Field Observer", "Researcher", "Senior Researcher", "Leading Authority" },
    steps = { 10, 30, 70 }, partyTarget = 4, catchBias = 1.5 } }

add{ id = "OAK_ASSISTANT", label = "Oak's Assistant", blurb = "assisting Professor Oak",
  weights = { seen = 0.8, collection = 0.5 },
  transition = "return",
  career = {
    home = { "OAKS_LAB", "PROFESSOR", "LAB" }, fieldwork = 0.35,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "studied", "reported", "fieldTrips" },
    ranks = { "Researcher I", "Researcher II", "Senior Assistant", "Oak's Trusted Researcher" },
    steps = { 10, 30, 70 }, partyTarget = 3, catchBias = 1.4 } }

add{ id = "TOWER_CARETAKER", label = "Tower Caretaker", blurb = "tending the Pokemon Tower",
  weights = { ghost = 1.0, defeats = 0.5 },
  transition = "return",
  career = {
    home = { "POKEMONTOWER", "POKEMON_TOWER", "LAVENDER" }, fieldwork = 0.1,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "vigils", "helped", "ghosts" },
    ranks = { "Mourner", "Keeper", "Caretaker", "Guardian of the Tower" },
    steps = { 15, 40, 90 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "GHOST_RESEARCHER", label = "Ghost Researcher", blurb = "studying Ghost Pokemon",
  weights = { ghost = 1.4 },
  transition = "return",
  career = {
    home = { "POKEMONTOWER", "POKEMON_TOWER", "LAVENDER" }, fieldwork = 0.4,
    priorities = { "HEAL", "SEEK_GHOST", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "sightings", "ghosts", "papers" },
    ranks = { "Curious", "Ghost Student", "Ghost Researcher", "Authority on Ghosts" },
    steps = { 10, 30, 65 }, partyTarget = 4, catchBias = 1.3 } }

add{ id = "EXPLORER", label = "Explorer", blurb = "exploring Kanto",
  weights = { wander = 1.1, maps = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "areas", "rareFinds", "encounters" },
    ranks = { "Wanderer", "Pathfinder", "Trailblazer", "Master Explorer" },
    steps = { 12, 30, 55 }, partyTarget = 3, catchBias = 1 } }

add{ id = "GYM_ASSISTANT", label = "Gym Assistant", blurb = "helping run a Gym",
  weights = { badges = 0.8, fight = 0.4 },
  style = { MONO_TYPE = 0.3 },
  transition = "return",
  career = {
    home = { "GYM" }, fieldwork = 0.25,
    priorities = { "HEAL", "CAREER_HOME", "CHALLENGE_PLAYER", "TRAIN" },
    metrics = { "drills", "sparred", "studied" },
    ranks = { "Sweeper", "Gym Hand", "Gym Assistant", "Leader's Right Hand" },
    steps = { 12, 35, 80 }, partyTarget = 5, catchBias = 0.6 } }

add{ id = "CENTER_ASSISTANT", label = "Centre Assistant", blurb = "helping at the Pokemon Center",
  weights = { notFight = 0.7 },
  style = { DEFENSIVE = 0.3 },
  transition = "return",
  career = {
    home = { "POKECENTER", "POKEMON_CENTER", "CENTER", "CENTRE" }, fieldwork = 0.2,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "shifts", "healed", "advised" },
    ranks = { "Volunteer", "Assistant", "Senior Assistant", "Head Nurse" },
    steps = { 15, 40, 85 }, partyTarget = 3, catchBias = 0.5 } }

add{ id = "MART_WORKER", label = "Mart Worker", blurb = "working at the Poke Mart",
  weights = { wealth = 0.5, notFight = 0.3 },
  transition = "return",
  career = {
    home = { "MART", "DEPT_STORE" }, fieldwork = 0.3,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN", "EXPLORE" },
    metrics = { "shifts", "stocked", "advised" },
    ranks = { "New Hire", "Shop Assistant", "Senior Assistant", "Store Manager" },
    steps = { 15, 40, 85 }, partyTarget = 2, catchBias = 0.4 } }

add{ id = "RETIRED", label = "Retired", blurb = "taking it easy",
  weights = { defeats = 0.9, notBadges = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CHALLENGE_PLAYER", "TRAIN" },
    metrics = { "quietDays", "friendlies" },
    ranks = { "Retired", "Settled", "Local Fixture", "Old Hand" },
    steps = { 20, 60, 140 }, partyTarget = 2, catchBias = 0.25 } }

add{ id = "TEAM_ROCKET", label = "Team Rocket", blurb = "up to no good",
  weights = { fight = 0.4, hostile = 0.7, poverty = 0.6, defeats = 0.3 },
  requires = { hostile = 1.0 },
  transition = "defection",
  career = {
    home = { "ROCKET_HIDEOUT", "GAME_CORNER", "SILPH", "CELADON" }, fieldwork = 0.45,
    priorities = { "HEAL", "CHALLENGE_PLAYER", "CAREER_HOME", "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    metrics = { "missions", "encounters", "failures" },
    ranks = { "Recruit", "Grunt", "Specialist", "Executive Candidate" },
    steps = { 10, 30, 70 }, partyTarget = 5, catchBias = 1.1 } }

add{ id = "BATTLE_COACH", label = "Battle Coach", blurb = "coaching competitive trainers",
  weights = { fight = 0.8, badges = 0.5 },
  transition = "return",
  career = {
    home = { "GYM", "DOJO" }, fieldwork = 0.35,
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "CAREER_HOME", "TRAIN" },
    metrics = { "encounters", "studied", "raised" },
    ranks = { "Assistant Coach", "Coach", "Senior Coach", "Master Coach" },
    steps = { 12, 36, 82 }, partyTarget = 5, catchBias = 0.7 } }

add{ id = "RANGER", label = "Pokemon Ranger", blurb = "protecting wild Pokemon",
  weights = { wander = 0.7, catch = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "areas", "encounters", "rareFinds" },
    ranks = { "Trail Guard", "Ranger", "Senior Ranger", "Chief Ranger" },
    steps = { 12, 34, 76 }, partyTarget = 4, catchBias = 1.2 } }

add{ id = "COURIER", label = "Courier", blurb = "carrying parcels between towns",
  weights = { wander = 0.8, notFight = 0.3 },
  transition = "return",
  career = {
    home = { "MART", "CENTER", "CENTRE" }, fieldwork = 0.75,
    -- 4.7.0: CAREER_HOME sat after EXPLORE, so a courier never reported to a
    -- Mart or Centre -- dead code since 2.4, unchecked because COURIER was
    -- missing from the hand-written Career.IMPLEMENTED list.
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "areas", "encounters" },
    ranks = { "Runner", "Courier", "Route Captain", "Master Courier" },
    steps = { 15, 42, 90 }, partyTarget = 3, catchBias = 0.6 } }

add{ id = "PHOTOGRAPHER", label = "Photographer", blurb = "photographing rare Pokemon",
  weights = { seen = 0.8, wander = 0.5 },
  transition = "return",
  career = {
    -- Same latent bug: SEEK_GHOST after EXPLORE never fired.
    priorities = { "HEAL", "SEEK_GHOST", "EXPLORE", "TRAIN" },
    metrics = { "areas", "rareFinds", "encounters" },
    ranks = { "Shutterbug", "Photographer", "Photojournalist", "Master Photographer" },
    steps = { 12, 38, 84 }, partyTarget = 4, catchBias = 1 } }

add{ id = "TYPE_SPECIALIST", label = "Type Specialist", blurb = "mastering a single Pokemon type",
  -- 4.7.0: the style bonus is the point of this path and it never had one, so
  -- badges+fight made it a strictly weaker GYM_ASSISTANT and it could not be
  -- offered to anybody -- true since 2.4, invisible until reachability was
  -- measured. A specialist is somebody running one type; the model already
  -- reads that.
  weights = { badges = 0.5, fight = 0.4 },
  style = { MONO_TYPE = 0.9 },
  transition = "return",
  career = {
    home = { "GYM" }, fieldwork = 0.4,
    -- 4.7.0: TRAIN used to lead this list, which made CAREER_HOME, RIVAL_DUEL
    -- and GYM dead code -- a type specialist never reported to its Gym and
    -- never duelled. TYPE_SPECIALIST was not in the old hand-written
    -- Career.IMPLEMENTED list, so the fallback-last contract never checked it.
    -- The list now runs in the order it always meant to.
    priorities = { "HEAL", "CAREER_HOME", "RIVAL_DUEL", "GYM", "TRAIN" },
    metrics = { "raised", "evolved", "encounters" },
    ranks = { "Type Student", "Specialist", "Type Expert", "Type Master" },
    steps = { 14, 40, 88 }, partyTarget = 6, catchBias = 1.1 } }

-- ------------------------------------------------------------------
-- 4.7.0: the hundred. Grouped by the kind of life they are, which is also
-- roughly the order a player meets them in.
--
-- Every row below is reachable: `tests/lifepath_data_test.lua` builds a rival
-- for each and asserts it can be the top-ranked path for SOMEBODY, so a row
-- with weights nothing can satisfy fails the suite rather than sitting in the
-- file looking like content.
-- ------------------------------------------------------------------

add{ id = "LEGENDARY_HUNTER", label = "Legendary Hunter", blurb = "chasing legends",
  weights = { seen = 0.9, wander = 0.8, catch = 0.5 },
  requires = { maps = 0.35 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "sightings", "expeditions", "rareFinds" },
    ranks = { "Rumour Chaser", "Legend Seeker", "Legendary Hunter", "Keeper of Legends" },
    steps = { 14, 40, 90 }, partyTarget = 5, catchBias = 1.7 } }

add{ id = "CELEBI_AGENT", label = "Agent of Celebi", blurb = "keeping the shrine's watch",
  weights = { wander = 0.7, seen = 0.6, ghost = 0.5 },
  requires = { maps = 0.3 },
  transition = "return",
  career = {
    home = { "FOREST", "SHRINE" }, fieldwork = 0.5,
    priorities = { "HEAL", "SEEK_GHOST", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "vigils", "groves", "sightings" },
    ranks = { "初 Initiate", "Agent", "Voice of the Grove", "Keeper of the Shrine" },
    steps = { 10, 30, 70 }, partyTarget = 4, catchBias = 1.3 } }

add{ id = "ARCEUS_AMBASSADOR", label = "Ambassador of Arceus", blurb = "carrying a creed across Kanto",
  weights = { seen = 0.6, wander = 0.6, notFight = 0.5 },
  requires = { seen = 0.35 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "sermons", "pilgrims", "areas" },
    ranks = { "Pilgrim", "Envoy", "Ambassador", "Voice of the Original One" },
    steps = { 12, 34, 78 }, partyTarget = 4, catchBias = 0.9 } }

add{ id = "LEAGUE_CHAMPION", label = "League Champion", blurb = "defending the title",
  weights = { badges = 1.2, fight = 0.6 },
  requires = { badges = 0.95 },
  transition = nil,
  career = {
    home = { "INDIGO", "PLATEAU" }, fieldwork = 0.35,
    priorities = { "HEAL", "RIVAL_DUEL", "CHALLENGE_PLAYER", "CAREER_HOME", "TRAIN" },
    metrics = { "defences", "sparred", "challengers" },
    ranks = { "Title Holder", "Champion", "Reigning Champion", "Undisputed Champion" },
    steps = { 6, 18, 44 }, partyTarget = 6, catchBias = 0.7 } }

add{ id = "ELITE_ASPIRANT", label = "Elite Four Aspirant", blurb = "training for the Elite Four",
  weights = { badges = 0.9, fight = 0.6, defeats = 0.3 },
  requires = { badges = 0.7 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "runs", "sparred", "raised" },
    ranks = { "Hopeful", "Contender", "Aspirant", "Elite in Waiting" },
    steps = { 10, 30, 70 }, partyTarget = 6, catchBias = 0.7 } }

add{ id = "TOURNAMENT_CIRCUIT", label = "Tournament Regular", blurb = "living on the tournament circuit",
  weights = { fight = 0.9, wander = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    metrics = { "entries", "wins", "crowds" },
    ranks = { "Entrant", "Regular", "Circuit Star", "Circuit Legend" },
    steps = { 12, 34, 76 }, partyTarget = 6, catchBias = 0.8 } }

add{ id = "DUELIST", label = "Duelist", blurb = "answering every challenge",
  weights = { fight = 1.1 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "duels", "wins", "streaks" },
    ranks = { "Scrapper", "Duelist", "Master Duelist", "Undefeated" },
    steps = { 10, 30, 70 }, partyTarget = 6, catchBias = 0.6 } }

add{ id = "GYM_LEADER_HOPEFUL", label = "Gym Leader Hopeful", blurb = "building a Gym of their own",
  weights = { badges = 0.8, fight = 0.5, wealth = 0.3 },
  requires = { badges = 0.6 },
  transition = "return",
  career = {
    home = { "GYM" }, fieldwork = 0.3,
    priorities = { "HEAL", "CAREER_HOME", "RIVAL_DUEL", "TRAIN" },
    metrics = { "challengers", "sparred", "built" },
    ranks = { "Applicant", "Deputy", "Acting Leader", "Gym Leader" },
    steps = { 14, 40, 92 }, partyTarget = 6, catchBias = 0.8 } }

add{ id = "REMATCH_HUNTER", label = "Rematch Hunter", blurb = "chasing every trainer who beat them",
  weights = { fight = 0.7, defeats = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "rematches", "avenged", "sparred" },
    ranks = { "Sore Loser", "Rematch Hunter", "Debt Collector", "Nobody's Loss" },
    steps = { 8, 26, 60 }, partyTarget = 6, catchBias = 0.7 } }

add{ id = "UNDERDOG", label = "Underdog", blurb = "winning with less",
  weights = { defeats = 0.7, notBadges = 0.5, fight = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "upsets", "sparred", "raised" },
    ranks = { "Written Off", "Underdog", "Giant Killer", "Impossible" },
    steps = { 10, 28, 64 }, partyTarget = 4, catchBias = 0.9 } }

add{ id = "SPARRING_PARTNER", label = "Sparring Partner", blurb = "making other trainers better",
  weights = { fight = 0.72, notFight = 0.2, badges = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "sparred", "students", "drills" },
    ranks = { "Practice Foe", "Sparring Partner", "Trusted Partner", "The One Everyone Trains With" },
    steps = { 12, 32, 72 }, partyTarget = 5, catchBias = 0.8 } }

add{ id = "MONO_TYPE_PURIST", label = "Mono-Type Purist", blurb = "running one type and nothing else",
  weights = { badges = 0.74, catch = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "TRAIN", "EXPLORE" },
    metrics = { "raised", "evolved", "caught" },
    ranks = { "Convert", "Purist", "Devotee", "Absolute" },
    steps = { 12, 34, 78 }, partyTarget = 6, catchBias = 1.3 } }

add{ id = "STRATEGIST", label = "Battle Strategist", blurb = "solving battles on paper",
  weights = { fight = 0.5, seen = 0.5, badges = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "plans", "sparred", "studied" },
    ranks = { "Note Taker", "Strategist", "Tactician", "Grandmaster" },
    steps = { 12, 34, 78 }, partyTarget = 6, catchBias = 0.8 } }

add{ id = "SPEEDRUNNER_PATH", label = "Speedrunner", blurb = "doing it all faster",
  weights = { fight = 0.5, wander = 0.5, badges = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "GYM", "TRAIN" },
    metrics = { "splits", "records", "runs" },
    ranks = { "Timing It", "Speedrunner", "Record Holder", "World Record" },
    steps = { 10, 28, 64 }, partyTarget = 4, catchBias = 0.6 } }

add{ id = "SHINY_HUNTER", label = "Shiny Hunter", blurb = "hunting for shinies",
  weights = { catch = 0.9, wander = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "encounters", "shinies", "hours" },
    ranks = { "Hopeful", "Shiny Hunter", "Devoted Hunter", "Blessed" },
    steps = { 14, 42, 96 }, partyTarget = 4, catchBias = 2.0 } }

add{ id = "SAFARI_WARDEN", label = "Safari Warden", blurb = "working the Safari Zone",
  weights = { catch = 0.7, collection = 0.5 },
  transition = "return",
  career = {
    home = { "SAFARI" }, fieldwork = 0.4,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "patrols", "released", "guests" },
    ranks = { "Warden's Hand", "Warden", "Head Warden", "Master of the Zone" },
    steps = { 12, 34, 76 }, partyTarget = 5, catchBias = 1.6 } }

add{ id = "DAYCARE_KEEPER", label = "Day-Care Keeper", blurb = "minding other trainers' Pokemon",
  weights = { catch = 0.5, notFight = 0.6 },
  transition = "return",
  career = {
    home = { "DAYCARE", "DAY_CARE" }, fieldwork = 0.15,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "minded", "raised", "hatched" },
    ranks = { "Helper", "Keeper", "Senior Keeper", "Master of the Day-Care" },
    steps = { 12, 34, 78 }, partyTarget = 3, catchBias = 1.2 } }

add{ id = "FOSSIL_REVIVER", label = "Fossil Reviver", blurb = "bringing back the long dead",
  weights = { seen = 0.6, collection = 0.5, maps = 0.4 },
  transition = "return",
  career = {
    home = { "MUSEUM", "LAB" }, fieldwork = 0.45,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "digs", "revived", "studied" },
    ranks = { "Digger", "Fossil Handler", "Reviver", "Master of the Ancient" },
    steps = { 10, 30, 70 }, partyTarget = 4, catchBias = 1.2 } }

add{ id = "EEVEE_SPECIALIST", label = "Eevee Specialist", blurb = "following every branch of one line",
  weights = { catch = 0.72, collection = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "TRAIN", "EXPLORE" },
    metrics = { "evolved", "raised", "caught" },
    ranks = { "Curious", "Specialist", "Branch Master", "Keeper of Every Path" },
    steps = { 10, 30, 68 }, partyTarget = 5, catchBias = 1.5 } }

add{ id = "BUG_CATCHER_LIFE", label = "Career Bug Catcher", blurb = "never growing out of bug catching",
  weights = { catch = 0.8, notFight = 0.3 },
  transition = "return",
  career = {
    home = { "FOREST" }, fieldwork = 0.5,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "caught", "areas", "raised" },
    ranks = { "Net Swinger", "Bug Catcher", "Bug Maniac", "Lord of the Forest" },
    steps = { 12, 34, 78 }, partyTarget = 5, catchBias = 1.9 } }

add{ id = "FISHERMAN", label = "Fisherman", blurb = "fishing every water in Kanto",
  weights = { catch = 0.7, wander = 0.5, notFight = 0.2 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "casts", "caught", "waters" },
    ranks = { "Angler", "Fisherman", "Master Angler", "The One Who Waits" },
    steps = { 14, 40, 90 }, partyTarget = 4, catchBias = 1.7 } }

add{ id = "SURFER", label = "Surfer", blurb = "living on the water",
  weights = { wander = 0.8, catch = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "waters", "areas", "encounters" },
    ranks = { "Paddler", "Surfer", "Wave Rider", "Master of the Waves" },
    steps = { 12, 36, 80 }, partyTarget = 4, catchBias = 1.2 } }

add{ id = "MOUNTAINEER", label = "Mountaineer", blurb = "climbing what others walk around",
  weights = { wander = 0.9, maps = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "climbs", "peaks", "areas" },
    ranks = { "Scrambler", "Climber", "Mountaineer", "Conqueror of Peaks" },
    steps = { 12, 34, 76 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "CAVE_DWELLER", label = "Cave Dweller", blurb = "living underground",
  weights = { wander = 0.6, maps = 0.6, notFight = 0.2 },
  transition = "return",
  career = {
    home = { "CAVE", "TUNNEL", "MT_" }, fieldwork = 0.5,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "depths", "areas", "encounters" },
    ranks = { "Spelunker", "Cave Dweller", "Deep Walker", "Master of the Dark" },
    steps = { 12, 34, 78 }, partyTarget = 4, catchBias = 1.2 } }

add{ id = "NIGHT_WALKER", label = "Night Walker", blurb = "travelling only after dark",
  weights = { wander = 0.7, ghost = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "SEEK_GHOST", "EXPLORE", "TRAIN" },
    metrics = { "nights", "areas", "encounters" },
    ranks = { "Insomniac", "Night Walker", "Owl", "Keeper of the Small Hours" },
    steps = { 12, 34, 78 }, partyTarget = 4, catchBias = 1.3 } }

add{ id = "DEX_COMPLETIONIST", label = "Dex Completionist", blurb = "filling every last entry",
  weights = { collection = 1.0, seen = 0.7 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "caught", "studied", "entries" },
    ranks = { "Collector", "Completionist", "Near Complete", "Complete" },
    steps = { 16, 48, 110 }, partyTarget = 5, catchBias = 2.0 } }

add{ id = "TYPE_THEORIST", label = "Type Theorist", blurb = "working out what beats what",
  weights = { seen = 0.82, fight = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "studied", "papers", "plans" },
    ranks = { "Student", "Theorist", "Authority", "The Chart Itself" },
    steps = { 12, 34, 78 }, partyTarget = 5, catchBias = 1.0 } }

add{ id = "MOVE_TUTOR", label = "Move Tutor", blurb = "teaching moves for a living",
  weights = { seen = 0.6, badges = 0.4, notFight = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "taught", "students", "moves" },
    ranks = { "Assistant Tutor", "Move Tutor", "Renowned Tutor", "Master Tutor" },
    steps = { 12, 34, 78 }, partyTarget = 4, catchBias = 0.9 } }

add{ id = "BREEDING_THEORIST", label = "Breeding Theorist", blurb = "studying inheritance",
  weights = { catch = 0.6, collection = 0.6, seen = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "TRAIN", "EXPLORE" },
    metrics = { "hatched", "studied", "papers" },
    ranks = { "Note Keeper", "Theorist", "Authority", "Founder of a Field" },
    steps = { 12, 36, 80 }, partyTarget = 4, catchBias = 1.6 } }

add{ id = "WEATHER_WATCHER", label = "Weather Watcher", blurb = "following the weather",
  weights = { seen = 0.82, wander = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "weatherSeen", "areas", "studied" },
    ranks = { "Sky Watcher", "Weather Watcher", "Forecaster", "Reader of Skies" },
    steps = { 12, 34, 78 }, partyTarget = 4, catchBias = 1.1 } }

add{ id = "CARTOGRAPHER", label = "Cartographer", blurb = "mapping every road",
  weights = { maps = 1.0, wander = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "areas", "maps", "miles" },
    ranks = { "Sketcher", "Cartographer", "Surveyor", "Mapmaker of Kanto" },
    steps = { 14, 40, 90 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "HISTORIAN", label = "Historian", blurb = "writing down what happened",
  weights = { seen = 0.6, maps = 0.5, notFight = 0.3 },
  transition = "return",
  career = {
    home = { "MUSEUM", "LIBRARY" }, fieldwork = 0.4,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "records", "studied", "papers" },
    ranks = { "Scribe", "Historian", "Chronicler", "Keeper of the Record" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "ARCHIVIST", label = "League Archivist", blurb = "keeping the League's records",
  weights = { badges = 0.5, seen = 0.5, notFight = 0.4 },
  transition = "return",
  career = {
    home = { "INDIGO", "PLATEAU", "LEAGUE" }, fieldwork = 0.2,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "records", "filed", "studied" },
    ranks = { "Clerk", "Archivist", "Senior Archivist", "Master of the Archive" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.7 } }

add{ id = "STATISTICIAN", label = "Battle Statistician", blurb = "counting what everyone else guesses",
  weights = { fight = 0.4, seen = 0.72 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "recorded", "studied", "plans" },
    ranks = { "Tally Keeper", "Statistician", "Analyst", "The Numbers" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 0.8 } }

add{ id = "MERCHANT", label = "Travelling Merchant", blurb = "selling from town to town",
  weights = { wealth = 0.8, wander = 0.5 },
  transition = "return",
  career = {
    home = { "MART" }, fieldwork = 0.6,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "sold", "routes", "profit" },
    ranks = { "Pedlar", "Merchant", "Trader", "Merchant Prince" },
    steps = { 14, 40, 90 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "AUCTIONEER", label = "Auctioneer", blurb = "running the auction block",
  weights = { wealth = 0.62, notFight = 0.15, seen = 0.35 },
  transition = "return",
  career = {
    home = { "MART", "GAME_CORNER" }, fieldwork = 0.25,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "lots", "sold", "profit" },
    ranks = { "Caller", "Auctioneer", "Master of Ceremonies", "Legendary Gavel" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "TRADER", label = "Wonder Trader", blurb = "trading with anyone, anywhere",
  weights = { collection = 0.7, catch = 0.5, wander = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "traded", "caught", "partners" },
    ranks = { "Swapper", "Trader", "Renowned Trader", "Trader of Legend" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.6 } }

add{ id = "ITEM_MAKER", label = "Apricorn Crafter", blurb = "making things by hand",
  weights = { catch = 0.45, notFight = 0.35, wealth = 0.25 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "made", "sold", "gathered" },
    ranks = { "Apprentice", "Crafter", "Master Crafter", "Living Treasure" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.3 } }

add{ id = "HERBALIST", label = "Herbalist", blurb = "brewing bitter medicine",
  weights = { notFight = 0.6, wander = 0.4, collection = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "brewed", "gathered", "healed" },
    ranks = { "Gatherer", "Herbalist", "Master Herbalist", "Keeper of Old Recipes" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.1 } }

add{ id = "NURSE", label = "Centre Nurse", blurb = "healing whoever walks in",
  weights = { notFight = 0.7, badges = 0.15 },
  transition = "return",
  career = {
    home = { "POKECENTER", "POKEMON_CENTER" }, fieldwork = 0.15,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "healed", "shifts", "saved" },
    ranks = { "Trainee Nurse", "Nurse", "Senior Nurse", "Head Nurse" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.7 } }

add{ id = "MECHANIC", label = "Bike Mechanic", blurb = "keeping Kanto moving",
  weights = { notFight = 0.35, wealth = 0.35, maps = 0.25 },
  transition = "return",
  career = {
    home = { "BIKE", "SHOP" }, fieldwork = 0.2,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "repaired", "shifts", "built" },
    ranks = { "Grease Hand", "Mechanic", "Master Mechanic", "Miracle Worker" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.7 } }

add{ id = "SAILOR", label = "Sailor", blurb = "working the boats",
  weights = { wander = 0.94, fight = 0.3 },
  transition = "return",
  career = {
    home = { "SHIP", "PORT", "VERMILION" }, fieldwork = 0.55,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "voyages", "ports", "cargo" },
    ranks = { "Deckhand", "Sailor", "Bosun", "Captain" },
    steps = { 14, 40, 90 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "PILOT", label = "Sky Courier", blurb = "carrying urgent mail by air",
  weights = { wander = 0.92, notFight = 0.20 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "flights", "deliveries", "areas" },
    ranks = { "Fledgling", "Sky Courier", "Master Courier", "The Fastest Wings" },
    steps = { 14, 42, 94 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "PERFORMER", label = "Performer", blurb = "putting on a show",
  weights = { notFight = 0.4, seen = 0.62, wander = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "shows", "crowds", "applause" },
    ranks = { "Street Act", "Performer", "Headliner", "Star of Kanto" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.1 } }

add{ id = "IDOL", label = "Idol", blurb = "being adored",
  weights = { seen = 0.5, wealth = 0.4, notFight = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "shows", "fans", "appearances" },
    ranks = { "Local Favourite", "Idol", "Superstar", "Adored by Kanto" },
    steps = { 14, 42, 94 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "COMMENTATOR", label = "Battle Commentator", blurb = "calling other people's fights",
  weights = { fight = 0.4, seen = 0.72, notFight = 0.2 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "CAREER_HOME", "TRAIN" },
    metrics = { "calls", "matches", "crowds" },
    ranks = { "Ringside", "Commentator", "Voice of the League", "The Voice" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.7 } }

add{ id = "JOURNALIST", label = "Journalist", blurb = "chasing the story",
  weights = { seen = 0.7, wander = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "stories", "interviews", "areas" },
    ranks = { "Stringer", "Journalist", "Correspondent", "Editor at Large" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "STORYTELLER", label = "Storyteller", blurb = "telling it better than it happened",
  weights = { wander = 0.5, seen = 0.5, notFight = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "tales", "audiences", "areas" },
    ranks = { "Yarn Spinner", "Storyteller", "Bard", "Keeper of Tales" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "MUSICIAN", label = "Musician", blurb = "playing for whoever listens",
  weights = { notFight = 0.62, wander = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "sets", "crowds", "songs" },
    ranks = { "Busker", "Musician", "Composer", "Legend of the Stage" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "ARTIST", label = "Artist", blurb = "painting what they see",
  weights = { seen = 0.7, notFight = 0.4, wander = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "works", "subjects", "areas" },
    ranks = { "Sketcher", "Artist", "Renowned Artist", "Master" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.0 } }

add{ id = "CHEF", label = "Chef", blurb = "feeding trainers and Pokemon alike",
  weights = { notFight = 0.35, collection = 0.3, wealth = 0.35 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "served", "dishes", "guests" },
    ranks = { "Kitchen Hand", "Chef", "Head Chef", "Master Chef" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "OFFICER", label = "Police Officer", blurb = "keeping the peace",
  weights = { fight = 0.5, notFight = 0.3, maps = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "EXPLORE", "TRAIN" },
    metrics = { "patrols", "arrests", "calls" },
    ranks = { "Cadet", "Officer", "Detective", "Chief" },
    steps = { 12, 36, 82 }, partyTarget = 5, catchBias = 0.9 } }

add{ id = "DETECTIVE", label = "Detective", blurb = "following what does not add up",
  weights = { seen = 0.6, maps = 0.5, fight = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "cases", "solved", "leads" },
    ranks = { "Legwork", "Detective", "Renowned Detective", "The One Who Always Knows" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 0.9 } }

add{ id = "BODYGUARD", label = "Bodyguard", blurb = "standing between trouble and someone else",
  weights = { fight = 0.82, badges = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "guarded", "stopped", "clients" },
    ranks = { "Muscle", "Bodyguard", "Trusted Guard", "Unbreakable" },
    steps = { 12, 36, 82 }, partyTarget = 6, catchBias = 0.7 } }

add{ id = "BOUNTY_HUNTER", label = "Bounty Hunter", blurb = "collecting on other people's debts",
  weights = { fight = 0.7, wander = 0.5, poverty = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "EXPLORE", "TRAIN" },
    metrics = { "bounties", "caught", "paid" },
    ranks = { "Chaser", "Bounty Hunter", "Feared Hunter", "Nobody Runs" },
    steps = { 12, 36, 82 }, partyTarget = 6, catchBias = 0.9 } }

add{ id = "SMUGGLER", label = "Smuggler", blurb = "moving what should not move",
  weights = { poverty = 0.5, wander = 0.72, wealth = 0.3 },
  requires = { poverty = 1.0 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "runs", "cargo", "evaded" },
    ranks = { "Mule", "Smuggler", "Ghost Route", "Untouchable" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "ROCKET_EXECUTIVE", label = "Rocket Executive", blurb = "running Rocket operations",
  weights = { fight = 0.6, hostile = 0.8, wealth = 0.4 },
  requires = { hostile = 1.0, fight = 0.5 },
  transition = "defection",
  career = {
    home = { "ROCKET", "GAME_CORNER" }, fieldwork = 0.5,
    priorities = { "HEAL", "RIVAL_DUEL", "CAREER_HOME", "TRAIN", "EXPLORE" },
    metrics = { "operations", "taken", "feared" },
    ranks = { "Executive", "Senior Executive", "Boss's Right Hand", "Second Only to the Boss" },
    steps = { 10, 30, 70 }, partyTarget = 6, catchBias = 1.1 } }

add{ id = "ROCKET_DEFECTOR", label = "Rocket Defector", blurb = "living down what they did",
  weights = { defeats = 0.64, notFight = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "TRAIN", "EXPLORE" },
    metrics = { "amends", "helped", "quiet" },
    ranks = { "Runaway", "Defector", "Forgiven", "Made Good" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "VIGILANTE", label = "Vigilante", blurb = "doing what the officers will not",
  weights = { hostile = 0.6, fight = 0.7 },
  requires = { hostile = 1.0 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "EXPLORE", "TRAIN" },
    metrics = { "stopped", "patrols", "feared" },
    ranks = { "Watcher", "Vigilante", "Feared Vigilante", "Legend of the Backstreets" },
    steps = { 12, 36, 82 }, partyTarget = 6, catchBias = 0.9 } }

add{ id = "SWORN_RIVAL", label = "Sworn Rival", blurb = "living to beat one person",
  weights = { fight = 0.8, jealousy = 0.9, hostile = 0.4 },
  requires = { jealousy = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "duels", "wins", "obsession" },
    ranks = { "Fixated", "Sworn Rival", "Obsessed", "Defined by Them" },
    steps = { 10, 28, 64 }, partyTarget = 6, catchBias = 0.7 } }

add{ id = "AVENGER", label = "Avenger", blurb = "paying somebody back",
  weights = { betrayal = 1.0, fight = 0.6 },
  requires = { betrayal = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "hunted", "avenged", "sparred" },
    ranks = { "Wounded", "Avenger", "Implacable", "Never Forgets" },
    steps = { 10, 28, 64 }, partyTarget = 6, catchBias = 0.8 } }

add{ id = "RECLUSE", label = "Recluse", blurb = "keeping away from everyone",
  weights = { fear = 0.9, notFight = 0.6, wander = 0.3 },
  requires = { fear = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "solitude", "areas", "quiet" },
    ranks = { "Withdrawn", "Recluse", "Hermit", "Unreachable" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.1 } }

add{ id = "PROTECTOR", label = "Protector", blurb = "keeping one person safe",
  weights = { kinship = 0.9, fight = 0.5 },
  requires = { kinship = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "STAY_CLOSE", "RIVAL_DUEL", "TRAIN" },
    metrics = { "guarded", "together", "stopped" },
    ranks = { "Watchful", "Protector", "Shield", "Would Stand Anywhere" },
    steps = { 10, 30, 70 }, partyTarget = 6, catchBias = 0.8 } }

add{ id = "FAMILY_TRAINER", label = "Family Trainer", blurb = "training alongside family",
  weights = { kinship = 1.0, notFight = 0.3 },
  requires = { kinship = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "STAY_CLOSE", "TRAIN", "EXPLORE" },
    metrics = { "together", "raised", "shared" },
    ranks = { "Sibling", "Family Trainer", "Family Pride", "The Family Name" },
    steps = { 12, 34, 78 }, partyTarget = 5, catchBias = 1.2 } }

add{ id = "MENTOR_PATH", label = "Mentor", blurb = "raising the next one up",
  weights = { mentorship = 1.0, badges = 0.4 },
  requires = { mentorship = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "TRAIN" },
    metrics = { "taught", "students", "raised" },
    ranks = { "Teaching", "Mentor", "Beloved Mentor", "Teacher of Champions" },
    steps = { 12, 34, 78 }, partyTarget = 5, catchBias = 0.9 } }

add{ id = "DISCIPLE", label = "Disciple", blurb = "following someone better",
  weights = { mentorship = 0.9, notBadges = 0.3 },
  requires = { mentorship = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "STAY_CLOSE", "TRAIN" },
    metrics = { "lessons", "copied", "raised" },
    ranks = { "Follower", "Disciple", "Star Pupil", "Surpassed the Teacher" },
    steps = { 10, 30, 70 }, partyTarget = 5, catchBias = 1.0 } }

add{ id = "DEVOTED_PARTNER", label = "Devoted Partner", blurb = "travelling with the one they love",
  weights = { devotion = 1.0, notFight = 0.3 },
  requires = { devotion = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "STAY_CLOSE", "TRAIN", "EXPLORE" },
    metrics = { "together", "shared", "miles" },
    ranks = { "Inseparable", "Partner", "Devoted", "Two Halves" },
    steps = { 12, 34, 78 }, partyTarget = 5, catchBias = 1.0 } }

add{ id = "PEACEMAKER", label = "Peacemaker", blurb = "talking other people down",
  weights = { notFight = 0.8, mentorship = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "settled", "spoken", "calm" },
    ranks = { "Interceder", "Peacemaker", "Trusted Voice", "The One They Listen To" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 0.9 } }

add{ id = "LONER", label = "Loner", blurb = "needing nobody",
  weights = { wander = 0.7, notFight = 0.3, fear = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "solitude", "areas", "encounters" },
    ranks = { "Aloof", "Loner", "Solitary", "Alone by Choice" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.1 } }

add{ id = "SHRINE_KEEPER", label = "Shrine Keeper", blurb = "tending an old shrine",
  weights = { ghost = 0.6, notFight = 0.5 },
  transition = "return",
  career = {
    home = { "SHRINE", "TOWER" }, fieldwork = 0.25,
    priorities = { "HEAL", "CAREER_HOME", "SEEK_GHOST", "TRAIN" },
    metrics = { "vigils", "offerings", "visitors" },
    ranks = { "Sweeper", "Keeper", "Head Keeper", "Voice of the Shrine" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "SPIRIT_MEDIUM", label = "Spirit Medium", blurb = "speaking for the dead",
  weights = { ghost = 1.2, notFight = 0.3 },
  requires = { ghost = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "SEEK_GHOST", "CAREER_HOME", "TRAIN" },
    metrics = { "seances", "ghosts", "comforted" },
    ranks = { "Sensitive", "Medium", "Great Medium", "Speaker for the Dead" },
    steps = { 10, 30, 70 }, partyTarget = 4, catchBias = 1.2 } }

add{ id = "CULTIST", label = "Cult Devotee", blurb = "believing something the rest do not",
  weights = { ghost = 0.62, hostile = 0.3, defeats = 0.4 },
  transition = "defection",
  career = {
    priorities = { "HEAL", "SEEK_GHOST", "EXPLORE", "TRAIN" },
    metrics = { "rites", "converts", "vigils" },
    ranks = { "Novice", "Devotee", "Zealot", "Prophet" },
    steps = { 12, 36, 82 }, partyTarget = 5, catchBias = 1.0 } }

add{ id = "PROPHET", label = "Doomsayer", blurb = "warning anyone who listens",
  weights = { defeats = 0.6, wander = 0.5, ghost = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "warnings", "listeners", "signs" },
    ranks = { "Muttering", "Doomsayer", "Heeded", "Proved Right" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "MOON_WATCHER", label = "Moon Watcher", blurb = "waiting on Mt Moon",
  weights = { ghost = 0.5, seen = 0.5, maps = 0.4 },
  transition = "return",
  career = {
    home = { "MT_MOON" }, fieldwork = 0.4,
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "vigils", "sightings", "nights" },
    ranks = { "Camper", "Watcher", "Moon Scholar", "Keeper of the Crater" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.3 } }

add{ id = "RUIN_SEEKER", label = "Ruin Seeker", blurb = "reading walls nobody else can",
  weights = { maps = 0.7, seen = 0.6 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "ruins", "glyphs", "areas" },
    ranks = { "Trespasser", "Ruin Seeker", "Decipherer", "Reader of the Old Walls" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.1 } }

add{ id = "DRAGON_SEEKER", label = "Dragon Seeker", blurb = "looking for dragons",
  weights = { seen = 0.6, wander = 0.6, fight = 0.4 },
  requires = { badges = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "RIVAL_DUEL", "EXPLORE", "TRAIN" },
    metrics = { "sightings", "trials", "raised" },
    ranks = { "Aspirant", "Dragon Seeker", "Dragon Tamer", "Dragon Master" },
    steps = { 14, 40, 90 }, partyTarget = 5, catchBias = 1.3 } }

add{ id = "BEAST_TRACKER", label = "Beast Tracker", blurb = "tracking the three that run",
  weights = { wander = 0.9, seen = 0.7 },
  requires = { maps = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "tracks", "sightings", "areas" },
    ranks = { "Follower of Tracks", "Tracker", "Master Tracker", "Never Loses the Trail" },
    steps = { 14, 42, 94 }, partyTarget = 4, catchBias = 1.5 } }

add{ id = "FARMER", label = "Berry Farmer", blurb = "growing what everyone else buys",
  weights = { notFight = 0.4, collection = 0.55, maps = 0.15 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "harvests", "planted", "sold" },
    ranks = { "Smallholder", "Farmer", "Master Grower", "Feeds a Region" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.0 } }

add{ id = "INNKEEPER", label = "Innkeeper", blurb = "keeping a room ready",
  weights = { notFight = 0.45, wealth = 0.3, maps = 0.35 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "guests", "nights", "meals" },
    ranks = { "Host", "Innkeeper", "Renowned Host", "Everybody's Second Home" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "TEACHER", label = "School Teacher", blurb = "teaching children before they set out",
  weights = { notFight = 0.7, seen = 0.4 },
  transition = "return",
  career = {
    home = { "SCHOOL" }, fieldwork = 0.15,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "taught", "pupils", "terms" },
    ranks = { "Assistant", "Teacher", "Senior Teacher", "Beloved Teacher" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.8 } }

add{ id = "LIGHTHOUSE_KEEPER", label = "Lighthouse Keeper", blurb = "keeping a light on",
  weights = { notFight = 0.35, ghost = 0.55, wander = 0.15 },
  transition = "return",
  career = {
    home = { "LIGHTHOUSE" }, fieldwork = 0.15,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "nights", "ships", "repairs" },
    ranks = { "Relief Keeper", "Keeper", "Head Keeper", "The Light Itself" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "GARDENER", label = "Gardener", blurb = "keeping things growing",
  weights = { notFight = 0.7, collection = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "planted", "tended", "seasons" },
    ranks = { "Hand", "Gardener", "Head Gardener", "Master of the Garden" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.1 } }

add{ id = "HERMIT", label = "Hermit", blurb = "living apart on purpose",
  weights = { wander = 0.5, notFight = 0.6, defeats = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "solitude", "seasons", "quiet" },
    ranks = { "Withdrawing", "Hermit", "Old Hermit", "Legend of the Hills" },
    steps = { 14, 42, 94 }, partyTarget = 2, catchBias = 0.9 } }

add{ id = "PILGRIM", label = "Pilgrim", blurb = "walking to every holy place",
  weights = { wander = 0.82, maps = 0.30, notFight = 0.20 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "shrines", "miles", "areas" },
    ranks = { "Setting Out", "Pilgrim", "Long Walker", "Has Walked It All" },
    steps = { 14, 42, 94 }, partyTarget = 3, catchBias = 0.9 } }

add{ id = "COLLECTOR_OF_ODDITIES", label = "Collector of Oddities", blurb = "collecting the strange",
  weights = { collection = 0.7, seen = 0.5, wealth = 0.3 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "oddities", "traded", "found" },
    ranks = { "Magpie", "Collector", "Renowned Collector", "Owner of Impossible Things" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.5 } }

add{ id = "GAMBLER", label = "Gambler", blurb = "living on the Game Corner floor",
  weights = { wealth = 0.45, poverty = 0.70, fight = 0.25 },
  transition = "return",
  career = {
    home = { "GAME_CORNER" }, fieldwork = 0.2,
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "bets", "won", "lost" },
    ranks = { "Chancer", "Gambler", "High Roller", "Knows When to Stop" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 1.0 } }

add{ id = "SCAVENGER", label = "Scavenger", blurb = "living off what others drop",
  weights = { poverty = 0.7, maps = 0.5, wander = 0.5 },
  transition = "return",
  career = {
    priorities = { "HEAL", "EXPLORE", "TRAIN" },
    metrics = { "finds", "sold", "areas" },
    ranks = { "Picker", "Scavenger", "Sharp Eye", "Finds What Nobody Else Does" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.2 } }

add{ id = "VOLUNTEER", label = "Volunteer", blurb = "helping wherever it is needed",
  weights = { notFight = 0.7, wander = 0.4 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "EXPLORE", "TRAIN" },
    metrics = { "helped", "shifts", "towns" },
    ranks = { "Willing Hand", "Volunteer", "Pillar", "Everyone Knows Their Name" },
    steps = { 12, 36, 82 }, partyTarget = 3, catchBias = 1.0 } }

add{ id = "APPRENTICE_SMITH", label = "Apprentice Smith", blurb = "learning a trade with fire",
  weights = { fight = 0.4, wealth = 0.35, notFight = 0.2 },
  transition = "return",
  career = {
    priorities = { "HEAL", "CAREER_HOME", "TRAIN" },
    metrics = { "made", "repaired", "learned" },
    ranks = { "Bellows", "Apprentice", "Journeyman", "Master Smith" },
    steps = { 12, 36, 82 }, partyTarget = 4, catchBias = 0.9 } }

return ROWS
