local req, mod = ...
local Util = req("src/Util")
local Travel = req("src/Travel")
local CatchMotivation = req("src/CatchMotivation")
local BattleSim = req("src/BattleSim")
local RivalNuzlocke = req("src/RivalNuzlocke")

-- THE DECIDER.
--
-- One function matters: AI.evaluate(rival, world).  It runs on a rival's
-- objective tick (not every frame, not every world tick -- see
-- src/Simulation.lua), consults the personality's priority list, and sets
-- exactly two fields: rival.objective and rival.destination (plus, for the
-- SEEK_GHOST detour, which ghost it is after -- rival.ghostTarget -- and for
-- RIVAL_DUEL, which rival it is after -- rival.rivalTarget).
-- Everything downstream -- routing, walking, gym attempts, encounters -- is a
-- consequence of those.
--
-- The state machine is deliberately boring:
--
--   objective            state while working toward it   arrival
--   HEAL              -> HEALING                      -> heal, re-evaluate
--   CHALLENGE_PLAYER  -> SEEKING_PLAYER               -> CHALLENGING_PLAYER
--   GYM               -> SEEKING_GYM                  -> CHALLENGING_GYM
--   TRAIN             -> TRAVELLING then TRAINING     -> grind, re-evaluate
--   EXPLORE           -> TRAVELLING then EXPLORING    -> wander, re-evaluate
--   SEEK_GHOST        -> SEEKING_GHOST                -> CHALLENGING_GHOST
--   RIVAL_DUEL        -> SEEKING_RIVAL                -> CHALLENGING_RIVAL
--   (eight badges)    -> LEAGUE_READY
--
-- TRAVELLING is the shared "I am not there yet" state, so a debug readout of
-- (state, destination) is always enough to explain what a rival is doing.
-- There is no hidden state and no timer that changes behaviour silently: the
-- only thing a state can do on its own is time out and re-evaluate.
--
-- SEEK_GHOST is the one objective with a third written field: rival.ghostTarget
-- carries WHICH ghost it is after, because the destination is that ghost's map
-- and the party to fight rides on the ghost, not on the map.

local AI = {}

-- ------------------------------------------------------------------
-- Weather (weather_fx interop)
-- ------------------------------------------------------------------
-- weather_fx publishes its current sky through mod.exports.weather() and this
-- mod never reads another mod's internals, but a sky is only real to a rival
-- that is exposed to it: weather_fx's own "indoors and covered frames answer
-- nil" rule is the shelter rule here, and a rival NOT on the player's map is
-- nowhere the player's weather exists, so it plays neutral.  The edge is
-- therefore a LOCAL effect -- two rivals standing beside the player fight
-- differently in the same sun, and a rival a region away is unaffected.
--
-- Since 4.0 "typed weather" every weather carries a chipType -- the Gen-1
-- type it favours and the type that is immune to its residual chip.  These
-- tables mirror that catalogue (smog is POISON, a dragonstorm is DRAGON, a
-- psystorm is PSYCHIC, and so on), keyed by the OVERWORLD id
-- exports.weather() returns.  MIST/FOG carry no chipType but still draw out
-- Ghosts in the encounter bias, which is why they map to GHOST here.
-- Weird weather is not listed and is neutral; a new sky id never crashes a
-- rival, it just has no opinion.

local WEATHER_FAVOUR = {
  -- the classic families
  SUNNY = "FIRE", HARSH_SUN = "FIRE", HEATWAVE = "FIRE", ASHFALL = "FIRE",
  RAIN_LIGHT = "WATER", RAIN_HEAVY = "WATER", HEAVY_RAIN = "WATER",
  STORM = "ELECTRIC", THUNDERSNOW = "ELECTRIC",
  SNOW_LIGHT = "ICE", BLIZZARD = "ICE", HAIL = "ICE", SLEET = "ICE",
  SANDSTORM = "ROCK", DUSTSTORM = "GROUND",
  STRONG_WINDS = "FLYING", FLOCKSTORM = "FLYING", GALE = "FLYING",
  -- the typed fronts
  PLAIN_FRONT = "NORMAL", VERDANT_RAIN = "GRASS", BRAWL_WIND = "FIGHTING",
  SMOG = "POISON", SWARM = "BUG", HAUNTED_MIST = "GHOST",
  DRAGONSTORM = "DRAGON", PSYSTORM = "PSYCHIC",
  -- the fog family draws Ghosts out, exactly like the encounter bias
  MIST = "GHOST", FOG = "GHOST",
}

-- The classic power rows' HURT side, keyed by overworld id (SUNNY slows
-- WATER moves, a wet sky slows FIRE moves).  A typed weather has no single
-- hurt type -- it chips every non-matching team instead -- so those are
-- covered by the no-match rule in weatherEdge, not by this table.
local WEATHER_WEAK = {
  SUNNY = "WATER", HARSH_SUN = "WATER", HEATWAVE = "WATER",
  RAIN_LIGHT = "FIRE", RAIN_HEAVY = "FIRE", HEAVY_RAIN = "FIRE",
  STORM = "FIRE", GALE = "FIRE",
}

-- How much the current sky over the player's map moves this rival's
-- confidence, as a multiplier on its strength estimate.  1 when weather_fx
-- is absent, the sky is unknown/neutral, or the rival is sheltering (not on
-- the player's map).
--
-- A team the sky favours fights bolder; a team it fights plays it safer.
-- "Fights it" means either the classic weakened type (water under a sun) or
-- -- for the typed weathers -- any team that does not match the sky's type
-- at all, because the residual chip wears that team down every turn.
function AI.weatherEdge(rival, world)
  world = world or {}
  local compat = world.compat or (rival.ctx and rival.ctx.compat)
  if not compat or not compat:weather() then return 1 end
  if not (world.playerMap and world.playerMap == rival.map) then return 1 end
  local id = compat:weatherId()
  local fav = WEATHER_FAVOUR[id]
  if not fav then return 1 end
  local weak = WEATHER_WEAK[id]
  local hasFav, hasWeak = false, false
  local function canonical(t) return t == "PSYCHIC_TYPE" and "PSYCHIC" or t end
  fav, weak = canonical(fav), canonical(weak)
  for _, slot in ipairs(rival.party or {}) do
    local def = rival:speciesDef(slot.species)
    for _, t in ipairs(BattleSim.typesOf(def)) do
      t = canonical(t)
      if t == fav then hasFav = true end
      if weak and t == weak then hasWeak = true end
    end
  end
  if hasFav then return 1.10 end
  if hasWeak then return 0.90 end
  return 0.90
end

-- ------------------------------------------------------------------
-- Preconditions
-- ------------------------------------------------------------------
-- Each returns true when the objective is available AND worth taking.  They
-- never mutate the rival: AI.evaluate does all the writing, in one place, so
-- a wrong decision is readable from one function.

local Can = {}

function Can.HEAL(rival)
  if #rival.party == 0 then return false end
  if rival.needsCounterVisit and rival:needsCounterVisit() then return true end
  if rival.needsGymPrepVisit and rival:needsGymPrepVisit() then return true end
  -- A Nuzlocke challenger treats supplies as survival equipment. If its next
  -- route catch is still open but it owns no ball, a mart/Center visit outranks
  -- grinding. It also heals far earlier than an ordinary rival.
  if RivalNuzlocke.isActive(rival) and rival.bestBall and not rival:bestBall() then return true end
  local normal = rival.personality.healAt or 0.3
  return rival:healthFraction() < RivalNuzlocke.cautiousHealThreshold(rival, normal)
end

function Can.CHALLENGE_PLAYER(rival, world)
  if not world.playerMap then return false end
  if (rival.encounterCooldown or 0) > 0 then return false end
  if #rival.party == 0 then return false end
  if RivalNuzlocke.isActive(rival) and not RivalNuzlocke.battleReady(rival, 0.80) then return false end
  -- a rival that cannot win does not pick a fight, unless its personality
  -- says it never does that arithmetic (CHALLENGER's playerConfidence is nil)
  local floor = rival.personality.playerConfidence
  if RivalNuzlocke.isActive(rival) then floor = math.max(tonumber(floor) or 0, 1.12) end
  if floor then
    local against = world.playerParty or {}
    if #against > 0 then
      local ratio = BattleSim.confidence(rival.ctx.data, rival.party, against)
      -- the sky over the player's map moves the estimate when they share it
      ratio = ratio * AI.weatherEdge(rival, world)
      if ratio * (rival.confidence or 1) < floor then return false end
    end
  end
  return true
end

function Can.GYM(rival, world)
  local gym, badge = rival:nextGym()
  if not (gym and badge) then return false end
  if (rival.gymCooldown or 0) > 0 then return false end
  -- Rivals may be at most Rival.BADGE_LEAD gyms ahead of the player, so they
  -- progress alongside them instead of racing to the Elite Four while the
  -- player is still clearing Pewter.
  --
  -- 3.2.0: the reading is stored on the rival and the DECISION is made by
  -- Rival:mayEarnBadge, which attemptGym also calls. Two copies of this rule
  -- could disagree -- and did: this site read `world.playerBadges`, which the
  -- simulation's per-tick ctx never carried, so it silently compared against 0
  -- while the manager's own path compared against the real count.
  if tonumber(world and world.playerBadges) then
    rival.playerPaceBadges = math.max(0, math.floor(world.playerBadges))
  end
  if rival.mayEarnBadge and not rival:mayEarnBadge() then return false end
  if #rival.party == 0 then return false end
  local minParty = rival.minimumPartyForNextGym and rival:minimumPartyForNextGym() or 1
  -- Catch-up is about entering real battles sooner, not receiving free wins.
  -- A four-badge player must not have every rival indefinitely catching a
  -- third Pokémon before anybody has even attempted Brock/Falkner.
  if rival.catchUpMode then minParty = 1 end
  if #rival.party < minParty then return false end
  if not rival.ctx.graph:has(gym.map) then return false end
  -- A gym behind Cut/Surf/etc. is not a viable objective until this rival's
  -- own active party can perform the field move and an allowed route exists.
  if rival.missingHMForMap and rival:missingHMForMap(gym.map) then return false end
  if rival.routeTo and not rival:routeTo(gym.map) then return false end
  -- health first: walking into Brock at 20% is a loss the rival could see
  if rival:healthFraction() < (RivalNuzlocke.isActive(rival) and 0.78 or 0.6) then return false end
  -- Three Pokémon is the explicit first-Gym readiness threshold. Once a
  -- badge-less rival reaches it, confidence/personality may no longer talk
  -- them into grinding forever. Cooldown, health, HM and real routing checks
  -- above still apply, so a loss produces recovery rather than a battle loop.
  local firstGymReady = rival:badgeCount() == 0 and #rival.party >= 3
  if firstGymReady and not RivalNuzlocke.isActive(rival) then return true end
  -- Each previous failure at THIS badge raises the bar by 12%.  A rival's
  -- own estimate of a gym is allowed to be wrong; what it is not allowed to
  -- do is be wrong the same way indefinitely.
  local attempts = rival.gymAttempts[badge] or 0
  local bar = (rival.personality.gymConfidence or 0.9) * (1 + 0.12 * attempts)
  -- Failed attempts still encourage ordinary rivals to improve. A badly
  -- trailing rival, however, must eventually test that improvement against
  -- the leader instead of raising an unreachable confidence threshold while
  -- its level ceiling prevents any further growth.
  if rival.catchUpMode and not RivalNuzlocke.isActive(rival) then bar = math.min(bar, 0.72) end
  bar = RivalNuzlocke.gymConfidenceBar(rival, bar)
  local ratio = AI.gymConfidence(rival, gym) * AI.weatherEdge(rival, world)
  return ratio >= bar
end

-- Training is for closing a gap.  A rival already at the ceiling for the gym
-- it is chasing has closed it, and grinding past that point is how a rival
-- ends a playthrough at L100 with one badge (the soak run's original result).
-- It still trains when its team is too SMALL, because a Collector wanting six
-- Pokemon has a real reason to be out in the grass.
function Can.TRAIN(rival)
  if #rival.party == 0 then return false end
  if rival:atLevelCeiling() then
    return CatchMotivation.needsPokemon(rival)
  end
  return true
end

function Can.EXPLORE(rival)
  -- Three badges behind is the soft floor. Do not fabricate progress; simply
  -- stop choosing leisure exploration until real training/travel closes it.
  if rival and rival.catchUpMode then return false end
  return true
end

-- 2.3.0: report for work.
--
-- A located career (§8, §10, §11, §13-15) has a home BUILDING, and §24 forbids
-- teleporting a rival into it: this routes there through the same graph, the
-- same progression gates and the same hop clock as any other journey.
--
-- It is deliberately not always-true, so it does not become the always-true
-- objective the 1.14 lesson warns about:
--   * a career with no home in this game (no lab on Gold, no Tower in a
--     conversion) can never select it, and the rival works to the rest of its
--     list instead;
--   * a rival already AT its post does not re-select it, or it would never do
--     anything else while standing in the doorway;
--   * and a share of the time it is out doing fieldwork, because a career
--     rival that never leaves its building is scenery rather than a character.
function Can.RANGER_MISSION(rival, world)
  local manager = rival.ctx and rival.ctx.manager
  local rangers = manager and manager.rangers
  if not rangers or rival.rocketAffiliation then return false end
  if rival:isFainted() or rival:healthFraction() < (RivalNuzlocke.isActive(rival) and 0.72 or 0.55) then return false end
  local mission = rangers:aiMissionFor(rival, world)
  if not mission then return false end
  return rival.rng:chance(0.90)
end

function Can.CAREER_HOME(rival, world)
  if type(rival.careerHome) ~= "function" then return false end
  local home = rival:careerHome()
  if not home then return false end
  if rival.map == home then return false end
  if not rival:canEnterMap(home) then return false end
  if not rival.ctx.graph:has(home) then return false end
  -- fieldwork: some of the time it has somewhere else to be
  local away = rival.careerFieldwork and rival:careerFieldwork() or 0
  if away > 0 and rival.rng:chance(away) then return false end
  return true
end

-- silph-scope interop: a rival occasionally walks to a ghost and fights it
-- headlessly (see Simulation.attemptGhost).  The result stays LOCAL -- no
-- shared file is written, no ghost is moved, this mod only watches.  Hard
-- gates first, then the personality's ghostChance roll, so absent mod or no
-- reachable ghost costs nothing and the objective is a detour, not a job.
function Can.SEEK_GHOST(rival, world)
  local compat = (world and world.compat) or (rival.ctx and rival.ctx.compat)
  if not compat or not compat:silph() then return false end
  if #rival.party == 0 then return false end
  if (rival.ghostCooldown or 0) > 0 then return false end
  if rival:healthFraction() < (RivalNuzlocke.isActive(rival) and 0.78 or 0.5) then return false end
  local ghostChance = rival.personality.ghostChance or 0.15
  if RivalNuzlocke.isActive(rival) then ghostChance = ghostChance * 0.35 end
  if not rival.rng:chance(ghostChance) then
    return false
  end
  local ghosts = compat:ghosts()
  if type(ghosts) ~= "table" or #ghosts == 0 then return false end
  for _, g in ipairs(ghosts) do
    if type(g) == "table" and type(g.mapId) == "string"
       and rival.ctx.graph:has(g.mapId) then
      return true
    end
  end
  return false
end

-- Rival-vs-rival duels (1.11.0): a rival occasionally seeks out another
-- rival and fights it for money.  Gated like every detour -- a roll, then
-- reachability -- so a rival with nobody to reach simply does not pick the
-- objective, and the same cooldown as the map-shared skirmish keeps duels
-- and skirmishes from stacking.
function Can.RIVAL_DUEL(rival, world)
  if (rival.rivalFightCooldown or 0) > 0 then return false end
  if #rival.party == 0 then return false end
  if rival:healthFraction() < (RivalNuzlocke.isActive(rival) and 0.85 or 0.5) then return false end
  if rival.map == "OAKS_LAB" or rival.map == "PALLET_TOWN" then return false end
  local duelChance = rival.personality.duelChance or 0.08
  if RivalNuzlocke.isActive(rival) then duelChance = duelChance * 0.35 end
  if not rival.rng:chance(duelChance) then
    return false
  end
  local rivals = (world and world.rivals) or {}
  for _, other in ipairs(rivals) do
    if other and other ~= rival and other.id ~= rival.id
       and other.map and other.map ~= "OAKS_LAB" and other.map ~= "PALLET_TOWN"
       and #other.party > 0 and rival.ctx.graph:has(other.map) then
      return true
    end
  end
  return false
end

-- 4.7.0: STAY_CLOSE as a REAL objective, not only the lovers clause above.
--
-- Four of the new careers are about being near somebody -- a protector, a
-- sibling, a disciple, a devoted partner -- and career_test rightly refuses a
-- priority list naming an objective the AI cannot evaluate. Rather than let
-- those careers list a word that does nothing, the objective exists: same
-- question (`closeCompanionId`), same guards, reachable from a priority list.
function Can.STAY_CLOSE(rival, world)
  if #rival.party == 0 then return false end
  if rival:healthFraction() < 0.5 then return false end
  if not rival.closeCompanionId then return false end
  local id = rival:closeCompanionId(world and world.rivals, world and world.tick)
  if not id then return false end
  for _, other in ipairs((world and world.rivals) or {}) do
    if other and other.id == id and other.map and other.map ~= rival.map
       and rival.ctx.graph:has(other.map) then
      return true
    end
  end
  return false
end

-- How strong this rival is relative to the gym it is aiming at.  Prefers the
-- leader's REAL party out of the merged trainers table (Gen 1 `parties` or a
-- Gen 2 member's `party`); falls back to the level hint in data/gyms.lua only
-- when the class is missing (an unimported cache, or a boot whose classes are
-- named differently).
function AI.gymConfidence(rival, gym)
  local data = rival.ctx.data
  local party = BattleSim.leaderParty(data, gym.class, gym.party or 1)
  if party and #party > 0 then
    return BattleSim.confidence(data, rival.party, party)
  end
  local level = gym.level or 20
  local mine = BattleSim.strength(data, rival.party)
  return mine / math.max(1, level)
end

-- ------------------------------------------------------------------
-- Destinations
-- ------------------------------------------------------------------

local Destination = {}

function Destination.HEAL(rival)
  local centers = rival.ctx.healingMaps
  if not centers or #centers == 0 then return rival.map end
  local id = rival.ctx.graph:nearest(rival.map, centers)
  return id or rival.map
end

function Destination.CHALLENGE_PLAYER(rival, world)
  return world.playerMap
end

function Destination.GYM(rival)
  local gym = rival:nextGym()
  if not gym then return rival.map end
  -- route to the CITY first when the gym's own map is not directly reachable
  -- from here; a gym is behind a door, and the door is in the town
  if rival.ctx.graph:route(rival.map, gym.map) then return gym.map end
  return gym.city
end

function Destination.RANGER_MISSION(rival)
  local manager = rival.ctx and rival.ctx.manager
  local rangers = manager and manager.rangers
  if rangers and rival.rangerMissionId then
    for _, mission in ipairs(rangers.missions or {}) do
      if mission.id == rival.rangerMissionId and mission.active ~= false then
        return mission.map
      end
    end
  end
  local mission = rangers and rangers:aiMissionFor(rival, {})
  return mission and mission.map or rival.map
end

function Destination.TRAIN(rival)
  -- A hunt is a real travel goal: go to a loaded encounter map where the
  -- target actually appears instead of waiting indefinitely on the wrong
  -- route and merely hoping it turns up.
  if rival.huntTarget and rival.huntMap
     and rival.ctx.graph:route(rival.map, rival.huntMap) then
    return rival.huntMap
  end
  local spots = rival.ctx.trainingMaps
  if not spots or #spots == 0 then return rival.map end
  -- train near where you are going, not near where you are: a rival grinding
  -- for Misty should drift toward Cerulean rather than back to Route 1
  local gym = rival:nextGym()
  local anchor = (gym and rival.ctx.graph:has(gym.city) and gym.city)
    or rival.map
  local best, bestLen
  for _, id in ipairs(spots) do
    local route = rival.routeTo and rival:routeTo(id)
      or rival.ctx.graph:route(anchor, id)
    if route then
      -- a little randomness so four rivals do not all pick Route 1
      local len = #route + rival.rng:int(0, 2)
      if not bestLen or len < bestLen then best, bestLen = id, len end
    end
  end
  return best or rival.map
end

function Destination.CAREER_HOME(rival)
  return (rival.careerHome and rival:careerHome()) or rival.map
end

function Destination.EXPLORE(rival)
  local graph = rival.ctx.graph
  local options = graph:neighbours(rival.map)
  local allowed = {}
  for _, edge in ipairs(options) do
    if rival:canEnterMap(edge.to) then allowed[#allowed + 1] = edge end
  end
  if #allowed == 0 then return rival.map end
  -- 1.37.0 §18: a rival that likes the current sky lingers where it can use
  -- it, and one the sky is wearing down heads indoors or onward.
  --
  -- Expressed as WEIGHTING over the same neighbour list, drawn with the same
  -- single rng:int call, so pre-1.37 saves replay identically. Weather FX has
  -- no per-map forecast to consult -- weather is global and it changes on its
  -- own schedule -- so this deliberately does not pretend to know where the
  -- rain is. What it models is the honest thing: a rival enjoying the weather
  -- takes fewer detours, and one suffering in it moves along.
  if #allowed > 1 and rival.weatherAffinity then
    local affinity = rival:weatherAffinity()
    if affinity ~= 0 then
      local weighted = {}
      for _, edge in ipairs(allowed) do
        local copies = 1
        local indoors = type(edge.to) == "string"
          and (edge.to:find("CENTER") or edge.to:find("MART")
               or edge.to:find("GYM") or edge.to:find("HOUSE"))
        if affinity < -0.25 and indoors then copies = 3
        elseif affinity > 0.25 and not indoors then copies = 2 end
        for _ = 1, copies do weighted[#weighted + 1] = edge end
      end
      if #weighted > 0 then allowed = weighted end
    end
  end
  -- 5.2.0 SPREAD. The weather block above already copies edges to weight
  -- them, so the style bias uses the same mechanism -- integer copies drawn
  -- with the SAME single rng:int call, no second roll and no float maths in
  -- the draw. What changes is how many copies of each neighbour are in the
  -- bag, not how many times the dice are rolled (§13).
  --
  -- This is what stops the convoy: a map another rival is standing on, or
  -- heading to, gets fewer copies; a VANGUARD gets more of whatever is
  -- further out; a WANDERER gets more of whatever it has not seen.
  if #allowed > 1 then
    local style = rival.travelStyle or Travel.styleOf(rival.personality)
    local ctx = {
      crowding = Travel.crowding(world and world.rivals, rival.id),
      visited = rival.visitedMaps,
      distanceFromPlayer = world and world.distanceFromPlayer,
    }
    local weighted = {}
    for _, edge in ipairs(allowed) do
      -- 1..4 copies. Rounded UP so a heavily penalised neighbour keeps one
      -- copy and can still be chosen: zero copies is a ban, and a ban can
      -- strand a rival whose only legal exit is occupied (§6).
      local w = Travel.weight(style, edge.to, ctx)
      local copies = math.max(1, math.min(4, math.floor(w * 2 + 0.5)))
      for _ = 1, copies do weighted[#weighted + 1] = edge end
    end
    if #weighted > 0 then allowed = weighted end
  end
  local edge = allowed[rival.rng:int(1, #allowed)]
  return edge and edge.to or rival.map
end

-- The ghost record being sought, or nil.  A random REACHABLE ghost: a target
-- the graph cannot reach would strand the rival in a travel state it can
-- never satisfy.  The caller writes rival.ghostTarget from this and routes to
-- the record's mapId.
function Destination.SEEK_GHOST(rival, world)
  local compat = (world and world.compat) or (rival.ctx and rival.ctx.compat)
  local ghosts = compat and compat:ghosts()
  if type(ghosts) ~= "table" then return nil end
  local reachable = {}
  for _, g in ipairs(ghosts) do
    if type(g) == "table" and type(g.mapId) == "string"
       and rival.ctx.graph:has(g.mapId) then
      reachable[#reachable + 1] = g
    end
  end
  if #reachable == 0 then return nil end
  return reachable[rival.rng:int(1, #reachable)]
end

-- The rival being dueled, or nil.  A random REACHABLE other rival: a target
-- the graph cannot reach would strand the challenger in a travel state it
-- can never satisfy.  The caller writes rival.rivalTarget from this and
-- routes to the target's map.
function Destination.STAY_CLOSE(rival, world)
  local id = rival.closeCompanionId
    and rival:closeCompanionId(world and world.rivals, world and world.tick)
  for _, other in ipairs((world and world.rivals) or {}) do
    if other and other.id == id and other.map then return other.map end
  end
  return rival.map
end

function Destination.RIVAL_DUEL(rival, world)
  local rivals = (world and world.rivals) or {}
  local reachable = {}
  for _, other in ipairs(rivals) do
    if other and other ~= rival and other.id ~= rival.id
       and other.map and other.map ~= "OAKS_LAB" and other.map ~= "PALLET_TOWN"
       and #other.party > 0 and rival.ctx.graph:has(other.map) then
      reachable[#reachable + 1] = other
    end
  end
  if #reachable == 0 then return nil end
  -- 1.33.0: WHO a rival crosses Kanto to fight is a relationship decision.
  -- The list is weighted by fight bias (a feud gets two or three entries, an
  -- ally one) and then drawn with the SAME single rng:int call as before, so
  -- the rival's own stream advances identically and older saves replay.
  -- A single candidate short-circuits: weighting one entry would otherwise
  -- turn a zero-draw int(1,1) into a real draw and shift the sequence.
  if #reachable == 1 then return reachable[1] end
  if rival.fightBiasToward then
    local weighted = {}
    for _, other in ipairs(reachable) do
      local bias = rival:fightBiasToward(other.id, world and world.tick)
      local copies = math.max(1, math.min(3, math.floor(bias * 2 + 0.5)))
      for _ = 1, copies do weighted[#weighted + 1] = other end
    end
    if #weighted > 0 then reachable = weighted end
  end
  return reachable[rival.rng:int(1, #reachable)]
end

-- ------------------------------------------------------------------
-- The objective tick
-- ------------------------------------------------------------------

local OBJECTIVE_STATE = {
  HEAL = "HEALING",
  CHALLENGE_PLAYER = "SEEKING_PLAYER",
  GYM = "SEEKING_GYM",
  TRAIN = "TRAVELLING",
  EXPLORE = "TRAVELLING",
  SEEK_GHOST = "SEEKING_GHOST",
  CAREER_HOME = "TRAVELLING",
  RIVAL_DUEL = "SEEKING_RIVAL",
  STAY_CLOSE = "TRAVELLING",
}

local function reasonFor(rival, objective, destination)
  if objective == "HEAL" then
    if rival.counterTarget then
      return "Visiting a Poké Center to prepare for " .. Util.spaced(rival.counterTarget)
    elseif rival.needsGymPrepVisit and rival:needsGymPrepVisit() then
      return "Visiting a Poké Center to prepare for the next Gym"
    end
    return "Healing an injured team"
  end
  if objective == "GYM" then
    local gym = rival:nextGym()
    return "Preparing to challenge " .. tostring(gym and gym.leader or "the next Gym")
  end
  if objective == "TRAIN" then return "Training for the next Gym" end
  if objective == "EXPLORE" then return "Exploring " .. Util.spaced(destination) end
  if objective == "CHALLENGE_PLAYER" then return "Looking for the player" end
  if objective == "SEEK_GHOST" then return "Investigating a ghost sighting" end
  if objective == "RIVAL_DUEL" then return "Seeking a rival battle" end
  if objective == "STAY_CLOSE" then return "Staying close to someone" end
  if objective == "CAREER_HOME" then
    -- §22: what a passer-by would say, never the career's identifier.
    local blurb = rival.careerBlurb and rival:careerBlurb()
    return blurb and ("Heading back to " .. Util.spaced(destination)
      .. " -- " .. blurb) or ("Heading to " .. Util.spaced(destination))
  end
  if objective == "LEAGUE" then return "Training for the Pokémon League" end
  return "Taking a break"
end

-- world = { playerMap, playerParty, tick }
function AI.evaluate(rival, world)
  world = world or {}
  if not rival then return nil end
  rival.ticks = (rival.ticks or 0) + 1

  -- Personality / graph must exist; a half-loaded rival must not take the tick down
  if type(rival.personality) ~= "table" then
    local personalities = rival.ctx and rival.ctx.personalities
    rival.personality = (personalities and personalities[rival.personalityId])
      or (personalities and personalities.CHALLENGER)
      or { priorities = { "TRAIN", "EXPLORE" }, wanderChance = 0.1,
           gymConfidence = 0.9, trainRate = 1, healAt = 0.3, partyTarget = 4 }
  end
  if not (rival.ctx and rival.ctx.graph) then
    return nil
  end

  -- A loaded save can contain a team from an older release. Enforce the
  -- current progression ceiling before making any new decision.
  pcall(function() rival:enforceLevelCeiling() end)

  -- HM soft-lock recovery outranks optional goals. If the next required route
  -- needs a field move with no compatible active user, hunt a compatible
  -- species in a reachable grass table and expose that reason to the UI.
  local hm = rival.neededHMForProgress and rival:neededHMForProgress()
  if hm then
    local fresh = not rival.hmGoal or rival.hmGoal ~= hm
      or not rival.huntTarget or not rival.huntMap
    if fresh and rival.pickHmHuntTarget
       and (not rival.hmSearchAfter or rival.ticks >= rival.hmSearchAfter) then
      rival:pickHmHuntTarget(hm)
      rival.hmSearchAfter = rival.ticks + 12
    end
    if rival.huntTarget and rival.huntMap then
      rival.objective = "TRAIN"
      rival:setState("TRAVELLING", "finding an HM user")
      rival:setDestination(rival.huntMap)
      rival.travelReason = "Hunting " .. Util.spaced(rival.huntTarget)
        .. " for " .. Util.spaced(hm)
      if fresh and world.log then
        world.log(rival, { kind = "hm_hunt", move = hm,
                           species = rival.huntTarget })
      end
      return rival.objective
    end
    rival.hmGoal = hm
    rival.objective = "TRAIN"
    rival:setState("TRAINING", "needs a compatible HM user")
    rival.travelReason = "Needs a Pokémon that can learn " .. Util.spaced(hm)
    return rival.objective
  elseif rival.hmGoal then
    rival.hmGoal = nil
    rival.hmGoalForced = false
    rival.hmSearchAfter = nil
  end

  -- cooldowns are the only thing that ticks unconditionally, so a rival that
  -- lost to Brock really does have to wait before trying again
  if (rival.gymCooldown or 0) > 0 then
    rival.gymCooldown = rival.gymCooldown - 1
  end
  if (rival.encounterCooldown or 0) > 0 then
    rival.encounterCooldown = rival.encounterCooldown - 1
  end
  if (rival.ghostCooldown or 0) > 0 then
    rival.ghostCooldown = rival.ghostCooldown - 1
  end

  -- the terminal objective: eight badges and it stops asking.
  --
  -- 2.2.0: ...unless this rival has stopped asking for a different reason. A
  -- breeder with eight badges is not queuing for the Elite Four, and a rival
  -- that left the Gym Challenge before earning them has no nextBadge() to
  -- report anyway -- so the career check comes FIRST, or a careered rival
  -- would be routed to Victory Road the moment its ladder ran out.
  if rival.pursuesBadges and not rival:pursuesBadges() then
    -- fall through to the career's own priority list below
  elseif not rival:nextBadge() then
    rival:setState("LEAGUE_READY", "all badges")
    rival.objective = "LEAGUE"
    local league = rival.activeLeague and rival:activeLeague() or rival.ctx.gyms.league
    local target = league and league.map
    if target and rival.ctx.graph:has(target) then
      rival:setDestination(target)
    elseif league and rival.ctx.graph:has(league.city) then
      rival:setDestination(league.city)
    end
    rival.travelReason = reasonFor(rival, "LEAGUE", rival.destination)
    return rival.objective
  end

  -- a rival with a wiped party is DEFEATED until it has healed; that is a
  -- real state rather than an instant recovery
  if rival:isFainted() then
    if rival.warpToLastPokemonCenter and rival:warpToLastPokemonCenter() then
      rival.objective = "HEAL"
      return rival.objective
    end
    rival:setState("DEFEATED", "party fainted")
    rival.objective = "HEAL"
    rival:setDestination(Destination.HEAL(rival))
    rival:setState("HEALING", "recovering")
    rival.travelReason = reasonFor(rival, "HEAL", rival.destination)
    return rival.objective
  end

  -- First badge progression outranks relationships, missions, wandering and
  -- personality priorities as soon as the rival has built a three-Pokémon
  -- team. They still walk to the Gym normally and Can.GYM retains every
  -- safety/legality gate.
  if rival:badgeCount() == 0 and #rival.party >= 3 and Can.GYM(rival, world) then
    rival.objective = "GYM"
    rival:setState(OBJECTIVE_STATE.GYM, "first Gym ready")
    rival:setDestination(Destination.GYM(rival, world) or rival.map)
    rival.travelReason = reasonFor(rival, "GYM", rival.destination)
    return rival.objective
  end

  -- 4.6.0: TWO RIVALS WHO ARE INSEPARABLE ACTUALLY TRAVEL TOGETHER.
  --
  -- Christopher asked that lovers "always try to stay close together", and a
  -- relationship the player can only read about in a menu is not one the world
  -- contains. So a rival in a mutual LOVERS pair routes to its partner's map.
  --
  -- This is deliberately NOT added to the personality priority lists. There are
  -- eight of them plus a generated pool, so an objective added that way is nine
  -- edits and a tenth place to forget; and more importantly the pair state is
  -- not a preference, it is a fact about two rivals that outranks preference.
  -- It sits here, below the badge terminal and the HM recovery -- being in love
  -- does not excuse a fainted party or a soft-locked route -- and above the
  -- wander roll, because a detour is exactly what it should displace.
  --
  -- The guards are what keep it from freezing the world: only when both are
  -- free, only when they are actually apart, only when the partner's map is
  -- reachable (so pacing and HM gates still apply -- routing is the normal
  -- routing), and never while either is mid-gym, healing or at the League.
  local partner = not rival.catchUpMode and rival.partnerAmong
    and rival:partnerAmong(world and world.rivals, world and world.tick)
  if partner and partner.map and partner.map ~= rival.map
     and rival.ctx.graph:has(partner.map)
     and not rival:isFainted()
     and rival:healthFraction() >= 0.5
     and rival.state ~= "CHALLENGING_GYM" and rival.state ~= "SEEKING_GYM"
     and rival.state ~= "LEAGUE_READY" and rival.state ~= "HEALING" then
    rival.objective = "STAY_CLOSE"
    rival.partnerId = partner.id
    rival:setState("TRAVELLING", "staying close to " .. tostring(partner.name))
    rival:setDestination(partner.map)
    rival.travelReason = "Travelling to " .. tostring(partner.name)
    return rival.objective
  end
  rival.partnerId = nil

  -- 5.5.0: Ranger anti-Rocket work is a strongly preferred civic objective.
  -- It is deliberately outside personality priority lists so every rival can
  -- participate, but the 72% roll means it is a preference, not a prison.
  local manager = rival.ctx and rival.ctx.manager
  local rangers = manager and manager.rangers
  if not rival.catchUpMode and rangers and not rival.rocketAffiliation
     and Can.RANGER_MISSION(rival, world) then
    local mission = rangers:aiMissionFor(rival, world)
    if mission and rangers:takeAIMission(rival, mission) then
      rival.objective = "RANGER_MISSION"
      rival:setState("TRAVELLING", "Ranger anti-Rocket operation")
      rival:setDestination(mission.map)
      rival.travelReason = "Helping Rangers stop Team Rocket"
      return rival.objective
    end
  end

  -- the wander roll: a personality-weighted chance of taking a detour instead
  -- of the priority list's answer.  This is what stops four rivals converging
  -- on the same route forever, and it is the only nondeterminism in the pick.
  -- 5.2.0: the SAME single roll, against a style-biased chance. Biasing the
  -- threshold rather than adding a second roll keeps the stream identical in
  -- length, so an existing save's rival does not desync (§13) -- it only
  -- changes where its own threshold sits.
  --
  -- A WANDERER genuinely detours more than a VANGUARD now. Before this, every
  -- personality shared one wander chance and the whole roster drifted the
  -- same way.
  local style = Travel.styleOf(rival.personality)
  rival.travelStyle = style
  if rival.rng:chance(Travel.wanderChance(style, rival.personality.wanderChance or 0))
     and Can.EXPLORE(rival, world) then
    rival.objective = "EXPLORE"
    rival:setState("TRAVELLING", "detour")
    rival:setDestination(Destination.EXPLORE(rival, world))
    rival.travelReason = reasonFor(rival, "EXPLORE", rival.destination)
    return rival.objective
  end

  -- 2.2.0: a rival on a career works to ITS objective order, not its
  -- personality's. Everything below is unchanged -- a career is a different
  -- priority list over the objectives that already exist, never a second AI,
  -- so it inherits every fix this loop has accumulated rather than repeating
  -- the bugs (bidirectional warps, destination-is-current-map, always-true
  -- objectives placed early) that this loop already learned.
  local priorities = rival.objectivePriorities and rival:objectivePriorities()
    or rival.personality.priorities
  -- Catch-up mode used to suppress EXPLORE and nothing else. Personalities
  -- with TRAIN first could therefore spend an entire four-badge playthrough
  -- building a preferred six-mon roster without attempting the first Gym.
  -- Preserve real travel/training/battles, but make the badge journey the
  -- authoritative order until the rival is within two badges of the player.
  if rival.catchUpMode and (not rival.pursuesBadges or rival:pursuesBadges()) then
    priorities = { "HEAL", "GYM", "TRAIN" }
  end
  for _, objective in ipairs(priorities) do
    local can = Can[objective]
    if can and can(rival, world) then
      rival.objective = objective
      rival:setState(OBJECTIVE_STATE[objective] or "TRAVELLING", objective)
      local destination = Destination[objective]
      local dest = destination and destination(rival, world)
      -- SEEK_GHOST and RIVAL_DUEL are the objectives whose destination is a
      -- RECORD (a ghost / another rival), not a map id: the rival remembers
      -- WHICH one so the fight at arrival uses the right party.  Everything
      -- else routes by map id.
      if objective == "SEEK_GHOST" then
        rival.ghostTarget = dest
        rival:setDestination(dest and dest.mapId or rival.map)
      elseif objective == "RIVAL_DUEL" then
        rival.rivalTarget = dest
        rival:setDestination(dest and dest.map or rival.map)
      else
        rival:setDestination(dest or rival.map)
      end
      rival.travelReason = reasonFor(rival, objective, rival.destination)
      return objective
    end
  end

  rival.objective = "IDLE"
  rival:setState("IDLE", "nothing to do")
  rival.travelReason = reasonFor(rival, "IDLE", rival.map)
  return rival.objective
end

-- Called when a rival reaches its destination; decides what arriving means.
-- Split out from evaluate so the simulation can arrive a rival without
-- re-running the whole priority list, and so the transition is testable.
function AI.onArrive(rival, world)
  if rival.recordPokemonCenterVisit then rival:recordPokemonCenterVisit() end
  -- 3.5.0: a Center visit is the HEALING ACTION, not merely a destination
  -- marker. Healing was left to Simulation.tickRival, so between arriving and
  -- the next tick a rival stood in the Pokemon Center still reading as
  -- FAINTED -- and anything that asked in that window (the menu, an
  -- interaction, a challenge) got the wrong answer.
  if rival.isAtPokemonCenter and rival:isAtPokemonCenter() then
    pcall(function()
      if rival.heal then rival:heal() end
      rival.gymCooldown = math.max(0, (rival.gymCooldown or 0) - 2)
    end)
  end
  local objective = rival.objective
  if objective == "GYM" then
    local gym = rival:nextGym()
    if gym and rival.map == gym.map then
      rival:setState("CHALLENGING_GYM", "at the gym")
    elseif gym then
      -- reached the city, now go through the door
      rival:setDestination(gym.map)
      rival:setState("SEEKING_GYM", "finding the door")
    end
  elseif objective == "HEAL" then
    -- Leave the rival in HEALING for Simulation.tickRival to process.  Keeping
    -- the whole centre visit in one place ensures PC management, shopping,
    -- duplicate sales and TM use happen as well as the heal itself.
    rival.gymCooldown = math.max(0, (rival.gymCooldown or 0) - 2)
    rival:setState("HEALING", "using the Poké Center")
    return "HEALING"
  elseif objective == "TRAIN" then
    rival:setState("TRAINING", "arrived at training ground")
  elseif objective == "EXPLORE" then
    rival:setState("EXPLORING", "arrived")
  elseif objective == "SEEK_GHOST" then
    local compat = (world and world.compat) or (rival.ctx and rival.ctx.compat)
    local ghost = rival.ghostTarget
    -- the ghost may be gone (silph unloaded, its list changed): arriving at an
    -- empty patch is just a detour, not a stuck state
    if compat and compat:silph() and ghost and ghost.mapId == rival.map then
      rival:setState("CHALLENGING_GHOST", "found the ghost")
    else
      rival.ghostTarget = nil
      rival:setState("IDLE", "no ghost here")
    end
  elseif objective == "RIVAL_DUEL" then
    local target = rival.rivalTarget
    -- the target may have moved on or been removed: arriving at an empty
    -- spot is just a detour, never a stuck state
    if target and target.map and target.map == rival.map then
      rival:setState("CHALLENGING_RIVAL",
                     "found " .. tostring(target.name or target.id))
    else
      rival.rivalTarget = nil
      rival:setState("IDLE", "no rival here")
    end
  elseif objective == "RANGER_MISSION" then
    local manager = rival.ctx and rival.ctx.manager
    local rangers = manager and manager.rangers
    local mission = rangers and rangers.missionForMap(rangers, rival.map)
    if mission and mission.assignedRivalId == rival.id then
      rival:setState("RANGER_MISSION", "engaging Team Rocket")
    else
      rival:setState("IDLE", "Ranger operation unavailable")
    end
  elseif objective == "CHALLENGE_PLAYER" then
    rival:setState("CHALLENGING_PLAYER", "found the player")
  else
    rival:setState("IDLE", "arrived")
  end
  return rival.objective
end

-- Whether this rival, standing on the player's map right now, actually walks
-- over and challenges them.  Personality first, then the confidence gate,
-- then a roll -- so a Speedrunner mostly ignores you and a Challenger mostly
-- does not.
function AI.wantsToChallenge(rival, world)
  if (rival.encounterCooldown or 0) > 0 then return false end
  if #rival.party == 0 then return false end
  if rival.state == "HEALING" or rival.state == "DEFEATED" then return false end
  if not Can.CHALLENGE_PLAYER(rival, world) then return false end
  local chance = (rival.personality.challengeChance or 0.25)
    * Util.clamp(rival.confidence or 1, 0.5, 1.5)
  -- 1.33.0: a rival that has come to respect the player picks fewer fights
  -- with them; one nursing a rivalry picks more.  Applied to the CHANCE
  -- rather than as a second roll, so no extra draw enters the stream.
  if rival.fightBiasToward then
    chance = chance * rival:fightBiasToward("player", world and world.tick)
  end
  return rival.rng:chance(Util.clamp(chance, 0, 1))
end

AI.Can = Can
AI.Destination = Destination

return AI
