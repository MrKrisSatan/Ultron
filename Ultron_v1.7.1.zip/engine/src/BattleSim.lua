local req, mod = ...
local Util = req("src/Util")

-- OFF-SCREEN BATTLE RESOLUTION
--
-- When a rival fights a Gym Leader on the far side of Kanto, no battle screen
-- can exist -- the player is standing somewhere else and the engine has
-- exactly one battle stack.  So this resolves that fight without rendering
-- it.  What it is NOT is a second battle engine: it never touches
-- BattleState, never builds a Pokemon, and produces a result plus damage
-- taken, nothing more.  Every battle the PLAYER can see goes through the real
-- engine (see src/Encounters.lua).
--
-- What it models, in order of how much the outcome depends on it:
--
--   * levels and real base stats, through the engine's own Stats.calc
--   * type effectiveness, off the merged type_chart, dual types included
--   * move power and STAB, off the merged moves table
--   * Gen 1's physical/special split BY TYPE, not by move
--   * speed deciding turn order
--   * party size and switch-on-faint
--
-- What it deliberately does not model: status, PP, accuracy misses, crits,
-- items, stat stages, and the AI's switching. Those change which turn a
-- battle ends on far more than whether it is won, and every one of them costs
-- a table lookup per turn on a phone.  The damage roll is the real one
-- (217..255)/255, drawn from the rival's own deterministic RNG, so a fight is
-- reproducible from a save rather than being a coin flip that re-rolls on
-- every load.
--
-- Accuracy check: run against the real Gym parties, a rival at the level the
-- vanilla game expects wins roughly 6 fights in 10 -- which is the point.  A
-- rival that always won would be a cutscene.

local BattleSim = {}

local function savedOn(saveKey,optionKey)
  local ok,v=pcall(function() return mod.save:get(saveKey) end)
  if ok and v~=nil then return v==true or v=="on" end
  ok,v=pcall(function() return mod.options:get(optionKey) end)
  return ok and (v==true or v=="on") or false
end

local function specialSplitOn()
  return savedOn("world_special_split_enabled","worldSpecialSplit")
end

local function physicalSplitOn()
  return savedOn("world_physical_split_enabled","worldPhysicalSplit")
end

-- Gen 1 splits physical from special by TYPE (engine/battle/core.asm).
local SPECIAL_TYPES = {
  FIRE = true, WATER = true, GRASS = true, ELECTRIC = true,
  PSYCHIC = true, PSYCHIC_TYPE = true, ICE = true, DRAGON = true,
  DARK = true, FAIRY = true,
}

local FALLBACK_BASE = { hp = 55, attack = 55, defense = 55,
                        speed = 55, special = 55 }

-- Trainer DVs in Gen 1 are a fixed 0x9888 pattern; using the same value for
-- both sides means the simulation is not quietly biased for or against the
-- rival by a DV roll it never made.
local DVS = { attack = 9, defense = 8, speed = 8, special = 8, hp = 8 }

-- ------------------------------------------------------------------
-- Data access, all defensive
-- ------------------------------------------------------------------

local function speciesDef(data, species)
  return data and ((data.gen2Pokemon and data.gen2Pokemon[species])
    or (data.pokemon and data.pokemon[species])) or nil
end

-- The party a gym leader fields, read off whichever trainers shape the loaded
-- game has.  Gen 1 keys records flat (data.trainers[class]) with a `parties`
-- list; Gen 2 nests them under data.gen2Trainers.classes and hangs rosters off
-- a `trainers` MEMBER list, each row a `party`.  One defensive walk covers
-- both.  nil means "no resolvable party", which callers treat as a refusal
-- rather than a coin flip.
function BattleSim.leaderParty(data, class, partyIndex)
  if not (class and data) then return nil end
  local trainers = data.trainers
  local record = trainers and (trainers[class]
    or (trainers.classes and trainers.classes[class]))
  if not record then
    trainers = data.gen2Trainers
    record = trainers and (trainers[class]
      or (trainers.classes and trainers.classes[class]))
  end
  if not record then return nil end
  if type(record.parties) == "table" then
    return record.parties[partyIndex or 1]
  end
  local member = record.trainers and record.trainers[partyIndex or 1]
  return member and member.party or nil
end

function BattleSim.typesOf(def)
  if not def then return { "NORMAL" } end
  if type(def.types) == "table" and #def.types > 0 then return def.types end
  local out = {}
  if def.type1 then out[#out + 1] = def.type1 end
  if def.type2 and def.type2 ~= def.type1 then out[#out + 1] = def.type2 end
  if #out == 0 then out[1] = "NORMAL" end
  return out
end

-- [attacker][defender] -> x10 multiplier, built once per data table.  Cached
-- on the data table itself under a private key so a hot reload that swaps
-- `data` gets a fresh index for free.
local CHART_KEY = "__ai_rivals_chart"

local function chart(data)
  local existing = rawget(data or {}, CHART_KEY)
  if existing then return existing end
  local index = {}
  local matchups = data and data.type_chart and data.type_chart.matchups
  for _, m in ipairs(matchups or {}) do
    index[m.attacker] = index[m.attacker] or {}
    index[m.attacker][m.defender] = m.multiplier
  end
  if data then rawset(data, CHART_KEY, index) end
  return index
end

-- x10 combined multiplier.  Each matchup row applies independently and floors
-- separately, which is what makes Gen 1's 20 * 5 land on neutral.
function BattleSim.effectiveness(data, moveType, defenderTypes)
  local index = chart(data)
  local row = index[moveType]
  if not row then return 10 end
  local mult = 10
  for _, dt in ipairs(defenderTypes or {}) do
    local m = row[dt]
    if m then mult = math.floor(mult * m / 10) end
  end
  return mult
end

-- ------------------------------------------------------------------
-- Combatants
-- ------------------------------------------------------------------

local Stats
local function statsFor(def, level)
  if Stats == nil then
    local ok, module = pcall(require, "src.pokemon.Stats")
    Stats = ok and module or false
  end
  local base = (def and def.baseStats) or FALLBACK_BASE
  if Stats and def and def.baseStats then
    local ok, out = pcall(Stats.calc, def, level, DVS)
    if ok and out then
      local base=def.baseStats or {}
      local function calc(baseValue)
        local v=math.floor(((baseValue or base.special or 55)+(DVS.special or 8))*2*level/100)
        return v+5
      end
      out.sp_attack=out.specialAttack or calc(def.sp_attack or base.specialAttack)
      out.sp_defense=out.specialDefense or calc(def.sp_defense or base.specialDefense)
      return out
    end
  end
  -- the same formula, inlined, for a boot where the module is unavailable
  local out = {}
  for _, key in ipairs({ "hp", "attack", "defense", "speed", "special" }) do
    local v = math.floor(((base[key] or 55) + (DVS[key] or 8)) * 2 * level / 100)
    out[key] = key == "hp" and (v + level + 10) or (v + 5)
  end
  local function split(baseValue)
    local v=math.floor(((baseValue or base.special or 55)+(DVS.special or 8))*2*level/100)
    return v+5
  end
  out.sp_attack=split(def and (def.sp_attack or base.specialAttack))
  out.sp_defense=split(def and (def.sp_defense or base.specialDefense))
  return out
end

-- Turn one party slot { species, level, moves } into a combatant.  Slots come
-- straight out of a rival's saved party or out of a trainer record's `parties`
-- entry -- the same shape, which is the whole reason rival parties are stored
-- in the engine's party-slot format.
function BattleSim.combatant(data, slot)
  -- A phone/rival-gear battle can be launched off a saved contact whose party
  -- entry never went through BattleSim.team's `slot and slot.species` guard
  -- (older-format saves, a partially-materialized rival, a corrupted phonebook
  -- entry). Indexing `slot.level` on a non-table there used to throw straight
  -- out of RivalGear's onChoose with no pcall around it -- a force-close on
  -- older builds, the engine's fatal-error ("blue screen") screen on current
  -- ones. Degrade to a harmless placeholder combatant instead of erroring.
  if type(slot) ~= "table" then
    slot = { species = nil, level = 5, moves = {} }
  end
  local level = math.max(1, math.floor(tonumber(slot.level) or 5))
  local def = speciesDef(data, slot.species)
  local stats = statsFor(def, level)
  local moves = {}
  for _, id in ipairs(slot.moves or {}) do
    local mdef = data and data.moves and data.moves[id]
    if mdef and (mdef.power or 0) > 0 then
      moves[#moves + 1] = { id = id, power = mdef.power,
                            type = mdef.type or "NORMAL",
                            category = mdef.category }
    end
  end
  if #moves == 0 then
    -- a slot with no damaging move still has to be able to act; STRUGGLE-ish
    moves[1] = { id = "__struggle", power = 35, type = "NORMAL",
                 category = "physical" }
  end
  -- Saved party HP is authoritative.  League runs call BattleSim repeatedly
  -- and must carry damage/faints from one member of the Elite Four to the
  -- next; rebuilding every combatant at max HP gave rivals a free full heal
  -- between rooms.  A missing HP field still means an undamaged Pokemon for
  -- old saves and freshly-caught slots.
  local savedHp = tonumber(slot.hp)
  local currentHp = savedHp == nil and stats.hp
    or Util.clamp(math.floor(savedHp), 0, stats.hp)
  return {
    species = slot.species, level = level,
    hp = currentHp, maxHp = stats.hp,
    attack = stats.attack, defense = stats.defense,
    speed = stats.speed, special = stats.special,
    sp_attack = stats.sp_attack or stats.specialAttack or stats.special,
    sp_defense = stats.sp_defense or stats.specialDefense or stats.special,
    types = BattleSim.typesOf(def), moves = moves,
  }
end

function BattleSim.team(data, party)
  local out = {}
  for _, slot in ipairs(party or {}) do
    if slot and slot.species then out[#out + 1] = BattleSim.combatant(data, slot) end
  end
  return out
end

-- A fight is sometimes run with a nil or bare-table RNG (the skirmish and
-- League paths pass one deliberately).  Every RNG touch goes through these
-- so a missing or non-RNG value degrades to a deterministic midpoint instead
-- of crashing the fight -- which is what would otherwise make rival-vs-rival
-- battles silently never resolve.
local function rngInt(rng, lo, hi)
  if type(rng) == "table" and type(rng.int) == "function" then
    local ok, v = pcall(rng.int, rng, lo, hi)
    if ok and type(v) == "number" then return v end
  end
  return math.floor((lo + hi) / 2)
end

local function rngChance(rng, p)
  if type(rng) == "table" and type(rng.chance) == "function" then
    local ok, v = pcall(rng.chance, rng, p)
    if ok then return v == true end
  end
  return true
end

-- ------------------------------------------------------------------
-- Weather (weather_fx interop)
-- ------------------------------------------------------------------

-- The battle-field weather strings weather_fx's exports.battleWeather()
-- returns, keyed to damage rows mirroring weather_fx's own lib/Battle.lua
-- (POWER + POWER_AMPLIFIED).  A type with no row is neutral; a weather id
-- this table does not know is neutral.  The rows apply to both sides -- the
-- sun boosts the leader's fire moves as hard as it boosts the rival's.
local WEATHER = {
  SUNNY      = { FIRE = 1.5, WATER = 0.5 },
  HARSH_SUN  = { FIRE = 1.5 },
  RAINY      = { WATER = 1.5, FIRE = 0.5 },
  HEAVY_RAIN = { WATER = 1.5 },
  SANDSTORM  = { ROCK = 1.5, GROUND = 1.5 },
}

local function weatherRow(weather)
  return weather and WEATHER[weather] or nil
end

-- weather_fx 4.x "typed weather": every battle weather carries a chipType,
-- the Gen-1 type immune to its residual chip, and every non-matching
-- battler takes floor(maxHp/16) per turn (on by default, canFaint = true).
-- Keyed by the same battle-field strings exports.battleWeather() returns,
-- so a SMOG or DRAGONSTORM fight wears the exposed team down exactly like
-- weather_fx's own battle layer.
-- 1.37.0: THIS TABLE IS A LAST RESORT, NOT THE ANSWER.
--
-- The chip type is a property of the OVERWORLD weather, and
-- exports.battleWeather() collapses several overworld weathers into one
-- battle-field string, so it cannot be recovered from that string:
--
--     STORM       (chips ELECTRIC) -> "RAINY"
--     GALE        (chips FLYING)   -> "RAINY"
--     RAIN_LIGHT  (chips WATER)    -> "RAINY"
--     THUNDERSNOW (chips ELECTRIC) -> "SNOWY"
--     ASHFALL     (chips FIRE)     -> "SANDSTORM"
--
-- Keyed on the battle string alone, every RAINY fight resolved to WATER: in a
-- thunderstorm this simulation chipped an Electric team that Weather FX would
-- have spared, and spared a Water team it would have chipped. Callers now pass
-- `opts.weatherId` (and `opts.chipType`, resolved from the live catalogue by
-- src/Weather.lua) and this table is used only when neither is available --
-- an old save shape, or a caller that predates 1.37.
local CHIP = {
  SUNNY = "FIRE", HARSH_SUN = "FIRE",
  RAINY = "WATER", HEAVY_RAIN = "WATER",
  SNOWY = "ICE", HAIL = "ICE",
  SANDSTORM = "ROCK",
  STRONG_WINDS = "FLYING",
  VERDANT_RAIN = "GRASS", BRAWL_WIND = "FIGHTING", SMOG = "POISON",
  DUSTSTORM = "GROUND", FLOCKSTORM = "FLYING", SWARM = "BUG",
  HAUNTED_MIST = "GHOST", DRAGONSTORM = "DRAGON", PSYSTORM = "PSYCHIC",
  PLAIN_FRONT = "NORMAL",
}

local function hasAnyType(types, wanted)
  local function canonical(t) return t == "PSYCHIC_TYPE" and "PSYCHIC" or t end
  wanted = canonical(wanted)
  for _, t in ipairs(types or {}) do
    if canonical(t) == wanted then return true end
  end
  return false
end

-- The residual chip a weather deals each turn: 1/16 of the target's own max
-- HP, minimum 1 -- the exact rule weather_fx applies to every non-matching
-- battler.  Exported so the suite can pin the arithmetic.
function BattleSim.chipDamage(maxHp)
  return math.max(1, math.floor((tonumber(maxHp) or 0) / 16))
end

-- ------------------------------------------------------------------
-- Damage
-- ------------------------------------------------------------------

function BattleSim.damage(data, attacker, defender, move, rng, weather)
  local special = SPECIAL_TYPES[move.type] and true or false
  if physicalSplitOn() and (move.category=="physical" or move.category=="special") then
    special=move.category=="special"
  end
  local split=specialSplitOn()
  local a = special and (split and attacker.sp_attack or attacker.special) or attacker.attack
  local d = special and (split and defender.sp_defense or defender.special) or defender.defense
  if d < 1 then d = 1 end

  local base = math.floor(math.floor(math.floor(2 * attacker.level / 5 + 2)
    * move.power * a / d) / 50) + 2

  -- STAB
  for _, t in ipairs(attacker.types) do
    if t == move.type then base = math.floor(base * 3 / 2) break end
  end

  -- battle weather (weather_fx interop): the sun makes fire moves hit harder
  -- and water moves softer, exactly as weather_fx models it in-battle
  local row = weatherRow(weather)
  if row and row[move.type] then base = math.floor(base * row[move.type]) end

  local mult = BattleSim.effectiveness(data, move.type, defender.types)
  base = math.floor(base * mult / 10)
  if base < 1 then
    -- an immunity really is zero; everything else floors at 1
    return mult == 0 and 0 or 1, mult
  end

  local roll = rngInt(rng, 217, 255)
  local out = math.floor(base * roll / 255)
  return math.max(1, out), mult
end

-- The move this combatant would pick: highest expected damage.  That is a
-- stand-in for the real trainer AI, and a deliberately simple one -- the
-- engine's TrainerAI scores by move effect and switching, neither of which
-- exists off-screen.  Weather moves the scoring the same way it moves the
-- damage, so a fire team in a sun actually prefers its fire moves.
function BattleSim.bestMove(data, attacker, defender, weather)
  local row = weatherRow(weather)
  local best, bestDamage
  for _, move in ipairs(attacker.moves) do
    local mult = BattleSim.effectiveness(data, move.type, defender.types)
    local special = SPECIAL_TYPES[move.type] and true or false
    if physicalSplitOn() and (move.category=="physical" or move.category=="special") then
      special=move.category=="special"
    end
    local a = special and (specialSplitOn() and attacker.sp_attack or attacker.special)
      or attacker.attack
    local score = move.power * mult * a
    if row and row[move.type] then score = score * row[move.type] end
    for _, t in ipairs(attacker.types) do
      if t == move.type then score = score * 1.5 break end
    end
    if not bestDamage or score > bestDamage then best, bestDamage = move, score end
  end
  return best or attacker.moves[1]
end

-- ------------------------------------------------------------------
-- The fight
-- ------------------------------------------------------------------

-- Returns a result table:
--   winner    "a" | "b"
--   turns     how long it took
--   aFainted / bFainted  how many mons went down on each side
--   aHp / bHp remaining HP per slot, index-aligned with both input parties,
--             so callers can carry damage forward for every participant
--
-- `maxTurns` is a stalemate guard: two defensive teams with resisted moves can
-- otherwise chip each other for thousands of turns.  A stalemate is scored on
-- remaining HP fraction, which is what the player would call "who was winning".
--
-- `weather` is a battle-field weather string from weather_fx's
-- exports.battleWeather() and is applied to both sides exactly like weather_fx
-- applies it.  Absent or unknown weather fights neutral.
function BattleSim.run(data, partyA, partyB, rng, opts)
  opts = opts or {}
  local a, b = BattleSim.team(data, partyA), BattleSim.team(data, partyB)
  if #a == 0 then return { winner = "b", turns = 0, aFainted = 0, bFainted = 0 } end
  if #b == 0 then return { winner = "a", turns = 0, aFainted = 0, bFainted = 0 } end

  -- carry damage in: a rival that limped out of a wild fight goes into the
  -- gym at the HP it actually has
  for i, slot in ipairs(partyA or {}) do
    if a[i] and slot.hp then
      a[i].hp = Util.clamp(math.floor(tonumber(slot.hp) or a[i].maxHp),
                           0, a[i].maxHp)
    end
  end
  for i, slot in ipairs(partyB or {}) do
    if b[i] and slot.hp then
      b[i].hp = Util.clamp(math.floor(tonumber(slot.hp) or b[i].maxHp),
                           0, b[i].maxHp)
    end
  end

  local ai, bi = 1, 1
  local function alive(team, i) return team[i] and team[i].hp > 0 end
  local function nextAlive(team, from)
    for i = from, #team do if team[i].hp > 0 then return i end end
    return nil
  end

  local aFainted, bFainted, turns = 0, 0, 0
  local trace = opts.trace and {} or nil
  local maxTurns = opts.maxTurns or 300
  -- Prefer the chip the caller resolved from the overworld id; fall back to
  -- the battle string only when it did not supply one.
  local chipType = opts.chipType or CHIP[opts.weather]

  -- The residual chip (weather_fx interop): every turn the sky wears down
  -- battlers that do not match its type, mirroring weather_fx's on-by-default
  -- typed-weather rule (1/16 max HP, canFaint = true).
  local function applyChip()
    if not chipType then return end
    for i, team in ipairs({ a, b }) do
      for _, mon in ipairs(team) do
        if mon.hp > 0 and not hasAnyType(mon.types, chipType) then
          mon.hp = math.max(0, mon.hp - BattleSim.chipDamage(mon.maxHp))
          if mon.hp == 0 then
            if team == a then aFainted = aFainted + 1 else bFainted = bFainted + 1 end
          end
        end
      end
    end
  end

  while turns < maxTurns do
    turns = turns + 1
    if not alive(a, ai) then
      ai = nextAlive(a, 1)
      if not ai then break end
    end
    if not alive(b, bi) then
      bi = nextAlive(b, 1)
      if not bi then break end
    end

    -- the sky's turn-end chip, applied at the start of each round
    applyChip()

    local A, B = a[ai], b[bi]
    -- speed ties go to the rival's own RNG rather than always to one side
    local aFirst = A.speed > B.speed
      or (A.speed == B.speed and rngChance(rng, 0.5))

    local first, second = A, B
    if not aFirst then first, second = B, A end

    for _, pair in ipairs({ { first, second }, { second, first } }) do
      local atk, def = pair[1], pair[2]
      if atk.hp > 0 and def.hp > 0 then
        local move = BattleSim.bestMove(data, atk, def, opts.weather)
        local dmg = BattleSim.damage(data, atk, def, move, rng, opts.weather)
        def.hp = def.hp - dmg
        if trace then
          trace[#trace + 1] = { turn=turns, attacker=atk.species, defender=def.species, move=move and move.id or "?", damage=dmg, defenderHp=math.max(0,def.hp), defenderMaxHp=def.maxHp }
        end
        if def.hp <= 0 then
          def.hp = 0
          if def == A then aFainted = aFainted + 1 else bFainted = bFainted + 1 end
        end
      end
    end
  end

  local aLeft, bLeft = nextAlive(a, 1), nextAlive(b, 1)
  local winner
  if aLeft and not bLeft then winner = "a"
  elseif bLeft and not aLeft then winner = "b"
  else
    -- stalemate: whoever has more of their team left, by HP fraction
    local function fraction(team)
      local sum = 0
      for _, mon in ipairs(team) do sum = sum + mon.hp / math.max(1, mon.maxHp) end
      return sum / #team
    end
    winner = fraction(a) >= fraction(b) and "a" or "b"
  end

  local aHp, bHp = {}, {}
  for i, mon in ipairs(a) do aHp[i] = mon.hp end
  for i, mon in ipairs(b) do bHp[i] = mon.hp end

  return { winner = winner, turns = turns, aFainted = aFainted,
           bFainted = bFainted, aHp = aHp, bHp = bHp, trace = trace }
end

-- ------------------------------------------------------------------
-- Strength estimate
-- ------------------------------------------------------------------

-- A cheap scalar used by the AI to answer "am I ready for this gym" without
-- simulating the whole fight every tick.  It is level-weighted with a
-- diminishing contribution from the back of the party, because a Lv30 lead
-- with five Lv5 fillers is not a Lv30-times-six team.
function BattleSim.strength(data, party)
  local total, weight = 0, 0
  local ordered = {}
  for _, slot in ipairs(party or {}) do
    if slot and slot.species then ordered[#ordered + 1] = slot end
  end
  table.sort(ordered, function(x, y)
    return (tonumber(x.level) or 0) > (tonumber(y.level) or 0)
  end)
  for i, slot in ipairs(ordered) do
    local def = speciesDef(data, slot.species)
    local base = def and def.baseStats or FALLBACK_BASE
    local bulk = ((base.hp or 55) + (base.attack or 55) + (base.defense or 55)
                  + (base.special or 55) + (base.speed or 55)) / 5
    local w = 1 / i
    total = total + (tonumber(slot.level) or 1) * (bulk / 55) * w
    weight = weight + w
  end
  if weight == 0 then return 0 end
  return total / weight
end

-- rival strength relative to an opposing party, 1.0 == even.  This is the
-- number every `*Confidence` field in data/personalities.lua is compared to.
function BattleSim.confidence(data, party, against)
  local mine = BattleSim.strength(data, party)
  local theirs = BattleSim.strength(data, against)
  if theirs <= 0 then return mine > 0 and 2 or 1 end
  return mine / theirs
end

BattleSim.WEATHER = WEATHER
BattleSim.CHIP = CHIP

return BattleSim
