local req, mod = ...
local Util = req("src/Util")
local LifePath = req("src/LifePath")

-- CAREERS (2.2.0).
--
-- 2.1 decided WHETHER a rival leaves the Gym Challenge and WHICH life it
-- takes. This file is what it then does with itself.
--
-- TEN CAREERS, IN TWO KINDS
--
-- 2.2 built the four that need NO world integration: Breeder (§7), Researcher
-- (§9), Explorer (§12) and Retired (§16). Every activity they want already
-- exists as an objective the AI can select.
--
-- 2.3 adds the six that are ABOUT A PLACE (§8, §10, §11, §13-15): Oak's
-- assistant belongs at the lab, a caretaker at the Pokemon Tower, a Centre
-- assistant behind the counter. These need one thing the first four did not --
-- a way to go somewhere and stay there.
--
-- §24 IS EXPLICIT: "Do not simply teleport them to their new location
-- permanently. They should use the existing movement/navigation systems."
--
-- So a located career gets a `home` PATTERN, not a map id, and one new
-- objective -- CAREER_HOME -- in the AI's existing vocabulary. The rival routes
-- there through the same graph, the same gates and the same hop clock as every
-- other journey it has ever made. Nothing teleports, nothing bypasses
-- canEnterMap, and a career whose building does not exist in this game simply
-- never finds a home and carries on with the rest of its list.
--
-- The pattern is matched by SUBSTRING for the same reason Presence.PLACES is:
-- a hardcoded OAKS_LAB is wrong on Gold, on a randomizer and on a total
-- conversion, and being wrong there should mean "no lab found", not a crash.
--
-- THE DESIGN, IN ONE LINE
--
-- A career is a different PRIORITY ORDER over the objectives that already
-- exist, plus a progress record. It is not a second AI.
--
-- That is deliberate and it is the §35 rule. Writing a bespoke movement loop
-- for a breeder would mean a second set of the bugs the first loop already
-- fixed: the bidirectional-warp bug, the destination-is-current-map bug, the
-- always-true-objective bug. A career that reuses AI.evaluate inherits all of
-- those fixes for free and can never drift from them.

local Career = {}

-- ------------------------------------------------------------------
-- The careers
-- ------------------------------------------------------------------
-- `priorities` is an objective list in the same vocabulary data/personalities
-- uses, so AI.evaluate consumes it unchanged. The vocabulary is exactly what
-- AI.Can implements -- HEAL, CHALLENGE_PLAYER, GYM, TRAIN, EXPLORE,
-- SEEK_GHOST, RIVAL_DUEL -- and career_test.lua asserts that every objective
-- named here exists. An invented name (there is no HUNT objective; hunting is
-- a TARGET pursued during TRAIN and EXPLORE) would sit in the list doing
-- nothing at all, which is the quietest possible way for a career to be
-- broken. The 1.14 lesson applies here as
-- hard as it does there: an always-true objective placed early makes every
-- later one dead code, so EXPLORE and TRAIN go LAST in every list.

-- 4.7.0: THE CAREERS ARE THE SAME ROWS AS THE LIFE PATHS.
--
-- A career used to be a second definition of a life, sitting in this file and
-- kept in step with data by hand. With a hundred paths that is a hundred
-- opportunities for the two to disagree about what a Breeder does -- so a
-- career is now built from the SAME row, and a path without a `career` block
-- simply is not a career (Career.isCareer keeps working unchanged).
--
-- `milestones` keeps its old name here because Career.rank/level read it; the
-- row calls the same list `ranks`, which is what it is.
local ROWS = req("data/lifepaths")

Career.DEFS = {}
for _, row in ipairs(ROWS) do
  local c = type(row.career) == "table" and row.career or nil
  if c then
    Career.DEFS[row.id] = {
      blurb = row.blurb,
      home = c.home,
      fieldwork = c.fieldwork,
      priorities = c.priorities,
      metrics = c.metrics,
      milestones = c.ranks,
      steps = c.steps,
      partyTarget = c.partyTarget,
      catchBias = c.catchBias,
    }
  end
end

function Career.isCareer(path) return Career.DEFS[path] ~= nil end

-- The substring list this career looks for, or nil for a career that is not
-- about a place.
function Career.homePatterns(path)
  local def = Career.DEFS[path]
  return def and def.home or nil
end

function Career.isLocated(path)
  return Career.homePatterns(path) ~= nil
end

-- How often a located rival is away doing fieldwork rather than at its post.
-- §8/§10: a career rival that never leaves is scenery, and one that never
-- arrives has not taken the job.
function Career.fieldwork(path)
  local def = Career.DEFS[path]
  return def and def.fieldwork or 0
end

-- Pick this career's home from the maps the rival may actually enter. Returns
-- nil when the game has no such place, which is a legitimate answer: the rival
-- simply works to the rest of its priority list.
--
-- Deterministic: candidates are gathered in sorted order and the nearest wins,
-- so two identical saves choose the same building.
function Career.findHome(path, mapIds, allow, nearest)
  local patterns = Career.homePatterns(path)
  if not patterns then return nil end
  local ids = {}
  for _, id in ipairs(mapIds or {}) do
    if type(id) == "string" then ids[#ids + 1] = id end
  end
  table.sort(ids)
  for _, pattern in ipairs(patterns) do
    local matches = {}
    for _, id in ipairs(ids) do
      if id:upper():find(pattern, 1, true) and (not allow or allow(id)) then
        matches[#matches + 1] = id
      end
    end
    if #matches > 0 then
      if nearest then
        local best = nearest(matches)
        if best then return best end
      end
      return matches[1]
    end
  end
  return nil
end
function Career.def(path) return Career.DEFS[path] end

-- Every career implemented so far. Ordered for deterministic iteration.
-- 4.7.0: DERIVED FROM THE ROWS, not hand-listed.
--
-- Both of these were hand-maintained lists of ids, and both had already
-- drifted: the five careers added in 2.4 (BATTLE_COACH, RANGER, COURIER,
-- PHOTOGRAPHER, TYPE_SPECIALIST) shipped WITH definitions and were never added
-- to IMPLEMENTED, which is the whole of career_test's long-standing
-- ten-failure baseline. A list that restates what another table already knows
-- will always drift; ask the table (lesson 19).
--
-- "Implemented" means the row carries a career block. "Located" means that
-- block names a home. Both are ordered by the data file so iteration stays
-- deterministic.
Career.IMPLEMENTED = {}
Career.LOCATED = {}
for _, row in ipairs(ROWS) do
  if type(row.career) == "table" then
    Career.IMPLEMENTED[#Career.IMPLEMENTED + 1] = row.id
    if type(row.career.home) == "table" and #row.career.home > 0 then
      Career.LOCATED[#Career.LOCATED + 1] = row.id
    end
  end
end

-- ------------------------------------------------------------------
-- Behaviour
-- ------------------------------------------------------------------

-- The objective order for a rival on this path, or nil to leave the
-- personality's own list alone. A rival still on the Gym Challenge, or on a
-- career this release has not built yet, is untouched -- which is what lets
-- 2.3 and 2.4 land without this file changing.
function Career.priorities(path)
  local def = Career.DEFS[path]
  return def and def.priorities or nil
end

-- §7, §12, §16: these rivals stop PRIORITISING badges. They do not become
-- pacifists -- "abandoning the Gym Challenge should not mean abandoning
-- Pokemon battles entirely" -- so only the gym objective itself is withdrawn.
function Career.pursuesBadges(path)
  return Career.DEFS[path] == nil
end

-- How much more (or less) likely this rival is to reach for a ball than its
-- personality alone would suggest. 1 is unchanged.
function Career.catchBias(path)
  local def = Career.DEFS[path]
  return def and def.catchBias or 1
end

function Career.partyTarget(path, fallback)
  local def = Career.DEFS[path]
  return def and def.partyTarget or fallback
end

-- ------------------------------------------------------------------
-- Progress (§26)
-- ------------------------------------------------------------------
-- One counter per declared metric and nothing else. The metric set is fixed
-- per career, so the saved table has a hard ceiling however long a career runs
-- -- the same discipline as 1.38's ledger and 1.35's milestone list.

Career.METRIC_MAX = 99999

function Career.newProgress(path, saved)
  local def = Career.DEFS[path]
  local out = {}
  if not def then return out end
  saved = type(saved) == "table" and saved or {}
  for _, metric in ipairs(def.metrics) do
    out[metric] = Util.clamp(math.floor(tonumber(saved[metric]) or 0),
                             0, Career.METRIC_MAX)
  end
  return out
end

function Career.serializeProgress(path, progress)
  return Career.newProgress(path, progress)
end

-- Credit a metric. An unknown metric is REFUSED rather than added, so a typo
-- at a call site cannot quietly grow the save with a column nothing reads.
function Career.credit(path, progress, metric, amount)
  local def = Career.DEFS[path]
  if not def or type(progress) ~= "table" then return false end
  if progress[metric] == nil then return false end
  amount = math.floor(tonumber(amount) or 1)
  if amount <= 0 then return false end
  progress[metric] = Util.clamp(progress[metric] + amount, 0, Career.METRIC_MAX)
  return true
end

function Career.total(path, progress)
  local def = Career.DEFS[path]
  if not def or type(progress) ~= "table" then return 0 end
  local total = 0
  for _, metric in ipairs(def.metrics) do total = total + (progress[metric] or 0) end
  return total
end

-- ------------------------------------------------------------------
-- Milestones (§27)
-- ------------------------------------------------------------------
-- Four ranks per career, derived from total progress. §27 says not to
-- overcomplicate this: ranks exist to change dialogue and unlock events, not
-- to be a second progression system.

function Career.level(path, progress)
  local def = Career.DEFS[path]
  if not def then return 0 end
  local total = Career.total(path, progress)
  local level = 1
  for _, step in ipairs(def.steps) do
    if total >= step then level = level + 1 end
  end
  return math.min(level, #def.milestones)
end

function Career.rank(path, progress)
  local def = Career.DEFS[path]
  if not def then return nil end
  return def.milestones[Career.level(path, progress)]
end

-- §23: a promotion is worth telling the player about; a single catch is not.
function Career.promotionHeadline(name, path, level)
  local def = Career.DEFS[path]
  if not def or level < 2 then return nil end
  local rank = def.milestones[level]
  if not rank then return nil end
  return tostring(name or "A rival") .. " is now a " .. rank .. "."
end

-- ------------------------------------------------------------------
-- What the world sees (§22)
-- ------------------------------------------------------------------

function Career.blurb(path)
  local def = Career.DEFS[path]
  return def and def.blurb or nil
end

function Career.describe(path, progress)
  local def = Career.DEFS[path]
  if not def then return LifePath.label(path) end
  local bits = {}
  for _, metric in ipairs(def.metrics) do
    bits[#bits + 1] = metric .. "=" .. tostring(progress and progress[metric] or 0)
  end
  return ("%s [%s] %s"):format(LifePath.label(path),
    Career.rank(path, progress) or "?", table.concat(bits, " "))
end

return Career
