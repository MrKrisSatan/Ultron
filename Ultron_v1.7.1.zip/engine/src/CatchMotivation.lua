-- One policy for how strongly an autonomous trainer wants another Pokemon.
-- This changes decisions and catch odds; it never creates a Pokemon, a ball,
-- or an encounter. Simulation.tryCatch remains the only capture door.
local CatchMotivation = {}

local function count(list)
  return type(list) == "table" and #list or 0
end

function CatchMotivation.target(rival)
  local authored = tonumber(rival and rival.personality
    and rival.personality.partyTarget) or 4
  local progression = rival and rival.partyTarget and rival:partyTarget() or authored
  -- Personality remains meaningful, but after the opening tournament every
  -- trainer is allowed to aspire to a full team. The target is a desire, not
  -- a free roster slot: legal encounters and paid balls are still required.
  return math.max(1, math.min(6, math.max(authored, tonumber(progression) or 1)))
end

function CatchMotivation.needsPokemon(rival)
  return count(rival and rival.party) < CatchMotivation.target(rival)
end

function CatchMotivation.chance(rival, base)
  base = math.max(0, math.min(1, tonumber(base) or 0))
  local have, target = count(rival and rival.party), CatchMotivation.target(rival)
  local minimum = rival and rival.minimumPartyForNextGym
    and rival:minimumPartyForNextGym() or 1

  -- A small team actively recruits. Missing members raise a floor rather than
  -- multiplying personality by a huge number, so cautious trainers remain
  -- cautious once their team is established.
  if have < target then
    base = math.max(base, math.min(0.58, 0.22 + (target - have) * 0.07))
  end
  if have < minimum then base = math.max(base, 0.55) end
  if have <= 1 and minimum >= 3 then base = math.max(base, 0.75) end
  if rival and rival.huntTarget then base = math.max(base, 0.48) end
  if rival and rival.catchUpMode and have < math.min(3, target) then
    base = math.max(base, 0.50)
  end
  return math.min(0.85, base)
end

return CatchMotivation
