local req, mod = ...
local Util = req("src/Util")
local GEN1 = req("data/SmogonGen1")
local GEN2 = req("data/SmogonGen2")

-- Offline competitive knowledge. No network calls occur in game and no set is
-- trusted blindly: every species, move and item is resolved against the live
-- merged game before it can alter a rival.
local Competitive = {}
local INDEX_KEY = "__world_competitive_ids"

local function canonical(id)
  return tostring(id or ""):upper():gsub("[^A-Z0-9]", "")
end

local function tableFor(data)
  return data and data.gen2Trainers and GEN2 or GEN1
end

local function liveIndex(data, field)
  if type(data) ~= "table" then return {} end
  local cache = rawget(data, INDEX_KEY)
  if not cache then cache = {}; rawset(data, INDEX_KEY, cache) end
  if cache[field] then return cache[field] end
  local out = {}
  for id in pairs(type(data[field]) == "table" and data[field] or {}) do
    out[canonical(id)] = id
  end
  cache[field] = out
  return out
end

local function liveId(data, field, wanted)
  local index = liveIndex(data, field)
  local exact = index[canonical(wanted)]
  if exact then return exact end
  -- Showdown represents typed Hidden Power as distinct options; Gen 2 carts
  -- commonly expose one HIDDEN_POWER move whose type comes from DVs.
  if canonical(wanted):match("^HIDDENPOWER") then return index.HIDDENPOWER end
end

function Competitive.entry(data, species)
  local rows = tableFor(data)
  return rows[species] or rows[liveId({ pokemon = rows }, "pokemon", species)]
    or rows[canonical(species)]
end

function Competitive.literacy(rival)
  return Util.clamp(math.floor(tonumber(rival and rival.competitiveLiteracy) or 0), 0, 100)
end

function Competitive.consults(rival)
  local literacy = Competitive.literacy(rival)
  return literacy > 0 and rival and rival.rng
    and rival.rng:chance(literacy / 100) or false
end

local function recommendations(row, rival)
  if not row then return {}, nil end
  if type(row.roles) == "table" and #row.roles > 0 then
    local role = row.roles[rival.rng:int(1, #row.roles)]
    return role.moves or {}, role
  end
  return row.moves or {}, row
end

local function levelMoveSet(rival, slot)
  local set = {}
  for _, id in ipairs(rival:movesFor(slot.species, slot.level or 5) or {}) do set[id] = true end
  return set
end

local function allowed(rival, id)
  if not id then return false end
  local exports = rival.ctx and rival.ctx.mod and rival.ctx.mod.exports
  if exports and type(exports.worldMoveAllowed) == "function" then
    local ok, yes = pcall(exports.worldMoveAllowed, id)
    if ok and yes == false then return false end
  end
  return true
end

-- Build a legal approximation of a competitive set. Better-read rivals copy
-- more of the recommendation; less literate rivals retain more of their old
-- set. New TM-compatible moves cost real money and are only trained at a
-- Pokemon Center through Competitive.prepare.
function Competitive.prepareSlot(rival, slot)
  local data = rival.ctx and rival.ctx.data
  local row = Competitive.entry(data, slot and slot.species)
  if not row then return false end
  local wanted, role = recommendations(row, rival)
  local literacy = Competitive.literacy(rival)
  local quota = math.max(1, math.min(4, math.floor((literacy + 15) / 25)))
  local current, currentSet = {}, {}
  for _, id in ipairs(slot.moves or {}) do current[#current + 1] = id; currentSet[id] = true end
  local levelMoves = levelMoveSet(rival, slot)
  local chosen, chosenSet, trained = {}, {}, 0

  local function add(id)
    if id and not chosenSet[id] and allowed(rival, id) and #chosen < 4 then
      chosen[#chosen + 1], chosenSet[id] = id, true
      return true
    end
    return false
  end

  for _, displayId in ipairs(wanted) do
    if #chosen >= quota then break end
    local id = liveId(data, "moves", displayId)
    if id and (currentSet[id] or levelMoves[id]) then
      add(id)
    elseif id and not chosenSet[id] and rival.canTmLearn
       and rival:canTmLearn(slot.species, id)
       and (tonumber(rival.money) or 0) >= 900 then
      -- One abstract competitive-training fee represents buying/accessing the
      -- legal TM. It is not free and it cannot teach an incompatible move.
      if rival:spend(300, "TRAINING") > 0 and add(id) then trained = trained + 1 end
    end
  end
  -- Preserve required field moves before ordinary fillers unless the rival's
  -- FORGETTABLE HMS rule explicitly allows team optimisation to overwrite
  -- them. Field traversal can reteach an owned HM later through teachHM().
  if not (rival.forgettableHmsEnabled and rival:forgettableHmsEnabled()) then
    for _, id in ipairs(current) do if rival.hms and rival.hms[id] then add(id) end end
  end
  for _, id in ipairs(current) do add(id) end
  local levelIds = {}
  for id in pairs(levelMoves) do levelIds[#levelIds + 1] = id end
  table.sort(levelIds)
  for _, id in ipairs(levelIds) do add(id) end
  if #chosen == 0 then return false end
  local changed = table.concat(chosen, ",") ~= table.concat(slot.moves or {}, ",")
  if changed then slot.moves = chosen end

  -- Gen 2 held items are used only when the rival actually owns one.
  local itemPool = role and role.items or row.items
  if literacy >= 60 and not slot.heldItem and type(itemPool) == "table" then
    for _, itemName in ipairs(itemPool) do
      local item = liveId(data, "items", itemName)
      if item and rival.itemCount and rival:itemCount(item) > 0
         and rival:takeItem(item) then slot.heldItem = item; break end
    end
  end
  if changed or trained > 0 then
    slot.competitiveRole = role and role.name or "Smogon set"
    slot.competitivePrepared = (tonumber(slot.competitivePrepared) or 0) + 1
  end
  return changed or trained > 0
end

function Competitive.prepare(rival)
  if not rival or not Competitive.consults(rival) then return 0 end
  local changed = 0
  for _, slot in ipairs(rival.party or {}) do
    if Competitive.prepareSlot(rival, slot) then changed = changed + 1 end
  end
  rival.competitiveTeamsBuilt = (tonumber(rival.competitiveTeamsBuilt) or 0)
    + (changed > 0 and 1 or 0)
  return changed
end

-- Small team-selection term. Matchup, level, bonds and the ace remain stronger;
-- this only separates otherwise comparable candidates using high-ladder usage.
local function keyed(row, field, id)
  local values = row and row[field]
  if type(values) ~= "table" then return 0 end
  return tonumber(values[id]) or tonumber(values[canonical(id)]) or 0
end

function Competitive.teamScore(rival, species, selected, opponents)
  local row = Competitive.entry(rival.ctx and rival.ctx.data, species)
  if not row then return 0 end
  local literacy = Competitive.literacy(rival) / 100
  local usage = math.max(0, tonumber(row.usage) or 0)
  local known = row.roles and #row.roles or #(row.moves or {})
  local synergy, counter = 0, 0
  for _, ally in ipairs(selected or {}) do
    synergy = synergy + math.min(1, keyed(row, "teammates", ally) / 100)
  end
  -- Smogon's counter table belongs to the opposing species: if it names this
  -- candidate, the candidate is a demonstrated check to that foe.
  for _, foe in ipairs(opponents or {}) do
    local foeRow = Competitive.entry(rival.ctx and rival.ctx.data, foe.species)
    counter = counter + keyed(foeRow, "counters", species)
  end
  return literacy * math.min(32,
    usage * 45 + math.min(8, known) + synergy * 5 + counter * 12)
end

return Competitive
