local req, mod = ...
local Util = req("src/Util")

-- RIVAL ECONOMY (1.38.0).
--
-- Money, a real bag and a mart have existed since 1.14. What has NOT existed
-- is a reason for two rivals to spend differently.
--
-- Before this release every rival walked the same `Rival.SHOP_ORDER` and
-- topped every item up to the same target; the only divergence in the whole
-- economy was that a catchy personality carried a few more Poké Balls. Four
-- rivals with the same money therefore ended a session holding the same bag,
-- which is roadmap §39's homogenisation wearing an apron -- and it makes §16's
-- "rivals should sometimes need to make resource decisions" false, because
-- walking a fixed list in a fixed order is not a decision.
--
-- WHAT THIS FILE ADDS
--
--   1. A spending PROFILE per rival, derived from fields that already exist.
--   2. A BUDGET: the purse is divided between categories by that profile, and
--      each category is filled within its own share. Money spent on balls is
--      money not available for potions -- an actual trade-off, which is the
--      thing §16 asks for.
--   3. A bounded LEDGER, so "where did his money go" has an answer.
--
-- NO NEW DATA FILE. The profile is derived from `catchChance`, `trainRate`,
-- `challengeChance`, `rivalFightChance` and `wanderChance`, which
-- data/personalities.lua has carried since the personality system was written.
-- This is the same move 1.34 made with `teamPlan`: the divergence was already
-- described in the data, nothing was reading it.

local Economy = {}

-- Categories. A closed set: the ledger is keyed on it, so the saved record can
-- never grow however long a game runs.
Economy.CATEGORIES = { "BALLS", "HEALING", "STATUS", "FIELD", "TRAINING", "EVOLUTION" }

local CATEGORY_SET = {}
for _, c in ipairs(Economy.CATEGORIES) do CATEGORY_SET[c] = true end
function Economy.isCategory(c) return CATEGORY_SET[c] == true end

-- Which category each shop item belongs to. Anything the shop gains later and
-- this table does not know is treated as HEALING (the safest default: it is
-- the category every rival funds).
Economy.ITEM_CATEGORY = {
  POKE_BALL = "BALLS", GREAT_BALL = "BALLS", ULTRA_BALL = "BALLS",
  POTION = "HEALING", SUPER_POTION = "HEALING", HYPER_POTION = "HEALING",
  ANTIDOTE = "STATUS", PARLYZ_HEAL = "STATUS", AWAKENING = "STATUS",
  BURN_HEAL = "STATUS", ICE_HEAL = "STATUS",
  REPEL = "FIELD",
  RARE_CANDY = "TRAINING",
}

function Economy.categoryOf(item)
  return Economy.ITEM_CATEGORY[item] or "HEALING"
end

-- ------------------------------------------------------------------
-- Spending profiles
-- ------------------------------------------------------------------
-- Weights are RELATIVE shares of the spendable purse, normalised before use,
-- so adding a category later cannot silently inflate anyone's total spend.
--
-- Each weight is read off a personality field that already describes the
-- behaviour it should pay for. That is deliberate: it means a rival's wallet
-- and its behaviour cannot disagree. A Collector that catches constantly
-- cannot be quietly under-funding balls, because the same number drives both.

Economy.BASE = {
  BALLS = 0.20, HEALING = 0.30, STATUS = 0.12,
  FIELD = 0.10, TRAINING = 0.20, EVOLUTION = 0.08,
}

function Economy.profile(personality, style)
  personality = type(personality) == "table" and personality or {}
  local function num(v, d) return tonumber(v) or d end
  local catch  = Util.clamp(num(personality.catchChance, 0.1), 0, 1)
  local train  = Util.clamp(num(personality.trainRate, 1), 0.5, 2)
  local fights = Util.clamp(num(personality.challengeChance, 0.3)
    + num(personality.rivalFightChance, 0.08), 0, 2)
  local wander = Util.clamp(num(personality.wanderChance, 0.1), 0, 1)

  local w = {}
  for category, base in pairs(Economy.BASE) do w[category] = base end
  -- A rival that catches a lot needs balls, and pays for them out of the same
  -- purse everything else comes from.
  w.BALLS    = w.BALLS + catch * 1.6
  -- Fighting costs potions and status cures.
  w.HEALING  = w.HEALING + fights * 0.55
  w.STATUS   = w.STATUS + fights * 0.22
  -- Wandering costs Repels.
  w.FIELD    = w.FIELD + wander * 0.60
  -- Training hard means paying for shortcuts.
  w.TRAINING = w.TRAINING + (train - 1) * 0.60

  -- The team identity gets a say, because 1.34 made it the thing that decides
  -- what a rival is trying to build.
  if style == "EVOLUTION" then
    w.EVOLUTION = w.EVOLUTION + 0.55
    w.TRAINING = w.TRAINING + 0.20
  elseif style == "HYPER_OFFENSIVE" or style == "FAST" then
    w.HEALING = w.HEALING + 0.15
  elseif style == "DEFENSIVE" or style == "STATUS" then
    w.HEALING = w.HEALING + 0.30
    w.STATUS = w.STATUS + 0.25
  elseif style == "MONO_TYPE" or style == "WEATHER" then
    w.BALLS = w.BALLS + 0.25
  end

  local total = 0
  for _, value in pairs(w) do total = total + math.max(0, value) end
  local out = {}
  for category in pairs(w) do
    out[category] = total > 0 and math.max(0, w[category]) / total or 0
  end
  return out
end

-- ------------------------------------------------------------------
-- The ledger
-- ------------------------------------------------------------------
-- Bounded by construction: one running total per category plus two scalars.
-- There is no transaction list, because a transaction list over a long game is
-- exactly the unbounded save table the brief forbids.

function Economy.newLedger(saved)
  saved = type(saved) == "table" and saved or {}
  local spent = {}
  for _, category in ipairs(Economy.CATEGORIES) do
    spent[category] = math.max(0, math.floor(tonumber(
      (type(saved.spent) == "table" and saved.spent[category]) or 0) or 0))
  end
  return {
    spent = spent,
    earned = math.max(0, math.floor(tonumber(saved.earned) or 0)),
    lost = math.max(0, math.floor(tonumber(saved.lost) or 0)),
  }
end

function Economy.serializeLedger(ledger) return Economy.newLedger(ledger) end

function Economy.recordSpend(ledger, category, amount)
  if type(ledger) ~= "table" then return false end
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return false end
  if not Economy.isCategory(category) then category = "HEALING" end
  -- Capped rather than allowed to run away: these are diagnostics, not
  -- currency, and a ten-hour game must not grow the number without limit.
  ledger.spent[category] = math.min(9999999, (ledger.spent[category] or 0) + amount)
  return true
end

function Economy.recordIncome(ledger, amount)
  if type(ledger) ~= "table" then return false end
  amount = math.floor(tonumber(amount) or 0)
  if amount == 0 then return false end
  if amount > 0 then
    ledger.earned = math.min(9999999, ledger.earned + amount)
  else
    ledger.lost = math.min(9999999, ledger.lost - amount)
  end
  return true
end

function Economy.totalSpent(ledger)
  local total = 0
  for _, value in pairs(type(ledger) == "table" and ledger.spent or {}) do
    total = total + value
  end
  return total
end

-- ------------------------------------------------------------------
-- Budgeting
-- ------------------------------------------------------------------

-- Divide `spendable` between categories by profile share.
--
-- Returns a table of category -> budget. Shares are floored, so the sum is
-- always <= spendable: a rounding error that hands out more money than the
-- rival has would be an invented resource, which §38 forbids outright.
function Economy.budget(spendable, profile)
  spendable = math.max(0, math.floor(tonumber(spendable) or 0))
  local out = {}
  local handed = 0
  for _, category in ipairs(Economy.CATEGORIES) do
    local share = math.max(0, tonumber(profile and profile[category]) or 0)
    local amount = math.floor(spendable * share)
    out[category] = amount
    handed = handed + amount
  end
  if handed > spendable then
    -- Cannot happen with floored shares that sum to <= 1, but a malformed
    -- profile must not be able to mint money.
    for _, category in ipairs(Economy.CATEGORIES) do out[category] = 0 end
  end
  return out
end

-- What a rival should own of `item` given its profile. The shop's own target
-- is the baseline; the profile scales it, and the result is never negative.
function Economy.targetFor(item, spec, profile, personality)
  local base = math.max(0, math.floor(tonumber(spec and spec.target) or 0))
  local category = Economy.categoryOf(item)
  local share = tonumber(profile and profile[category]) or 0
  local baseline = Economy.BASE[category] or 0.15
  -- A rival funding a category twice as heavily as the default carries about
  -- twice as much of it, capped so nobody hoards thirty Repels.
  local scale = baseline > 0 and Util.clamp(share / baseline, 0.35, 2.5) or 1
  local target = math.floor(base * scale + 0.5)
  if item == "POKE_BALL" then
    target = target + math.floor((tonumber(personality and personality.catchChance) or 0) * 12)
  end
  return math.max(0, target)
end

-- A one-line summary for the debug verb.
function Economy.describe(ledger, profile)
  local bits = {}
  for _, category in ipairs(Economy.CATEGORIES) do
    bits[#bits + 1] = ("%s %d%%/%d"):format(
      category:sub(1, 4):lower(),
      math.floor((tonumber(profile and profile[category]) or 0) * 100 + 0.5),
      (type(ledger) == "table" and ledger.spent[category]) or 0)
  end
  return table.concat(bits, "  ")
end

return Economy
