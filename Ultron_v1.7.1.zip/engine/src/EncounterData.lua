-- One adapter for Gen 1 and Gen 2 encounter-table shapes.
local E={}

local function canonical(id)
  return tostring(id or ""):upper():gsub("^J2_",""):gsub("^JOHTO_","")
    :gsub("[^A-Z0-9]","")
end

local function unwrap(row)
  if type(row)~="table" then return nil end
  local part=row.grass or row.water or row.day or row.morning or row.night or row
  if type(part)~="table" then return nil end
  return part.slots or part.species or part.encounters or part
end

local function collect(row,out,seen)
  if type(row)~="table" then return end
  local nested=false
  for _,key in ipairs({"grass","water","fish","fishing","oldRod","goodRod","superRod","morning","day","night","swarmGrass"}) do
    if type(row[key])=="table" then nested=true; collect(row[key],out,seen) end
  end
  local slots=row.slots or row.species or row.encounters
  if type(slots)=="table" then row=slots; nested=false end
  if not nested then
    for key,entry in pairs(row) do
      local species=type(entry)=="table" and (entry.species or entry.mon or entry.id or entry.pokemon or entry[1]) or (type(entry)=="string" and entry or (type(key)=="string" and key or nil))
      if type(species)=="string" then local sig=species..":"..tostring(type(entry)=="table" and (entry.level or entry.lvl or entry[2]) or entry); if not seen[sig] then seen[sig]=true; out[#out+1]={key=key,entry=entry} end end
    end
  end
end

function E.slots(data,mapId)
  local ids={mapId}
  if type(mapId)=="string" then
    if mapId:sub(1,3)=="J2_" then ids[#ids+1]=mapId:sub(4)
    else ids[#ids+1]="J2_"..mapId end
    if mapId:sub(1,7)=="JOHTO_" then ids[#ids+1]=mapId:sub(8) end
  end
  for _,id in ipairs(ids) do
    local row=data and data.encounters and data.encounters[id]
    local slots=unwrap(row)
    if type(slots)=="table" and next(slots)~=nil then return slots end
    local gen2=data and data.gen2Encounters
    for _,kind in ipairs(gen2 and {gen2.grass,gen2.swarmGrass,gen2.water,
        gen2.morning,gen2.day,gen2.night} or {}) do
      slots=unwrap(kind and kind[id])
      if type(slots)=="table" and next(slots)~=nil then return slots end
    end
  end
  -- Engine revisions differ on J2_ prefixes, underscores and whether the
  -- encounter kind is nested under data.encounters or gen2Encounters. Match
  -- the requested route canonically as a final read-only compatibility pass.
  local wanted=canonical(mapId)
  local function scan(container,depth)
    if type(container)~="table" or depth>3 then return nil end
    for key,row in pairs(container) do
      if canonical(key)==wanted then
        local slots=unwrap(row)
        if type(slots)=="table" and next(slots)~=nil then return slots end
      end
    end
    for _,row in pairs(container) do
      local hit=scan(row,depth+1)
      if hit then return hit end
    end
  end
  return scan(data and data.gen2Encounters,1) or scan(data and data.encounters,1)
end

function E.entry(key,entry)
  local species
  if type(entry)=="table" then
    species=entry.species or entry.mon or entry.id or entry.pokemon or entry[1]
  elseif type(entry)=="string" then species=entry
  elseif type(key)=="string" then species=key end
  local level=type(entry)=="table" and (entry.level or entry.lvl
    or entry.minLevel or entry.min or entry.levelMin or entry[2])
    or (type(entry)=="number" and entry or nil)
  return species,tonumber(level)
end

function E.each(data,mapId,fn)
  local rows,seen={},{}
  local ids={mapId,type(mapId)=="string" and (mapId:sub(1,3)=="J2_" and mapId:sub(4) or "J2_"..mapId) or mapId}
  for _,id in ipairs(ids) do
    collect(data and data.encounters and data.encounters[id],rows,seen)
    local g=data and data.gen2Encounters
    if type(g)=="table" then for _,container in pairs(g) do if type(container)=="table" then collect(container[id],rows,seen) end end end
  end
  if #rows==0 then local slots=E.slots(data,mapId); collect(slots,rows,seen) end
  local n=0
  for _,row in ipairs(rows) do local key,entry=row.key,row.entry
    local species,level=E.entry(key,entry)
    if type(species)=="string" then fn(species,level,entry); n=n+1 end
  end
  return n
end

return E
