local req, mod = ...
local Util = req("src/Util")

-- RIVAL LIFE PATHS -- FOUNDATION (2.1.0).
--
-- One or occasionally two rivals may permanently abandon the Gym Challenge and
-- develop a different life. This file is the part that decides WHETHER and
-- WHICH; the careers themselves arrive in later releases.
--
-- THE SHAPE THE BRIEF ASKS FOR (§2)
--
--   SAVE SEED -> what is POSSIBLE
--   EXPERIENCE -> what actually HAPPENS
--
-- Which is the same discipline every system since 1.33 has used, so it is
-- built the same way:
--
--   * ELIGIBILITY is a pure function of (world seed, rival id). It is never
--     stored as a decision and never rerolled, so it cannot drift and cannot
--     be save-scummed -- reloading gives the identical answer because it is
--     the same arithmetic on the same seed. (§32)
--   * PRESSURE is DERIVED from the rival's own history -- defeats, badges,
--     collection, relationships, the identity it built -- exactly as 1.35's
--     mood is. There is no accumulating pressure scalar, so there is nothing
--     to drift, nothing to balance, and nothing extra to save.
--   * Only the COMMITMENT is stored, and once stored it is locked. (§33)
--
-- That division is what makes the outcome feel earned rather than rolled: the
-- seed says a rival COULD become a breeder; three hundred captures and a
-- string of gym failures are what make it one.

local LifePath = {}

-- ------------------------------------------------------------------
-- The paths (§1)
-- ------------------------------------------------------------------
-- A closed, ordered set. Ordered because eligibility and selection iterate it
-- and must do so identically on every machine and every load -- pairs() order
-- would make a rival's destiny depend on the Lua build.

LifePath.GYM_CHALLENGE = "GYM_CHALLENGE"

-- 4.7.0: THE PATHS ARE DATA NOW (data/lifepaths.lua).
--
-- A path used to exist in four places -- this list, LABELS, a hand-written
-- line inside compatibility(), and Career.DEFS -- plus a TRANSITIONS row. That
-- is fine at sixteen and impossible at a hundred: four hundred edits and four
-- places to disagree. The rows carry all of it; this module reads them.
--
-- Order is the data file's order, which keeps the original sixteen first so a
-- save that stored a path by id is unaffected.
LifePath.ROWS = req("data/lifepaths")

LifePath.ROW_BY_ID = {}
LifePath.PATHS = {}
for _, row in ipairs(LifePath.ROWS) do
  if type(row) == "table" and type(row.id) == "string" then
    LifePath.PATHS[#LifePath.PATHS + 1] = row.id
    LifePath.ROW_BY_ID[row.id] = row
  end
end

function LifePath.row(path) return LifePath.ROW_BY_ID[path or ""] end

local PATH_SET = { [LifePath.GYM_CHALLENGE] = true }
for _, p in ipairs(LifePath.PATHS) do PATH_SET[p] = true end
function LifePath.isPath(name) return PATH_SET[name] == true end

LifePath.LABELS = { GYM_CHALLENGE = "Gym Challenge" }
for _, row in ipairs(LifePath.ROWS) do
  LifePath.LABELS[row.id] = row.label or row.id
end
function LifePath.label(path) return LifePath.LABELS[path or ""] or "Gym Challenge" end

-- The state machine (§5). Every stage except the last is DERIVED from pressure;
-- ACTIVE is the one that is stored, because it is the one that is a decision.
LifePath.STAGES = {
  "GYM_CHALLENGE", "PRESSURE", "CONSIDERING", "TRANSITIONING", "ACTIVE",
}
local STAGE_SET = {}
for _, s in ipairs(LifePath.STAGES) do STAGE_SET[s] = true end
function LifePath.isStage(s) return STAGE_SET[s] == true end

-- Thresholds on derived pressure, 0..1. Configurable (§3 asks for tunables).
LifePath.PRESSURE_NOTICED   = 0.35   -- something is shifting
LifePath.PRESSURE_CONSIDER  = 0.60   -- the rival is actively questioning it
LifePath.PRESSURE_COMMIT    = 0.82   -- enough to walk away, given a trigger

-- Distribution (§3). Starting values, meant to be tuned.
LifePath.CONFIG = {
  none = 0.85,   -- no rival diverges
  one  = 0.12,   -- exactly one
  two  = 0.03,   -- two, substantially rarer
}

-- ------------------------------------------------------------------
-- Deterministic seeding (§32)
-- ------------------------------------------------------------------
-- A stable string hash. Lua 5.1 has no bit library on every host this mod
-- ships to, so this is plain arithmetic chosen to stay well inside a double's
-- exact integer range on every platform -- a hash that overflows differently
-- on two builds would give one rival two different destinies.

local function hash(seed, text)
  local h = 2166136261
  local s = tostring(seed) .. "|" .. tostring(text)
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

-- 0 <= x < 1, deterministic in (seed, key).
function LifePath.roll(seed, key)
  return hash(seed, key) / 4294967296
end

-- How many rivals may diverge in this save. Pure in the seed.
function LifePath.divergentCount(seed, config, rosterSize)
  config = config or LifePath.CONFIG
  rosterSize = math.max(0, math.floor(tonumber(rosterSize) or 0))
  -- Preserve the original authored-four distribution. Large casts scale by a
  -- seeded 10-25 percent instead of leaving 98 of 100 rivals unable to use
  -- the career system. The result is stable for the lifetime of the save.
  if rosterSize > 4 then
    local fraction = 0.10 + LifePath.roll(seed, "divergent-share") * 0.15
    return math.max(1, math.floor(rosterSize * fraction + 0.5))
  end
  local none = tonumber(config.none) or LifePath.CONFIG.none
  local one = tonumber(config.one) or LifePath.CONFIG.one
  local r = LifePath.roll(seed, "divergent-count")
  if r < none then return 0 end
  if r < none + one then return 1 end
  return 2
end

-- WHICH rivals are eligible. Pure in (seed, roster), and never all of them:
-- §3 forbids every rival abandoning the Gym Challenge, so the count is capped
-- below the roster size regardless of what the configuration says.
function LifePath.eligibleRivals(seed, rivalIds, config)
  local ids = {}
  for _, id in ipairs(rivalIds or {}) do
    if type(id) == "string" then ids[#ids + 1] = id end
  end
  table.sort(ids)          -- deterministic regardless of roster order
  local want = math.min(LifePath.divergentCount(seed, config, #ids), math.max(0, #ids - 1))
  if want <= 0 or #ids == 0 then return {} end
  -- Rank by a per-rival roll and take the top `want`. Ties break on id.
  local ranked = {}
  for _, id in ipairs(ids) do
    ranked[#ranked + 1] = { id = id, r = LifePath.roll(seed, "eligible:" .. id) }
  end
  table.sort(ranked, function(a, b)
    if a.r ~= b.r then return a.r > b.r end
    return a.id < b.id
  end)
  local out = {}
  for i = 1, want do out[#out + 1] = ranked[i].id end
  table.sort(out)
  return out
end

function LifePath.isEligible(seed, rivalId, rivalIds, config)
  for _, id in ipairs(LifePath.eligibleRivals(seed, rivalIds, config)) do
    if id == rivalId then return true end
  end
  return false
end

-- ------------------------------------------------------------------
-- Compatibility (§4)
-- ------------------------------------------------------------------
-- Which paths suit this rival. §4 is explicit that personality must NOT be the
-- only input and that unexpected outcomes must remain possible, so this is a
-- weighting over evidence -- and every path keeps a floor, so a Collector can
-- still, rarely, end up in Team Rocket.
--
-- `facts` is a snapshot, exactly like Story's: read from systems that already
-- own the numbers, never a new counter.

LifePath.FLOOR = 0.08

-- ------------------------------------------------------------------
-- The fact vocabulary (4.7.0)
-- ------------------------------------------------------------------
-- Every weight a row may name, and the ONE place each is computed. A row that
-- names anything else is a load error rather than a silent zero: with a
-- hundred rows, a weight that quietly never fires would never be noticed by
-- reading, and "a guard that can never be true is worse than no guard".

LifePath.FACTS = {
  "catch", "fight", "notFight", "wander", "collection", "seen", "badges",
  "notBadges", "maps", "defeats", "poverty", "wealth", "ghost", "hostile",
  -- 4.7.0's relationship facts: who a rival knows changes what they become.
  "betrayal", "jealousy", "fear", "kinship", "mentorship", "devotion",
}

local FACT_SET = {}
for _, name in ipairs(LifePath.FACTS) do FACT_SET[name] = true end

-- Validated at LOAD, once, so a bad row fails loudly at boot instead of
-- producing a path nobody can ever be dealt.
LifePath.ROW_ERRORS = {}
for _, row in ipairs(LifePath.ROWS) do
  for fact in pairs(type(row.weights) == "table" and row.weights or {}) do
    if not FACT_SET[fact] then
      LifePath.ROW_ERRORS[#LifePath.ROW_ERRORS + 1] =
        tostring(row.id) .. " names unknown fact '" .. tostring(fact) .. "'"
    end
  end
  for fact in pairs(type(row.requires) == "table" and row.requires or {}) do
    if not FACT_SET[fact] then
      LifePath.ROW_ERRORS[#LifePath.ROW_ERRORS + 1] =
        tostring(row.id) .. " requires unknown fact '" .. tostring(fact) .. "'"
    end
  end
end

-- The normalised reading of a rival's history. Every number here was computed
-- inline in the old hand-written compatibility(); moving them out changes
-- nothing about their values, which lifepath_data_test.lua pins by re-deriving
-- the pre-4.7 formula and comparing to the last decimal.
function LifePath.factsOf(facts)
  facts = type(facts) == "table" and facts or {}
  local function num(v, d) return tonumber(v) or d end
  local fight = Util.clamp(num(facts.challengeChance, 0.3), 0, 1)
  local badges = Util.clamp(num(facts.badges, 0) / 8, 0, 1)
  local f = {
    catch = Util.clamp(num(facts.catchChance, 0.1), 0, 1),
    fight = fight,
    notFight = 1 - fight,
    wander = Util.clamp(num(facts.wanderChance, 0.1), 0, 1),
    collection = Util.clamp(num(facts.collection, 0) / 60, 0, 1),
    seen = Util.clamp(num(facts.seen, 0) / 120, 0, 1),
    badges = badges,
    notBadges = 1 - badges,
    -- deliberately NOT clamped: this is how the pre-4.7 EXPLORER line read it
    maps = num(facts.mapsKnown, 0) / 64,
    defeats = Util.clamp(num(facts.leagueFailures, 0) / 6, 0, 1),
    poverty = num(facts.money, 3000) < 800 and 1 or 0,
    wealth = Util.clamp(num(facts.money, 0) / 20000, 0, 1),
    ghost = Util.clamp(num(facts.ghostAffinity, 0), 0, 1),
    -- §17's grievance prerequisite: toward ANYONE, player or rival.
    hostile = (facts.hostileToPlayer or facts.hostileToRival) and 1 or 0,
    -- 4.7.0. Derived by the rival from its own bonds; absent means zero,
    -- never a default (lesson 5): a rival nobody has wronged is not
    -- slightly betrayed.
    betrayal = Util.clamp(num(facts.betrayal, 0), 0, 1),
    jealousy = Util.clamp(num(facts.jealousy, 0), 0, 1),
    fear = Util.clamp(num(facts.fear, 0), 0, 1),
    kinship = Util.clamp(num(facts.kinship, 0), 0, 1),
    mentorship = Util.clamp(num(facts.mentorship, 0), 0, 1),
    devotion = Util.clamp(num(facts.devotion, 0), 0, 1),
  }
  return f
end

-- Compatibility: the rows' own weights, normalised across all paths.
--
-- `requires` is the rarity mechanism and it is a GATE, not a penalty: a path
-- that asks for betrayal is unreachable by a rival nobody has betrayed, at any
-- score. That is how the rarest lives stay rare without a die roll, exactly as
-- §17 asked of Team Rocket -- prerequisites, not just a low weight.
function LifePath.compatibility(rawFacts)
  local f = LifePath.factsOf(rawFacts)
  local style = type(rawFacts) == "table" and rawFacts.teamStyle or nil
  local w = {}
  for _, row in ipairs(LifePath.ROWS) do
    local score = LifePath.FLOOR
    local gated = false
    for fact, minimum in pairs(type(row.requires) == "table" and row.requires or {}) do
      if (f[fact] or 0) < (tonumber(minimum) or 0) then gated = true end
    end
    if not gated then
      for fact, coefficient in pairs(type(row.weights) == "table" and row.weights or {}) do
        score = score + (f[fact] or 0) * (tonumber(coefficient) or 0)
      end
      if style and type(row.style) == "table" and row.style[style] then
        score = score + row.style[style]
      end
      -- Hidden background influence is a tie-breaker, never a gate. This
      -- keeps rare paths rare while letting a compatible upbringing lean a
      -- close decision toward a fitting future.
      local backgroundBias = type(rawFacts) == "table"
        and type(rawFacts.backgroundPathBias) == "table"
        and rawFacts.backgroundPathBias[row.id]
      if backgroundBias then
        score = score + (tonumber(backgroundBias) or 0)
      end
    end
    w[row.id] = score
  end

  local total = 0
  for _, v in pairs(w) do total = total + v end
  local out = {}
  for path, v in pairs(w) do out[path] = total > 0 and v / total or 0 end
  return out
end

-- Which paths this rival is BARRED from, and why. Separate from the score so a
-- debug readout can say "not eligible: needs betrayal" rather than showing a
-- number near zero and leaving the reason to be guessed at.
function LifePath.gatedPaths(rawFacts)
  local f = LifePath.factsOf(rawFacts)
  local out = {}
  for _, row in ipairs(LifePath.ROWS) do
    for fact, minimum in pairs(type(row.requires) == "table" and row.requires or {}) do
      if (f[fact] or 0) < (tonumber(minimum) or 0) then
        out[row.id] = fact
      end
    end
  end
  return out
end

-- The paths this rival could plausibly take, strongest first. Deterministic
-- ordering; ties break on the path name.
-- HOW MANY PATHS A RIVAL ACTUALLY CHOOSES BETWEEN.
--
-- The commit site takes the top three and picks among them weighted by score.
-- That window was sized when there were sixteen paths; at a hundred and five
-- it is a keyhole, and three legacy lives (MART_WORKER, RANGER,
-- TYPE_SPECIALIST) measurably stopped being reachable at all -- not because
-- their weights changed but because the queue in front of them got six times
-- longer. Measured, not guessed: tests/lifepath_reach_test.lua sweeps random
-- rivals and fails if ANY path can never be offered.
--
-- So the window scales with the roster instead of being a constant somebody
-- has to remember to raise. The pick is still weighted by score and still
-- decided by the world seed, so §33 holds: no reroll by reloading.
function LifePath.candidateWindow()
  return math.max(3, math.ceil(#LifePath.PATHS * 0.08))
end

function LifePath.rankPaths(facts, limit)
  local scores = LifePath.compatibility(facts)
  local ranked = {}
  for _, path in ipairs(LifePath.PATHS) do
    ranked[#ranked + 1] = { path = path, score = scores[path] or 0 }
  end
  table.sort(ranked, function(a, b)
    if a.score ~= b.score then return a.score > b.score end
    return a.path < b.path
  end)
  local out = {}
  for i = 1, math.min(limit or #ranked, #ranked) do out[#out + 1] = ranked[i] end
  return out
end

-- ------------------------------------------------------------------
-- Pressure (§2, §5)
-- ------------------------------------------------------------------
-- DERIVED, 0..1. Nothing here is stored, so there is no scalar to drift and
-- nothing to migrate. A rival under pressure is one whose actual history has
-- stopped rewarding the Gym Challenge.

function LifePath.pressure(facts)
  -- No facts means no information, which must mean no pressure. Falling
  -- through to the defaults instead produced a small non-zero reading from
  -- nothing at all, and a system that manufactures pressure out of an absent
  -- snapshot would eventually push a rival off the Gym Challenge for no
  -- reason a player could ever have observed.
  if type(facts) ~= "table" then return 0 end
  local function num(v, d) return tonumber(v) or d end
  local p = 0
  -- Failing at the thing you are supposedly doing
  p = p + Util.clamp(num(facts.leagueFailures, 0) / 5, 0, 1) * 0.30
  p = p + Util.clamp(num(facts.gymFailures, 0) / 8, 0, 1) * 0.20
  -- Being beaten by the player, repeatedly
  p = p + Util.clamp(num(facts.playerLosses, 0) / 12, 0, 1) * 0.15
  -- Stalled: badges have not moved in a long time
  p = p + Util.clamp(num(facts.badgeDrought, 0) / 6000, 0, 1) * 0.15
  -- Interested in something else entirely
  p = p + Util.clamp(num(facts.collection, 0) / 60, 0, 1) * 0.10
  p = p + Util.clamp(num(facts.ghostAffinity, 0), 0, 1) * 0.05
  -- Low confidence
  p = p + Util.clamp((1.2 - num(facts.confidence, 1)) / 0.7, 0, 1) * 0.05
  -- ...and a rival that is WINNING is not under pressure to stop, whatever
  -- else is true. Without this a successful Collector accumulates enough
  -- "interested in something else" to walk away from a run it is winning.
  local success = Util.clamp(num(facts.badges, 0) / 8, 0, 1)
  p = p * (1 - success * 0.55)
  if facts.champion then p = 0 end
  return Util.clamp(p, 0, 1)
end

-- The derived stage (§5). `committed` is the stored decision.
function LifePath.stage(pressure, committed)
  if committed then return "ACTIVE" end
  pressure = tonumber(pressure) or 0
  if pressure >= LifePath.PRESSURE_COMMIT then return "TRANSITIONING" end
  if pressure >= LifePath.PRESSURE_CONSIDER then return "CONSIDERING" end
  if pressure >= LifePath.PRESSURE_NOTICED then return "PRESSURE" end
  return "GYM_CHALLENGE"
end

-- ------------------------------------------------------------------
-- The stored record (§31)
-- ------------------------------------------------------------------
-- Deliberately small. Everything derivable is derived; what is stored is the
-- decision, its history, and the career progress a later release will fill in.

LifePath.HISTORY_LIMIT = 8

function LifePath.newRecord(saved)
  saved = type(saved) == "table" and saved or {}
  local history = {}
  for _, entry in ipairs(type(saved.history) == "table" and saved.history or {}) do
    if type(entry) == "table" and LifePath.isPath(entry.path) then
      history[#history + 1] = {
        path = entry.path,
        tick = math.max(0, math.floor(tonumber(entry.tick) or 0)),
        reason = type(entry.reason) == "string" and entry.reason:sub(1, 40) or nil,
      }
    end
  end
  while #history > LifePath.HISTORY_LIMIT do table.remove(history, 1) end
  local path = LifePath.isPath(saved.path) and saved.path or LifePath.GYM_CHALLENGE
  return {
    path = path,
    previous = LifePath.isPath(saved.previous) and saved.previous or nil,
    preChampionPath = LifePath.isPath(saved.preChampionPath) and saved.preChampionPath or nil,
    -- §33: once a divergence is committed it is locked. A record that names a
    -- path other than the Gym Challenge is locked by definition, so the flag
    -- cannot disagree with the path it is supposed to be protecting.
    locked = path ~= LifePath.GYM_CHALLENGE or saved.locked == true,
    since = math.max(0, math.floor(tonumber(saved.since) or 0)),
    history = history,
    careerLevel = Util.clamp(math.floor(tonumber(saved.careerLevel) or 0), 0, 4),
    progress = math.max(0, math.floor(tonumber(saved.progress) or 0)),
  }
end

function LifePath.serializeRecord(record) return LifePath.newRecord(record) end

function LifePath.onGymChallenge(record)
  return type(record) ~= "table" or record.path == LifePath.GYM_CHALLENGE
end

-- 5.9.0: CHAMPIONSHIP IS AN EARNED LIFE STATE.
-- Becoming Champion is different from the ordinary pressure-based divergence:
-- it is caused by winning the League/title, so it may temporarily supersede
-- any existing career. The previous life is preserved and restored when the
-- crown is lost. This keeps a Ranger who becomes Champion a Ranger at heart
-- rather than permanently erasing years of simulated history.
function LifePath.assumeChampion(record, tick, reason)
  if type(record) ~= "table" then return false end
  if record.path == "LEAGUE_CHAMPION" then return false end
  record.preChampionPath = LifePath.isPath(record.path) and record.path or LifePath.GYM_CHALLENGE
  record.previous = record.path
  record.path = "LEAGUE_CHAMPION"
  record.locked = true
  record.since = math.max(0, math.floor(tonumber(tick) or 0))
  record.careerLevel = 1
  record.progress = 0
  record.history[#record.history + 1] = {
    path = record.path, tick = record.since,
    reason = type(reason) == "string" and reason:sub(1, 40) or "earned Champion title",
  }
  while #record.history > LifePath.HISTORY_LIMIT do table.remove(record.history, 1) end
  return true
end

function LifePath.leaveChampion(record, tick, reason)
  if type(record) ~= "table" or record.path ~= "LEAGUE_CHAMPION" then return false end
  local restore = LifePath.isPath(record.preChampionPath) and record.preChampionPath
    or LifePath.GYM_CHALLENGE
  record.previous = record.path
  record.path = restore
  record.preChampionPath = nil
  record.locked = restore ~= LifePath.GYM_CHALLENGE
  record.since = math.max(0, math.floor(tonumber(tick) or 0))
  record.careerLevel = restore == LifePath.GYM_CHALLENGE and 0 or 1
  record.progress = 0
  record.history[#record.history + 1] = {
    path = restore, tick = record.since,
    reason = type(reason) == "string" and reason:sub(1, 40) or "lost Champion title",
  }
  while #record.history > LifePath.HISTORY_LIMIT do table.remove(record.history, 1) end
  return true
end

-- Commit a divergence. Refuses when already locked, when the path is not one
-- this build knows, or when the rival was never eligible -- the eligibility
-- check belongs at the call site, but the refusal belongs here so no caller
-- can bypass it by forgetting.
function LifePath.commit(record, path, tick, reason)
  if type(record) ~= "table" then return false end
  if record.locked then return false end
  if not LifePath.isPath(path) or path == LifePath.GYM_CHALLENGE then return false end
  record.previous = record.path
  record.path = path
  record.locked = true
  record.since = math.max(0, math.floor(tonumber(tick) or 0))
  record.careerLevel = 1
  record.progress = 0
  record.history[#record.history + 1] = {
    path = path,
    tick = record.since,
    reason = type(reason) == "string" and reason:sub(1, 40) or nil,
  }
  while #record.history > LifePath.HISTORY_LIMIT do table.remove(record.history, 1) end
  return true
end

-- ------------------------------------------------------------------
-- Transitions (2.4.0 -- §19, §28, §29)
-- ------------------------------------------------------------------
-- THE TENSION THIS RESOLVES.
--
-- §33 says a committed life path is LOCKED and must not be re-decidable.
-- §19 says a Rocket rival may defect. §28 says a career may end in a return to
-- the Gym Challenge. Those look contradictory and they are not: the lock
-- exists to stop a player RE-ROLLING a destiny by reloading, not to stop a
-- character's story continuing.
--
-- So `commit` still refuses outright once locked -- there is no path back to
-- "pick again". A TRANSITION is a different operation with its own named
-- prerequisites: it may only move along an edge this table declares, and every
-- edge requires something the rival has actually done. You cannot reload into
-- a defection any more than you could reload into a different career; you can
-- only earn one.
--
-- Ordered lists, so the destination chosen from a seed is stable.

-- 4.7.0: built from the rows' `transition` field.
--
--   "return"    -- §28/§29: this life may end in a return to the ladder
--   "defection" -- §19: a life somebody escapes INTO another life
--   nil         -- a path nobody walks away from
--
-- The Rocket defection set is named here rather than per-row because it is one
-- shared answer to "where does a defector land", and repeating it on every
-- Rocket-ish row would be sixteen places to disagree.
LifePath.DEFECTION_TARGETS = {
  "RESEARCHER", "EXPLORER", "GYM_ASSISTANT", "OAK_ASSISTANT",
  "RETIRED", "ROCKET_DEFECTOR", LifePath.GYM_CHALLENGE,
}

LifePath.TRANSITIONS = {}
for _, row in ipairs(LifePath.ROWS) do
  if row.transition == "defection" then
    LifePath.TRANSITIONS[row.id] =
      { reason = "defection", to = LifePath.DEFECTION_TARGETS }
  elseif row.transition == "return" then
    LifePath.TRANSITIONS[row.id] =
      { reason = "return", to = { LifePath.GYM_CHALLENGE } }
  end
end

-- How much doubt a rival must accumulate before a transition is even offered.
LifePath.TRANSITION_PRESSURE = 0.75
-- ...and how long it must have lived this life first, so nobody defects the
-- afternoon they join.
LifePath.TRANSITION_TENURE = 3000

function LifePath.mayTransition(record, tick)
  if type(record) ~= "table" then return false end
  local edge = LifePath.TRANSITIONS[record.path]
  if not edge then return false end
  local lived = math.max(0, math.floor(tonumber(tick) or 0) - (record.since or 0))
  return lived >= LifePath.TRANSITION_TENURE
end

function LifePath.transitionTargets(path)
  local edge = LifePath.TRANSITIONS[path]
  return edge and edge.to or {}
end

-- §19's DOUBT -> CONFLICT -> DEFECTION, and §28's rediscovered competitive
-- spirit, are the same shape: a derived reading of whether this life is still
-- working out. Derived, like every pressure in this mod -- nothing stored.
function LifePath.doubt(path, facts)
  if type(facts) ~= "table" then return 0 end
  -- A path with no declared edge has nothing to doubt: a rival on the Gym
  -- Challenge is not "considering leaving its career", it has not got one.
  -- Falling through to the career branch produced a small non-zero reading for
  -- an ordinary rival -- the same shape as 2.1's pressure-from-no-facts bug,
  -- and the same fix: absence of a question means zero, not a default answer.
  if not LifePath.TRANSITIONS[path] then return 0 end
  local function num(v, d) return tonumber(v) or d end
  local d = 0
  if path == "TEAM_ROCKET" then
    -- §19's triggers: the player keeps beating them, the relationship warms,
    -- and the work is not paying.
    d = d + Util.clamp(num(facts.playerLosses, 0) / 8, 0, 1) * 0.45
    if facts.warmToPlayer then d = d + 0.25 end
    d = d + Util.clamp(num(facts.careerFailures, 0) / 5, 0, 1) * 0.20
    d = d + Util.clamp((1.1 - num(facts.confidence, 1)) / 0.6, 0, 1) * 0.10
  else
    -- §28: the career is DONE -- mastered, and the competitive itch returns.
    if num(facts.careerLevel, 1) >= 4 then d = d + 0.55 end
    d = d + Util.clamp(num(facts.careerLevel, 1) / 4, 0, 1) * 0.20
    d = d + Util.clamp((num(facts.confidence, 1) - 1) / 0.8, 0, 1) * 0.25
  end
  return Util.clamp(d, 0, 1)
end

-- Move along a declared edge. Returns the new path, or nil.
--
-- Unlike `commit`, this does NOT require the record to be unlocked -- it
-- requires the edge to exist, the tenure to have been served, and the caller to
-- have checked the doubt. The record stays locked afterwards, so the new life
-- is no more re-decidable than the old one.
function LifePath.transition(record, path, tick, reason)
  if type(record) ~= "table" then return nil end
  local edge = LifePath.TRANSITIONS[record.path]
  if not edge then return nil end
  local allowed = false
  for _, target in ipairs(edge.to) do
    if target == path then allowed = true break end
  end
  if not allowed then return nil end
  record.previous = record.path
  record.path = path
  -- A return to the Gym Challenge unlocks nothing: the rival is back on the
  -- ladder, but it has already spent its one divergence and cannot take
  -- another. §33 holds across the whole arc.
  record.locked = true
  record.since = math.max(0, math.floor(tonumber(tick) or 0))
  record.careerLevel = path == LifePath.GYM_CHALLENGE and 0 or 1
  record.progress = 0
  record.history[#record.history + 1] = {
    path = path, tick = record.since,
    reason = type(reason) == "string" and reason:sub(1, 40) or edge.reason,
  }
  while #record.history > LifePath.HISTORY_LIMIT do table.remove(record.history, 1) end
  return path
end

-- Has this rival been through Team Rocket and come out the other side? Read by
-- dialogue and by the §20 relationship shifts.
function LifePath.isRedeemed(record)
  if type(record) ~= "table" then return false end
  if record.path == "TEAM_ROCKET" then return false end
  for _, entry in ipairs(record.history or {}) do
    if entry.path == "TEAM_ROCKET" then return true end
  end
  return false
end

function LifePath.hasReturned(record)
  return type(record) == "table"
    and record.path == LifePath.GYM_CHALLENGE
    and record.previous ~= nil
    and record.previous ~= LifePath.GYM_CHALLENGE
end

-- §23: only a genuine divergence is news, and it is phrased as something the
-- world noticed rather than as a system announcement (§22).
function LifePath.headline(name, path)
  name = tostring(name or "A rival")
  if path == "BREEDER" then
    return name .. " has given up the Gym Challenge to raise Pokemon."
  elseif path == "OAK_ASSISTANT" then
    return name .. " has joined Professor Oak as a research assistant!"
  elseif path == "RESEARCHER" then
    return name .. " has turned to Pokemon research."
  elseif path == "TOWER_CARETAKER" then
    return name .. " has been seen tending the Pokemon Tower."
  elseif path == "GHOST_RESEARCHER" then
    return name .. " has been studying Ghost Pokemon at the Pokemon Tower."
  elseif path == "EXPLORER" then
    return name .. " has set out to explore Kanto instead."
  elseif path == "GYM_ASSISTANT" then
    return name .. " is training at a Gym rather than challenging it."
  elseif path == "CENTER_ASSISTANT" then
    return name .. " is helping out at the Pokemon Center."
  elseif path == "MART_WORKER" then
    return name .. " has taken a job at the Poke Mart."
  elseif path == "RETIRED" then
    return name .. " has given up the Gym Challenge."
  elseif path == "TEAM_ROCKET" then
    return name .. " has joined Team Rocket!"
  end
  -- 4.7.0: every other path speaks through its own blurb rather than needing a
  -- hand-written arm here. The eleven above are kept because their wording is
  -- better than a formula, but a hundred paths cannot each have one -- and the
  -- five added in 2.x never got one, which is why `BATTLE_COACH has a
  -- headline` has been failing since then. A row's blurb IS the sentence.
  local row = LifePath.ROW_BY_ID[path or ""]
  if row and type(row.blurb) == "string" and row.blurb ~= "" then
    return name .. " has left the Gym Challenge and is now " .. row.blurb .. "."
  end
  return nil
end

-- §19/§28/§29. Kept apart from the divergence headline because coming BACK is
-- a different beat from leaving, and the player will have been told the first
-- one hours earlier.
function LifePath.transitionHeadline(name, from, to)
  name = tostring(name or "A rival")
  if from == "TEAM_ROCKET" then
    if to == LifePath.GYM_CHALLENGE then
      return name .. " has left Team Rocket and returned to the Gym Challenge."
    end
    return name .. " has walked away from Team Rocket."
  end
  if to == LifePath.GYM_CHALLENGE then
    return name .. " is challenging the Gyms again."
  end
  return nil
end

function LifePath.describe(record, pressure, eligible)
  if type(record) ~= "table" then return "no life path record" end
  return ("%s (%s)  pressure %d%%  eligible: %s%s"):format(
    LifePath.label(record.path), LifePath.stage(pressure, record.locked),
    math.floor((tonumber(pressure) or 0) * 100 + 0.5),
    eligible and "yes" or "no",
    record.previous and ("  was " .. LifePath.label(record.previous)) or "")
end

return LifePath
