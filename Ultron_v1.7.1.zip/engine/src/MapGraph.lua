local req, mod = ...
local Util = req("src/Util")

-- STRATEGIC NAVIGATION
--
-- The graph is built once from the merged `maps` table and nothing else, so
-- it is whatever the loaded game actually is: a mod that registers a new
-- route is routable the moment it merges, and Yellow's layout differences
-- come out of Yellow's own map records.  Two kinds of edge:
--
--   connection  map.connections[dir] = { map = OTHER, offset = n }
--               a seam you walk across.  The engine treats these as
--               bidirectional in practice, but a handful of ROM headers only
--               declare one side, so the builder adds the reverse edge if the
--               far map did not declare it.  Without that, a rival could walk
--               into Viridian Forest and have no route out.
--
--   warp        map.warps[i] = { destMap = OTHER, destWarp = n, x, y }
--               a door.  This is what makes gyms, Poke Centers, caves and
--               Silph Co reachable at all -- they are separate maps with no
--               connections whatsoever.  The edge carries the (x, y) of the
--               warp tile, which is where the rival must physically stand
--               when it is on screen.
--
-- Both edge kinds cost 1.  A door is not cheaper than a route seam for
-- routing purposes, and pretending otherwise made rivals cut through
-- buildings on the way to a gym.
--
-- BFS, not A*: the graph is a couple of hundred nodes with an average degree
-- under 5, the answer is cached per (from, to), and there is no admissible
-- heuristic across a warp graph anyway -- two maps adjacent through a door
-- can be at opposite ends of the region.

local MapGraph = {}
MapGraph.__index = MapGraph

local function addEdge(nodes, from, to, kind, x, y, dir, offset)
  if not from or not to or from == to then return end
  local node = nodes[from]
  if not node then
    node = { id = from, edges = {} }
    nodes[from] = node
  end
  -- keep the first edge found to a given neighbour: a map with three doors
  -- into the same building only needs one route, and the extra edges just
  -- make the BFS frontier wider for no new reachability
  for _, edge in ipairs(node.edges) do
    if edge.to == to then
      -- A later, explicitly declared warp is more authoritative than a
      -- coordinate-free synthetic reverse edge created while reading the
      -- opposite map.
      if edge.x == nil and x ~= nil then
        edge.kind, edge.x, edge.y, edge.dir, edge.offset = kind, x, y, dir or edge.dir, offset or edge.offset
      end
      return
    end
  end
  node.edges[#node.edges + 1] =
    { to = to, kind = kind, x = x, y = y, dir = dir, offset = offset }
end

function MapGraph.build(maps)
  local self = setmetatable({ nodes = {}, cache = {}, maps = maps or {} },
                            MapGraph)
  local nodes = self.nodes
  local count = 0

  for id, def in pairs(self.maps) do
    if type(def) == "table" then
      count = count + 1
      if not nodes[id] then nodes[id] = { id = id, edges = {} } end

      for dir, conn in pairs(def.connections or {}) do
        local other = type(conn) == "table" and conn.map or conn
        local offset = type(conn) == "table" and conn.offset or nil
        -- Ignore dangling map references from partial conversions or removed
        -- content. Creating a synthetic node here makes :has() lie and lets a
        -- rival save an impossible destination.
        if type(other) == "string" and type(self.maps[other]) == "table" then
          addEdge(nodes, id, other, "connection", nil, nil, dir, offset)
          -- reverse edge only if the far map does not declare one back; a
          -- declared reverse carries its own offset and must win
          local far = self.maps[other]
          local declared = false
          for _, back in pairs(far and far.connections or {}) do
            local backId = type(back) == "table" and back.map or back
            if backId == id then declared = true break end
          end
          if not declared then
            local opposite={north="south",south="north",east="west",west="east",up="down",down="up",left="right",right="left"}
            addEdge(nodes, other, id, "connection", nil, nil, opposite[dir], offset and -offset or nil)
          end
        end
      end

      for _, warp in ipairs(def.warps or {}) do
        if type(warp) == "table" and type(warp.destMap) == "string"
           and warp.destMap ~= "LAST_MAP"
           and type(self.maps[warp.destMap]) == "table" then
          addEdge(nodes, id, warp.destMap, "warp", warp.x, warp.y)
          -- A door is walkable both ways, but the far side is usually a gym,
          -- shop or centre whose own map declares no warp back (the ROM puts
          -- the return in the warp's destWarp index, not in a warps list we
          -- can read).  Without the reverse edge a rival routes INTO a gym and
          -- is then stranded there forever, which is exactly what the
          -- PEWTER_GYM case in tests/ caught.
          -- Source coordinates are meaningful only on `id`.  Reusing them on
          -- the destination can put a rival in a wall.  A reverse edge without
          -- coordinates lets the live map layer resolve a safe entrance from
          -- the destination map's own warp/collision data.
          addEdge(nodes, warp.destMap, id, "warp")
        end
      end
    end
  end

  self.mapCount = count
  return self
end

function MapGraph:has(mapId)
  return self.nodes[mapId] ~= nil
end

function MapGraph:neighbours(mapId)
  local node = self.nodes[mapId]
  return node and node.edges or {}
end

-- The full route as a list of map ids, `from` first and `to` last.  Returns
-- nil when the two are not connected, which a caller must treat as "pick a
-- different destination" rather than "walk anyway".
--
-- Cached per (from, to).  The cache is dropped wholesale by :invalidate()
-- when the map table changes under us (mod hot reload, a registered map).
function MapGraph:route(from, to)
  if from == to then return { from } end
  if not (self.nodes[from] and self.nodes[to]) then return nil end
  local key = from .. ">" .. to
  local hit = self.cache[key]
  if hit ~= nil then
    if hit == false then return nil end
    return hit
  end

  local prev, seen = {}, { [from] = true }
  local frontier, nextFrontier = { from }, {}
  local found = false

  while #frontier > 0 and not found do
    for _, id in ipairs(frontier) do
      for _, edge in ipairs(self.nodes[id].edges) do
        if not seen[edge.to] then
          seen[edge.to] = true
          prev[edge.to] = id
          if edge.to == to then found = true break end
          nextFrontier[#nextFrontier + 1] = edge.to
        end
      end
      if found then break end
    end
    frontier, nextFrontier = nextFrontier, {}
  end

  if not found then
    self.cache[key] = false
    return nil
  end

  local path, cursor = {}, to
  while cursor do
    table.insert(path, 1, cursor)
    cursor = prev[cursor]
  end
  self.cache[key] = path
  return path
end

-- Uncached BFS with a caller-owned access predicate. Rival story progression
-- differs per trainer, so these routes cannot share the global route cache.
function MapGraph:routeAllowed(from, to, allowed)
  if from == to then return { from } end
  if not (self.nodes[from] and self.nodes[to]) then return nil end
  local prev, seen = {}, { [from] = true }
  local queue, head = { from }, 1
  while head <= #queue do
    local id = queue[head]
    head = head + 1
    for _, edge in ipairs(self.nodes[id].edges) do
      if not seen[edge.to] and (edge.to == to or not allowed or allowed(edge.to)) then
        seen[edge.to], prev[edge.to] = true, id
        if edge.to == to then
          local path, cursor = {}, to
          while cursor do table.insert(path, 1, cursor); cursor = prev[cursor] end
          return path
        end
        queue[#queue + 1] = edge.to
      end
    end
  end
  return nil
end

-- The edge a rival takes to leave `from` towards `to`, so the local walker
-- knows whether it is heading for a map seam or a specific door tile.
function MapGraph:edgeBetween(from, to)
  for _, edge in ipairs(self:neighbours(from)) do
    if edge.to == to then return edge end
  end
  return nil
end

-- Nearest member of `candidates` by route length.  Used for "which Poke
-- Center" and "which patch of grass"; returns the id and the route.
function MapGraph:nearest(from, candidates)
  local bestId, bestRoute
  for _, id in ipairs(candidates or {}) do
    if self.nodes[id] then
      local route = self:route(from, id)
      if route and (not bestRoute or #route < #bestRoute) then
        bestId, bestRoute = id, route
      end
    end
  end
  return bestId, bestRoute
end

function MapGraph:invalidate()
  self.cache = {}
end

-- Every map id present in the graph whose name starts with one of the given
-- prefixes.  Used to resolve the training/healing candidate lists in
-- data/gyms.lua against the game that is actually loaded, so a name the cache
-- does not have is dropped instead of routing to nowhere.
function MapGraph:matching(prefixes)
  local out = {}
  for id in pairs(self.nodes) do
    for _, prefix in ipairs(prefixes or {}) do
      if id:sub(1, #prefix) == prefix then
        out[#out + 1] = id
        break
      end
    end
  end
  table.sort(out)
  return out
end

function MapGraph:filterExisting(list)
  local out = {}
  for _, id in ipairs(list or {}) do
    if self.nodes[id] then out[#out + 1] = id end
  end
  return out
end

return MapGraph
