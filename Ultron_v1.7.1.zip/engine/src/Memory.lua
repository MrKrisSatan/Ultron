local req, mod = ...
local Util = req("src/Util")

local Memory = {}
Memory.EVENT_LIMIT = 40
Memory.KEY_LIMIT = 24

local function counts(t) return type(t) == "table" and t or {} end
local function bump(t, key)
  if type(key) ~= "string" or key == "" then return end
  t[key] = math.min(999, (tonumber(t[key]) or 0) + 1)
end
local function top(t)
  local best, score
  for key, n in pairs(t or {}) do
    n = tonumber(n) or 0
    if not score or n > score or (n == score and tostring(key) < tostring(best)) then
      best, score = key, n
    end
  end
  return best
end
local function trimCounts(t)
  local rows = {}
  for key, n in pairs(t or {}) do rows[#rows + 1] = { key, tonumber(n) or 0 } end
  table.sort(rows, function(a, b) return a[2] > b[2] end)
  for i = Memory.KEY_LIMIT + 1, #rows do t[rows[i][1]] = nil end
end

function Memory.new(saved)
  saved = type(saved) == "table" and Util.copy(saved) or {}
  local m = {
    battles = type(saved.battles) == "table" and saved.battles
      or { player = { total = 0, wins = 0, losses = 0 }, rivals = {} },
    player = type(saved.player) == "table" and saved.player or {},
    last = type(saved.last) == "table" and saved.last or {},
    events = type(saved.events) == "table" and saved.events or {},
  }
  m.battles.player = type(m.battles.player) == "table" and m.battles.player
    or { total = 0, wins = 0, losses = 0 }
  m.battles.rivals = type(m.battles.rivals) == "table" and m.battles.rivals or {}
  m.player.leads = counts(m.player.leads)
  m.player.species = counts(m.player.species)
  m.player.moves = counts(m.player.moves)
  while #m.events > Memory.EVENT_LIMIT do table.remove(m.events, 1) end
  return m
end

function Memory.event(memory, event)
  if type(memory) ~= "table" or type(event) ~= "table" then return false end
  memory.events = memory.events or {}
  memory.events[#memory.events + 1] = {
    tick = tonumber(event.tick) or 0, type = event.type or event.kind or "EVENT",
    location = event.location or event.map, target = event.target or event.targetId,
    outcome = event.outcome or (event.won == true and "win")
      or (event.won == false and "loss") or nil,
  }
  while #memory.events > Memory.EVENT_LIMIT do table.remove(memory.events, 1) end
  return true
end

function Memory.playerBattle(memory, observation)
  memory = Memory.new(memory)
  observation = observation or {}
  local b = memory.battles.player
  b.total = (tonumber(b.total) or 0) + 1
  local won = observation.rivalWon == true
  b[won and "wins" or "losses"] = (tonumber(b[won and "wins" or "losses"]) or 0) + 1
  bump(memory.player.leads, observation.lead)
  for _, species in ipairs(observation.species or {}) do bump(memory.player.species, species) end
  for _, move in ipairs(observation.moves or {}) do bump(memory.player.moves, move) end
  trimCounts(memory.player.leads); trimCounts(memory.player.species); trimCounts(memory.player.moves)
  memory.player.favouriteLead = top(memory.player.leads)
  memory.player.favouritePokemon = top(memory.player.species)
  memory.player.commonMove = top(memory.player.moves)
  memory.last = { tick = tonumber(observation.tick) or 0,
    location = observation.location, result = won and "win" or "loss" }
  Memory.event(memory, { tick = observation.tick, type = "PLAYER_BATTLE",
    location = observation.location, target = "player", won = won })
  return memory
end

function Memory.serialize(memory) return Memory.new(memory) end
return Memory