local req, mod = ...

-- LOCAL NAVIGATION
--
-- A* over the active map's collision grid, 4-connected, unit cost.  The grid
-- comes from `mod.world:mapOverview()`, which is the engine's own read-only
-- projection of the live Map -- so this never reimplements walkability, it
-- reads the answer the collision system already computed.  Row characters:
--
--   "."  walkable      "+"  warp tile (walkable, and a routing target)
--   "~"  water         " "  blocked
--
-- Water is blocked for a rival: nothing in this mod gives them SURF, and a
-- rival strolling across Route 20 would be a visible lie.
--
-- Three things keep this cheap enough for a phone:
--
--   1. It only ever runs for the map the player is standing on.  Off-screen
--      rivals have no grid and need none -- see src/Simulation.lua.
--   2. `budget` caps expanded nodes (default 1200).  A blocked target on a
--      large route can otherwise flood the whole map before failing; the cap
--      turns the worst case into a partial answer rather than a frame spike.
--   3. Callers cache.  Rival.path is recomputed only on the five events the
--      README lists, never per frame.
--
-- The open set is a binary heap rather than a linear scan, because the linear
-- version's cost is quadratic in path length and Route 12 is 20x72 cells.

local Pathfinder = {}

local WALKABLE = { ["."] = true, ["+"] = true }

-- ------------------------------------------------------------------
-- Grid
-- ------------------------------------------------------------------

-- Turn a mapOverview into something with O(1) cell lookup.  Lua string
-- indexing through :sub is a fresh allocation per call, which at ~1200 node
-- expansions x 4 neighbours is 5k garbage strings per search; the byte array
-- is built once per map entry instead.
function Pathfinder.grid(overview)
  if not (overview and overview.rows and #overview.rows > 0) then return nil end
  local rows = overview.rows
  local h = #rows
  local w = overview.width or #rows[1]
  local cells = {}
  for y = 1, h do
    local row = rows[y]
    local line = {}
    for x = 1, w do
      line[x] = WALKABLE[row:sub(x, x)] or false
    end
    cells[y] = line
  end
  return { w = w, h = h, cells = cells, mapId = overview.mapId }
end

function Pathfinder.walkable(grid, x, y)
  if not grid then return false end
  if x < 0 or y < 0 or x >= grid.w or y >= grid.h then return false end
  local row = grid.cells[y + 1]
  return row and row[x + 1] or false
end

-- ------------------------------------------------------------------
-- Binary min-heap keyed on f
-- ------------------------------------------------------------------

local function heapPush(heap, node)
  local i = #heap + 1
  heap[i] = node
  while i > 1 do
    local parent = math.floor(i / 2)
    if heap[parent].f <= heap[i].f then break end
    heap[parent], heap[i] = heap[i], heap[parent]
    i = parent
  end
end

local function heapPop(heap)
  local n = #heap
  if n == 0 then return nil end
  local top = heap[1]
  heap[1] = heap[n]
  heap[n] = nil
  n = n - 1
  local i = 1
  while true do
    local l, r, best = i * 2, i * 2 + 1, i
    if l <= n and heap[l].f < heap[best].f then best = l end
    if r <= n and heap[r].f < heap[best].f then best = r end
    if best == i then break end
    heap[i], heap[best] = heap[best], heap[i]
    i = best
  end
  return top
end

-- ------------------------------------------------------------------
-- Search
-- ------------------------------------------------------------------

local DIRS = {
  { 0, -1, "up" }, { 0, 1, "down" }, { -1, 0, "left" }, { 1, 0, "right" },
}

-- opts.budget      max node expansions (default 1200)
-- opts.adjacent    true to stop one cell short of the target, which is what
--                  approaching the player wants -- you cannot stand on them
-- opts.blocked     optional set, "x,y" -> true, of cells to treat as walls
--                  (other rivals, the player when not approaching them)
--
-- Returns a list of { x, y, dir } steps EXCLUDING the start cell, plus the
-- number of nodes expanded so a caller can log it.  Returns nil when there is
-- no route, or when the budget ran out first -- the two are distinguished by
-- the second return, "unreachable" or "budget".
function Pathfinder.find(grid, sx, sy, tx, ty, opts)
  opts = opts or {}
  if not grid then return nil, "no grid" end
  local budget = opts.budget or 1200
  local blocked = opts.blocked
  local adjacent = opts.adjacent and true or false

  if sx == tx and sy == ty then return {}, 0 end

  local function isTarget(x, y)
    if adjacent then
      return (math.abs(x - tx) + math.abs(y - ty)) == 1
    end
    return x == tx and y == ty
  end

  -- a target the rival cannot stand on is a caller error, not a search
  -- failure, so answer it before spending the budget
  if not adjacent and not Pathfinder.walkable(grid, tx, ty) then
    return nil, "unreachable"
  end

  local function key(x, y) return y * grid.w + x end
  local function h(x, y) return math.abs(x - tx) + math.abs(y - ty) end

  local open = {}
  local came, gScore, closed = {}, {}, {}
  local startKey = key(sx, sy)
  gScore[startKey] = 0
  heapPush(open, { x = sx, y = sy, f = h(sx, sy), key = startKey })

  local expanded = 0
  while #open > 0 do
    local current = heapPop(open)
    if not closed[current.key] then
      closed[current.key] = true
      expanded = expanded + 1

      if isTarget(current.x, current.y) then
        local steps, cursor = {}, current
        while cursor and not (cursor.x == sx and cursor.y == sy) do
          table.insert(steps, 1,
            { x = cursor.x, y = cursor.y, dir = cursor.dir })
          cursor = came[cursor.key]
        end
        return steps, expanded
      end

      if expanded >= budget then return nil, "budget" end

      local g = gScore[current.key]
      for _, d in ipairs(DIRS) do
        local nx, ny = current.x + d[1], current.y + d[2]
        local nk = key(nx, ny)
        if not closed[nk] and Pathfinder.walkable(grid, nx, ny)
           and not (blocked and blocked[nx .. "," .. ny]) then
          local tentative = g + 1
          if gScore[nk] == nil or tentative < gScore[nk] then
            gScore[nk] = tentative
            local node = { x = nx, y = ny, key = nk, dir = d[3],
                           f = tentative + h(nx, ny) }
            came[nk] = current
            heapPush(open, node)
          end
        end
      end
    end
  end

  return nil, "unreachable"
end

-- The nearest walkable cell to (x, y), searched outward in rings.  A rival
-- materialising onto a map it only knows abstractly can land inside a
-- building's footprint; rather than refuse to spawn, it gets nudged to the
-- closest legal tile.  `limit` bounds the ring radius.
function Pathfinder.nearestWalkable(grid, x, y, limit)
  if Pathfinder.walkable(grid, x, y) then return x, y end
  for r = 1, (limit or 12) do
    for dy = -r, r do
      local span = r - math.abs(dy)
      for _, dx in ipairs({ -span, span }) do
        local nx, ny = x + dx, y + dy
        if Pathfinder.walkable(grid, nx, ny) then return nx, ny end
      end
    end
  end
  return nil
end

return Pathfinder
