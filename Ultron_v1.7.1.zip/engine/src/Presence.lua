local req, mod = ...
local Util = req("src/Util")

-- PRESENCE (1.36.0).
--
-- Every release from 1.32 to 1.35 added INTERIOR state: memory, relationships,
-- team identity, story. All of it is real and all of it is invisible unless
-- the player opens a menu. Roadmap §36 ("Living Kanto") is the release that
-- turns the simulation outward, and its questions are all one question:
--
--     What could the player plausibly have NOTICED about this rival?
--
-- So this file is not another simulation. It is an OBSERVER. It reads state
-- the other systems already maintain -- where a rival is, what its objective
-- is, why it is travelling -- and decides what, if anything, the player gets
-- to see. Nothing here changes a rival's decisions.
--
-- THE RATE LIMIT IS THE FEATURE
--
-- A sighting system with no budget is a spam system. "You spotted Chris" every
-- forty seconds stops being atmosphere within ten minutes and becomes noise
-- the player learns to ignore -- which is worse than having no sightings at
-- all, because it teaches them to tune out the news channel that 1.33, 1.34
-- and 1.35 all report through. The budget is enforced here, in one place,
-- rather than left to each call site to remember.

local Presence = {}

-- Ticks a rival must wait between producing sightings. Per rival, so four
-- rivals in one town cannot each fire on the same tick.
Presence.SIGHTING_COOLDOWN = 240
-- Ticks between ANY two sightings, worldwide. The player is one person; two
-- rivals noticed in the same breath reads as a coincidence, not a world.
Presence.GLOBAL_COOLDOWN = 90
-- How many recent sightings the log keeps. Bounded, and small: this is a
-- "recently seen" list, not a history.
Presence.LOG_LIMIT = 12
-- Ticks a camp lasts before the rival packs up and moves on.
Presence.CAMP_MIN = 180
Presence.CAMP_MAX = 900

-- ------------------------------------------------------------------
-- Location purpose (roadmap §12)
-- ------------------------------------------------------------------
-- "The rival should have an explicit reason for travelling."
--
-- Matched on the map ID by substring rather than an exact list, because this
-- mod runs on Red/Blue/Yellow, on Gold, on randomizers and on total
-- conversions, and a hardcoded MT_MOON table is wrong on three of those. A map
-- matching nothing simply has no special purpose, which is the right answer
-- for Route 3.
--
-- Ordered: the first match wins, so specific patterns precede general ones.
Presence.PLACES = {
  { match = "POKEMON_TOWER",   kind = "GHOST",    why = "hunting Ghost Pokemon" },
  { match = "POWER_PLANT",     kind = "ELECTRIC", why = "after Electric Pokemon" },
  { match = "SAFARI",          kind = "RARE",     why = "looking for something rare" },
  { match = "SEAFOAM",         kind = "WATER",    why = "after Water and Ice Pokemon" },
  { match = "MT_MOON",         kind = "RARE",     why = "searching Mt. Moon" },
  { match = "VICTORY_ROAD",    kind = "LEAGUE",   why = "on the way to the League" },
  { match = "CERULEAN_CAVE",   kind = "RARE",     why = "somewhere they should not be" },
  { match = "ROCK_TUNNEL",     kind = "CAVE",     why = "cutting through Rock Tunnel" },
  { match = "DIGLETTS_CAVE",   kind = "CAVE",     why = "digging around" },
  { match = "GAME_CORNER",     kind = "SHOP",     why = "at the Game Corner" },
  { match = "DEPT_STORE",      kind = "SHOP",     why = "shopping" },
  { match = "MART",            kind = "SHOP",     why = "stocking up" },
  { match = "POKECENTER",      kind = "HEAL",     why = "at the Pokemon Center" },
  { match = "POKEMON_CENTER",  kind = "HEAL",     why = "at the Pokemon Center" },
  { match = "GYM",             kind = "GYM",      why = "at the Gym" },
  { match = "CAVE",            kind = "CAVE",     why = "exploring a cave" },
  { match = "TOWER",           kind = "GHOST",    why = "exploring the tower" },
  { match = "FOREST",          kind = "BUG",      why = "in the forest" },
}

-- Returns kind, why -- or nil when this map is just a map.
function Presence.place(mapId)
  if type(mapId) ~= "string" then return nil end
  local id = mapId:upper()
  for _, entry in ipairs(Presence.PLACES) do
    if id:find(entry.match, 1, true) then return entry.kind, entry.why end
  end
  return nil
end

-- ------------------------------------------------------------------
-- The record
-- ------------------------------------------------------------------

local function num(v, d) return tonumber(v) or d end

function Presence.new(saved)
  saved = type(saved) == "table" and saved or {}
  local log = {}
  for _, entry in ipairs(type(saved.log) == "table" and saved.log or {}) do
    if type(entry) == "table" and type(entry.rival) == "string" then
      log[#log + 1] = {
        rival = entry.rival,
        tick = math.max(0, math.floor(num(entry.tick, 0))),
        map = type(entry.map) == "string" and entry.map or nil,
        kind = type(entry.kind) == "string" and entry.kind or "SEEN",
        note = type(entry.note) == "string" and entry.note:sub(1, 120) or nil,
      }
    end
  end
  while #log > Presence.LOG_LIMIT do table.remove(log, 1) end
  local byRival = {}
  for id, tick in pairs(type(saved.byRival) == "table" and saved.byRival or {}) do
    if type(id) == "string" then
      byRival[id] = math.max(0, math.floor(num(tick, 0)))
    end
  end
  return {
    log = log,
    lastTick = math.max(0, math.floor(num(saved.lastTick, 0))),
    byRival = byRival,
  }
end

function Presence.serialize(state)
  return Presence.new(state)
end

-- ------------------------------------------------------------------
-- Sightings (roadmap §13)
-- ------------------------------------------------------------------

-- What KIND of sighting a rival's current state supports. Read straight off
-- the objective and the map, so a sighting can never contradict what the rival
-- is actually doing: a player who follows up finds exactly that.
function Presence.classify(view)
  if type(view) ~= "table" then return nil end
  if view.camping then return "CAMP" end
  local kind = Presence.place(view.map)
  if kind == "HEAL" then return "CENTER" end
  if kind == "SHOP" then return "SHOP" end
  if kind == "GYM" then return "GYM" end
  local objective = view.objective
  if objective == "GYM" or view.state == "SEEKING_GYM" then return "GYM" end
  if objective == "HEAL" then return "CENTER" end
  if objective == "TRAIN" or view.state == "TRAINING" then return "TRAINING" end
  if objective == "RIVAL_DUEL" then return "HUNTING_RIVAL" end
  if objective == "LEAGUE" then return "LEAGUE" end
  if view.hunting then return "HUNTING" end
  if view.travelling then return "TRAVELLING" end
  return "SEEN"
end

local DIRECTION = { north = "north", south = "south", east = "east", west = "west" }

-- The sentence. Deliberately observational -- what a passer-by would notice --
-- and never a claim about interior state the player has no way to see. "You
-- spotted Chris heading north" is fair; "Chris is frustrated" is not something
-- you learn by watching someone cross a bridge, and 1.35 already has a place
-- to say it (talking to them).
function Presence.line(view, kind)
  local name = tostring(view.name or "A rival")
  local where = view.mapLabel or Util.spaced(view.map or "")
  -- A simulated same-map location is not automatically a visible NPC. The
  -- opening-corridor quarantine and an exhausted object pool can both leave a
  -- rival abstract. Never tell the player "you spotted" someone who cannot
  -- physically be found on the loaded map.
  if view.sameMap and view.visible == false then
    if kind == "TRAINING" or kind == "CAMP" then
      return "A trainer in " .. where .. " mentioned seeing " .. name
        .. " training nearby."
    elseif kind == "CENTER" then
      return "Someone in " .. where .. " said " .. name
        .. " recently visited the Pokemon Center."
    elseif kind == "SHOP" then
      return "The Poke Mart in " .. where .. " recently served " .. name .. "."
    end
    return "Someone in " .. where .. " recently saw " .. name .. "."
  end
  if kind == "CAMP" then
    return "You came across " .. name .. " training in " .. where .. "."
  elseif kind == "CENTER" then
    return "You saw " .. name .. " going into the Pokemon Center."
  elseif kind == "SHOP" then
    return "You saw " .. name .. " stocking up at the Poke Mart."
  elseif kind == "GYM" then
    return "You spotted " .. name .. " outside the Gym in " .. where .. "."
  elseif kind == "TRAINING" then
    return "You spotted " .. name .. " training in " .. where .. "."
  elseif kind == "HUNTING" then
    if view.huntTarget then
      return "You saw " .. name .. " searching " .. where
        .. " for " .. Util.spaced(view.huntTarget) .. "."
    end
    return "You saw " .. name .. " searching the grass in " .. where .. "."
  elseif kind == "HUNTING_RIVAL" then
    return "You saw " .. name .. " asking after another trainer."
  elseif kind == "LEAGUE" then
    return "You spotted " .. name .. " heading for Victory Road."
  elseif kind == "TRAVELLING" then
    local dir = DIRECTION[view.direction or ""]
    if dir then return "You spotted " .. name .. " heading " .. dir .. "." end
    return "You spotted " .. name .. " leaving " .. where .. "."
  end
  local _, why = Presence.place(view.map)
  if why then return "You saw " .. name .. " " .. why .. "." end
  return "You spotted " .. name .. " in " .. where .. "."
end

-- Decide whether the player notices this rival right now.
--
-- Returns a sighting, or nil. The ONLY thing it mutates is the presence
-- record's own cooldowns and log, so a caller cannot accidentally produce a
-- sighting twice by calling it twice, and nothing about the rival changes.
function Presence.observe(state, view, tick)
  if type(state) ~= "table" or type(view) ~= "table" then return nil end
  tick = math.max(0, math.floor(num(tick, 0)))
  local id = view.id
  if type(id) ~= "string" then return nil end
  -- Not visible, not noticed. A rival two maps away is simulated, not seen.
  if not view.sameMap and not view.adjacent then return nil end
  -- A rival the player is already battling or travelling with is not "spotted".
  if view.engaged then return nil end
  if tick - state.lastTick < Presence.GLOBAL_COOLDOWN then return nil end
  local last = state.byRival[id]
  if last and tick - last < Presence.SIGHTING_COOLDOWN then return nil end

  local kind = Presence.classify(view)
  if not kind then return nil end
  -- An adjacent-map rival can only be glimpsed in transit: you do not see
  -- someone shopping from the next route over.
  if view.adjacent and not view.sameMap then
    if kind ~= "TRAVELLING" and kind ~= "LEAGUE" then return nil end
  end

  local sighting = {
    rival = id, tick = tick, map = view.map, kind = kind,
    note = Presence.line(view, kind),
  }
  state.byRival[id] = tick
  state.lastTick = tick
  state.log[#state.log + 1] = sighting
  while #state.log > Presence.LOG_LIMIT do table.remove(state.log, 1) end
  -- byRival is keyed by rival id, so it is bounded by the roster; an id from a
  -- rival that no longer exists is dropped on the next load by Presence.new.
  return sighting
end

function Presence.recent(state, count)
  local out = {}
  local log = type(state) == "table" and state.log or {}
  local wanted = count or Presence.LOG_LIMIT
  for i = #log, 1, -1 do
    if #out >= wanted then break end
    out[#out + 1] = log[i]
  end
  return out
end

function Presence.lastSeen(state, id)
  local log = type(state) == "table" and state.log or {}
  for i = #log, 1, -1 do
    if log[i].rival == id then return log[i] end
  end
  return nil
end

-- ------------------------------------------------------------------
-- Camps (roadmap §14)
-- ------------------------------------------------------------------
-- "Allow rivals to temporarily stop travelling and establish a training
-- state... The player may stumble upon them."
--
-- A camp is not a new activity -- rivals already train. It is a rival choosing
-- to STAY somewhere long enough that the player can find it in the same place
-- twice, which is what makes a world feel inhabited rather than a set of
-- drifting dots.

function Presence.campDuration(rng)
  if rng and rng.int then
    return rng:int(Presence.CAMP_MIN, Presence.CAMP_MAX)
  end
  return Presence.CAMP_MIN
end

-- Should this rival settle here? Only where training is legal and meaningful.
function Presence.campWorthy(view)
  if type(view) ~= "table" then return false end
  if view.camping then return false end
  if not view.canTrain then return false end
  local kind = Presence.place(view.map)
  -- towns and buildings are for errands, not camps
  if kind == "HEAL" or kind == "SHOP" or kind == "GYM" then return false end
  return true
end

-- ------------------------------------------------------------------
-- Errands (roadmap §17) -- ALREADY DONE, deliberately not reimplemented
-- ------------------------------------------------------------------
-- Rivals have visibly restocked Poke Balls and bought TMs since 1.14: those
-- purchases log as `bought_balls` / `tm_bought` and already render in the news
-- ticker. §17 asks for rivals to be seen visiting marts and Centers, and those
-- events are exactly that. A second "errand" channel here would be duplicate
-- infrastructure reporting the same purchases twice.
--
-- What 1.36 adds is the other half: Presence.place() classifies a Mart, a
-- Center, a Gym and a Dept. Store, so a rival standing in one is SIGHTED doing
-- that rather than sighted generically.

return Presence
