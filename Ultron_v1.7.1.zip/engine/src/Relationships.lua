local req, mod = ...
local Util = req("src/Util")

-- ONE RELATIONSHIP MODEL (1.33.0).
--
-- Every social system in this mod -- dialogue, who picks a fight with whom,
-- who trades, who cooperates on world events, who hands over a gift --
-- reads the same three numbers out of this file.  There is no second opinion
-- table anywhere: `Rival.bonds` is the only store, and it is bounded.
--
-- WHY THREE AXES AND NOT ONE NUMBER
--
-- "Green respects Crystal but still wants to beat her" and "Green likes
-- Crystal and has stopped caring" are different relationships that a single
-- friendliness scalar cannot tell apart.  So a bond carries:
--
--   regard   -100..100  warmth.  Falls when you lose to someone, rises when
--                       they help you, when you trade, when you get even.
--   rivalry     0..100  competitive heat.  Only ever raised by contests.
--   respect     0..100  earned esteem.  Raised by losing to someone good and
--                       by beating someone who used to beat you.  Never decays
--                       -- respect once earned is the thing that persists, and
--                       it is why two rivals with identical records can end up
--                       in different places.
--
-- The named STATE is DERIVED from those axes plus the head-to-head record.
-- Nothing in this mod ever assigns a state directly and nothing rolls dice to
-- pick one: every state a player can see is the arithmetic consequence of
-- battles, gifts, trades and favours that actually happened, and the bond
-- keeps the last few reason codes so a debug command can say why.
--
-- DECAY IS LAZY, NOT TICKED.
--
-- A background sweep over four rivals x N bonds every tick is exactly the
-- kind of continuous simulation the performance budget forbids.  Instead each
-- bond stores the tick it was last touched, and regard/rivalry are drifted
-- toward rest at READ time by a pure function of (now - lastTick).  Cost is
-- zero when nobody is looking.

local R = {}

R.STATES = {
  "FRIENDLY", "NEUTRAL", "COMPETITIVE", "RIVALRY",
  "RESPECT", "HOSTILE", "MENTOR", "ALLIED",
  -- 4.6.0. Five more one-sided states, so a bond that has been running for
  -- hours has somewhere further to go than the eight it could reach in the
  -- first twenty minutes. Every one is a STRICT SUBSET of a state that already
  -- existed and is tested ahead of it, so nothing that used to read RIVALRY
  -- now reads NEUTRAL -- a bond only ever moves to a more specific answer.
  --   DEVOTED   deep attachment; both sides DEVOTED is what makes LOVERS
  --   NEMESIS   hatred with a history, beyond ordinary hostility
  --   PROTEGE   the mirror of MENTOR, seen from the junior side
  --   ADMIRER   looks up to someone who keeps beating them
  --   ESTRANGED was close once and is not now -- the only state that needs
  --             memory of a PEAK, because "fallen out" is not visible in a
  --             current reading alone
  "DEVOTED", "NEMESIS", "PROTEGE", "ADMIRER", "ESTRANGED",
  -- 4.7.0, the four Christopher named that the model could not yet say:
  --   BETRAYED  an ally who turned; needs the remembered event, not just a
  --             low number, because the numbers decay and the fact does not
  --   JEALOUS   a peer who pulled ahead -- behind AND resentful, which is a
  --             different relationship from an ordinary rivalry between equals
  --   FEARFUL   beaten so often and so badly that they stop wanting the match
  --   FAMILY    DECLARED, never derived: no sequence of battles makes two
  --             rivals siblings, so this one is read off the roster
  "BETRAYED", "JEALOUS", "FEARFUL", "FAMILY",
}

-- Pair states. A relationship between two rivals is TWO bonds, and the
-- interesting outcomes are agreements between them: LOVERS is not something
-- one rival can decide. Derived from both sides by R.pairState; never stored.
R.PAIR_STATES = {
  "LOVERS", "CLOSE_FRIENDS", "FAMILY", "ARCH_RIVALS", "FEUD", "MENTORSHIP",
  "UNREQUITED", "NONE",
}

local STATE_SET = {}
for _, s in ipairs(R.STATES) do STATE_SET[s] = true end
function R.isState(name) return STATE_SET[name] == true end

-- Bounds.  A save may never grow past these, whatever happens in the world.
R.BOND_LIMIT   = 16   -- player + active rival roster + slack
R.REASON_LIMIT = 6    -- recent mechanical causes per bond
R.MEMORY_LIMIT = 10   -- significant social memories per bond
R.DECAY_TICKS  = 900  -- ticks of no contact per one point of drift to rest
R.DECAY_MAX    = 40   -- most drift a single lazy read may apply

-- DEVOTION IS SLOW ON PURPOSE (4.6.0).
--
-- Christopher asked for lovers to be "a very rare outcome". Rarity here is not
-- a dice roll -- nothing in this file rolls for a state -- it is a conjunction
-- that is hard to satisfy by accident: near-maximum affection AND high regard
-- AND several favours actually done AND real respect AND a long shared
-- history. Affection alone cannot do it (it starts seeded at up to 75), and
-- neither can a burst of gifts, because the clock has to run too.
R.DEVOTION_AFFECTION = 90
R.DEVOTION_REGARD    = 65
R.DEVOTION_FAVOURS   = 4
R.DEVOTION_RESPECT   = 25
R.DEVOTION_TICKS     = 3000   -- how long they must have known each other
-- Hatred with a history. HOSTILE is a falling-out; this is what it becomes
-- when the two keep meeting and it keeps getting worse.
R.NEMESIS_REGARD     = -80
R.NEMESIS_RIVALRY    = 60
R.NEMESIS_CONTESTS   = 6
-- "Was close once." Without a remembered peak this is indistinguishable from
-- a bond that was always cold, which is exactly the information that makes it
-- worth showing.
R.ESTRANGED_PEAK     = 45
R.ESTRANGED_REGARD   = -25

local AXIS_MIN, AXIS_MAX = -100, 100
local AFFECTION_MIN, AFFECTION_MAX = 0, 100

-- ------------------------------------------------------------------
-- Causes
-- ------------------------------------------------------------------
-- The complete list.  A caller may only name a code that appears here, which
-- is what stops relationships from becoming arbitrary numbers: to move a bond
-- you must name the thing that happened.

R.EFFECTS = {
  BATTLE_WIN      = { regard =  -2, rivalry =   8, respect =  2, affection =  2 },
  BATTLE_LOSS     = { regard =  -7, rivalry =  14, respect =  6, affection =  3 },
  -- layered on top of BATTLE_WIN when the winner was behind head-to-head
  AVENGED         = { regard =  18, rivalry =  -6, respect = 14, affection =  5 },
  -- layered on top of BATTLE_LOSS from the third consecutive defeat
  REPEAT_LOSS     = { regard =  -5, rivalry =   8, respect =  4 },
  -- layered on top of either result once a long head-to-head is still level.
  -- Without this, both battle outcomes push regard down and ANY sufficiently
  -- long rivalry decays into HOSTILE no matter how it went, which is both
  -- wrong (an even rivalry is the classic respectful one) and homogenising
  -- (every pair ends up at an axis clamp). Found by the 20k-tick soak.
  WORTHY          = { regard =   7, rivalry =  -2, respect =  5, affection =  4 },
  HELPED          = { regard =  22, rivalry =  -4, respect =  6, favours = 1, affection = 12 },
  GIFT_RECEIVED   = { regard =  16, rivalry =  -2, favours = 1, affection = 10 },
  TRADED          = { regard =  12, respect =   2, favours = 1, affection =  8 },
  COOPERATED      = { regard =  14, rivalry = -10, respect =  8, favours = 1, affection = 10 },
  REQUEST_DONE    = { regard =  25, respect =  10, favours = 1, affection = 14 },
  REQUEST_IGNORED = { regard =  -6, affection = -7 },
  OVERTAKEN       = { regard =  -4, rivalry =  10 },
  TITLE_LOST      = { regard = -14, rivalry =  25, respect = 10 },
  TITLE_TAKEN     = { regard =  -2, rivalry =  18, respect =  6 },
  SNUBBED         = { regard =  -5, rivalry =   4, affection = -9 },
  -- §20 (2.4.0): a life-path change is a cause like any other. Green joining
  -- Team Rocket is something that happens TO Crystal's opinion of him, and to
  -- the player's, and it has to move the same three axes everything else does
  -- rather than being a special case bolted onto the side.
  TURNED_ROCKET   = { regard = -30, rivalry =  10, respect = -8, affection = -20 },
  LEFT_ROCKET     = { regard =  22, rivalry =  -6, respect =  10, affection = 10 },
  CHANGED_PATH    = { regard =  -6, rivalry =  -8 },
  CAME_BACK       = { regard =   8, rivalry =  12, respect =  4 },
  -- 4.7.0. BETRAYED is the one cause that needs a memory of its own: being
  -- let down by somebody who was nothing to you is a snub, and being let down
  -- by an ALLY is a different relationship afterwards. `betrayals` counts the
  -- second kind, because once the axes have decayed there is nothing left in
  -- the numbers to say it ever happened.
  BETRAYED        = { regard = -34, rivalry =  16, respect = -6, affection = -26,
                      betrayal = 1 },
  -- Somebody who was level with them pulled clearly ahead. OVERTAKEN is the
  -- event; this is the one that stings, because it was a peer.
  OUTSHONE        = { regard = -10, rivalry =  16, affection = -6 },
  -- Standing between them and harm. The opposite pole to BETRAYED, and the
  -- cause the family and protector lives grow out of.
  PROTECTED       = { regard =  26, rivalry =  -8, respect =  12, favours = 1,
                      affection = 16 },
  SHARED_JOURNEY  = { regard =   5, rivalry =  -1, respect =   2, affection = 4 },
}

R.REASON_TEXT = {
  BATTLE_WIN      = "beat them",
  BATTLE_LOSS     = "lost to them",
  AVENGED         = "got even",
  REPEAT_LOSS     = "beaten again",
  WORTHY          = "well matched",
  HELPED          = "was helped",
  GIFT_RECEIVED   = "was given a gift",
  TRADED          = "traded",
  COOPERATED      = "fought alongside",
  REQUEST_DONE    = "request granted",
  REQUEST_IGNORED = "request ignored",
  OVERTAKEN       = "was overtaken",
  TITLE_LOST      = "lost the title",
  TITLE_TAKEN     = "took the title",
  SNUBBED         = "was brushed off",
  TURNED_ROCKET   = "joined Team Rocket",
  LEFT_ROCKET     = "left Team Rocket",
  CHANGED_PATH    = "changed their life",
  CAME_BACK       = "came back to the ladder",
  BETRAYED        = "was betrayed",
  OUTSHONE        = "was left behind",
  PROTECTED       = "was protected",
  SHARED_JOURNEY  = "travelled together",
}

function R.reasonText(code) return R.REASON_TEXT[code] or "?" end

-- How much more (or less) likely this rival is to pick a fight with someone
-- it feels this way about.  Read by AI duel targeting and by the same-map
-- skirmish so hostility is visible as behaviour, not just as a label.
R.FIGHT_BIAS = {
  -- 4.6.0's states sit where their meaning puts them: a NEMESIS is sought out
  -- harder than an ordinary enemy, an ADMIRER wants the match, a PROTEGE is
  -- taught rather than fought, and DEVOTED is the one relationship that does
  -- not pick fights at all.
  -- A betrayal is sought out harder than anything else in the model.
  BETRAYED = 2.40, NEMESIS = 2.20,
  JEALOUS = 1.70, HOSTILE = 1.80,
  -- Fear is the one state that makes a rival AVOID the match.
  FEARFUL = 0.20, FAMILY = 0.55, RIVALRY = 1.60, ADMIRER = 1.35, COMPETITIVE = 1.25,
  NEUTRAL = 1.00, ESTRANGED = 1.10,
  RESPECT = 0.90, MENTOR = 0.70, PROTEGE = 0.70, FRIENDLY = 0.60,
  ALLIED = 0.40, DEVOTED = 0.15,
}

function R.fightBias(state) return R.FIGHT_BIAS[state or "NEUTRAL"] or 1.0 end

-- Who will stand next to whom.  Consumed by trading now and by rival double
-- battles in a later version; keeping the predicate here is what stops those
-- two features from inventing separate notions of "friendly enough".
local COOPERATIVE = { ALLIED = true, FRIENDLY = true, MENTOR = true, RESPECT = true,
  DEVOTED = true, PROTEGE = true, FAMILY = true }
function R.willCooperate(state) return COOPERATIVE[state or "NEUTRAL"] == true end

-- ------------------------------------------------------------------
-- Normalisation
-- ------------------------------------------------------------------

local function num(v, default)
  local n = tonumber(v)
  if not n then return default end
  return n
end

local function clampAxis(v, lo)
  return math.floor(Util.clamp(num(v, 0), lo or AXIS_MIN, AXIS_MAX))
end

-- AXES ARE ASYMPTOTIC, NOT CUMULATIVE.
--
-- A flat delta per event makes an axis the lifetime INTEGRAL of everything
-- that ever happened, so after a few hundred contests every pair is pinned at
-- a clamp and the derived state is decided by which clamp -- exactly the
-- homogenisation this system exists to avoid.  The 20k-tick soak produced
-- nothing but ALLIED and HOSTILE.
--
-- So a change AWAY from rest is damped by the headroom remaining in that
-- direction, while a change TOWARD rest lands at full strength.  An axis then
-- approaches its bound without reaching it, and a rival who changes how it
-- behaves can always move a relationship back -- which is the difference
-- between a relationship and a scoreboard.
local function nudge(current, delta, lo)
  current = num(current, 0)
  delta = num(delta, 0)
  if delta == 0 then return current end
  lo = lo or AXIS_MIN
  local towardRest = (current > 0 and delta < 0) or (current < 0 and delta > 0)
  if not towardRest then
    local bound = delta > 0 and AXIS_MAX or lo
    local span = math.abs(bound)
    if span > 0 then
      local headroom = math.abs(bound - current) / span
      local scaled = delta * headroom
      -- never round a real cause down to nothing: an event always moves the
      -- axis by at least one, or the last few points would be unreachable
      if scaled > 0 then delta = math.max(1, math.floor(scaled + 0.5))
      else delta = math.min(-1, math.ceil(scaled - 0.5)) end
    end
  end
  return Util.clamp(current + delta, lo, AXIS_MAX)
end

local function blankBond(tick)
  return {
    regard = 0, rivalry = 0, respect = 0, affection = 0, affectionSeeded = false,
    -- The high-water marks. Two scalars, bounded like every other axis; they
    -- are the whole of the "memory" ESTRANGED needs.
    peakRegard = 0, peakAffection = 0,
    -- 4.7.0: how many times an ALLY turned on them, and whether the roster
    -- declares these two family. Both are facts the axes cannot reconstruct
    -- once they have decayed -- which is the test for storing anything here.
    betrayals = 0, kin = false,
    wins = 0, losses = 0, streak = 0, favours = 0, lead = 0,
    state = "NEUTRAL", since = num(tick, 0), tick = num(tick, 0),
    -- WHEN THEY MET, which is not the same as when the CURRENT state began.
    -- `since` is reset every time the derived state moves, so using it as
    -- "how long they have known each other" is self-defeating: crossing the
    -- devotion threshold changes the state, which resets `since`, which drops
    -- the bond back below the threshold on the very next read. A requirement
    -- that is cancelled by being met can never be held, and the soak caught it
    -- oscillating exactly there. `met` is written once and never moved.
    met = num(tick, 0),
    reasons = {},
    memories = {},
  }
end

local function normaliseBond(saved, tick)
  local b = blankBond(tick)
  if type(saved) ~= "table" then return b end
  b.regard  = clampAxis(saved.regard, AXIS_MIN)
  b.rivalry = clampAxis(saved.rivalry, 0)
  b.respect = clampAxis(saved.respect, 0)
  b.affection = math.floor(Util.clamp(num(saved.affection, 0), AFFECTION_MIN, AFFECTION_MAX))
  b.affectionSeeded = saved.affectionSeeded == true
  -- An old save has no peaks recorded. They start at the CURRENT reading
  -- rather than at zero: a bond loaded at regard 60 was demonstrably at least
  -- that warm, and claiming a peak of 0 would be a statement the save
  -- contradicts.
  b.peakRegard = clampAxis(num(saved.peakRegard, math.max(0, b.regard)), 0)
  b.peakAffection = math.floor(Util.clamp(
    num(saved.peakAffection, b.affection), AFFECTION_MIN, AFFECTION_MAX))
  b.betrayals = math.max(0, math.floor(num(saved.betrayals, 0)))
  b.kin = saved.kin == true
  b.wins    = math.max(0, math.floor(num(saved.wins, 0)))
  b.losses  = math.max(0, math.floor(num(saved.losses, 0)))
  b.streak  = math.floor(Util.clamp(num(saved.streak, 0), -99, 99))
  b.favours = math.max(0, math.floor(num(saved.favours, 0)))
  b.lead    = math.floor(Util.clamp(num(saved.lead, 0), -8, 8))
  b.tick    = math.max(0, math.floor(num(saved.tick, num(tick, 0))))
  b.since   = math.max(0, math.floor(num(saved.since, b.tick)))
  -- A save written before `met` existed: the earliest moment it can prove is
  -- the start of the current state, so that is what it claims. Never later
  -- than `since`, or a loaded bond would forget history it demonstrably has.
  b.met     = math.max(0, math.floor(num(saved.met, math.min(b.since, b.tick))))
  b.state   = R.isState(saved.state) and saved.state or "NEUTRAL"
  local reasons = {}
  for _, entry in ipairs(type(saved.reasons) == "table" and saved.reasons or {}) do
    local code = type(entry) == "table" and entry.code or entry
    if type(code) == "string" and R.EFFECTS[code] then
      reasons[#reasons + 1] = {
        code = code,
        tick = math.max(0, math.floor(num(type(entry) == "table" and entry.tick or 0, 0))),
      }
    end
  end
  while #reasons > R.REASON_LIMIT do table.remove(reasons, 1) end
  b.reasons = reasons
  local memories = {}
  for _, entry in ipairs(type(saved.memories) == "table" and saved.memories or {}) do
    if type(entry) == "table" and type(entry.kind) == "string" then
      memories[#memories + 1] = {
        kind = entry.kind,
        tick = math.max(0, math.floor(num(entry.tick, 0))),
        cause = type(entry.cause) == "string" and entry.cause or nil,
        from = R.isState(entry.from) and entry.from or nil,
        to = R.isState(entry.to) and entry.to or nil,
        text = type(entry.text) == "string" and entry.text:sub(1, 96) or nil,
      }
    end
  end
  while #memories > R.MEMORY_LIMIT do table.remove(memories, 1) end
  b.memories = memories
  return b
end

-- Drop the least recently touched bonds until the store fits.  Deterministic:
-- ties break on the subject id, never on pairs() order.
local function enforceLimit(bonds)
  local ids = {}
  for id in pairs(bonds) do ids[#ids + 1] = id end
  if #ids <= R.BOND_LIMIT then return bonds end
  table.sort(ids, function(a, b)
    local ta, tb = bonds[a].tick or 0, bonds[b].tick or 0
    if ta ~= tb then return ta > tb end
    return tostring(a) < tostring(b)
  end)
  for i = R.BOND_LIMIT + 1, #ids do bonds[ids[i]] = nil end
  return bonds
end

-- Accepts nil (an old save with no relationship data at all), in which case
-- every subject starts NEUTRAL with no history -- which is exactly the
-- migration behaviour a pre-1.33 save needs.
function R.new(saved)
  local bonds = {}
  for id, bond in pairs(type(saved) == "table" and saved or {}) do
    if type(id) == "string" and id ~= "" then bonds[id] = normaliseBond(bond) end
  end
  return enforceLimit(bonds)
end

function R.serialize(bonds) return R.new(bonds) end

-- ------------------------------------------------------------------
-- Derivation
-- ------------------------------------------------------------------
-- Pure.  Same bond in, same state out, on any platform, in any save.
--
-- Order is the design.  HOSTILE and ALLIED are the extremes and win outright.
-- RIVALRY sits ABOVE RESPECT so a hot feud reads as a feud -- but only while
-- respect is still low, which is what lets the canonical arc (beaten, beaten,
-- beaten, then finally winning) land on RESPECT rather than staying angry
-- forever.  FRIENDLY is last of the positives because liking someone does not
-- override an active competition with them.

function R.state(bond)
  if type(bond) ~= "table" then return "NEUTRAL" end
  local regard  = num(bond.regard, 0)
  local rivalry = num(bond.rivalry, 0)
  local respect = num(bond.respect, 0)
  local edge    = num(bond.wins, 0) - num(bond.losses, 0)
  -- Thresholds are calibrated against the ASYMPTOTIC axes above, not against
  -- raw event counts. Roughly: two contests reach COMPETITIVE, four reach
  -- RIVALRY, eight one-sided defeats reach HOSTILE, and three favours reach
  -- ALLIED. Retune these and rerun tests/relationships_test.lua, which pins
  -- the arc, and the soak, which pins the spread.
  -- HOSTILITY NEEDS A GRIEVANCE, NOT A SCOREBOARD.
  --
  -- The v2.0 integration soak found all four rivals HOSTILE toward the player
  -- while WINNING two battles in three: 200 wins from 300 pinned regard at
  -- -100. Every battle result nudges regard down a little, so over hundreds of
  -- contests any long relationship slides to the floor regardless of who is
  -- actually winning. WORTHY counteracts that for a LEVEL record; a lopsided
  -- one had nothing.
  --
  -- Two counterweights were tried and both were worse than the disease. A
  -- "you do not resent someone you keep beating" bonus small enough to
  -- preserve texture did not reverse the drift; large enough to reverse it,
  -- the whole social graph went uniformly warm and collapsed to two states.
  --
  -- The rule that works is a statement about what hostility MEANS: you do not
  -- come to hate someone you comfortably beat. Battle results alone cannot
  -- produce HOSTILE for a rival that is clearly ahead. That needs real
  -- grievance -- a snub, an ignored request, a stolen title -- which the
  -- causes above supply and which erodes regard on its own terms. A dominant
  -- rival with low regard reads as a RIVALRY, which is what it is.
  local contests = num(bond.wins, 0) + num(bond.losses, 0)
  local known = math.max(0, num(bond.tick, 0) - num(bond.met, num(bond.since, 0)))

  -- 4.6.0: THE NEW STATES ARE TESTED BEFORE THE ONES THEY REFINE.
  --
  -- Each pair below is (more specific, then the general case it came from):
  -- NEMESIS before HOSTILE, DEVOTED before ALLIED, PROTEGE beside MENTOR,
  -- ADMIRER before RESPECT. Written the other way round the specific state is
  -- unreachable -- the general one matches first and always wins -- which is
  -- the "guard that can never be true" failure in a new costume.
  -- 4.7.0's four, and WHERE they sit is the whole design.
  --
  -- BETRAYED outranks even NEMESIS: hatred earned over a hundred battles and
  -- hatred earned in one afternoon by somebody who was supposed to be on your
  -- side are not the same relationship, and the second is the one worth
  -- naming. It is also the only state here that needs a remembered EVENT --
  -- the axes decay, so a bond that says nothing but "very low regard" cannot
  -- tell a betrayal from an ordinary falling-out a year later.
  if num(bond.betrayals, 0) > 0 and regard <= -30 then return "BETRAYED" end
  if regard <= R.NEMESIS_REGARD and rivalry >= R.NEMESIS_RIVALRY
     and contests >= R.NEMESIS_CONTESTS and edge < 3 then
    return "NEMESIS"
  end
  if regard <= -55 and edge < 3 then return "HOSTILE" end
  if num(bond.affection, 0) >= R.DEVOTION_AFFECTION
     and regard >= R.DEVOTION_REGARD
     and num(bond.favours, 0) >= R.DEVOTION_FAVOURS
     and respect >= R.DEVOTION_RESPECT
     and known >= R.DEVOTION_TICKS then
    return "DEVOTED"
  end
  if regard >= 45 and num(bond.favours, 0) >= 2 then return "ALLIED" end
  if regard >= 18 and edge >= 3 and num(bond.lead, 0) >= 2 then return "MENTOR" end
  -- The junior half of the same relationship: behind on the head-to-head and
  -- behind on badges, but warm about it.
  if regard >= 18 and edge <= -3 and num(bond.lead, 0) <= -2 then return "PROTEGE" end
  -- FEARFUL before RIVALRY: a rival that has been beaten six more times than
  -- it has won, and taken no respect from it, is not in a rivalry -- it is
  -- avoiding somebody. Reading that as RIVALRY is what made every one-sided
  -- mauling look like a contest.
  if edge <= -6 and respect < 40 and regard <= 0 then return "FEARFUL" end
  -- JEALOUS before RIVALRY too, and it needs BOTH halves: behind on badges
  -- (they pulled ahead) and hot about it. Rivalry between equals stays
  -- RIVALRY, which is the relationship it actually is.
  if num(bond.lead, 0) <= -2 and rivalry >= 30 and regard < 20
     and num(bond.peakRegard, 0) >= 10 then
    return "JEALOUS"
  end
  if rivalry >= 45 and respect < 40 then return "RIVALRY" end
  -- Respect earned the hard way, from well behind. RESPECT with a losing
  -- record of four or more is not the same relationship as respect between
  -- equals, and reading them as one state loses the more interesting half.
  if respect >= 55 and edge <= -4 and regard >= 0 then return "ADMIRER" end
  if respect >= 40 and regard > -20 then return "RESPECT" end
  -- Warm once, cold now. Inert on any save written before peaks existed,
  -- because a peak that was never recorded reads as the current value.
  if num(bond.peakRegard, 0) >= R.ESTRANGED_PEAK
     and regard <= R.ESTRANGED_REGARD then
    return "ESTRANGED"
  end
  if rivalry >= 20 then return "COMPETITIVE" end
  -- FAMILY is declared by the roster, never earned, so it is read LAST among
  -- the warm states: kin who have fallen out are hostile, kin who compete are
  -- competitive, and kin who are simply kin are family. A tie of blood does
  -- not overwrite what actually happened between them.
  if bond.kin == true and regard > -20 then return "FAMILY" end
  if regard >= 28 then return "FRIENDLY" end
  return "NEUTRAL"
end

-- ------------------------------------------------------------------
-- Pair states (4.6.0)
-- ------------------------------------------------------------------
-- What the two of them ARE, rather than what one of them feels. Both bonds
-- go in; nothing is stored. LOVERS requires both sides to have independently
-- reached DEVOTED, which is what makes it rare without a die being rolled.

local WARM = { DEVOTED = true, ALLIED = true, FRIENDLY = true, FAMILY = true }
local COLD = { HOSTILE = true, NEMESIS = true, BETRAYED = true }

function R.pairState(bondA, bondB)
  local a = R.state(bondA)
  local b = R.state(bondB)
  if a == "DEVOTED" and b == "DEVOTED" then return "LOVERS" end
  if COLD[a] and COLD[b] then return "FEUD" end
  -- UNREQUITED is checked BEFORE mutual warmth on purpose. DEVOTED is itself a
  -- warm state, so "one of them is devoted and the other merely likes them"
  -- satisfies both tests -- and read in the other order it would answer
  -- CLOSE_FRIENDS forever and UNREQUITED never. Same ordering rule as R.state:
  -- the more specific answer is asked first or it is unreachable.
  if (a == "DEVOTED") ~= (b == "DEVOTED") then return "UNREQUITED" end
  -- Kin first among the warm pairings: two rivals the roster declares family
  -- are family, whatever else they also are.
  if a == "FAMILY" and b == "FAMILY" then return "FAMILY" end
  if WARM[a] and WARM[b] then return "CLOSE_FRIENDS" end
  if a == "RIVALRY" and b == "RIVALRY" then return "ARCH_RIVALS" end
  if (a == "MENTOR" and (b == "PROTEGE" or b == "ADMIRER"))
     or (b == "MENTOR" and (a == "PROTEGE" or a == "ADMIRER")) then
    return "MENTORSHIP"
  end
  return "NONE"
end

function R.isPairState(name)
  for _, s in ipairs(R.PAIR_STATES) do if s == name then return true end end
  return false
end

-- ------------------------------------------------------------------
-- Lazy decay
-- ------------------------------------------------------------------
-- Pure: returns a decayed COPY and never touches the store.  Callers that
-- intend to write go through R.apply, which decays first and then mutates.

local function decayed(bond, tick)
  local now = num(tick, bond.tick or 0)
  local steps = math.floor(math.max(0, now - num(bond.tick, now)) / R.DECAY_TICKS)
  if steps <= 0 then return bond end
  steps = math.min(steps, R.DECAY_MAX)
  local out = Util.copy(bond)
  local function toward(v)
    if v > 0 then return math.max(0, v - steps) end
    if v < 0 then return math.min(0, v + steps) end
    return 0
  end
  out.regard  = toward(out.regard)
  out.rivalry = toward(out.rivalry)
  -- respect deliberately does not decay
  out.tick = now
  out.state = R.state(out)
  return out
end

-- The bond this rival holds toward `id`, as of `tick`.  Always a table: an
-- unmet subject is a blank NEUTRAL bond rather than nil, so callers never
-- branch on absence.
function R.bond(bonds, id, tick)
  if type(bonds) ~= "table" or type(id) ~= "string" then return blankBond(tick) end
  local bond = bonds[id]
  if not bond then return blankBond(tick) end
  return decayed(bond, tick)
end

function R.stateOf(bonds, id, tick) return R.state(R.bond(bonds, id, tick)) end

-- ------------------------------------------------------------------
-- Writing
-- ------------------------------------------------------------------

-- 5.21.2: SOCIAL HISTORY. Reasons remain the compact mechanical audit trail;
-- memories are the small set of moments a rival would actually remember. They
-- are stored on the bond so save/load, relationship decay and every consumer
-- share one source of truth.
local SIGNIFICANT_CAUSE = {
  HELPED=true, TRADED=true, COOPERATED=true, REQUEST_DONE=true,
  REQUEST_IGNORED=true, TITLE_LOST=true, TITLE_TAKEN=true, TURNED_ROCKET=true,
  LEFT_ROCKET=true, BETRAYED=true, PROTECTED=true, SHARED_JOURNEY=true,
}
local NEGATIVE = { HOSTILE=true, NEMESIS=true, BETRAYED=true, JEALOUS=true, FEARFUL=true, ESTRANGED=true }
local POSITIVE = { FRIENDLY=true, RESPECT=true, ALLIED=true, MENTOR=true, PROTEGE=true, DEVOTED=true, ADMIRER=true }

local function addMemory(bond, entry)
  bond.memories = type(bond.memories) == "table" and bond.memories or {}
  local last = bond.memories[#bond.memories]
  if last and last.kind == entry.kind and last.cause == entry.cause and last.to == entry.to then
    last.tick = entry.tick
    if entry.text then last.text = entry.text end
    return
  end
  bond.memories[#bond.memories + 1] = entry
  while #bond.memories > R.MEMORY_LIMIT do table.remove(bond.memories, 1) end
end

function R.memories(bond)
  local out = {}
  for _,m in ipairs(type(bond) == "table" and type(bond.memories) == "table" and bond.memories or {}) do
    out[#out+1] = {kind=m.kind,tick=m.tick,cause=m.cause,from=m.from,to=m.to,text=m.text}
  end
  return out
end

function R.memoryText(memory, otherName)
  if type(memory) ~= "table" then return nil end
  if memory.text and memory.text ~= "" then return memory.text end
  local who = tostring(otherName or "them")
  if memory.kind == "RECONCILIATION" then return "Reconciled with " .. who .. "." end
  if memory.kind == "MENTORSHIP" then return "A mentorship with " .. who .. " took shape." end
  if memory.kind == "FRIENDSHIP" then return "Became close to " .. who .. "." end
  if memory.kind == "GRUDGE" then return "A lasting grudge against " .. who .. " began." end
  if memory.kind == "BETRAYAL" then return "Remembers being betrayed by " .. who .. "." end
  if memory.kind == "RESCUE" then return "Remembers " .. who .. " standing between them and danger." end
  local cause = memory.cause and R.reasonText(memory.cause) or "shared history"
  return "Remembers when " .. who .. " " .. cause .. "."
end

-- opts = { tick, lead, memoryText }
-- Returns bond, previousState, newState, changed.
function R.apply(bonds, id, code, opts)
  if type(bonds) ~= "table" or type(id) ~= "string" or id == "" then
    return nil, "NEUTRAL", "NEUTRAL", false
  end
  local effect = R.EFFECTS[code]
  if not effect then return nil, "NEUTRAL", "NEUTRAL", false end
  opts = opts or {}
  local tick = math.max(0, math.floor(num(opts.tick, 0)))
  local bond = bonds[id]
  bond = bond and decayed(bond, tick) or blankBond(tick)
  -- A bond table that did not come through R.new (a pre-4.6 save handed
  -- straight to apply, or another surface's fixture) has no `met`. Stamp it
  -- once, at the earliest moment this bond can prove, rather than leaving the
  -- devotion clock reading from `since` -- which moves every time the state
  -- does, and so never accumulates.
  if bond.met == nil then
    bond.met = math.min(num(bond.since, tick), tick)
  end
  local before = R.state(bond)

  bond.regard  = clampAxis(nudge(bond.regard,  effect.regard,  AXIS_MIN), AXIS_MIN)
  bond.rivalry = clampAxis(nudge(bond.rivalry, effect.rivalry, 0), 0)
  bond.respect = clampAxis(nudge(bond.respect, effect.respect, 0), 0)
  bond.affection = math.floor(Util.clamp(num(bond.affection, 0) + num(effect.affection, 0), AFFECTION_MIN, AFFECTION_MAX))
  bond.favours = math.min(99, bond.favours + (effect.favours or 0))
  -- High-water marks, updated on the one path every change goes through, so
  -- there is no second place that can forget to.
  if (tonumber(effect.betrayal) or 0) > 0 then
    bond.betrayals = math.min(99, num(bond.betrayals, 0) + 1)
  end
  bond.peakRegard = math.max(num(bond.peakRegard, 0), bond.regard)
  bond.peakAffection = math.max(num(bond.peakAffection, 0), bond.affection)
  if opts.lead ~= nil then
    bond.lead = math.floor(Util.clamp(num(opts.lead, 0), -8, 8))
  end
  bond.tick = math.max(bond.tick or 0, tick)
  bond.reasons[#bond.reasons + 1] = { code = code, tick = tick }
  while #bond.reasons > R.REASON_LIMIT do table.remove(bond.reasons, 1) end

  local after = R.state(bond)
  if SIGNIFICANT_CAUSE[code] then
    local kind = "MILESTONE"
    if code == "BETRAYED" or code == "TURNED_ROCKET" then kind = "BETRAYAL"
    elseif code == "PROTECTED" or code == "HELPED" then kind = "RESCUE"
    elseif code == "SHARED_JOURNEY" or code == "COOPERATED" then kind = "SHARED_HISTORY" end
    addMemory(bond, {kind=kind,tick=tick,cause=code,from=before,to=after,text=opts.memoryText})
  end
  if after ~= before then
    bond.since = tick
    local kind = "TURNING_POINT"
    if NEGATIVE[before] and POSITIVE[after] then kind = "RECONCILIATION"
    elseif after == "MENTOR" or after == "PROTEGE" then kind = "MENTORSHIP"
    elseif after == "FRIENDLY" or after == "ALLIED" or after == "DEVOTED" then kind = "FRIENDSHIP"
    elseif NEGATIVE[after] then kind = "GRUDGE" end
    addMemory(bond, {kind=kind,tick=tick,cause=code,from=before,to=after})
  end
  bond.state = after
  bonds[id] = bond
  enforceLimit(bonds)
  return bond, before, after, after ~= before
end

-- A completed contest between this rival and `id`, from this rival's side.
-- The follow-on causes (AVENGED, REPEAT_LOSS) are derived HERE from the bond's
-- own record so no caller has to remember to add them, and so two callers
-- cannot disagree about when they apply.
function R.battle(bonds, id, won, opts)
  if type(bonds) ~= "table" or type(id) ~= "string" or id == "" then
    return nil, "NEUTRAL", "NEUTRAL", false
  end
  opts = opts or {}
  local tick = math.max(0, math.floor(num(opts.tick, 0)))
  local prior = bonds[id] and decayed(bonds[id], tick) or blankBond(tick)
  local before = R.state(prior)
  local behind = num(prior.losses, 0) > num(prior.wins, 0)
  local streak = num(prior.streak, 0)

  local bond = select(1, R.apply(bonds, id, won and "BATTLE_WIN" or "BATTLE_LOSS", opts))
  if not bond then return nil, before, before, false end
  bond.wins   = bond.wins + (won and 1 or 0)
  bond.losses = bond.losses + (won and 0 or 1)
  bond.streak = won and math.max(1, streak + 1) or math.min(-1, streak - 1)

  if won and behind then
    R.apply(bonds, id, "AVENGED", opts)
  elseif not won and bond.streak <= -3 then
    R.apply(bonds, id, "REPEAT_LOSS", opts)
  end
  -- A long, level head-to-head is the respectful kind of rivalry.  Derived
  -- here rather than left to callers so it cannot be forgotten at one of the
  -- three call sites.
  local total = num(bond.wins, 0) + num(bond.losses, 0)
  if total >= 6 and math.abs(num(bond.wins, 0) - num(bond.losses, 0)) <= 1 then
    R.apply(bonds, id, "WORTHY", opts)
  end
  bond = bonds[id]
  local after = R.state(bond)
  if after ~= before then bond.since = tick end
  bond.state = after
  return bond, before, after, after ~= before
end

-- ------------------------------------------------------------------
-- Seeded affection
-- ------------------------------------------------------------------

local function affectionHash(seed, ownerId, subjectId)
  local h = math.floor(num(seed, 1)) % 2147483647
  local text = tostring(ownerId or "?") .. ":" .. tostring(subjectId or "?")
  for i = 1, #text do h = (h * 1103515245 + text:byte(i) + 12345) % 2147483647 end
  return h
end

-- Every relationship starts with its own stable random warmth for this save.
-- Existing saves keep any affection already written; only missing values are seeded.
function R.seedAffection(bonds, id, seed, ownerId)
  if type(bonds) ~= "table" or type(id) ~= "string" or id == "" then return nil end
  local bond = bonds[id] or blankBond(0)
  if bond.affectionSeeded ~= true then
    bond.affection = 15 + (affectionHash(seed, ownerId, id) % 61) -- 15..75
    bond.affectionSeeded = true
    bonds[id] = bond
    enforceLimit(bonds)
  end
  return bond.affection
end

function R.affection(bonds, id, tick)
  return math.floor(Util.clamp(num(R.bond(bonds, id, tick).affection, 0), 0, 100))
end

-- ------------------------------------------------------------------
-- Presentation
-- ------------------------------------------------------------------

R.LABELS = {
  FRIENDLY = "Friendship", NEUTRAL = "Neutral", COMPETITIVE = "Competition",
  RIVALRY = "Rivalry", RESPECT = "Respect", HOSTILE = "Hatred",
  MENTOR = "Mentor", ALLIED = "Allied",
  DEVOTED = "Devoted", NEMESIS = "Nemesis", PROTEGE = "Protege",
  ADMIRER = "Admirer", ESTRANGED = "Estranged",
  BETRAYED = "Betrayal", JEALOUS = "Jealousy", FEARFUL = "Fear",
  FAMILY = "Family",
}

R.PAIR_LABELS = {
  LOVERS = "Lovers", CLOSE_FRIENDS = "Close Friends", FAMILY = "Family",
  ARCH_RIVALS = "Arch Rivals", FEUD = "Feud", MENTORSHIP = "Mentorship",
  UNREQUITED = "Unrequited", NONE = "",
}

function R.pairLabel(state) return R.PAIR_LABELS[state or "NONE"] or "" end

function R.label(state) return R.LABELS[state or "NEUTRAL"] or "Neutral" end

-- "RIVALRY 12-4 r-38/74/32 (lost to them)".  Debug only; nothing parses this.
function R.describe(bond)
  if type(bond) ~= "table" then return "NEUTRAL" end
  local last = bond.reasons and bond.reasons[#bond.reasons]
  return string.format("%s %d-%d r%d/v%d/s%d a%d%s",
    R.state(bond), num(bond.wins, 0), num(bond.losses, 0),
    num(bond.regard, 0), num(bond.rivalry, 0), num(bond.respect, 0), num(bond.affection, 0),
    last and (" (" .. R.reasonText(last.code) .. ")") or "")
end

-- The sentence the news system prints when a derived state actually moves.
-- Only transitions get printed, and only through this one function, so the
-- player is never told the same thing twice in different words.
function R.headline(name, otherName, state)
  name, otherName = tostring(name or "?"), tostring(otherName or "?")
  if state == "RIVALRY" then
    return name .. " now sees " .. otherName .. " as a bitter rival."
  elseif state == "HOSTILE" then
    return name .. " has fallen out with " .. otherName .. "."
  elseif state == "RESPECT" then
    return name .. " has earned respect for " .. otherName .. "."
  elseif state == "ALLIED" then
    return name .. " and " .. otherName .. " are travelling as allies."
  elseif state == "FRIENDLY" then
    return name .. " has warmed to " .. otherName .. "."
  elseif state == "MENTOR" then
    return name .. " has taken " .. otherName .. " under their wing."
  elseif state == "COMPETITIVE" then
    return name .. " is starting to measure up against " .. otherName .. "."
  elseif state == "DEVOTED" then
    return name .. " has grown very close to " .. otherName .. "."
  elseif state == "NEMESIS" then
    return name .. " has come to hate " .. otherName .. "."
  elseif state == "PROTEGE" then
    return name .. " is learning everything they can from " .. otherName .. "."
  elseif state == "ADMIRER" then
    return name .. " has come to look up to " .. otherName .. "."
  elseif state == "ESTRANGED" then
    return name .. " and " .. otherName .. " have drifted apart."
  elseif state == "BETRAYED" then
    return name .. " will not forgive " .. otherName .. "."
  elseif state == "JEALOUS" then
    return name .. " cannot stand how far ahead " .. otherName .. " is."
  elseif state == "FEARFUL" then
    return name .. " has started avoiding " .. otherName .. "."
  end
  return nil
end

-- The pair headline. Said ONCE, about both of them, when the two bonds agree
-- on something -- so "they are together now" is not reported twice in two
-- slightly different sentences (the 461-to-13 lesson: a state change is not
-- automatically news, and the same news is not two items).
function R.pairHeadline(nameA, nameB, pairState)
  nameA, nameB = tostring(nameA or "?"), tostring(nameB or "?")
  if pairState == "LOVERS" then
    return nameA .. " and " .. nameB .. " are inseparable now."
  elseif pairState == "CLOSE_FRIENDS" then
    return nameA .. " and " .. nameB .. " have become close friends."
  elseif pairState == "ARCH_RIVALS" then
    return nameA .. " and " .. nameB .. " have become arch rivals."
  elseif pairState == "FEUD" then
    return nameA .. " and " .. nameB .. " are openly feuding."
  elseif pairState == "MENTORSHIP" then
    return nameA .. " is teaching " .. nameB .. " the ropes."
  end
  return nil
end

return R
