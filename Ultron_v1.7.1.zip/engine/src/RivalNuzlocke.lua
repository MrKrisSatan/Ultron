local req, mod = ...
local Util = req("src/Util")

-- Nuzlocke participation for autonomous AI rivals.
--
-- This is deliberately separate from src/Nuzlocke.lua.  The player's rules
-- are chosen in the NUZLOCKE tab; a rival is an independent trainer choosing
-- to attempt its own run.  The two systems can therefore coexist, or either
-- one can be used by itself.
local N = {}

N.MODE_COUNTS = { off=0, one=0, rare=0.05, some=0.15, many=0.35, all=1.0 }
N.TITLE = "Nuzlocke Rival"

local function truthy(v)
  if v==true or v==1 then return true end
  local s=tostring(v or ""):lower()
  return s=="1" or s=="true" or s=="on" or s=="yes"
end

local function hash(seed,text)
  local h=(tonumber(seed) or 1)%4294967296
  text=tostring(text or "")
  for i=1,#text do h=(h*33+text:byte(i)+17)%4294967296 end
  return h
end

local function areaKey(mapId)
  local id=tostring(mapId or ""):upper()
  -- The World carries both native and absorbed Johto namespaces.  Preserve
  -- the route number but strip the namespace so a connection/map alias cannot
  -- accidentally grant the same trainer two Route 29 catches.
  local n=id:match("ROUTE[_ ]?(%d+)")
  if n then return "ROUTE_"..n end
  -- Named encounter areas are one area across floors/interiors.
  id=id:gsub("^J2_","")
  id=id:gsub("_B%d+F$",""):gsub("_%d+F$","")
       :gsub("_FLOOR_%d+$",""):gsub("_BASEMENT_%d+$","")
  return id
end
N.areaKey=areaKey

local function state(rival)
  local s=type(rival) == "table" and rival.nuzlocke or nil
  return type(s)=="table" and s or nil
end

function N.isActive(rival)
  local s=state(rival)
  return s~=nil and s.active==true and s.failed~=true
end

function N.start(rival,tick,rules,replacementOf)
  if type(rival)~="table" then return nil end
  local existing=state(rival)
  if existing and existing.active and not existing.failed then return existing end
  rival.nuzlocke={
    version=1, active=true, failed=false, rules=rules or "standard",
    startedTick=math.max(0,math.floor(tonumber(tick) or tonumber(rival.ticks) or 0)),
    encounters={}, deaths={}, deathCount=0, catches=0, replacementOf=replacementOf,
    playerInformed=false,
  }
  -- Nuzlocke rivals do not species-hunt or Wonder Trade around the encounter
  -- rule. Their identity is the run, not collector optimisation.
  rival.huntTarget=nil; rival.huntMap=nil; rival.huntFailedAttempts=0
  rival.wonderTradeCooldown=999999
  return rival.nuzlocke
end

function N.restore(rival,saved)
  if type(rival)~="table" then return end
  if type(saved)~="table" then rival.nuzlocke=nil; return end
  rival.nuzlocke=Util.copy(saved)
  local s=rival.nuzlocke
  s.version=1; s.active=s.active==true; s.failed=s.failed==true
  s.encounters=type(s.encounters)=="table" and s.encounters or {}
  s.deaths=type(s.deaths)=="table" and s.deaths or {}
  s.deathCount=math.max(0,math.floor(tonumber(s.deathCount) or #s.deaths))
  s.catches=math.max(0,math.floor(tonumber(s.catches) or 0))
end

function N.serialize(rival)
  local s=state(rival)
  return s and Util.copy(s) or nil
end

function N.encounterOpen(rival,mapId)
  if not N.isActive(rival) then return true,nil end
  local key=areaKey(mapId)
  return rival.nuzlocke.encounters[key]==nil,key
end

function N.recordCatch(rival,mapId,species,level,tick)
  if not N.isActive(rival) then return false end
  local key=areaKey(mapId)
  if rival.nuzlocke.encounters[key] then return false end
  rival.nuzlocke.encounters[key]={species=tostring(species or "UNKNOWN"),level=tonumber(level),tick=tonumber(tick) or tonumber(rival.ticks) or 0,caught=true}
  rival.nuzlocke.catches=(tonumber(rival.nuzlocke.catches) or 0)+1
  return true,key
end

function N.recordMiss(rival,mapId,species,reason,tick)
  if not N.isActive(rival) then return false end
  local key=areaKey(mapId)
  if rival.nuzlocke.encounters[key] then return false end
  rival.nuzlocke.encounters[key]={species=tostring(species or "UNKNOWN"),tick=tonumber(tick) or tonumber(rival.ticks) or 0,caught=false,reason=reason or "MISSED"}
  return true,key
end

local function memorial(slot,reason,tick)
  return { species=slot and slot.species or "UNKNOWN", level=tonumber(slot and slot.level) or 1,
    nickname=slot and (slot.nickname or slot.name), reason=reason or "FAINTED",
    tick=tonumber(tick) or 0, ace=slot and slot.ace==true }
end

-- Remove every newly-fainted Pokemon from the usable team.  Dead Pokemon are
-- memorial data only; putting them into the normal PC would let managePC pull
-- them back out and silently violate permadeath.
function N.sweepFaints(rival,reason,tick,log)
  if not N.isActive(rival) then return 0,false end
  local s=rival.nuzlocke
  local dead=0
  local kept={}
  for _,slot in ipairs(rival.party or {}) do
    local hp=tonumber(slot.hp)
    if hp~=nil and hp<=0 then
      local row=memorial(slot,reason,tick)
      s.deaths[#s.deaths+1]=row; s.deathCount=(tonumber(s.deathCount) or 0)+1; dead=dead+1
      if log then pcall(log,rival,{kind="nuzlocke_death",species=row.species,level=row.level,reason=row.reason}) end
    else kept[#kept+1]=slot end
  end
  rival.party=kept
  -- A Nuzlocke rival may have living legal catches in the PC. A battle wipe,
  -- however, is the run-ending condition used by this challenge population.
  local wiped=#kept==0 and dead>0
  if wiped then N.fail(rival,reason or "WHITEOUT",tick,log) end
  if rival.refreshAce then pcall(rival.refreshAce,rival) end
  return dead,wiped
end

function N.fail(rival,reason,tick,log)
  local s=state(rival)
  if not s or s.failed then return false end
  s.failed=true; s.active=false; s.failReason=reason or "NUZLOCKE FAILED"
  s.failedTick=tonumber(tick) or tonumber(rival.ticks) or 0
  rival.nuzlockeFailedPending=true
  rival.objective="NUZLOCKE_FAILED"
  rival.destination=nil; rival.route=nil; rival.path=nil
  if rival.setState then pcall(rival.setState,rival,"DEFEATED","Nuzlocke challenge ended") end
  if log then pcall(log,rival,{kind="nuzlocke_failed",reason=s.failReason,deaths=s.deathCount or 0}) end
  return true
end

function N.cautiousHealThreshold(rival,normal)
  if N.isActive(rival) then return math.max(0.62,tonumber(normal) or 0.3) end
  return tonumber(normal) or 0.3
end

function N.battleReady(rival,minimumHealth)
  if not N.isActive(rival) then return true end
  local health=rival.healthFraction and rival:healthFraction() or 1
  return health>=math.max(0.72,tonumber(minimumHealth) or 0)
end

function N.gymConfidenceBar(rival,bar)
  if not N.isActive(rival) then return bar end
  return math.max(1.08,(tonumber(bar) or 0.9)*1.15)
end

function N.shopTarget(rival,item,target)
  if not N.isActive(rival) then return target end
  local floors={POKE_BALL=8,GREAT_BALL=3,ULTRA_BALL=2,POTION=6,SUPER_POTION=4,HYPER_POTION=2,ANTIDOTE=4,PARLYZ_HEAL=2,AWAKENING=2,BURN_HEAL=1,ICE_HEAL=1}
  return math.max(tonumber(target) or 0,floors[item] or 0)
end

function N.allowedShopItem(rival,item)
  if N.isActive(rival) and item=="REVIVE" then return false end
  return true
end

function N.prioritySupplies(rival)
  if not N.isActive(rival) then return {} end
  return {
    {item="POKE_BALL",target=8},
    {item="ANTIDOTE",target=4},
    {item="POTION",target=6},
    {item="PARLYZ_HEAL",target=2},
    {item="SUPER_POTION",target=3},
  }
end

function N.populationTarget(total,mode)
  total=math.max(0,math.floor(tonumber(total) or 0)); mode=tostring(mode or "some"):lower()
  if mode=="one" then return total>0 and 1 or 0 end
  local ratio=N.MODE_COUNTS[mode] or N.MODE_COUNTS.some
  if ratio<=0 or total==0 then return 0 end
  if ratio>=1 then return total end
  return math.min(total,math.max(1,math.floor(total*ratio+0.5)))
end

-- Pick exactly target rivals from the ordinary live roster. Existing active
-- runs are preserved; only missing slots are filled. This prevents reloads or
-- an options refresh from rerolling who is undertaking the challenge.
function N.ensurePopulation(rivals,mode,seed,tick,log)
  local eligible={}; local activeRows={}
  for _,r in ipairs(rivals or {}) do
    if r and r.def and not r.def.rareSpecial and not r.def.alwaysActive and not r.def.generational then
      eligible[#eligible+1]=r
      if N.isActive(r) then activeRows[#activeRows+1]=r end
    end
  end
  local target=N.populationTarget(#eligible,mode)
  table.sort(eligible,function(a,b)
    local ha=hash(seed,"nuz:"..tostring(a.id)); local hb=hash(seed,"nuz:"..tostring(b.id))
    if ha~=hb then return ha<hb end
    return tostring(a.id)<tostring(b.id)
  end)

  -- The population setting is authoritative. Reducing it retires excess
  -- challenges without deleting those rivals from the ordinary world. A
  -- failed run is never reactivated by this reconciliation.
  local kept=0
  for _,r in ipairs(eligible) do
    if N.isActive(r) then
      kept=kept+1
      if kept>target then
        r.nuzlocke.active=false
        r.nuzlocke.retiredFromChallenge=true
        r.nuzlocke.retiredTick=tonumber(tick) or tonumber(r.ticks) or 0
      end
    end
  end
  local active=math.min(kept,target)
  local added=0
  for _,r in ipairs(eligible) do
    if active>=target then break end
    local ss=state(r)
    if not (ss and (ss.active or ss.failed or ss.retiredFromChallenge)) then
      N.start(r,tick,"standard")
      active=active+1; added=added+1
      if log then pcall(log,r,{kind="nuzlocke_start"}) end
    end
  end
  return added,target
end

function N.introLine(rival)
  if not N.isActive(rival) then return nil end
  return tostring(rival.name or "This rival")..": I'm attempting a Nuzlocke. If one of my Pokemon faints, it's gone, and I only catch my first encounter on each route."
end

return N
