local req, mod = ...

-- Sprite interoperability for AI Rivals.
--
-- The central rule is simple: AI Rivals owns NO trainer/player/NPC artwork.
-- It only asks the currently merged game data for a logical walker id at the
-- moment an NPC is spawned.  A visual replacement mod therefore remains the
-- authority over the image/frame data attached to that id.  We never write
-- record.image, frames, palette, dimensions, or renderer markers.
--
-- Replacement mods generally patch the vanilla logical ids in place.  For
-- overhauls that instead introduce renamed ids, the semantic fallback scanner
-- below can also locate a compatible live walker from id/name/role metadata.

local Sprites = {}
Sprites.__index = Sprites

Sprites.FOREIGN_MARKERS = {
  "hgssNativeImage", "hgssFrameWidth", "hgssFrameHeight",
  "nativeImage", "replacementImage", "spriteReplacement",
  "trueColor", "frameWidth", "frameHeight",
}

local FEMALE = {
  ADRIANNA=true, ALEXANDRA=true, AMBER=true, AMELIA=true, ARIA=true, ASHLEY=true,
  BEA=true, BETH=true, BIANCA=true, CASS=true, CHARLOTTE=true, CHLOE=true,
  CLAIRE=true, DANA=true, DAWN=true, ELLA=true, EMILY=true, ERIN=true,
  FLORA=true, GINA=true, GRACE=true, HANNAH=true, HOLLY=true, JADE=true,
  JASMINE=true, JESSICA=true, JUNE=true, KAREN=true, LARISSA=true,
  LAURA=true, LILY=true, LUCY=true, MIA=true, NATALIE=true, OLIVIA=true,
  RACHEL=true, SARA=true, SARAH=true, SOPHIE=true, VICTORIA=true,
}
local MALE = {
  AARON=true, ALEXANDER=true, ANDY=true, BEN=true, CALEB=true, CEDRIC=true,
  CHRIS=true, CHRISTOPHER=true, COLE=true, DANTE=true, DAVID=true, ELI=true,
  FINN=true, GABE=true, HEATH=true, IVAN=true, JACK=true, JAMES=true,
  JAMIE=true, JESSE=true, JOHN=true, JOSH=true, KEVIN=true, LEON=true,
  MATT=true, MICHAEL=true, NATHAN=true, NICK=true, NOAH=true, PATRICK=true,
  ROBERT=true, RYAN=true, SAM=true, SHAWN=true, THOMAS=true, TYLER=true,
  WILLIAM=true,
}

local ROLE_IDS = {
  female = {
    "SPRITE_COOLTRAINER_F", "SPRITE_LASS", "SPRITE_BRUNETTE_GIRL",
    "SPRITE_GIRL", "SPRITE_KRIS", "SPRITE_TEACHER",
  },
  male = {
    "SPRITE_COOLTRAINER_M", "SPRITE_SUPER_NERD", "SPRITE_YOUNGSTER",
    "SPRITE_BUG_CATCHER", "SPRITE_ROCKER", "SPRITE_BLUE", "SPRITE_RED",
    "SPRITE_CHRIS", "SPRITE_SILVER", "SPRITE_GENTLEMAN", "SPRITE_FISHER",
    "SPRITE_SUPER_NERD_GEN2",
  },
  attendant = {
    "SPRITE_SUPER_NERD", "SPRITE_CLERK", "SPRITE_GENTLEMAN", "SPRITE_TEACHER",
    "SPRITE_COOLTRAINER_M", "SPRITE_COOLTRAINER_F", "SPRITE_YOUNGSTER",
    "SPRITE_FISHER", "SPRITE_SUPER_NERD_GEN2",
  },
}

local ROLE_WORDS = {
  female = { "COOLTRAINER_F", "LASS", "GIRL", "FEMALE", "KRIS", "TEACHER", "WOMAN" },
  male = { "COOLTRAINER_M", "YOUNGSTER", "BUG_CATCHER", "SUPER_NERD", "MALE", "CHRIS", "SILVER", "GENTLEMAN", "FISHER", "ROCKER" },
  attendant = { "CLERK", "ATTENDANT", "RECEPTION", "SHOP", "SUPER_NERD", "GENTLEMAN", "TEACHER" },
}

local function firstToken(name)
  local s = tostring(name or ""):upper():gsub("[^A-Z ]", " ")
  return s:match("^%s*([A-Z]+)") or s
end

function Sprites.inferGender(name, explicit)
  local token = firstToken(name)
  if FEMALE[token] then return "female" end
  if MALE[token] then return "male" end
  if explicit == "female" or explicit == "male" then return explicit end
  return "male"
end

-- Kept as a public helper for old compatibility tests and third-party probes.
-- AI Rivals itself no longer paints sprite records at all.
function Sprites.foreignArt(record, vanillaImage, ourImage)
  if type(record) ~= "table" then return false end
  for _, key in ipairs(Sprites.FOREIGN_MARKERS) do
    if record[key] ~= nil then return true end
  end
  local image = record.image
  if image == nil or vanillaImage == nil then return false end
  if ourImage ~= nil and image == ourImage then return false end
  return image ~= vanillaImage
end

function Sprites.new(modApi)
  return setmetatable({ mod = modApi, slots = {}, assignments = {} }, Sprites)
end

-- Historical no-ops retained for callers.  Capturing/repainting a "vanilla"
-- baseline is exactly what caused conflicts with visual overhaul mods, so the
-- compatibility model is now fully live-data driven.
function Sprites:captureVanilla() end
function Sprites:refreshVanilla() end

function Sprites:activeData(data)
  local live
  pcall(function() live = self.mod and self.mod.game and self.mod.game.data end)
  return type(live) == "table" and live or data
end

function Sprites:table(data)
  data = self:activeData(data)
  if type(data) ~= "table" then return nil end
  -- Gold may expose a Gen 1-compatible `sprites` facade as well as the real
  -- gen2Sprites table. Runtime map objects are rebuilt by the Gen 2 engine,
  -- so their sprite id MUST come from gen2Sprites or it may be reinterpreted
  -- as an unrelated overworld/Pokemon sprite after a map reload.
  if data.gen2Maps or data.gen2Trainers or data.gen2Sprites then
    return data.gen2Sprites or data.sprites
  end
  return data.sprites
end

local function brokenExternalAsset(id, rec)
  if type(rec)~="table" then return false end
  local key=tostring(id or ""):upper()
  for _,field in ipairs({"hgssNativeImage","nativeImage","replacementImage","spriteReplacement","image"}) do
    local value=rec[field]
    if key:find("KRIS",1,true) and field~="image" and value~=nil then
      return true
    end
    if type(value)=="string" then
      local path=value:lower():gsub("\\","/")
      -- HGSS Sprites currently publishes a Kris override record whose target
      -- file is absent. Selecting it reaches Sprite.lua:59 and aborts the
      -- whole game. Reject both the explicit missing path and the KRIS record
      -- carrying a foreign override; the ROM/native walker fallback remains.
      if path:find("/kris.png",1,true)
         or (key:find("KRIS",1,true) and path:find("mods/",1,true)) then
        return true
      end
    end
  end
  return false
end

local function usable(rec, id)
  if type(rec) ~= "table" then return false end
  if brokenExternalAsset(id,rec) then return false end
  -- Player portraits, battle pictures and decorative sprites can share the
  -- same table as overworld people. An image alone does not make them valid
  -- NPC walkers; feeding an explicitly non-walker record to a map object
  -- creates a perfectly interactive but invisible rival on some renderers.
  if rec.walker == false or rec.npc == false or rec.overworld == false
     or rec.visible == false or rec.hidden == true then return false end
  if tonumber(rec.width) == 0 or tonumber(rec.height) == 0
     or tonumber(rec.frameWidth) == 0 or tonumber(rec.frameHeight) == 0 then
    return false
  end
  -- image is the common contract, but some replacement renderers supply a
  -- native/proxy image through their own marker and leave image lazy.
  return rec.image ~= nil or rec.hgssNativeImage ~= nil or rec.nativeImage ~= nil
      or rec.replacementImage ~= nil or rec.walker == true
end

function Sprites:exists(id, data)
  local sprites = self:table(data)
  return id ~= nil and type(sprites) == "table" and usable(sprites[id],id)
end

-- Public name for materialisation/static-slot callers. Keeping the complete
-- test here prevents the three spawn paths from slowly acquiring different
-- ideas of what constitutes a drawable overworld person.
function Sprites:npcSafe(id, data)
  return self:exists(id, data)
end

local function appendUnique(out, seen, id)
  if id ~= nil and id ~= "" and not seen[id] then
    seen[id] = true
    out[#out + 1] = id
  end
end

function Sprites:semanticWalker(role, data, preferred)
  local sprites = self:table(data)
  if type(sprites) ~= "table" then return nil end

  local candidates, seen = {}, {}
  if type(preferred) == "table" then
    for _, id in ipairs(preferred) do appendUnique(candidates, seen, id) end
  else
    appendUnique(candidates, seen, preferred)
  end
  for _, id in ipairs(ROLE_IDS[role] or {}) do appendUnique(candidates, seen, id) end
  for _, id in ipairs(candidates) do
    if usable(sprites[id],id) then return id, "logical-id" end
  end

  -- Renamed-id fallback for total visual overhauls.  We do not inspect image
  -- paths or copy art; we simply find a live walker whose own metadata says it
  -- fulfils the requested semantic role.
  local words = ROLE_WORDS[role] or {}
  local matches = {}
  for id, rec in pairs(sprites) do
    if usable(rec,id) then
      local hay = table.concat({ tostring(id or ""), tostring(rec.id or ""),
        tostring(rec.name or ""), tostring(rec.label or ""),
        tostring(rec.role or ""), tostring(rec.class or "") }, " "):upper()
      local score = 0
      for i, word in ipairs(words) do
        if hay:find(word, 1, true) then score = score + (#words - i + 1) end
      end
      if score > 0 then matches[#matches + 1] = { id=id, score=score } end
    end
  end
  table.sort(matches, function(a,b)
    if a.score ~= b.score then return a.score > b.score end
    return tostring(a.id) < tostring(b.id)
  end)
  if matches[1] then return matches[1].id, "semantic-scan" end

  -- Last resort is any live walker, chosen deterministically.  This preserves
  -- playability even in a conversion that removed every familiar id.
  local any = {}
  for id, rec in pairs(sprites) do if usable(rec,id) then any[#any+1] = id end end
  table.sort(any, function(a,b) return tostring(a) < tostring(b) end)
  if any[1] then return any[1], "live-fallback" end
  return nil
end

function Sprites:registerSlots(roster, data)
  self.slots = {}
  for _, def in ipairs(roster or {}) do
    local gender = Sprites.inferGender(def.name, def.gender)
    local sprite, source = self:semanticWalker(gender, data,
      { def.overworldSprite, def.sprite, def.spriteId, def.fallbackSprite })
    self.slots[def.id] = { gender=gender, sprite=sprite, source=source }
  end
end

function Sprites:resolve(data)
  local roster = data and data.roster or data
  self:registerSlots(roster or {}, self:activeData(data))
  return self.slots
end

-- Append the ids a roster row names for itself, most specific first.
--
-- THIS IS NOT A LOOP OVER A TABLE CONSTRUCTOR. Both call sites used to do
--
--     for _, id in ipairs({ def.overworldSprite, def.sprite, def.spriteId,
--                           def.fallbackSprite }) do
--
-- and ipairs STOPS AT THE FIRST NIL. Every roster row in this mod leaves
-- overworldSprite nil and sets fallbackSprite, so the constructor was
-- { nil, nil, nil, "SPRITE_BLACKBELT" } and the loop yielded NOTHING. Guts
-- has never once been resolved as a Blackbelt -- he has been silently taking
-- SPRITE_COOLTRAINER_M, the first male id in the role list, since the day
-- walkerFor was written. Nothing errored, and the fallback was good enough to
-- look intentional.
local function appendAuthored(list, def)
  if type(def) ~= "table" then return list end
  local fields = { "overworldSprite", "sprite", "spriteId", "fallbackSprite" }
  for _, field in ipairs(fields) do
    local id = def[field]
    if id ~= nil and id ~= "" then list[#list + 1] = id end
  end
  return list
end

-- ONE SPRITE PER RIVAL, CHOSEN BY GENDER, KEPT FOR THE SAVE (5.1.0)
-- ------------------------------------------------------------------
-- walkerFor returns the FIRST usable id in preference order, which is right
-- for "what should this trainer look like" and wrong for a roster: every male
-- rival without an authored preference resolved to SPRITE_COOLTRAINER_M and
-- the world filled up with the same man. data/rivals.lua worked around it by
-- alternating two sprites on slot parity, which is two men instead of one.
--
-- assignWalker picks ONE id out of the whole gender pool as a pure function of
-- (world seed, rival id). Deterministic, so the same save always dresses a
-- rival the same way even before anything is stamped; varied, because the
-- index is a hash rather than a position.
--
-- AUTHORED PREFERENCE STILL WINS. Chris is meant to look like Blue. If the
-- def names sprites and one is usable, that is the answer and the hash never
-- runs -- identity beats variety.
local function hashPick(seed, text, n)
  if n <= 0 then return nil end
  local h = 2166136261
  local s = tostring(seed) .. "|" .. tostring(text)
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return (h % n) + 1
end

function Sprites:genderPool(def, data)
  local role = Sprites.inferGender(def and def.name, def and def.gender)
  local sprites = self:table(data)
  local out = {}
  if type(sprites) ~= "table" then return out, role end
  for _, id in ipairs(ROLE_IDS[role] or {}) do
    if usable(sprites[id],id) then out[#out + 1] = id end
  end
  return out, role
end

-- `seed` is the persisted world seed. Returns id, source.
function Sprites:assignWalker(def, data, seed, preferred)
  local authored = {}
  if type(preferred) == "table" then
    for _, id in ipairs(preferred) do authored[#authored + 1] = id end
  elseif preferred then authored[#authored + 1] = preferred end
  if def then
    -- fallbackSprite counts as AUTHORED. Guts is meant to be a Blackbelt and
    -- Navin a Youngster, and neither id is in a gender pool. Generated rows
    -- (slots 6..100) no longer set the field at all, so they still reach the
    -- hash and get one sprite each from their full gender pool.
    appendAuthored(authored, def)
  end
  local sprites = self:table(data)
  if type(sprites) == "table" then
    for _, id in ipairs(authored) do
      if usable(sprites[id],id) then return id, "authored" end
    end
  end

  local pool = self:genderPool(def, data)
  if #pool > 0 then
    local index = hashPick(seed, "sprite:" .. tostring(def and def.id or "?"), #pool)
    return pool[index], "assigned"
  end

  -- No pool at all means a total conversion removed every id we know. Fall
  -- back to the existing resolver, which scans metadata and then takes any
  -- live walker -- §7: the thing genuinely may not exist.
  return self:walkerFor(def, data, preferred), "fallback"
end

function Sprites:walkerFor(def, data, preferred)
  local gender = Sprites.inferGender(def and def.name, def and def.gender)
  local list = {}
  if type(preferred) == "table" then
    for _, id in ipairs(preferred) do list[#list+1] = id end
  elseif preferred then list[#list+1] = preferred end
  appendAuthored(list, def)
  return self:semanticWalker(gender, data, list)
end

function Sprites:npcFor(role, data, preferred)
  return self:semanticWalker(role or "attendant", data, preferred)
end

-- Battle portraits are intentionally not copied or rewritten.  Trainer records
-- continue to reference the game's logical trainer class, so replacement mods
-- that replace that class's portrait stay authoritative.
function Sprites:battlePicFor() return nil end

function Sprites:describe()
  local out = {}
  for id, row in pairs(self.slots or {}) do
    out[#out + 1] = ("%s=%s/%s"):format(id, tostring(row.gender), tostring(row.sprite or "live"))
  end
  table.sort(out)
  return table.concat(out, " ")
end

return Sprites
