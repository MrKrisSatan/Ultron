local req, mod = ...
local Util = req("src/Util")
local BattleSim = req("src/BattleSim")

-- TEAM IDENTITY (1.34.0).
--
-- 1.32 gave rivals memory and 1.33 gave them relationships. This file gives
-- them a recognisable TEAM: a reason to prefer one Pokémon over another that
-- is not simply "it is stronger".
--
-- WHY THIS IS NOT A NEW SCORING FUNCTION
--
-- `Rival:teamFor` already picks the best six against a specific opponent, by
-- level, coverage, resistance and move power. That function is REACTIVE and it
-- is correct -- a rival walking into Misty should bring what beats Misty. But
-- if it is the only thing choosing a team, four rivals converge on the same
-- optimum, which is exactly the homogenisation roadmap §39 forbids.
--
-- So this file contributes an IDENTITY term that sits alongside the matchup
-- term rather than replacing it. The matchup answers "what wins this fight";
-- the identity answers "what kind of trainer am I". A Collector with a mono-
-- type habit still brings a counter to a Gym, but between two similar options
-- it takes the one that looks like its team.
--
-- WHERE THE IDENTITY COMES FROM
--
-- `personality.teamPlan` has been declared in data/personalities.lua since the
-- personality system was written and read by NOTHING. It is the seed here, so
-- the four rivals start divergent without a new data file.
--
--   CHALLENGER  aggressive -> HYPER_OFFENSIVE
--   SPEEDRUNNER coverage   -> FAST
--   COLLECTOR   varied     -> EVOLUTION
--   STRATEGIST  balanced   -> BALANCED
--
-- From there the identity MOVES, and only on evidence. A rival that keeps
-- being beaten drifts defensive; one that wins with speed leans further into
-- it; one whose type credit concentrates becomes a mono-type specialist. Type
-- preference is never assigned: it accumulates from the types a rival actually
-- fields and wins with, bounded to a handful of entries.
--
-- Everything here is pure and deterministic. No RNG, no clock, no engine.

local TeamPlan = {}

-- 1.37.0 adds WEATHER, which roadmap §6 listed and 1.34 omitted: a rival that
-- builds around the sky rather than around a matchup. It is the archetype that
-- makes §18's weather-aware travel a team decision instead of a detour.
TeamPlan.ARCHETYPES = {
  "BALANCED", "HYPER_OFFENSIVE", "DEFENSIVE", "STATUS",
  "MONO_TYPE", "FAST", "EVOLUTION", "FAVOURITE", "ANTI_PLAYER",
  "WEATHER",
}

local ARCHETYPE_SET = {}
for _, a in ipairs(TeamPlan.ARCHETYPES) do ARCHETYPE_SET[a] = true end
function TeamPlan.isArchetype(name) return ARCHETYPE_SET[name] == true end

-- Bounds. Type credit is the only thing here that could grow with play.
TeamPlan.TYPE_LIMIT = 8      -- types a rival tracks credit for
TeamPlan.CREDIT_MAX = 60     -- ceiling on any one type's credit
TeamPlan.DRIFT_LIMIT = 40    -- evidence needed before the style may move
TeamPlan.MONO_SHARE = 0.55   -- share of credit that marks a type specialist

-- The seed mapping from the (previously unused) personality field.
TeamPlan.FROM_PLAN = {
  aggressive = "HYPER_OFFENSIVE",
  coverage   = "FAST",
  varied     = "EVOLUTION",
  balanced   = "BALANCED",
  defensive  = "DEFENSIVE",
  status     = "STATUS",
  mono       = "MONO_TYPE",
  weather    = "WEATHER",
}

-- Weights are applied to NORMALISED traits (each roughly 0..1), so a weight
-- reads directly as "how much this archetype cares". They deliberately do not
-- sum to one: an archetype that cares about little is a narrow archetype.
TeamPlan.WEIGHTS = {
  BALANCED        = { offence = 0.5, bulk = 0.5, speed = 0.4, status = 0.3,
                      evolution = 0.3, typeFocus = 0.0, favourite = 0.5 },
  HYPER_OFFENSIVE = { offence = 1.4, bulk = 0.0, speed = 0.7, status = 0.0,
                      evolution = 0.3, typeFocus = 0.0, favourite = 0.4 },
  DEFENSIVE       = { offence = 0.2, bulk = 1.4, speed = 0.0, status = 0.6,
                      evolution = 0.2, typeFocus = 0.0, favourite = 0.5 },
  STATUS          = { offence = 0.3, bulk = 0.7, speed = 0.4, status = 1.4,
                      evolution = 0.2, typeFocus = 0.0, favourite = 0.4 },
  MONO_TYPE       = { offence = 0.5, bulk = 0.4, speed = 0.3, status = 0.2,
                      evolution = 0.3, typeFocus = 1.5, favourite = 0.6 },
  FAST            = { offence = 0.8, bulk = 0.1, speed = 1.4, status = 0.1,
                      evolution = 0.3, typeFocus = 0.0, favourite = 0.4 },
  EVOLUTION       = { offence = 0.4, bulk = 0.4, speed = 0.3, status = 0.2,
                      evolution = 1.4, typeFocus = 0.2, favourite = 0.6 },
  FAVOURITE       = { offence = 0.4, bulk = 0.4, speed = 0.3, status = 0.2,
                      evolution = 0.3, typeFocus = 0.4, favourite = 1.6 },
  ANTI_PLAYER     = { offence = 0.9, bulk = 0.4, speed = 0.6, status = 0.4,
                      evolution = 0.2, typeFocus = 0.0, favourite = 0.4 },
  -- Weather teams lean on typeFocus like MONO_TYPE, but the type they focus on
  -- is the sky's rather than their own record -- see Rival:weatherFocusType.
  WEATHER         = { offence = 0.6, bulk = 0.5, speed = 0.3, status = 0.3,
                      evolution = 0.3, typeFocus = 1.2, favourite = 0.5 },
}

TeamPlan.LABELS = {
  BALANCED = "Balanced", HYPER_OFFENSIVE = "Hyper Offensive",
  DEFENSIVE = "Defensive", STATUS = "Status", MONO_TYPE = "Mono-Type",
  FAST = "Fast", EVOLUTION = "Evolution", FAVOURITE = "Favourite",
  ANTI_PLAYER = "Anti-Player", WEATHER = "Weather",
}

TeamPlan.BATTLE_STYLE = {
  BALANCED = "Tactical", HYPER_OFFENSIVE = "Aggressive",
  DEFENSIVE = "Defensive", STATUS = "Tactical", MONO_TYPE = "Tactical",
  FAST = "Aggressive", EVOLUTION = "Ace Protector",
  FAVOURITE = "Ace Protector", ANTI_PLAYER = "Tactical",
  WEATHER = "Weather",
}

function TeamPlan.label(style) return TeamPlan.LABELS[style or "BALANCED"] or "Balanced" end
function TeamPlan.battleStyle(style)
  return TeamPlan.BATTLE_STYLE[style or "BALANCED"] or "Tactical"
end

-- ------------------------------------------------------------------
-- Species traits
-- ------------------------------------------------------------------
-- Read from the engine's own species table. Nothing is invented and nothing is
-- cached across boots: a total conversion with different stats yields
-- different traits, which is the point.

local function stat(base, ...)
  for _, key in ipairs({ ... }) do
    local v = tonumber(base and base[key])
    if v then return v end
  end
  return 0
end

-- 0..1 each, so archetype weights are comparable.
function TeamPlan.traits(def, moves, data)
  local base = def and (def.baseStats or def.base or def.stats) or {}
  local hp   = stat(base, "hp")
  local atk  = stat(base, "attack", "atk")
  local dfn  = stat(base, "defense", "defence", "def")
  local spd  = stat(base, "speed", "spe")
  local spc  = stat(base, "special", "sp_attack", "spAttack", "specialAttack")
  local offence = math.min(1, math.max(atk, spc) / 130)
  local bulk    = math.min(1, (hp + dfn) / 240)
  local speed   = math.min(1, spd / 130)
  -- Evolution potential: something still to become is worth more to a rival
  -- building toward a final form than a species that is already finished.
  local evolution = 0
  local evolutions = def and def.evolutions
  if type(evolutions) == "table" and #evolutions > 0 then evolution = 1 end
  -- Status inclination is read off the moves the Pokémon actually knows: a
  -- zero-power move is a status move in every generation this mod supports.
  local status, total = 0, 0
  for _, mid in ipairs(moves or {}) do
    local md = data and data.moves and data.moves[mid]
    if md then
      total = total + 1
      if (tonumber(md.power) or 0) <= 0 then status = status + 1 end
    end
  end
  return {
    offence = offence, bulk = bulk, speed = speed,
    evolution = evolution,
    status = total > 0 and (status / total) or 0,
  }
end

-- ------------------------------------------------------------------
-- The identity record
-- ------------------------------------------------------------------

local function num(v, d) return tonumber(v) or d end

function TeamPlan.new(saved, seedPlan)
  saved = type(saved) == "table" and saved or {}
  local style = saved.style
  if not TeamPlan.isArchetype(style) then
    style = TeamPlan.FROM_PLAN[tostring(seedPlan or "")] or "BALANCED"
  end
  local credit = {}
  for typeId, value in pairs(type(saved.types) == "table" and saved.types or {}) do
    if type(typeId) == "string" and typeId ~= "" then
      credit[typeId] = Util.clamp(math.floor(num(value, 0)), 0, TeamPlan.CREDIT_MAX)
    end
  end
  local plan = {
    style = style,
    seed = TeamPlan.isArchetype(saved.seed) and saved.seed
      or TeamPlan.FROM_PLAN[tostring(seedPlan or "")] or "BALANCED",
    types = credit,
    -- signed evidence toward a style change; only |drift| >= DRIFT_LIMIT moves it
    drift = Util.clamp(math.floor(num(saved.drift, 0)), -99, 99),
    driftToward = TeamPlan.isArchetype(saved.driftToward) and saved.driftToward or nil,
    changed = math.max(0, math.floor(num(saved.changed, 0))),
  }
  TeamPlan.trimTypes(plan)
  return plan
end

function TeamPlan.serialize(plan) return TeamPlan.new(plan) end

-- Deterministic: ties break on the type name, never on pairs() order.
function TeamPlan.trimTypes(plan)
  local ids = {}
  for id in pairs(plan.types) do ids[#ids + 1] = id end
  if #ids <= TeamPlan.TYPE_LIMIT then return plan end
  table.sort(ids, function(a, b)
    local ca, cb = plan.types[a], plan.types[b]
    if ca ~= cb then return ca > cb end
    return a < b
  end)
  for i = TeamPlan.TYPE_LIMIT + 1, #ids do plan.types[ids[i]] = nil end
  return plan
end

-- The type this rival has actually been succeeding with, and how dominant it
-- is. Returns nil when no type has pulled ahead -- a rival with no preference
-- yet must not be given one.
function TeamPlan.preferredType(plan)
  if type(plan) ~= "table" then return nil, 0 end
  local best, bestValue, total = nil, 0, 0
  local ids = {}
  for id in pairs(plan.types or {}) do ids[#ids + 1] = id end
  table.sort(ids)
  for _, id in ipairs(ids) do
    local value = num(plan.types[id], 0)
    total = total + value
    if value > bestValue then best, bestValue = id, value end
  end
  if not best or total <= 0 then return nil, 0 end
  return best, bestValue / total
end

function TeamPlan.preferredTypes(plan, count)
  local ids = {}
  for id in pairs(type(plan) == "table" and plan.types or {}) do ids[#ids + 1] = id end
  table.sort(ids, function(a, b)
    local ca, cb = plan.types[a], plan.types[b]
    if ca ~= cb then return ca > cb end
    return a < b
  end)
  local out = {}
  for i = 1, math.min(count or 2, #ids) do out[#out + 1] = ids[i] end
  return out
end

-- Credit the types a rival just fought with. Winning is worth more than
-- turning up, but turning up counts -- a rival that keeps fielding Water
-- Pokémon is a Water trainer whether or not it is a good one.
function TeamPlan.creditTypes(plan, types, won)
  if type(plan) ~= "table" or type(types) ~= "table" then return plan end
  local gain = won and 3 or 1
  for _, id in ipairs(types) do
    if type(id) == "string" and id ~= "" then
      plan.types[id] = Util.clamp(num(plan.types[id], 0) + gain, 0, TeamPlan.CREDIT_MAX)
    end
  end
  TeamPlan.trimTypes(plan)
  return plan
end

-- ------------------------------------------------------------------
-- Style drift
-- ------------------------------------------------------------------
-- A style may only move on accumulated evidence, and the evidence must point
-- somewhere specific. This is the same discipline as src/Relationships.lua: no
-- rival ever wakes up with a different identity.

TeamPlan.DRIFT_REASONS = {
  BEATEN_BADLY   = { toward = "DEFENSIVE",   weight = 6 },
  WON_QUICKLY    = { toward = "HYPER_OFFENSIVE", weight = 5 },
  OUTSPED        = { toward = "FAST",        weight = 5 },
  TYPE_MASTERY   = { toward = "MONO_TYPE",   weight = 7 },
  ACE_BOND       = { toward = "FAVOURITE",   weight = 6 },
  PLAYER_PROBLEM = { toward = "ANTI_PLAYER", weight = 7 },
  EVOLVED        = { toward = "EVOLUTION",   weight = 4 },
  -- 1.37.0: winning repeatedly under a sky that suited the team is evidence
  -- for building around the sky on purpose.
  RODE_THE_SKY   = { toward = "WEATHER",     weight = 6 },
}

-- Returns plan, previousStyle, newStyle, changed.
function TeamPlan.observe(plan, reason)
  if type(plan) ~= "table" then return plan, nil, nil, false end
  local entry = TeamPlan.DRIFT_REASONS[reason]
  if not entry then return plan, plan.style, plan.style, false end
  local before = plan.style
  if entry.toward == plan.style then
    -- evidence for what it already is reinforces rather than moves it
    plan.drift = 0
    plan.driftToward = nil
    return plan, before, before, false
  end
  if plan.driftToward ~= entry.toward then
    -- evidence pointing somewhere new erodes the old case before it builds a
    -- new one, so a rival pulled in three directions at once stays put
    plan.drift = math.max(0, plan.drift - entry.weight)
    if plan.drift <= 0 then
      plan.driftToward = entry.toward
      plan.drift = entry.weight
    end
    return plan, before, before, false
  end
  plan.drift = math.min(99, plan.drift + entry.weight)
  if plan.drift >= TeamPlan.DRIFT_LIMIT then
    plan.style = entry.toward
    plan.drift = 0
    plan.driftToward = nil
    plan.changed = math.min(999, plan.changed + 1)
    return plan, before, plan.style, true
  end
  return plan, before, before, false
end

-- ------------------------------------------------------------------
-- Scoring
-- ------------------------------------------------------------------

-- How well one Pokémon fits this rival's identity, 0..1-ish before weighting.
-- Callers scale it; nothing here knows about levels or matchups, which belong
-- to Rival:teamFor.
function TeamPlan.fit(plan, def, moves, data, opts)
  if type(plan) ~= "table" then return 0 end
  local w = TeamPlan.WEIGHTS[plan.style] or TeamPlan.WEIGHTS.BALANCED
  local t = TeamPlan.traits(def, moves, data)
  opts = opts or {}
  local score = t.offence * w.offence
    + t.bulk * w.bulk
    + t.speed * w.speed
    + t.status * w.status
    + t.evolution * w.evolution
  if (w.typeFocus or 0) > 0 then
    -- A WEATHER rival focuses on whatever the sky currently favours; every
    -- other focused archetype focuses on its own accumulated record. The
    -- caller supplies the sky's type because TeamPlan must not reach into
    -- Weather FX -- it has no host, no compat handle, and no business
    -- acquiring one.
    local preferred = (plan.style == "WEATHER" and opts.skyType)
      or TeamPlan.preferredType(plan)
    if preferred then
      for _, id in ipairs(BattleSim.typesOf(def)) do
        if id == preferred then
          score = score + w.typeFocus
          break
        end
      end
    end
  end
  if opts.favourite and (w.favourite or 0) > 0 then
    score = score + w.favourite
  end
  return score
end

-- ------------------------------------------------------------------
-- The favourite (roadmap §7)
-- ------------------------------------------------------------------
-- The ace was previously chosen purely by how remarkable a Pokémon is --
-- rarity, base stats, shininess. That makes a rival's ace a fact about the
-- SPECIES, so two Collectors who both catch a Lapras end up with the same ace.
--
-- §7 asks for the favourite to emerge from the relationship instead: the
-- first Pokémon, the one with the most battles and victories, the one that has
-- been on the team longest. Those are recorded on the slot as it earns them
-- (see Rival:creditLeadBattle), so this stays a pure function of saved data.

function TeamPlan.serviceScore(slot, now)
  if type(slot) ~= "table" then return 0 end
  local battles = num(slot.battles, 0)
  local wins = num(slot.wins, 0)
  -- Diminishing returns: a Pokémon that has fought two hundred battles is not
  -- a hundred times the favourite of one that fought two. Without this, the
  -- starter can never be displaced, however long another Pokémon serves.
  local service = 26 * (1 - 1 / (1 + battles / 12))
  local glory = 34 * (1 - 1 / (1 + wins / 8))
  local tenure = 0
  local since = tonumber(slot.since)
  if since and now and now > since then
    tenure = 20 * (1 - 1 / (1 + (now - since) / 900))
  end
  local first = (slot.origin == "starter") and 18 or 0
  return service + glory + tenure + first
end

return TeamPlan
