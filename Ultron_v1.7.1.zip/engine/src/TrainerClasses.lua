local req=...
local Util=req("src/Util")
local T={}

T.CLASSES={
TRAINER={label="TRAINER",positive={},negative={}},
ACE_TRAINER={label="ACE TRAINER",positive={"BATTLE_XP_25","MONEY_20","DODGE_05"},negative={"DAMAGE_TAKEN_10","CATCH_MINUS_10"},expMultiplier=1.25,moneyMultiplier=1.20,dodgeChance=0.05,incomingDamageMultiplier=1.10,catchMultiplier=0.90},
COLLECTOR={label="COLLECTOR",positive={"CATCH_25","RARE_70","HIGH_DV_20"},negative={"BATTLE_XP_MINUS_10","SHOP_15"},catchMultiplier=1.25,rareEncounterMultiplier=1.70,highDvChance=0.20,expMultiplier=0.90,shopPriceMultiplier=1.15},
BREEDER={label="BREEDER",positive={"LOW_LEVEL_XP_35","HIGH_DV_25","FRIENDSHIP_50"},negative={"MONEY_MINUS_15"},lowLevelExpMultiplier=1.35,highDvChance=0.25,friendshipMultiplier=1.50,moneyMultiplier=0.85},
PRODIGY={label="PRODIGY",positive={"BATTLE_XP_50","HIGH_DV_35","MONEY_15"},negative={"DAMAGE_TAKEN_10","CATCH_MINUS_05"},expMultiplier=1.50,highDvChance=0.35,moneyMultiplier=1.15,incomingDamageMultiplier=1.10,catchMultiplier=0.95},
LUCKY_TRAINER={label="LUCKY TRAINER",positive={"MAX_DV_70","RARE_50","CATCH_10"},negative={"MONEY_MINUS_20","SHOP_10"},perfectDvChance=0.70,rareEncounterMultiplier=1.50,catchMultiplier=1.10,moneyMultiplier=0.80,shopPriceMultiplier=1.10},
SURVIVALIST={label="SURVIVALIST",positive={"DODGE_10","CATCH_10","STATUS_RESIST_25"},negative={"BATTLE_XP_MINUS_10"},dodgeChance=0.10,catchMultiplier=1.10,statusResist=0.25,expMultiplier=0.90},
RANGER={label="RANGER",positive={"CATCH_25","DODGE_05","RARE_25"},negative={"ROCKET_HOSTILE","MONEY_MINUS_10"},catchMultiplier=1.25,dodgeChance=0.05,rareEncounterMultiplier=1.25,moneyMultiplier=0.90,rangerAffinity=1.80,rocketAffinity=0.20},
ROCKET={label="ROCKET",positive={"MONEY_50","CATCH_15","ROCKET_REWARD_X2"},negative={"RANGER_HOSTILE","BATTLE_XP_MINUS_10"},moneyMultiplier=1.50,catchMultiplier=1.15,expMultiplier=0.90,rocketAffinity=2.00,rangerAffinity=0.20},
SCIENTIST={label="SCIENTIST",positive={"RARE_70","HIGH_DV_30","CATCH_UNSEEN_20"},negative={"BATTLE_XP_MINUS_15","DAMAGE_TAKEN_05"},rareEncounterMultiplier=1.70,highDvChance=0.30,unseenCatchMultiplier=1.20,expMultiplier=0.85,incomingDamageMultiplier=1.05},
GAMBLER={label="GAMBLER",positive={"MONEY_VARIABLE","RARE_40","PERFECT_DV_10"},negative={"BAD_DV_15","DAMAGE_TAKEN_05"},rareEncounterMultiplier=1.40,perfectDvChance=0.10,worseDvChance=0.15,incomingDamageMultiplier=1.05,gambleMoney=true},
UNDERDOG={label="UNDERDOG",positive={"HIGHER_LEVEL_XP_X2","CATCH_HIGHER_25"},negative={"LOWER_LEVEL_XP_MINUS_20"},higherLevelExpMultiplier=2.0,lowerLevelExpMultiplier=0.80,higherLevelCatchMultiplier=1.25},
GLASS_CANNON={label="GLASS CANNON",positive={"DAMAGE_DEALT_20","BATTLE_XP_25"},negative={"DAMAGE_TAKEN_20"},outgoingDamageMultiplier=1.20,incomingDamageMultiplier=1.20,expMultiplier=1.25},
TREASURE_HUNTER={label="TREASURE HUNTER",positive={"MONEY_50","RARE_25","ITEM_FIND_25"},negative={"CATCH_MINUS_15","BATTLE_XP_MINUS_10"},moneyMultiplier=1.50,rareEncounterMultiplier=1.25,itemFindMultiplier=1.25,catchMultiplier=0.85,expMultiplier=0.90},
WEATHER_CHASER={label="WEATHER CHASER",positive={"WX_RARE_70","WEATHER_CATCH_25","WEATHER_XP_25"},negative={"WEATHER_DAMAGE_10"},rareEncounterMultiplier=1.35,weatherVariantMultiplier=1.70,weatherCatchMultiplier=1.25,weatherExpMultiplier=1.25,weatherDamageMultiplier=1.10},
CHAMPION_ASPIRANT={label="CHAMPION ASPIRANT",positive={"TRAINER_XP_25","TRAINER_MONEY_25","DODGE_05"},negative={"GYM_DIFFICULTY_10"},expMultiplier=1.25,moneyMultiplier=1.25,dodgeChance=0.05,gymDifficultyMultiplier=1.10},
BUG_CATCHER={label="BUG CATCHER",positive={"BUG_CATCH_35","BUG_XP_35","BUG_RARE_50"},negative={"BUG_WEAKNESS_10"},typeCatch={BUG=1.35},typeExp={BUG=1.35},typeRare={BUG=1.50},typeIncoming={BUG=1.10}},
FISHER={label="FISHER",positive={"WATER_CATCH_40","WATER_XP_25","WATER_RARE_50"},negative={"LAND_XP_MINUS_10"},typeCatch={WATER=1.40},typeExp={WATER=1.25},typeRare={WATER=1.50},landExpMultiplier=0.90},
TRADER={label="TRADER",positive={"WONDER_RETRADE_20_MIN"},negative={},wonderRetradeCooldown=20*60},
}

-- Multi-tier class advancements. TRAINER intentionally remains neutral.
-- Every specialist receives three choices at 3, 6 and 8 badges and after
-- becoming a regional Champion. Each new definition clones the previous one,
-- so both its benefits and drawbacks stack for the rest of the save.
local EVOLUTION_NAMES={
 ACE_TRAINER={"BATTLE_MASTER","TACTICIAN","VETERAN"},
 COLLECTOR={"DEX_CURATOR","RARE_HUNTER","MASTER_COLLECTOR"},
 BREEDER={"DAYCARE_MASTER","GENETICIST","POKEMON_CARETAKER"},
 PRODIGY={"POKEMON_SAVANT","BATTLE_GENIUS","WUNDERKIND"},
 LUCKY_TRAINER={"FORTUNES_FAVOURITE","SERENDIPITY_MASTER","JACKPOT_TRAINER"},
 SURVIVALIST={"WILDERNESS_MASTER","PATHFINDER","IRON_SURVIVOR"},
 RANGER={"RANGER_CAPTAIN","ECOLOGIST","WILDLIFE_GUARDIAN"},
 ROCKET={"ROCKET_ADMIN","ROCKET_MASTERMIND","ROCKET_ENFORCER"},
 SCIENTIST={"PROFESSOR","FIELD_RESEARCHER","POKEMON_ENGINEER"},
 GAMBLER={"HIGH_ROLLER","ODDS_MASTER","FORTUNE_SEEKER"},
 UNDERDOG={"GIANT_SLAYER","COMEBACK_KING","PEOPLES_CHAMPION"},
 GLASS_CANNON={"BERSERKER","DUELIST","ALL_OUT_ACE"},
 TREASURE_HUNTER={"RELIC_HUNTER","ARCHEOLOGIST","MASTER_PROSPECTOR"},
 WEATHER_CHASER={"STORMCALLER","WX_SPECIALIST","CLIMATOLOGIST"},
 CHAMPION_ASPIRANT={"CHAMPION","LEAGUE_MASTER","ELITE_CHALLENGER"},
 BUG_CATCHER={"BUG_MASTER","ENTOMOLOGIST","SWARM_KEEPER"},
 FISHER={"MASTER_ANGLER","MARINE_EXPLORER","TIDE_MASTER"},
 TRADER={"TRADE_TYCOON","WONDER_BROKER","MARKET_MASTER"},
}
T.EVOLUTIONS={}
T.ADVANCEMENT_THRESHOLDS={3,6,8,"CHAMPION"}
local TIER_TITLES={"SPECIALIST","EXPERT","MASTER","LEGEND"}
-- Each milestone has its own three trade-offs. These are deliberately built
-- only from modifiers consumed by the live battle/catch/economy hooks below.
-- `advanced` clones the current class before applying one package, so a tier
-- never replaces the starting class or an earlier advancement.
local ADVANCEMENTS={
 [1]={
  {positive="XP +10%, DAMAGE +5%",negative="DAMAGE TAKEN +4%",apply=function(d)
    d.expMultiplier=(d.expMultiplier or 1)*1.10; d.outgoingDamageMultiplier=(d.outgoingDamageMultiplier or 1)*1.05; d.incomingDamageMultiplier=(d.incomingDamageMultiplier or 1)*1.04 end},
  {positive="CATCH +10%, RARES +15%",negative="MONEY -6%",apply=function(d)
    d.catchMultiplier=(d.catchMultiplier or 1)*1.10; d.rareEncounterMultiplier=(d.rareEncounterMultiplier or 1)*1.15; d.moneyMultiplier=(d.moneyMultiplier or 1)*0.94 end},
  {positive="MONEY +10%, DODGE +2.5%",negative="XP -5%",apply=function(d)
    d.moneyMultiplier=(d.moneyMultiplier or 1)*1.10; d.dodgeChance=(d.dodgeChance or 0)+0.025; d.expMultiplier=(d.expMultiplier or 1)*0.95 end},
 },
 [2]={
  {positive="DAMAGE +8%, DODGE +2%",negative="CATCH -6%",apply=function(d)
    d.outgoingDamageMultiplier=(d.outgoingDamageMultiplier or 1)*1.08; d.dodgeChance=(d.dodgeChance or 0)+0.02; d.catchMultiplier=(d.catchMultiplier or 1)*0.94 end},
  {positive="HIGH DV +18%, CATCH +8%",negative="XP -7%",apply=function(d)
    d.highDvChance=(d.highDvChance or 0)+0.18; d.catchMultiplier=(d.catchMultiplier or 1)*1.08; d.expMultiplier=(d.expMultiplier or 1)*0.93 end},
  {positive="MONEY +15%, RARES +10%",negative="DAMAGE TAKEN +6%",apply=function(d)
    d.moneyMultiplier=(d.moneyMultiplier or 1)*1.15; d.rareEncounterMultiplier=(d.rareEncounterMultiplier or 1)*1.10; d.incomingDamageMultiplier=(d.incomingDamageMultiplier or 1)*1.06 end},
 },
 [3]={
  {positive="XP +15%, HIGH DV +10%",negative="MONEY -10%",apply=function(d)
    d.expMultiplier=(d.expMultiplier or 1)*1.15; d.highDvChance=(d.highDvChance or 0)+0.10; d.moneyMultiplier=(d.moneyMultiplier or 1)*0.90 end},
  {positive="RARES +25%, PERFECT DV +8%",negative="DAMAGE TAKEN +8%",apply=function(d)
    d.rareEncounterMultiplier=(d.rareEncounterMultiplier or 1)*1.25; d.perfectDvChance=(d.perfectDvChance or 0)+0.08; d.incomingDamageMultiplier=(d.incomingDamageMultiplier or 1)*1.08 end},
  {positive="DODGE +5%, CATCH +12%",negative="DAMAGE -6%",apply=function(d)
    d.dodgeChance=(d.dodgeChance or 0)+0.05; d.catchMultiplier=(d.catchMultiplier or 1)*1.12; d.outgoingDamageMultiplier=(d.outgoingDamageMultiplier or 1)*0.94 end},
 },
 [4]={
  {positive="DAMAGE +12%, XP +12%",negative="DAMAGE TAKEN +10%",apply=function(d)
    d.outgoingDamageMultiplier=(d.outgoingDamageMultiplier or 1)*1.12; d.expMultiplier=(d.expMultiplier or 1)*1.12; d.incomingDamageMultiplier=(d.incomingDamageMultiplier or 1)*1.10 end},
  {positive="RARES +35%, PERFECT DV +12%",negative="MONEY -15%",apply=function(d)
    d.rareEncounterMultiplier=(d.rareEncounterMultiplier or 1)*1.35; d.perfectDvChance=(d.perfectDvChance or 0)+0.12; d.moneyMultiplier=(d.moneyMultiplier or 1)*0.85 end},
  {positive="MONEY +25%, DODGE +7.5%",negative="XP -12%",apply=function(d)
    d.moneyMultiplier=(d.moneyMultiplier or 1)*1.25; d.dodgeChance=(d.dodgeChance or 0)+0.075; d.expMultiplier=(d.expMultiplier or 1)*0.88 end},
 },
}
local function clone(v)
 if type(v)~="table" then return v end
 local o={}; for k,x in pairs(v) do o[k]=clone(x) end; return o
end
local function advanced(previous,id,label,base,tier,branch)
 local d=clone(T.CLASSES[previous]); d.label=label
 d.baseClass=base; d.previousClass=previous; d.evolutionBranch=branch
 d.advancementTier=tier; d.prestige=true
  d.positive=d.positive or {}; d.negative=d.negative or {}
 local package=ADVANCEMENTS[tier] and ADVANCEMENTS[tier][branch]
 if package then
  package.apply(d)
  d.advancementPositive=package.positive; d.advancementNegative=package.negative
  d.positive[#d.positive+1]="T"..tier.."B"..branch.."_POSITIVE"
  d.negative[#d.negative+1]="T"..tier.."B"..branch.."_NEGATIVE"
 end
 return d
end
for base,names in pairs(EVOLUTION_NAMES) do
 T.EVOLUTIONS[base]={}
 local parents={base}
 for tier=1,4 do
  local nextParents={}
  for _,previous in ipairs(parents) do
   T.EVOLUTIONS[previous]={}
   for branch=1,3 do
    local id=base.."__T"..tier.."B"..branch.."_"..previous:gsub("[^A-Z0-9]",""):sub(-10)
    local root=tier==1 and names[branch]:gsub("_"," ")
      or (TIER_TITLES[tier].." "..({"VANGUARD","SEEKER","WARDEN"})[branch])
    T.CLASSES[id]=advanced(previous,id,root,base,tier,branch)
    T.EVOLUTIONS[previous][branch]=id; nextParents[#nextParents+1]=id
   end
  end
  parents=nextParents
 end
end
function T.baseClass(id) local d=T.CLASSES[id]; return d and (d.baseClass or id) or "TRAINER" end
function T.advancementTier(id) local d=T.CLASSES[id]; return d and (d.advancementTier or 0) or 0 end
function T.evolutionChoices(id) return T.EVOLUTIONS[id] or {} end
function T.advancementSummary(id)
 local d=T.CLASSES[id] or {}
 return d.advancementPositive or "BONUS",d.advancementNegative or "DRAWBACK"
end
function T.isEvolved(id) return T.advancementTier(id)>0 end
function T.canEvolve(id,badges,champion)
 if id=="TRAINER" then return false end
 local tier=T.advancementTier(id); if tier>=4 or #T.evolutionChoices(id)~=3 then return false end
 local need=T.ADVANCEMENT_THRESHOLDS[tier+1]
 return need=="CHAMPION" and champion==true or type(need)=="number" and (tonumber(badges) or 0)>=need
end
function T.evolve(id,branch) return T.evolutionChoices(id)[tonumber(branch) or 0] end

-- Rivals see exactly the same three definitions as the player. Their choice
-- is a transparent play-style score from state they already own, with a
-- deterministic hash only breaking true ties.
function T.bestEvolution(agent,badges,champion,seed)
 local choices=T.evolutionChoices(agent and agent.trainerClassId)
 if not T.canEvolve(agent and agent.trainerClassId,badges,champion) then return nil end
 local p=agent and agent.personality or {}; local priorities=p.priorities or {}
 local wants={power=0,discovery=0,control=0}
 for _,v in ipairs(priorities) do
  if v=="TRAIN" or v=="BATTLE_RIVAL" or v=="GYM" then wants.power=wants.power+2 end
  if v=="CATCH" or v=="EXPLORE" or v=="SEEK_RARE" then wants.discovery=wants.discovery+2 end
  if v=="SHOP" or v=="HEAL" or v=="EARN" then wants.control=wants.control+2 end
 end
 wants.power=wants.power+(tonumber(agent and agent.playerWins) or 0)
 wants.discovery=wants.discovery+math.min(6,tonumber(agent and agent.dex and agent.dex.caught) or #(agent and agent.party or {}))
 wants.control=wants.control+math.floor((tonumber(agent and agent.money) or 0)/2000)
 local scores={wants.power,wants.discovery,wants.control}; local best={}
 local high=math.max(scores[1],scores[2],scores[3])
 for i=1,3 do if scores[i]==high then best[#best+1]=i end end
 local pick=best[1+((tonumber(seed) or 1)+#tostring(agent and agent.id or ""))%#best]
 return choices[pick],pick,scores
end
T.ORDER={"TRAINER","ACE_TRAINER","COLLECTOR","BREEDER","PRODIGY","LUCKY_TRAINER","SURVIVALIST","RANGER","ROCKET","SCIENTIST","GAMBLER","UNDERDOG","GLASS_CANNON","TREASURE_HUNTER","WEATHER_CHASER","CHAMPION_ASPIRANT","BUG_CATCHER","FISHER","TRADER"}

local function hash(seed,text)
 local h=(tonumber(seed) or 1)%2147483647; text=tostring(text or "")
 for i=1,#text do h=(h*1103515245+text:byte(i)+12345)%2147483647 end
 return h
end
function T.get(id) return T.CLASSES[id] or T.CLASSES.TRAINER end
function T.label(id) return T.get(id).label end
function T.valid(id) return type(id)=="string" and T.CLASSES[id]~=nil end
function T.choices()
 local a,b={},{}
 for _,id in ipairs(T.ORDER) do a[#a+1]=T.label(id); b[#b+1]=id end
 return a,b
end

local POOLS={
 RIVAL={"TRAINER","ACE_TRAINER","COLLECTOR","BREEDER","PRODIGY","LUCKY_TRAINER","SURVIVALIST","SCIENTIST","GAMBLER","UNDERDOG","GLASS_CANNON","TREASURE_HUNTER","WEATHER_CHASER","CHAMPION_ASPIRANT","BUG_CATCHER","FISHER","TRADER"},
 RANGER={"RANGER","RANGER","SURVIVALIST","BREEDER","SCIENTIST","ACE_TRAINER","COLLECTOR"},
 ROCKET={"ROCKET","ROCKET","ACE_TRAINER","COLLECTOR","SCIENTIST","GAMBLER","GLASS_CANNON","TREASURE_HUNTER"},
}
local function bias(agent,pool)
 local p=agent and agent.personality
 local id=type(p)=="table" and (p.id or p.label) or p
 id=tostring(id or ""):upper()
 local want
 if id:find("CRUSADER",1,true) then want="CHAMPION_ASPIRANT"
 elseif id:find("COLLECT",1,true) then want="COLLECTOR"
 elseif id:find("STRATEG",1,true) or id:find("CHALLENG",1,true) then want="ACE_TRAINER"
 elseif id:find("SPEED",1,true) then want="PRODIGY"
 elseif id:find("SCIENT",1,true) or id:find("RESEARCH",1,true) then want="SCIENTIST" end
 if not want then return pool end
 local out={want,want}; for _,v in ipairs(pool) do out[#out+1]=v end; return out
end
-- 6.58.2: agent.trainerClass is the battle-registry class STRING everywhere
-- else in this codebase reads it (Rocket:classForMember, Rangers member
-- lookup, Comms, DoubleBattles, Simulation, Phone, ai/main.lua's start_battle
-- calls, and rival.def.trainerClass). This function used to unconditionally
-- overwrite that field with the AI-personality-archetype TABLE from T.get(),
-- clobbering Rocket's own lazily-derived "AIR_ROCKET_<id>" string (and
-- Rangers' pre-set "AIR_RANGER_<i>" string) before either was ever read,
-- which broke trainer-registry lookups and start_battle calls for those
-- members. Nothing in this codebase ever reads .trainerClass as a table, so
-- the archetype now goes under its own field instead of a shared one.
function T.assign(agent,faction,seed)
 if type(agent)~="table" then return "TRAINER" end
 if T.valid(agent.trainerClassId) then agent.trainerArchetype=T.get(agent.trainerClassId); return agent.trainerClassId end
 local pool=bias(agent,POOLS[faction or "RIVAL"] or POOLS.RIVAL)
 local id=pool[1+(hash(seed,tostring(agent.id or agent.name or "agent")..":class")%#pool)]
 agent.trainerClassId=id; agent.trainerArchetype=T.get(id); return id
end

local function defFor(data,species)
 local d=Util.speciesRegistry(data); return species and d[species]
end
local function types(data,species)
 local d=defFor(data,species) or {}; return {d.type1 or d.type,d.type2}
end
local function typed(map,list)
 local m=1
 if type(map)~="table" then return m end
 for _,t in ipairs(list or {}) do if t and map[t] then m=math.max(m,tonumber(map[t]) or 1) end end
 return m
end
function T.catchMultiplier(subject,data,species,ctx)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local m=(tonumber(c.catchMultiplier) or 1)*typed(c.typeCatch,types(data,species))
 if ctx and ctx.weather and ctx.weather~="CLEAR" then m=m*(tonumber(c.weatherCatchMultiplier) or 1) end
 if ctx and ctx.higherLevel then m=m*(tonumber(c.higherLevelCatchMultiplier) or 1) end
 if ctx and ctx.unseen then m=m*(tonumber(c.unseenCatchMultiplier) or 1) end
 return m
end
function T.expMultiplier(subject,data,species,ctx)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local m=(tonumber(c.expMultiplier) or 1)*typed(c.typeExp,types(data,species))
 if ctx and ctx.higherLevel then m=m*(tonumber(c.higherLevelExpMultiplier) or 1) end
 if ctx and ctx.lowerLevel then m=m*(tonumber(c.lowerLevelExpMultiplier) or 1) end
 if ctx and ctx.lowLevel then m=m*(tonumber(c.lowLevelExpMultiplier) or 1) end
 if ctx and ctx.weather and ctx.weather~="CLEAR" then m=m*(tonumber(c.weatherExpMultiplier) or 1) end
 if ctx and ctx.land and c.landExpMultiplier then m=m*c.landExpMultiplier end
 return m
end
function T.moneyMultiplier(subject,rng)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 if c.gambleMoney then
  local r
  if rng and rng.int then r=rng:int(50,400)
  elseif love and love.math and love.math.random then r=love.math.random(50,400)
  else r=math.random(50,400) end
  return r/100
 end
 return tonumber(c.moneyMultiplier) or 1
end
local function chance(rng,p)
 if not p or p<=0 then return false end
 if rng and rng.chance then return rng:chance(p) end
 local r=(love and love.math and love.math.random and love.math.random()) or math.random()
 return r<p
end
function T.modifyDVs(subject,mon,rng)
 if type(mon)~="table" then return false end
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local d=type(mon.dvs)=="table" and mon.dvs or {}
 local changed=false
 if chance(rng,c.perfectDvChance) then
  d.attack,d.defense,d.speed,d.special=15,15,15,15
  if d.specialAttack~=nil then d.specialAttack=15 end
  if d.specialDefense~=nil then d.specialDefense=15 end
  changed=true
 elseif chance(rng,c.highDvChance) then
  for _,k in ipairs({"attack","defense","speed","special","specialAttack","specialDefense"}) do
   if d[k]~=nil or k=="attack" or k=="defense" or k=="speed" or k=="special" then d[k]=math.max(tonumber(d[k]) or 0,12) end
  end
  changed=true
 elseif chance(rng,c.worseDvChance) then
  for _,k in ipairs({"attack","defense","speed","special","specialAttack","specialDefense"}) do
   if d[k]~=nil or k=="attack" or k=="defense" or k=="speed" or k=="special" then d[k]=math.min(tonumber(d[k]) or 7,5) end
  end
  changed=true
 end
 if changed then mon.dvs=d end
 return changed
end

local function encounterSlots(data,mapId)
 local e=data and data.encounters and data.encounters[mapId]
 if type(e)=="table" then return e.slots or e.grass or e end
 local g=data and data.gen2Encounters
 for _,bucket in ipairs(g and {g.grass,g.swarmGrass,g.water} or {}) do
  local row=bucket and bucket[mapId]; if type(row)=="table" then return row.slots or row end
 end
end
function T.modifyEncounter(id,data,enc,ctx,rng)
 local rare=tonumber(T.get(id).rareEncounterMultiplier) or 1
 if rare<=1 or not (enc and enc.species and ctx and ctx.mapId) then return enc end
 local slots=encounterSlots(data,ctx.mapId); if type(slots)~="table" then return enc end
 local dex=Util.speciesRegistry(data); local pool={}
 for key,row in pairs(slots) do
  local sp=type(row)=="table" and (row.species or row.mon or row.id) or (type(row)=="string" and row or (type(key)=="string" and key or nil))
  if sp and dex[sp] then pool[#pool+1]={species=sp,rate=tonumber(dex[sp].catchRate or dex[sp].catch_rate) or 255} end
 end
 if #pool<2 then return enc end
 table.sort(pool,function(a,b) if a.rate~=b.rate then return a.rate<b.rate end return tostring(a.species)<tostring(b.species) end)
 if not chance(rng,math.min(0.45,(rare-1)*0.25)) then return enc end
 local top=math.max(1,math.ceil(#pool*0.25)); local i
 if rng and rng.int then i=rng:int(1,top)
 elseif love and love.math and love.math.random then i=love.math.random(1,top)
 else i=math.random(1,top) end
 return {species=pool[i].species,level=enc.level,classRare=true}
end
T.TRAIT_TEXT={
 ADV_POWER="+10% EXP, +5% DAMAGE",
 ADV_FRAGILE="+4% DAMAGE TAKEN",
 ADV_DISCOVERY="+10% CATCH, +15% RARES",
 ADV_POOR="-6% PRIZE MONEY",
 ADV_CONTROL="+10% MONEY, +2.5% DODGE",
 ADV_SLOW_GROWTH="-5% BATTLE EXP",
 BATTLE_XP_25="+25% BATTLE EXP",
 MONEY_20="+20% PRIZE MONEY",
 DODGE_05="5% CHANCE TO DODGE",
 DAMAGE_TAKEN_10="+10% DAMAGE TAKEN",
 CATCH_MINUS_10="-10% CATCH RATE",
 CATCH_25="+25% CATCH RATE",
 RARE_70="+70% RARE ENCOUNTERS",
 HIGH_DV_20="20% BETTER DV CHANCE",
 BATTLE_XP_MINUS_10="-10% BATTLE EXP",
 SHOP_15="+15% SHOP PRICES",
 LOW_LEVEL_XP_35="+35% EXP FOR WEAKER TEAM MEMBERS",
 HIGH_DV_25="25% BETTER DV CHANCE",
 FRIENDSHIP_50="+50% FRIENDSHIP GROWTH",
 MONEY_MINUS_15="-15% PRIZE MONEY",
 BATTLE_XP_50="+50% BATTLE EXP",
 HIGH_DV_35="35% BETTER DV CHANCE",
 MONEY_15="+15% PRIZE MONEY",
 CATCH_MINUS_05="-5% CATCH RATE",
 MAX_DV_70="70% CHANCE FOR MAX DVS",
 RARE_50="+50% RARE ENCOUNTERS",
 CATCH_10="+10% CATCH RATE",
 MONEY_MINUS_20="-20% PRIZE MONEY",
 SHOP_10="+10% SHOP PRICES",
 DODGE_10="10% CHANCE TO DODGE",
 STATUS_RESIST_25="25% STATUS RESISTANCE",
 RARE_25="+25% RARE ENCOUNTERS",
 ROCKET_HOSTILE="TEAM ROCKET IS MORE HOSTILE",
 MONEY_MINUS_10="-10% PRIZE MONEY",
 MONEY_50="+50% PRIZE MONEY",
 CATCH_15="+15% CATCH RATE",
 ROCKET_REWARD_X2="2X ROCKET JOB REWARDS",
 RANGER_HOSTILE="RANGERS ARE MORE HOSTILE",
 HIGH_DV_30="30% BETTER DV CHANCE",
 CATCH_UNSEEN_20="+20% CATCH RATE ON UNSEEN POKEMON",
 BATTLE_XP_MINUS_15="-15% BATTLE EXP",
 DAMAGE_TAKEN_05="+5% DAMAGE TAKEN",
 MONEY_VARIABLE="PRIZE MONEY CAN ROLL 0.5X-4X",
 RARE_40="+40% RARE ENCOUNTERS",
 PERFECT_DV_10="10% CHANCE FOR MAX DVS",
 BAD_DV_15="15% CHANCE OF WORSE DVS",
 HIGHER_LEVEL_XP_X2="2X EXP VS HIGHER LEVELS",
 CATCH_HIGHER_25="+25% CATCH VS HIGHER LEVELS",
 LOWER_LEVEL_XP_MINUS_20="-20% EXP VS WEAKER POKEMON",
 DAMAGE_DEALT_20="+20% DAMAGE DEALT",
 DAMAGE_TAKEN_20="+20% DAMAGE TAKEN",
 ITEM_FIND_25="+25% ITEM FIND CHANCE",
 CATCH_MINUS_15="-15% CATCH RATE",
 WX_RARE_70="+70% WX/WEATHER VARIANT CHANCE",
 WEATHER_CATCH_25="+25% CATCH RATE IN WEATHER",
 WEATHER_XP_25="+25% EXP IN WEATHER",
 WEATHER_DAMAGE_10="+10% WEATHER DAMAGE TAKEN",
 TRAINER_XP_25="+25% TRAINER BATTLE EXP",
 TRAINER_MONEY_25="+25% TRAINER PRIZE MONEY",
 GYM_DIFFICULTY_10="GYM OPPONENTS ARE 10% TOUGHER",
 BUG_CATCH_35="+35% BUG CATCH RATE",
 BUG_XP_35="+35% EXP FOR BUG POKEMON",
 BUG_RARE_50="+50% RARE BUG ENCOUNTERS",
 BUG_WEAKNESS_10="+10% DAMAGE TO BUG WEAKNESSES",
 WATER_CATCH_40="+40% WATER CATCH RATE",
 WATER_XP_25="+25% EXP FOR WATER POKEMON",
 WATER_RARE_50="+50% RARE WATER ENCOUNTERS",
 LAND_XP_MINUS_10="-10% EXP FROM LAND ENCOUNTERS",
}

function T.traitText(id)
  local tier,branch,kind=tostring(id or ""):match("^T(%d)B(%d)_(%u+)$")
  local package=tier and ADVANCEMENTS[tonumber(tier)]
    and ADVANCEMENTS[tonumber(tier)][tonumber(branch)]
  if package and (kind=="POSITIVE" or kind=="NEGATIVE") then
    return kind=="POSITIVE" and package.positive or package.negative
  end
  return T.TRAIT_TEXT[id] or tostring(id or ""):gsub("_"," ")
end

function T.confirmationText(id)
  local c=T.get(id)
  local pages={}
  local first={c.label}
  if id=="TRAINER" then
    first[#first+1]="NO POSITIVE TRAITS"
    first[#first+1]="NO NEGATIVE TRAITS"
    first[#first+1]="THE CLASSIC POKEMON JOURNEY."
    pages[#pages+1]=table.concat(first,"\n")
  else
    first[#first+1]="POSITIVES:"
    for _,trait in ipairs(c.positive or {}) do
      first[#first+1]=T.traitText(trait)
    end
    pages[#pages+1]=table.concat(first,"\n")

    local second={"NEGATIVES:"}
    for _,trait in ipairs(c.negative or {}) do
      second[#second+1]=T.traitText(trait)
    end
    if #(c.negative or {})==0 then second[#second+1]="NONE" end
    pages[#pages+1]=table.concat(second,"\n")
  end
  pages[#pages+1]="IS THIS YOUR CLASS?"
  return table.concat(pages,"\f")
end

function T.summary(id)
 local c=T.get(id); local out={c.label}
 for _,v in ipairs(c.positive or {}) do out[#out+1]="+"..v:gsub("_"," ") end
 for _,v in ipairs(c.negative or {}) do out[#out+1]="-"..v:gsub("_"," ") end
 return out
end
return T
