local req, mod = ...
local Util = req("src/Util")

-- WEATHER INTELLIGENCE (1.37.0).
--
-- STOP MIRRORING, START READING.
--
-- Since 1.19 this mod has carried hand-written copies of Weather FX's own
-- tables: which battle weather boosts which move type, which type each sky
-- chips. Copies drift, and auditing Weather FX 4.18.6 against ours found that
-- they had -- with a real consequence in battle. See CHIP RESOLUTION below.
--
-- So the catalogue is now READ from the host at runtime through
-- `exports.types()`, which returns Weather FX's live `Types.list`. The static
-- table below is a FALLBACK for when Weather FX is absent, older, or exports
-- something this file does not recognise -- never the primary source.
--
-- Weather FX documents `weather`, `channel`, `battleWeather` and `timeOfDay`
-- as its stable surface and makes no promise about anything else, so
-- `exports.types()` is validated per entry before a single field is trusted
-- and any malformed row is skipped rather than believed.
--
-- CHIP RESOLUTION -- the bug this release fixes
--
-- `exports.battleWeather()` collapses several overworld weathers into one
-- battle-field string, and the chip type is NOT recoverable from it:
--
--     STORM       (chips ELECTRIC) -> battle "RAINY"
--     GALE        (chips FLYING)   -> battle "RAINY"
--     RAIN_LIGHT  (chips WATER)    -> battle "RAINY"
--     THUNDERSNOW (chips ELECTRIC) -> battle "SNOWY"
--     ASHFALL     (chips FIRE)     -> battle "SANDSTORM"
--
-- Our CHIP table was keyed on the battle string, so it resolved every RAINY
-- fight to WATER. In a thunderstorm the simulation chipped an Electric team
-- that Weather FX would have spared, and spared a Water team it would have
-- chipped -- quietly wrong results in every off-screen battle fought under a
-- storm. Chip is now resolved from the OVERWORLD id, which is unambiguous.

local Weather = {}

-- ------------------------------------------------------------------
-- Fallback catalogue
-- ------------------------------------------------------------------
-- Mirrors Weather FX 4.18.6. Used ONLY when the host cannot be read. Fields
-- are exactly those this mod consumes; everything else is Weather FX's own
-- business and is deliberately not copied here.
--
--   chip   the type immune to this sky's residual damage
--   battle the battle-field string exports.battleWeather() returns
--   plus the coarse flags Weather FX keys its encounter rules on

Weather.FALLBACK = {
  CLEAR        = {},
  SUNNY        = { chip = "FIRE",     battle = "SUNNY",        sunny = true },
  HARSH_SUN    = { chip = "FIRE",     battle = "HARSH_SUN",    sunny = true },
  HEATWAVE     = { chip = "FIRE",     battle = "SUNNY",        sunny = true },
  RAIN_LIGHT   = { chip = "WATER",    battle = "RAINY",        wet = true },
  RAIN_HEAVY   = { chip = "WATER",    battle = "RAINY",        wet = true },
  HEAVY_RAIN   = { chip = "WATER",    battle = "HEAVY_RAIN",   wet = true },
  STORM        = { chip = "ELECTRIC", battle = "RAINY",        wet = true },
  GALE         = { chip = "FLYING",   battle = "RAINY",        wet = true },
  VERDANT_RAIN = { chip = "GRASS",    battle = "VERDANT_RAIN", wet = true },
  SNOW_LIGHT   = { chip = "ICE",      battle = "SNOWY",        frozen = true },
  BLIZZARD     = { chip = "ICE",      battle = "SNOWY",        frozen = true },
  SLEET        = { chip = "ICE",      battle = "SNOWY",        frozen = true, wet = true },
  THUNDERSNOW  = { chip = "ELECTRIC", battle = "SNOWY",        frozen = true },
  HAIL         = { chip = "ICE",      battle = "HAIL",         frozen = true },
  SANDSTORM    = { chip = "ROCK",     battle = "SANDSTORM",    sandy = true },
  DUSTSTORM    = { chip = "GROUND",   battle = "DUSTSTORM",    sandy = true },
  ASHFALL      = { chip = "FIRE",     battle = "SANDSTORM",    sandy = true },
  STRONG_WINDS = { chip = "FLYING",   battle = "STRONG_WINDS" },
  FLOCKSTORM   = { chip = "FLYING",   battle = "FLOCKSTORM" },
  SWARM        = { chip = "BUG",      battle = "SWARM" },
  SMOG         = { chip = "POISON",   battle = "SMOG" },
  BRAWL_WIND   = { chip = "FIGHTING", battle = "BRAWL_WIND" },
  HAUNTED_MIST = { chip = "GHOST",    battle = "HAUNTED_MIST" },
  DRAGONSTORM  = { chip = "DRAGON",   battle = "DRAGONSTORM" },
  PSYSTORM     = { chip = "PSYCHIC",  battle = "PSYSTORM",     psychic = true },
  PLAIN_FRONT  = { chip = "NORMAL",   battle = "PLAIN_FRONT" },
  MIST         = { battle = "FOG",    foggy = true },
  FOG          = { battle = "FOG",    foggy = true },
}

-- Gen 1 data calls the Psychic type PSYCHIC_TYPE in some tables and PSYCHIC in
-- others. One spelling, decided here, so no comparison elsewhere has to know.
function Weather.canonicalType(t)
  if t == "PSYCHIC_TYPE" then return "PSYCHIC" end
  return t
end

-- ------------------------------------------------------------------
-- Reading the host
-- ------------------------------------------------------------------

local function validEntry(def)
  if type(def) ~= "table" then return nil end
  local id = def.id
  if type(id) ~= "string" or id == "" then return nil end
  local out = { id = id }
  if type(def.chipType) == "string" then out.chip = Weather.canonicalType(def.chipType) end
  if type(def.battle) == "string" then out.battle = def.battle end
  out.sunny = def.sunny == true
  out.wet = def.wet == true
  out.frozen = def.frozen == true
  out.sandy = def.sandy == true
  out.psychic = def.psychic == true
  return out
end

-- The catalogue, live from the host where possible.
--
-- Cached on the compat handle rather than in a module upvalue: Weather FX can
-- load after this mod, and a module-level cache would freeze the fallback in
-- place for the session. The cache is keyed on the host's reported version so
-- a hot reload to a different build re-reads rather than serving stale rows.
function Weather.catalogue(compat)
  local fallback = {}
  for id, def in pairs(Weather.FALLBACK) do
    fallback[id] = { id = id, chip = def.chip, battle = def.battle,
      sunny = def.sunny == true, wet = def.wet == true,
      frozen = def.frozen == true, sandy = def.sandy == true,
      psychic = def.psychic == true, foggy = def.foggy == true }
  end
  if not compat or type(compat.exports) ~= "function" then return fallback, "fallback" end
  local ok, exports = pcall(compat.exports, compat, "weather")
  if not ok or type(exports) ~= "table" then return fallback, "fallback" end

  local version = type(exports.version) == "string" and exports.version or "?"
  local cached = compat._weatherCatalogue
  if cached and cached.version == version then
    return cached.entries, cached.source
  end

  local entries, source = fallback, "fallback"
  if type(exports.types) == "function" then
    local gotList, list = pcall(exports.types)
    if gotList and type(list) == "table" then
      local live, count = {}, 0
      for _, def in ipairs(list) do
        local entry = validEntry(def)
        if entry then
          live[entry.id] = entry
          count = count + 1
        end
      end
      -- A host that returns a table but no usable rows is treated as absent.
      -- Believing an empty catalogue would silently disable every weather
      -- decision in the mod while reporting success.
      if count >= 4 then
        -- keep fallback-only ids (a downgrade should not lose knowledge we
        -- already have) but let every live row win where they overlap
        for id, def in pairs(fallback) do
          if live[id] == nil then live[id] = def end
        end
        entries, source = live, "host"
      end
    end
  end
  compat._weatherCatalogue = { version = version, entries = entries, source = source }
  return entries, source
end

function Weather.entry(compat, id)
  if type(id) ~= "string" then return nil end
  local catalogue = Weather.catalogue(compat)
  return catalogue[id]
end

-- The type this sky does NOT chip, resolved from the overworld id.
--
-- Never from the battle string: see CHIP RESOLUTION at the top of this file.
function Weather.chipType(compat, id)
  local entry = Weather.entry(compat, id)
  return entry and entry.chip or nil
end

function Weather.battleString(compat, id)
  local entry = Weather.entry(compat, id)
  return entry and entry.battle or nil
end

-- The type a sky FAVOURS for wild encounters. This is Weather FX's own rule
-- from lib/Encounters.lua, reproduced because it is a rule rather than a
-- table and there is no export for it: chipType first, then the coarse flags.
function Weather.favouredType(compat, id)
  local entry = Weather.entry(compat, id)
  if not entry then return nil end
  if entry.chip then return entry.chip end
  if entry.foggy then return "GHOST" end
  if entry.sunny then return "FIRE" end
  if entry.frozen then return "ICE" end
  if entry.wet then return "WATER" end
  if entry.sandy then return "ROCK" end
  return nil
end

-- Types a sky drives away, mirroring Weather FX's DEFAULT_BANS. A rival that
-- knows this can decide a sky is bad hunting for what it wants, which is what
-- makes §19 weather hunting a decision rather than a coin flip.
Weather.BANS = {
  wet     = { "FIRE" },
  sunny   = { "WATER", "ICE" },
  frozen  = { "BUG", "GRASS", "FLYING" },
  sandy   = { "WATER", "BUG" },
  foggy   = { "FIRE" },
  psychic = { "DARK" },
}

function Weather.bannedTypes(compat, id)
  local entry = Weather.entry(compat, id)
  local out = {}
  if not entry then return out end
  for flag, list in pairs(Weather.BANS) do
    if entry[flag] then
      for _, t in ipairs(list) do out[Weather.canonicalType(t)] = true end
    end
  end
  return out
end

-- ------------------------------------------------------------------
-- What a rival makes of the sky
-- ------------------------------------------------------------------

-- -1 .. 1. Positive means this sky suits this team, negative means it wears
-- them down. Derived from the same chip rule the battle uses, so a rival's
-- opinion of the weather and its actual performance under it agree.
function Weather.affinity(compat, id, types)
  local entry = Weather.entry(compat, id)
  if not entry or not entry.chip then return 0 end
  local chip = Weather.canonicalType(entry.chip)
  local matched, total = 0, 0
  for _, t in ipairs(types or {}) do
    total = total + 1
    if Weather.canonicalType(t) == chip then matched = matched + 1 end
  end
  if total == 0 then return 0 end
  -- A team wholly of the sky's type is immune to the chip; a team with none
  -- of it takes chip damage on every member, every turn.
  return (matched / total) * 2 - 1
end

-- Is this sky worth travelling toward to hunt `wanted`? §19.
function Weather.favoursType(compat, id, wanted)
  if type(wanted) ~= "string" then return false end
  wanted = Weather.canonicalType(wanted)
  if Weather.favouredType(compat, id) == wanted then return true end
  return false
end

function Weather.bansType(compat, id, wanted)
  if type(wanted) ~= "string" then return false end
  return Weather.bannedTypes(compat, id)[Weather.canonicalType(wanted)] == true
end

-- A short phrase for dialogue, news and the debug overlay.
function Weather.label(id)
  if type(id) ~= "string" or id == "" then return "clear skies" end
  return (id:gsub("_", " "):lower())
end

return Weather
