local Util=require("mods.ultron.src.Util")
local Achievements={}
local DEFS={
  FIRST_BLOOD={label="FIRST BLOOD",desc="Ultron defeated the player."},
  NOT_AGAIN={label="NOT AGAIN",desc="Ultron blacked out three times."},
  SIGNATURE_BOND={label="SIGNATURE BOND",desc="Ultron chose a permanent signature partner."},
  MACHINE_CHAMPION={label="MACHINE CHAMPION",desc="Ultron entered the Hall of Fame."},
  CARTOGRAPHER={label="CARTOGRAPHER",desc="Ultron learned ten reusable physical routes."},
  COLLECTIVE_MIND={label="COLLECTIVE MIND",desc="Ultron learned from ten independent training sources."},
  LEGEND_THIEF={label="LEGEND THIEF",desc="Ultron caught a legendary Pokemon before the player."},
  NAMING_RIGHTS={label="NAMING RIGHTS",desc="Ultron gave a bonded Pokemon a personal nickname."},
  OLD_GUARD={label="OLD GUARD",desc="A long-serving partner became a veteran."},
  COMEBACK_PROTOCOL={label="COMEBACK PROTOCOL",desc="A partner helped Ultron win a rematch after losing to the player."},
  DYNASTY={label="DYNASTY",desc="A partner entered the Hall of Fame twice and became an Ultron legend."},
}
local ORDER={"FIRST_BLOOD","NOT_AGAIN","SIGNATURE_BOND","MACHINE_CHAMPION","CARTOGRAPHER","COLLECTIVE_MIND","LEGEND_THIEF","NAMING_RIGHTS","OLD_GUARD","COMEBACK_PROTOCOL","DYNASTY"}
local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function Achievements.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=1,unlocked=copy(saved.unlocked),order=copy(saved.order)}
end
local function count(t) local n=0; for _ in pairs(type(t)=="table" and t or {}) do n=n+1 end; return n end
local function blackouts(career)
  local n=0; for _,f in pairs(career and career.failures or {}) do n=n+(tonumber(type(f)=="table" and f.blackouts) or 0) end; return n
end
local function legendaryClaimed(research)
  for _,r in pairs(research and research.ledger or {}) do if type(r)=="table" and r.status=="CLAIMED_ULTRON" then return true end end
  return false
end
local function partnerStats(legacy)
  local veterans,legends,comebacks=0,0,0
  for _,p in pairs(legacy and legacy.profiles or {}) do
    local status=tostring(type(p)=="table" and p.status or "")
    if status=="VETERAN" or status=="HALL_OF_FAMER" or status=="LEGEND" then veterans=veterans+1 end
    if status=="LEGEND" then legends=legends+1 end
    comebacks=comebacks+(tonumber(type(p)=="table" and p.comebacks) or 0)
  end
  return veterans,legends,comebacks
end
local function unlock(state,key,tick)
  if state.unlocked[key] or not DEFS[key] then return nil end
  state.unlocked[key]={tick=tonumber(tick) or 0}; state.order[#state.order+1]=key
  return {kind="achievement",id=key,label=DEFS[key].label,desc=DEFS[key].desc}
end
function Achievements.tick(saved,ctx)
  local s=Achievements.new(saved); ctx=type(ctx)=="table" and ctx or {}; local events={}; local c=ctx.career or {}
  local r=c.rivalry or {}
  local veterans,legends,partnerComebacks=partnerStats(ctx.partnerLegacy)
  local checks={
    FIRST_BLOOD=(tonumber(r.ultronWins) or 0)>=1,
    NOT_AGAIN=blackouts(c)>=3,
    SIGNATURE_BOND=type(c.signatureSpecies)=="string",
    MACHINE_CHAMPION=type(c.hallOfFame)=="table" and #c.hallOfFame>=1,
    CARTOGRAPHER=count(ctx.routeMemory and ctx.routeMemory.learned)>=10,
    COLLECTIVE_MIND=(tonumber(ctx.trainingSources) or 0)>=10,
    LEGEND_THIEF=legendaryClaimed(ctx.research),
    NAMING_RIGHTS=(tonumber(ctx.nicknames and ctx.nicknames.total) or 0)>=1,
    OLD_GUARD=veterans>=1,
    COMEBACK_PROTOCOL=partnerComebacks>=1,
    DYNASTY=legends>=1,
  }
  for _,key in ipairs(ORDER) do if checks[key] then local e=unlock(s,key,ctx.tick); if e then events[#events+1]=e end end end
  return s,events
end
function Achievements.summary(saved)
  local s=Achievements.new(saved); local out={"ULTRON ACHIEVEMENTS: "..tostring(#s.order).."/"..tostring(#ORDER)}
  if #s.order==0 then out[#out+1]="None unlocked yet." else
    for _,key in ipairs(s.order) do local d=DEFS[key]; if d then out[#out+1]="* "..d.label.." - "..d.desc end end
  end
  return table.concat(out,"\n")
end
Achievements.DEFS=DEFS; Achievements.ORDER=ORDER
return Achievements
