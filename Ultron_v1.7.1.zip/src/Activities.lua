local Activities={}
local function upper(v) return tostring(v or ""):upper() end
function Activities.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=1,cooldown=math.max(0,tonumber(saved.cooldown) or 0),uses=tonumber(saved.uses) or 0,last=saved.last}
end
local function find(mod,ids)
  if not(mod and mod.find) then return nil end
  for _,id in ipairs(ids) do local ok,h=pcall(function() return mod:find(id) end); if ok and h then return h end end
end
local function exported(handle,names,...)
  local e=handle and handle.exports
  for _,name in ipairs(names) do if e and type(e[name])=="function" then local ok,res=pcall(e[name],...); if ok and res~=false then return true,res end end end
  return false
end
function Activities.tick(saved,rival,engine)
  local s=Activities.new(saved); if s.cooldown>0 then s.cooldown=s.cooldown-1; return s end
  if not(rival and engine and rival.map) then return s end
  local map=upper(rival.map); local kind,ok,res
  if map:find("BUG_CATCH",1,true) or map:find("NATIONAL_PARK",1,true) then
    kind="bug_contest"; ok,res=exported(find(engine.mod,{"bug_catching_contest","bug-contest","the_world"}),{"ultronEnterBugContest","aiEnterBugContest"},rival)
  elseif map:find("SAFARI",1,true) then
    kind="safari"; ok,res=exported(find(engine.mod,{"safari_zone","safari-zone","the_world"}),{"ultronEnterSafari","aiEnterSafari"},rival)
  elseif rival.isAtPokemonCenter and rival:isAtPokemonCenter() then
    local wonder=find(engine.mod,{"wonder_trade","wonder-trader","the_world"})
    if wonder and rival.wonderTradeDuplicate then kind="wonder_trade"; res=rival:wonderTradeDuplicate(); ok=res~=nil end
    if not ok then
      local gift=find(engine.mod,{"mystery_gift","mystery-gift","the_world"})
      kind="mystery_gift"; ok,res=exported(gift,{"claimForAI","claimForRival","ultronClaim"},rival)
    end
  elseif map:find("ROUTE",1,true) or map:find("LAKE",1,true) or map:find("SEA",1,true) then
    local fishing=find(engine.mod,{"fishing","the_world"})
    kind="fishing"; ok,res=exported(fishing,{"fishForAI","fishForRival","ultronFish"},rival,rival.map)
  end
  if ok then s.cooldown=80; s.uses=s.uses+1; s.last=kind; return s,{kind=kind,text="Ultron used "..kind:gsub("_"," ").." legitimately."} end
  return s
end
return Activities
