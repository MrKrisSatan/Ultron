local Util = require("mods.ultron.src.Util")
local Atlas = {}

function Atlas.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    knownMaps = type(saved.knownMaps) == "table" and saved.knownMaps or {},
    blocked = type(saved.blocked) == "table" and saved.blocked or {},
    mapGrids = type(saved.mapGrids) == "table" and saved.mapGrids or {},
    recoveries = math.max(0, tonumber(saved.recoveries) or 0),
    lastMap = saved.lastMap, lastX = saved.lastX, lastY = saved.lastY,
    stationary = math.max(0, tonumber(saved.stationary) or 0),
    graphCount = math.max(0, tonumber(saved.graphCount) or 0),
  }
end

function Atlas.index(state, graph)
  state = Atlas.new(state); state.knownMaps = {}
  for id in pairs(graph and graph.nodes or {}) do state.knownMaps[id] = true end
  state.graphCount = Util.count(state.knownMaps); return state
end

function Atlas.knows(state, mapId)
  return type(state)=="table" and type(state.knownMaps)=="table" and state.knownMaps[mapId]==true
end

local function rememberLiveGrid(state,manager,mapId)
  if not(manager and manager.overview and mapId) then return end
  local ok,o=pcall(function() return manager:overview() end)
  if not(ok and o and o.mapId==mapId and type(o.rows)=="table" and #o.rows>0) then return end
  local rows={}; for i,row in ipairs(o.rows) do rows[i]=tostring(row) end
  state.mapGrids[mapId]={width=tonumber(o.width) or #rows[1],rows=rows}
end

function Atlas.observe(state, rival, manager, dt)
  state = Atlas.new(state); if not rival then return state end
  local map,x,y=rival.map,rival.x,rival.y
  rememberLiveGrid(state,manager,map)
  if map and x and y and map==state.lastMap and x==state.lastX and y==state.lastY
     and (rival.state=="TRAVELLING" or rival.state=="EXPLORING" or rival.state=="SEEKING_GYM" or rival.state=="SEEKING_PLAYER") then
    state.stationary=state.stationary+(tonumber(dt) or 0)
  else state.stationary=0 end
  state.lastMap,state.lastX,state.lastY=map,x,y
  local key=tostring(map)..":"..tostring(x)..","..tostring(y)
  local learned=tonumber(state.blocked[key]) or 0
  local threshold=learned>=2 and 0.8 or 5.5
  if state.stationary>=threshold then
    -- No teleport recovery. A stalled cell becomes navigation evidence; the
    -- route/path is discarded and Ultron backtracks/replans from the same tile.
    state.blocked[key]=math.min(9,learned+1); state.recoveries=state.recoveries+1
    rival.path,rival.localWalkGoal,rival.walkTarget=nil,nil,nil
    rival.route=nil; rival.stuckTicks=(rival.stuckTicks or 0)+1
    state.stationary=0
  end
  return state
end
return Atlas
