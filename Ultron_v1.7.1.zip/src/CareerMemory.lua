local Util = require("mods.ultron.src.Util")
local Career = {}

local STAGE_LABELS = {
  UNKNOWN = "Unknown",
  RIVAL = "Rival",
  NEMESIS = "Nemesis",
  RESPECTED_RIVAL = "Respected Rival",
  CHAMPION_CHALLENGER = "Champion Challenger",
  LEGENDARY_RIVAL = "Legendary Rival",
}

local GOAL_LABELS = {
  PERFECT_TEAM = "Perfect the championship team",
  POKEDEX = "Complete the Pokedex",
  LEGENDARY_HUNT = "Pursue legendary Pokemon",
  UNBEATEN_REIGN = "Build an unbeaten Champion reign",
  DEFEAT_PLAYER = "Solve and defeat the player",
}

local function copyTable(v)
  return type(v) == "table" and Util.copy(v) or {}
end

local function clampInt(v, lo, hi)
  v = math.floor(tonumber(v) or 0)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function speciesOf(slot)
  if type(slot) ~= "table" then return nil end
  return slot.species or slot.speciesId or slot.id
end

local function compactParty(party)
  local out = {}
  for _, slot in ipairs(type(party) == "table" and party or {}) do
    local species = speciesOf(slot)
    if species then
      out[#out + 1] = {
        species = species,
        level = clampInt(slot.level or 1, 1, 100),
        ace = slot.ace == true,
        starter = slot.origin == "starter",
        shiny = slot.shiny == true,
        nickname = type(slot.nickname)=="string" and slot.nickname or nil,
        bondId = type(slot.ultronBondId)=="string" and slot.ultronBondId or nil,
      }
    end
  end
  return out
end

local function bestAnchor(party)
  local best, bestScore
  for _, slot in ipairs(type(party) == "table" and party or {}) do
    local species = speciesOf(slot)
    if species then
      local score = clampInt(slot.level or 1, 1, 100)
      if slot.ace then score = score + 1000 end
      if slot.origin == "starter" then score = score + 80 end
      score = score + math.min(100, tonumber(slot.wins) or 0) * 3
      if not bestScore or score > bestScore then best, bestScore = slot, score end
    end
  end
  return best and speciesOf(best) or nil
end

local function battleRecord(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    battles = math.max(0, tonumber(saved.battles) or 0),
    ultronWins = math.max(0, tonumber(saved.ultronWins) or 0),
    playerWins = math.max(0, tonumber(saved.playerWins) or 0),
    score = clampInt(saved.score or 0, 0, 100),
    stage = STAGE_LABELS[saved.stage] and saved.stage or "UNKNOWN",
  }
end

local function postChampion(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    goal = GOAL_LABELS[saved.goal] and saved.goal or nil,
    chosen = saved.chosen == true,
    titleEntries = math.max(0, tonumber(saved.titleEntries) or 0),
    reignsLost = math.max(0, tonumber(saved.reignsLost) or 0),
  }
end

function Career.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    version = 1,
    rivalry = battleRecord(saved.rivalry),
    battles = copyTable(saved.battles),
    affinity = copyTable(saved.affinity),
    signatureSpecies = type(saved.signatureSpecies) == "string" and saved.signatureSpecies or nil,
    signatureBondId = type(saved.signatureBondId) == "string" and saved.signatureBondId or nil,
    signatureLocked = saved.signatureLocked == true,
    failures = copyTable(saved.failures),
    hallOfFame = copyTable(saved.hallOfFame),
    postChampion = postChampion(saved.postChampion),
    lastChampionFlag = saved.lastChampionFlag == true,
    eventCount = math.max(0, tonumber(saved.eventCount) or 0),
  }
end

local function stageFor(state, rival, chat)
  local r = state.rivalry
  if r.battles <= 0 then return "UNKNOWN", 0 end
  local trust = tonumber(chat and chat.trust) or 0
  local conversational = tonumber(chat and chat.rivalry) or 25
  local closeness = math.max(0, 12 - math.abs(r.ultronWins - r.playerWins) * 2)
  local score = clampInt(20 + r.battles * 5 + closeness + conversational * 0.25 + math.max(0, trust) * 0.15, 0, 100)
  if rival and (rival.champion or rival.everChampion) then score = clampInt(score + 12, 0, 100) end
  local stage = "RIVAL"
  if rival and (rival.champion or rival.everChampion) then
    if r.battles >= 10 and state.signatureSpecies then stage = "LEGENDARY_RIVAL" else stage = "CHAMPION_CHALLENGER" end
  elseif r.battles >= 8 and trust >= 0 then
    stage = "RESPECTED_RIVAL"
  elseif r.battles >= 4 and score >= 50 then
    stage = "NEMESIS"
  end
  return stage, score
end

local function updateStage(state, rival, chat)
  local old = state.rivalry.stage
  local stage, score = stageFor(state, rival, chat)
  state.rivalry.stage, state.rivalry.score = stage, score
  if old ~= stage then return {kind="rivalry_stage", from=old, to=stage, label=STAGE_LABELS[stage]} end
end

local function affinityFor(state, species)
  local a = state.affinity[species]
  if type(a) ~= "table" then
    a = {teamBattles=0,wins=0,losses=0,score=0,lastTick=0}
    state.affinity[species] = a
  end
  return a
end

local function updateAffinity(state, party, won, tick)
  for _, slot in ipairs(type(party) == "table" and party or {}) do
    local species = speciesOf(slot)
    if species then
      local a = affinityFor(state, species)
      a.teamBattles = math.max(0, tonumber(a.teamBattles) or 0) + 1
      if won then a.wins = math.max(0, tonumber(a.wins) or 0) + 1 else a.losses = math.max(0, tonumber(a.losses) or 0) + 1 end
      local gain = won and 3 or 1
      if slot.ace then gain = gain + 2 end
      if slot.origin == "starter" then gain = gain + 1 end
      a.score = math.min(9999, math.max(0, tonumber(a.score) or 0) + gain)
      a.lastTick = tonumber(tick) or 0
    end
  end
end

local function maybeChooseSignature(state)
  if state.signatureLocked and state.signatureSpecies then return nil end
  local best, bestScore
  for species, a in pairs(state.affinity or {}) do
    local battles = tonumber(a.teamBattles) or 0
    local score = tonumber(a.score) or 0
    if battles >= 5 and score >= 12 then
      local total = score + math.min(25, battles * 2) + math.min(20, (tonumber(a.wins) or 0) * 2)
      if not bestScore or total > bestScore or (total == bestScore and tostring(species) < tostring(best)) then
        best, bestScore = species, total
      end
    end
  end
  if best then
    state.signatureSpecies = best
    state.signatureLocked = true
    return {kind="signature_chosen", species=best}
  end
end

local function rememberBattle(state, rival, outcome, ctx)
  local row = {
    tick = tonumber(ctx and ctx.tick) or tonumber(rival and rival.ticks) or 0,
    map = (ctx and ctx.map) or (rival and rival.map),
    result = outcome and outcome.rivalWon and "WIN" or "LOSS",
    ultronTeam = compactParty((ctx and ctx.ultronParty) or (rival and rival.party)),
    playerTeam = compactParty(ctx and ctx.playerParty),
    anchor = bestAnchor((ctx and ctx.ultronParty) or (rival and rival.party)),
  }
  state.battles[#state.battles + 1] = row
  while #state.battles > 64 do table.remove(state.battles, 1) end
  return row
end

function Career.recordPlayerBattle(saved, rival, outcome, ctx, chat)
  local state = Career.new(saved)
  local events = {}
  local won = outcome and outcome.rivalWon == true
  state.rivalry.battles = state.rivalry.battles + 1
  if won then state.rivalry.ultronWins = state.rivalry.ultronWins + 1 else state.rivalry.playerWins = state.rivalry.playerWins + 1 end
  local party = (ctx and ctx.ultronParty) or (rival and rival.party) or {}
  updateAffinity(state, party, won, ctx and ctx.tick)
  local row = rememberBattle(state, rival, outcome, ctx)
  events[#events + 1] = {kind="battle_notebook", result=row.result, map=row.map, anchor=row.anchor}
  local signature = maybeChooseSignature(state); if signature then events[#events + 1] = signature end
  local stage = updateStage(state, rival, chat); if stage then events[#events + 1] = stage end
  state.eventCount = state.eventCount + 1
  return state, events
end

local function failureRecord(state, map)
  map = tostring(map or "UNKNOWN")
  local f = state.failures[map]
  if type(f) ~= "table" then f = {losses=0,blackouts=0,lastReason=nil,lastTick=0}; state.failures[map] = f end
  return f, map
end

function Career.observeNews(saved, rival, event, chat)
  local state = Career.new(saved)
  event = type(event) == "table" and event or {}
  local kind = tostring(event.kind or "")
  local failed = (kind == "blackout") or ((kind == "trainer" or kind == "trainer_battle" or kind == "league" or event.gym) and event.won == false)
  if failed then
    local f, map = failureRecord(state, event.map or event.from or (rival and rival.map))
    f.losses = f.losses + 1
    if kind == "blackout" then f.blackouts = f.blackouts + 1 end
    f.lastReason = event.text or kind
    f.lastTick = tonumber(event.tick) or tonumber(rival and rival.ticks) or 0
    state.eventCount = state.eventCount + 1
  end
  local stage = updateStage(state, rival, chat)
  return state, stage and {stage} or {}
end

local function hashGoalSeed(state, rival)
  local text = table.concat({
    tostring(state.signatureSpecies or "NONE"),
    tostring(state.rivalry.battles), tostring(state.rivalry.ultronWins), tostring(state.rivalry.playerWins),
    tostring(rival and rival.def and rival.def.seed or 0),
  }, ":")
  local h = 0
  for i=1,#text do h = (h * 33 + text:byte(i)) % 2147483647 end
  return h
end

local function choosePostChampionGoal(state, rival)
  if state.postChampion.chosen and state.postChampion.goal then return nil end
  local goal
  if state.rivalry.playerWins > state.rivalry.ultronWins then
    goal = "DEFEAT_PLAYER"
  else
    local goals = {"PERFECT_TEAM","POKEDEX","LEGENDARY_HUNT","UNBEATEN_REIGN","DEFEAT_PLAYER"}
    goal = goals[(hashGoalSeed(state, rival) % #goals) + 1]
  end
  state.postChampion.goal, state.postChampion.chosen = goal, true
  return {kind="post_champion_goal", goal=goal, label=GOAL_LABELS[goal]}
end

local function captureHallOfFame(state, rival)
  local row = {
    tick = tonumber(rival and rival.ticks) or 0,
    team = compactParty(rival and rival.party),
    signature = state.signatureSpecies,
    ultronWins = state.rivalry.ultronWins,
    playerWins = state.rivalry.playerWins,
    badges = rival and rival.badgeCount and rival:badgeCount() or 0,
  }
  state.hallOfFame[#state.hallOfFame + 1] = row
  while #state.hallOfFame > 12 do table.remove(state.hallOfFame, 1) end
  state.postChampion.titleEntries = state.postChampion.titleEntries + 1
  return {kind="hall_of_fame", entry=#state.hallOfFame, team=row.team}
end

function Career.observeProgress(saved, rival, chat)
  local state = Career.new(saved)
  local events = {}
  local champion = rival and rival.champion == true
  if champion and not state.lastChampionFlag then
    events[#events + 1] = captureHallOfFame(state, rival)
    local g = choosePostChampionGoal(state, rival); if g then events[#events + 1] = g end
  elseif not champion and state.lastChampionFlag and rival and rival.everChampion then
    state.postChampion.reignsLost = state.postChampion.reignsLost + 1
    events[#events + 1] = {kind="champion_reign_lost"}
  elseif rival and rival.everChampion and not state.postChampion.chosen then
    local g = choosePostChampionGoal(state, rival); if g then events[#events + 1] = g end
  end
  state.lastChampionFlag = champion
  local signature = maybeChooseSignature(state); if signature then events[#events + 1] = signature end
  local stage = updateStage(state, rival, chat); if stage then events[#events + 1] = stage end
  return state, events
end

local function allSlots(rival)
  local out={}
  for _,slot in ipairs(rival and rival.party or {}) do out[#out+1]=slot end
  for _,box in ipairs(rival and rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do out[#out+1]=slot end end
  return out
end

local function findSignatureSlot(rival, state)
  if not rival then return nil end
  if state.signatureBondId then
    for _,slot in ipairs(allSlots(rival)) do if slot.ultronBondId==state.signatureBondId then return slot end end
  end
  if not state.signatureSpecies then return nil end
  local best,bestScore
  for _,slot in ipairs(allSlots(rival)) do
    if speciesOf(slot)==state.signatureSpecies then
      local score=(tonumber(slot.ultronLegacyScore) or 0)+(tonumber(slot.attachment) or 0)+(slot.ace and 1000 or 0)
      if not bestScore or score>bestScore then best,bestScore=slot,score end
    end
  end
  return best
end

function Career.apply(saved, rival)
  local state = Career.new(saved)
  if not rival then return state end
  rival.ultronSignatureSpecies = state.signatureSpecies
  rival.ultronSignatureBondId = state.signatureBondId
  rival._ultronPostChampionGoal = state.postChampion.goal
  if state.signatureSpecies then
    local slot = findSignatureSlot(rival, state)
    if slot then
      if not state.signatureBondId and type(slot.ultronBondId)=="string" then state.signatureBondId=slot.ultronBondId end
      rival.ultronSignatureBondId=state.signatureBondId
      slot.attached = true
      slot.attachment = math.max(tonumber(slot.attachment) or 0, 110)
    end
  end
  if rival.refreshAce then pcall(function() rival:refreshAce() end) end
  return state
end

function Career.stageLabel(saved)
  local state = Career.new(saved)
  return STAGE_LABELS[state.rivalry.stage] or state.rivalry.stage
end

function Career.goalLabel(saved)
  local state = Career.new(saved)
  return GOAL_LABELS[state.postChampion.goal] or "Not chosen"
end

function Career.summary(saved)
  local state = Career.new(saved)
  local r = state.rivalry
  local recent = state.battles[#state.battles]
  local worstMap, worstScore
  for map, f in pairs(state.failures) do
    local score = (tonumber(f.blackouts) or 0) * 3 + (tonumber(f.losses) or 0)
    if not worstScore or score > worstScore then worstMap, worstScore = map, score end
  end
  local lines = {
    "RIVALRY: "..Career.stageLabel(state).." ("..tostring(r.score).."/100)",
    "RECORD VS PLAYER: "..tostring(r.ultronWins).."-"..tostring(r.playerWins),
    "SIGNATURE: "..tostring(state.signatureSpecies or "Not chosen"),
    "HALL OF FAME TEAMS: "..tostring(#state.hallOfFame),
    "POST-CHAMPION GOAL: "..Career.goalLabel(state),
  }
  if recent then lines[#lines + 1] = "LAST BATTLE: "..tostring(recent.result).." at "..tostring(recent.map or "UNKNOWN"):gsub("_"," ") end
  if worstMap then lines[#lines + 1] = "HARDEST MEMORY: "..tostring(worstMap):gsub("_"," ") end
  return table.concat(lines, "\n")
end

function Career.recentBattle(saved)
  local state = Career.new(saved)
  return state.battles[#state.battles]
end

Career.STAGE_LABELS = STAGE_LABELS
Career.GOAL_LABELS = GOAL_LABELS
return Career
