local Util = require("mods.ultron.src.Util")
local Competitive = require("mods.ultron.src.Competitive")
local Brain = {}
local Exchange = require("mods.ultron.src.TrainingExchange")

local function hasMove(data, slot, wanted)
  for _, id in ipairs(slot and slot.moves or {}) do
    local key = tostring(id):upper():gsub("[^A-Z0-9]", "")
    if key == wanted then return true end
    local md = data and data.moves and data.moves[id]
    if md and tostring(md.name or ""):upper():gsub("[^A-Z0-9]", "") == wanted then return true end
  end
  return false
end

function Brain.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    rebuilds = math.max(0, tonumber(saved.rebuilds) or 0),
    lastPreparedTick = tonumber(saved.lastPreparedTick) or -9999,
    lastReason = saved.lastReason,
    scouting = type(saved.scouting) == "table" and saved.scouting or {},
    grade = saved.grade or "CHAMPIONSHIP",
  }
end

-- Ultron vendors the offline Smogon Gen1/Gen2 snapshot and
-- legal move/item checks. Setting literacy=100 turns every consultation on;
-- this layer adds tournament-style team discipline without pretending modern
-- VGC rules exist inside Gen1/2 mechanics.

local function rematchThreats(career)
  local score={}
  local battles=career and career.battles or {}
  local start=math.max(1,#battles-7)
  for i=start,#battles do
    local row=battles[i]
    if row and row.result=="LOSS" then
      for _,slot in ipairs(row.playerTeam or {}) do
        if slot.species then score[slot.species]=(score[slot.species] or 0)+2+(tonumber(slot.level) or 1)/100 end
      end
    end
  end
  local rows={}
  for species,value in pairs(score) do rows[#rows+1]={species=species,score=value} end
  table.sort(rows,function(a,b) if a.score~=b.score then return a.score>b.score end return tostring(a.species)<tostring(b.species) end)
  while #rows>6 do table.remove(rows) end
  return rows
end

function Brain.prepare(state, rival, modules, reason, training, career)
  state = Brain.new(state)
  if not rival then return state, 0 end
  rival.competitiveLiteracy = 100
  rival.teamPlan = rival.teamPlan or {}
  local known = rival.knownOpponentParty and rival:knownOpponentParty("player") or nil
  local collective = Exchange.collectiveParty(training, rival.ctx and rival.ctx.data, 6)
  local target = {}
  local seen = {}
  local threats=rematchThreats(career)
  for _, slot in ipairs(known or {}) do
    if slot and slot.species and not seen[slot.species] then
      target[#target + 1] = slot; seen[slot.species] = true
    end
  end
  -- Shared training data is prior knowledge, never a replacement for what this
  -- local player has actually revealed. Fill only unknown slots with the most
  -- common species learned from other Ultrons.
  for _, threat in ipairs(threats) do
    if #target>=6 then break end
    if threat.species and not seen[threat.species] then target[#target+1]={species=threat.species,rematchThreat=true}; seen[threat.species]=true end
  end
  for _, slot in ipairs(collective or {}) do
    if #target >= 6 then break end
    if slot.species and not seen[slot.species] then target[#target + 1] = slot; seen[slot.species] = true end
  end
  local postGoal=career and career.postChampion and career.postChampion.goal or nil
  if #target > 0 then
    rival.counterTarget = (known and #known > 0) and "player" or rival.counterTarget
    if rival.teamPlan then rival.teamPlan.style = (known and #known > 0) and "ANTI_PLAYER" or "COLLECTIVE_META" end
  elseif rival.teamPlan and not rival.teamPlan.style then
    rival.teamPlan.style = "BALANCED"
  end
  if rival.teamPlan then
    rival.teamPlan.ultronGoal=postGoal
    if postGoal=="DEFEAT_PLAYER" and known and #known>0 then rival.teamPlan.style="ANTI_PLAYER" end
    if postGoal=="PERFECT_TEAM" and #target==0 then rival.teamPlan.style="BALANCED" end
  end

  local changed = 0
  if rival.isAtPokemonCenter and rival:isAtPokemonCenter() then
    local ok, n = pcall(Competitive.prepare, rival)
    if ok then changed = tonumber(n) or 0 end
  end

  -- At a Center, let the existing opponent-aware team selector use Smogon
  -- usage/synergy/counter terms across active party + PC. No Pokémon are
  -- created here and no illegal move/item is granted.
  if rival.isAtPokemonCenter and rival:isAtPokemonCenter()
      and #target > 0 and rival.swapTeamForGym then
    pcall(function()
      local _, swapped = rival:swapTeamForGym(target)
      if swapped then changed = changed + 1 end
    end)
  end

  -- Lightweight doubles literacy signal for future battle-AI consumers. It
  -- records whether the currently legal set contains common tournament tools.
  local data = rival.ctx and rival.ctx.data
  local protect, speedControl, spread = 0, 0, 0
  for _, slot in ipairs(rival.party or {}) do
    if hasMove(data, slot, "PROTECT") or hasMove(data, slot, "DETECT") then protect = protect + 1 end
    if hasMove(data, slot, "THUNDERWAVE") or hasMove(data, slot, "ICYWIND")
       or hasMove(data, slot, "TAILWIND") or hasMove(data, slot, "TRICKROOM") then speedControl = speedControl + 1 end
    if hasMove(data, slot, "ROCKSLIDE") or hasMove(data, slot, "SURF")
       or hasMove(data, slot, "EARTHQUAKE") or hasMove(data, slot, "BLIZZARD") then spread = spread + 1 end
  end
  local collectiveConfidence=0
  for _,slot in ipairs(collective or {}) do collectiveConfidence=math.max(collectiveConfidence,tonumber(slot.collectiveConfidence) or 0) end
  state.scouting = {protect=protect, speedControl=speedControl, spread=spread,
    knownPlayerMons=known and #known or 0, collectiveMons=#collective, targetMons=#target,
    collectiveConfidence=collectiveConfidence,postChampionGoal=postGoal,rematchThreats=threats}
  if changed > 0 then state.rebuilds = state.rebuilds + 1 end
  state.lastReason = reason or "periodic"
  state.lastPreparedTick = tonumber(rival.ticks) or 0
  return state, changed
end

function Brain.shouldPrepare(state, rival, changes, career)
  state = Brain.new(state)
  for _, c in ipairs(changes or {}) do
    if c.kind == "badge" or c.kind == "lost_to_player" or c.kind == "catch" then return true end
  end
  if rival and rival.isAtPokemonCenter and rival:isAtPokemonCenter() then
    local interval=120
    local goal=career and career.postChampion and career.postChampion.goal or nil
    if rival.everChampion and (goal=="PERFECT_TEAM" or goal=="DEFEAT_PLAYER") then interval=60 end
    return ((tonumber(rival.ticks) or 0) - (state.lastPreparedTick or 0)) >= interval
  end
  return false
end

return Brain
