-- Sandbox-safe client file import/export helpers.
--
-- Training knowledge is absorbed into mod.save (the engine persistence area),
-- never stored inside mods/ultron. Desktop import/export uses native OS dialogs
-- through the engine-owned HostShell bridge. Android/iOS import uses the same
-- system document picker bridge as Gen1Recomp's ROM importer and consumes the
-- resulting picked_rom.gb only while Ultron owns a feature-specific marker.
local ClientFiles={}
local cachedFs
local mobileIdle=0
local MOBILE_PICKED="picked_rom.gb"
local MOBILE_PENDING="ultron_training_picker_pending.flag"
local IMPORT_STAGE="ultron_training_import_stage.txt"
local EXPORT_STAGE="ultron_training_export_stage.txt"
local OTHER_PICKER_FLAGS={
  "stadium2_battle_background_picker_pending.flag",
  "stadium2_custom_player_sprite_picker_pending.flag",
  "stadium_overworld_picker_pending.flag",
}

local function req(name)
  local ok,v=pcall(require,name)
  if ok and type(v)=="table" then return v end
end

function ClientFiles.fs()
  if cachedFs then return cachedFs end
  local SaveData=req("src.core.SaveData")
  if SaveData and type(SaveData.persistenceFs)=="function" then
    local ok,f=pcall(SaveData.persistenceFs)
    if ok and type(f)=="table" then cachedFs=f; return f end
  end
  local ok,f=pcall(function() return love and love.filesystem end)
  if ok and type(f)=="table" then cachedFs=f; return f end
end

function ClientFiles.osName()
  local Platform=req("src.core.Platform")
  if Platform and type(Platform.detect)=="function" then
    local ok,info=pcall(Platform.detect)
    if ok and type(info)=="table" and type(info.os)=="string" then return info.os end
  end
  local ok,name=pcall(function() return love and love.system and love.system.getOS and love.system.getOS() end)
  return ok and type(name)=="string" and name or "Unknown"
end

function ClientFiles.hostShell() return req("src.core.HostShell") end

local function pipeOutput(shell,cmd)
  if not(shell and type(shell.popen)=="function") then return nil end
  local ok,p=pcall(shell.popen,cmd,"r")
  if not(ok and p) then return nil end
  local okRead,out=pcall(p.read,p,"*a")
  if type(shell.pclose)=="function" then pcall(shell.pclose,p) else pcall(p.close,p) end
  if not(okRead and type(out)=="string") then return nil end
  out=out:gsub("^%s+",""):gsub("%s+$","")
  return out~="" and out or nil
end
ClientFiles.pipeOutput=pipeOutput

local function quote(shell,s)
  if shell and type(shell.quote)=="function" then return shell.quote(s) end
  return "'"..tostring(s):gsub("'","'\\''").."'"
end
local function psq(s) return "'"..tostring(s):gsub("'","''").."'" end

local function fileInfo(path)
  local f=ClientFiles.fs(); if not(f and type(f.getInfo)=="function") then return nil end
  local ok,v=pcall(f.getInfo,path,"file"); return ok and v or nil
end
local function remove(path)
  local f=ClientFiles.fs(); if f and type(f.remove)=="function" then pcall(f.remove,path) end
end
local function write(path,data)
  local f=ClientFiles.fs(); if not(f and type(f.write)=="function") then return false,"persistence filesystem unavailable" end
  local ok,res=pcall(f.write,path,data); return ok and res~=false, ok and nil or tostring(res)
end
local function read(path)
  local f=ClientFiles.fs(); if not(f and type(f.read)=="function") then return nil,"persistence filesystem unavailable" end
  local ok,data=pcall(f.read,path); if ok and type(data)=="string" then return data end
  return nil,tostring(data)
end
ClientFiles.writePersistent=write
ClientFiles.readPersistent=read
ClientFiles.removePersistent=remove

function ClientFiles.persistenceDir()
  local f=ClientFiles.fs()
  if f and type(f.getSaveDirectory)=="function" then
    local ok,p=pcall(f.getSaveDirectory); if ok and type(p)=="string" and p~="" then return p end
  end
  local SaveData=req("src.core.SaveData")
  if SaveData and type(SaveData.portableBaseDir)=="function" then
    local ok,p=pcall(SaveData.portableBaseDir); if ok and type(p)=="string" and p~="" then return p end
  end
end

function ClientFiles.canDesktopDialog()
  local shell=ClientFiles.hostShell(); if not(shell and type(shell.popen)=="function") then return false end
  local p=ClientFiles.osName(); return p=="Windows" or p=="OS X" or p=="Linux"
end

function ClientFiles.chooseOpen(title,extensions,label)
  if not ClientFiles.canDesktopDialog() then return nil end
  title=tostring(title or "Choose a file"); label=tostring(label or "Files"); extensions=extensions or {}
  local pats={}; for _,ext in ipairs(extensions) do ext=tostring(ext):gsub("^%.",""); if ext~="" then pats[#pats+1]="*."..ext end end
  if #pats==0 then pats[1]="*.*" end
  local shell=ClientFiles.hostShell(); local osName=ClientFiles.osName()
  if osName=="Windows" then
    local winPats=table.concat(pats,";")
    local script=table.concat({
      "Add-Type -AssemblyName System.Windows.Forms;",
      "$d=New-Object System.Windows.Forms.OpenFileDialog;",
      "$d.Title=",psq(title),";",
      "$d.Filter=",psq(label.." ("..winPats..")|"..winPats.."|All files (*.*)|*.*"),";",
      "if($d.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;[Console]::Write($d.FileName)}",
    })
    return pipeOutput(shell,'powershell -NoProfile -STA -Command "'..script..'"')
  elseif osName=="OS X" then
    local prompt=title:gsub("\\","\\\\"):gsub('"','\\"')
    return pipeOutput(shell,"osascript -e "..quote(shell,'POSIX path of (choose file with prompt "'..prompt..'")').." 2>/dev/null")
  elseif osName=="Linux" then
    local filter=label.." | "..table.concat(pats," ")
    local p=pipeOutput(shell,"zenity --file-selection --title="..quote(shell,title).." --file-filter="..quote(shell,filter).." 2>/dev/null")
    if p then return p end
    return pipeOutput(shell,"kdialog --getopenfilename \"$HOME\" "..quote(shell,table.concat(pats," ").."|"..label).." 2>/dev/null")
  end
end

function ClientFiles.chooseSave(title,defaultName,label)
  if not ClientFiles.canDesktopDialog() then return nil end
  title=tostring(title or "Save file"); defaultName=tostring(defaultName or "Ultron_training_data.txt"); label=tostring(label or "Ultron training data")
  local shell=ClientFiles.hostShell(); local osName=ClientFiles.osName()
  if osName=="Windows" then
    local script=table.concat({
      "Add-Type -AssemblyName System.Windows.Forms;",
      "$d=New-Object System.Windows.Forms.SaveFileDialog;",
      "$d.Title=",psq(title),";",
      "$d.FileName=",psq(defaultName),";",
      "$d.Filter=",psq(label.." (*.txt)|*.txt|All files (*.*)|*.*"),";",
      "if($d.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;[Console]::Write($d.FileName)}",
    })
    return pipeOutput(shell,'powershell -NoProfile -STA -Command "'..script..'"')
  elseif osName=="OS X" then
    local safe=defaultName:gsub("\\","\\\\"):gsub('"','\\"')
    return pipeOutput(shell,"osascript -e "..quote(shell,'POSIX path of (choose file name with default name "'..safe..'")').." 2>/dev/null")
  elseif osName=="Linux" then
    local p=pipeOutput(shell,"zenity --file-selection --save --confirm-overwrite --filename="..quote(shell,defaultName).." --file-filter="..quote(shell,label.." | *.txt").." 2>/dev/null")
    if p then return p end
    return pipeOutput(shell,"kdialog --getsavefilename \"$HOME/"..defaultName.."\" "..quote(shell,"*.txt|"..label).." 2>/dev/null")
  end
end

local function copyCommand(source,dest)
  local shell=ClientFiles.hostShell(); if not shell then return nil end
  if ClientFiles.osName()=="Windows" then
    local script=table.concat({"$src=",psq(source),";","$dst=",psq(dest),";","Copy-Item -LiteralPath $src -Destination $dst -Force;","[Console]::Write('OK')"})
    return 'powershell -NoProfile -NonInteractive -Command "'..script..'"'
  end
  return "cp -f -- "..quote(shell,source).." "..quote(shell,dest).." 2>/dev/null && printf OK"
end

function ClientFiles.stageExternal(path,relative)
  if type(path)~="string" or path=="" then return false,"no selected file" end
  relative=relative or IMPORT_STAGE
  local saveDir=ClientFiles.persistenceDir(); if not saveDir then return false,"user-data directory unavailable" end
  local shell=ClientFiles.hostShell(); if not shell then return false,"host file bridge unavailable" end
  remove(relative)
  local dest=saveDir.."/"..relative
  local cmd=copyCommand(path,dest); if not cmd then return false,"host file bridge unavailable" end
  pipeOutput(shell,cmd)
  return fileInfo(relative) and true or false, fileInfo(relative) and relative or "could not copy selected file"
end

function ClientFiles.readExternal(path)
  local ok,rel=ClientFiles.stageExternal(path,IMPORT_STAGE)
  if not ok then return nil,rel end
  local data,err=read(rel); remove(rel); return data,err
end

function ClientFiles.writeExternal(path,data)
  if type(path)~="string" or path=="" then return false,"no export destination selected" end
  local ok,err=write(EXPORT_STAGE,tostring(data or "")); if not ok then return false,err end
  local saveDir=ClientFiles.persistenceDir(); if not saveDir then remove(EXPORT_STAGE); return false,"user-data directory unavailable" end
  local cmd=copyCommand(saveDir.."/"..EXPORT_STAGE,path)
  if not cmd then remove(EXPORT_STAGE); return false,"host file bridge unavailable" end
  local out=pipeOutput(ClientFiles.hostShell(),cmd); remove(EXPORT_STAGE)
  return out~=nil, out and nil or "could not write selected destination"
end

local function otherPickerBusy()
  for _,flag in ipairs(OTHER_PICKER_FLAGS) do if fileInfo(flag) then return true,flag end end
  return false
end

function ClientFiles.openMobileFilePicker()
  local osName=ClientFiles.osName(); if osName~="Android" and osName~="iOS" then return false,"not a mobile picker platform" end
  local RomImporter=req("src.import.RomImporter")
  if not(RomImporter and type(RomImporter.choose)=="function") then return false,"engine document picker unavailable" end
  local fake={workState=nil,isNX=false,baseRomDiscovery=false,baseRoms={},nativePicker=false,android=true,ready={red=true,blue=true,yellow=true,gold=true,silver=true,crystal=true},pickSkip={},notice=nil,pickPending=nil,pickTimer=nil}
  function fake:setError(message) self._compatError=tostring(message) end
  local version="red"
  local GameVersion=req("src.core.GameVersion")
  if GameVersion and type(GameVersion.get)=="function" then local ok,v=pcall(GameVersion.get); if ok and type(v)=="string" then version=v end end
  local ok,err=pcall(RomImporter.choose,fake,version)
  if not ok then return false,tostring(err) end
  if fake.pickPending or fake.pickerPendingKind then return true end
  if fake._compatError then return false,fake._compatError end
  return false,"file picker did not open"
end

function ClientFiles.beginMobileImport()
  local busy=otherPickerBusy(); if busy then return false,"another file picker is already active" end
  remove(MOBILE_PICKED); remove(MOBILE_PENDING)
  local ok,err=write(MOBILE_PENDING,"ultron-training\n"); if not ok then return false,err end
  local launched,why=ClientFiles.openMobileFilePicker()
  if not launched then remove(MOBILE_PENDING); return false,why end
  mobileIdle=0; return true
end

-- Returns: state string ("picked"/"cancelled"/nil), bytes/reason.
function ClientFiles.pollMobileImport()
  if not fileInfo(MOBILE_PENDING) then mobileIdle=0; return nil end
  if fileInfo(MOBILE_PICKED) then
    local data,err=read(MOBILE_PICKED); remove(MOBILE_PICKED); remove(MOBILE_PENDING); mobileIdle=0
    if data then return "picked",data end
    return "cancelled",err or "could not read selected file"
  end
  mobileIdle=mobileIdle+1
  if mobileIdle>120 then remove(MOBILE_PENDING); mobileIdle=0; return "cancelled","Import cancelled." end
  return nil
end

function ClientFiles.mobileImportPending() return fileInfo(MOBILE_PENDING)~=nil end
function ClientFiles.storageDescription()
  local dir=ClientFiles.persistenceDir()
  return dir and ("Ultron knowledge is stored in the game user-data/save area: "..dir) or "Ultron knowledge is stored in the game's persistent save data, outside the mod directory."
end

ClientFiles.MOBILE_PENDING=MOBILE_PENDING
ClientFiles.MOBILE_PICKED=MOBILE_PICKED
return ClientFiles
