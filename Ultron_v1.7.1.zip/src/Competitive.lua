-- Adapted from The World v6.70.9 ai/src/Competitive.lua so Ultron can invoke
-- the same preparation logic directly from a separate mod. The statistical
-- tables remain owned by The World and are required in place.
local Util = require("mods.ultron.src.Util")
local GEN1 = require("mods.ultron.engine.data.SmogonGen1")
local GEN2 = require("mods.ultron.engine.data.SmogonGen2")

local Competitive = {}
local INDEX_KEY = "__ultron_competitive_ids"

local function canonical(id)
  return tostring(id or ""):upper():gsub("[^A-Z0-9]", "")
end

local function tableFor(data)
  return data and data.gen2Trainers and GEN2 or GEN1
end

local function liveIndex(data, field)
  if type(data) ~= "table" then return {} end
  local cache = rawget(data, INDEX_KEY)
  if not cache then cache = {}; rawset(data, INDEX_KEY, cache) end
  if cache[field] then return cache[field] end
  local out = {}
  for id in pairs(type(data[field]) == "table" and data[field] or {}) do
    out[canonical(id)] = id
  end
  cache[field] = out
  return out
end

local function liveId(data, field, wanted)
  local index = liveIndex(data, field)
  local exact = index[canonical(wanted)]
  if exact then return exact end
  if canonical(wanted):match("^HIDDENPOWER") then return index.HIDDENPOWER end
end

function Competitive.entry(data, species)
  local rows = tableFor(data)
  return rows[species] or rows[canonical(species)]
end

function Competitive.literacy(rival)
  return Util.clamp(math.floor(tonumber(rival and rival.competitiveLiteracy) or 0), 0, 100)
end

function Competitive.consults(rival)
  local literacy = Competitive.literacy(rival)
  return literacy > 0 and rival and rival.rng
    and rival.rng:chance(literacy / 100) or false
end

local function recommendations(row, rival)
  if not row then return {}, nil end
  if type(row.roles) == "table" and #row.roles > 0 then
    local role = row.roles[rival.rng:int(1, #row.roles)]
    return role.moves or {}, role
  end
  return row.moves or {}, row
end

local function levelMoveSet(rival, slot)
  local set = {}
  for _, id in ipairs(rival:movesFor(slot.species, slot.level or 5) or {}) do set[id] = true end
  return set
end

local function allowed(rival, id)
  if not id then return false end
  local exports = rival.ctx and rival.ctx.mod and rival.ctx.mod.exports
  if exports and type(exports.worldMoveAllowed) == "function" then
    local ok, yes = pcall(exports.worldMoveAllowed, id)
    if ok and yes == false then return false end
  end
  return true
end

function Competitive.prepareSlot(rival, slot)
  local data = rival.ctx and rival.ctx.data
  local row = Competitive.entry(data, slot and slot.species)
  if not row then return false end
  local wanted, role = recommendations(row, rival)
  local literacy = Competitive.literacy(rival)
  local quota = math.max(1, math.min(4, math.floor((literacy + 15) / 25)))
  local current, currentSet = {}, {}
  for _, id in ipairs(slot.moves or {}) do current[#current + 1] = id; currentSet[id] = true end
  local levelMoves = levelMoveSet(rival, slot)
  local chosen, chosenSet, trained = {}, {}, 0

  local function add(id)
    if id and not chosenSet[id] and allowed(rival, id) and #chosen < 4 then
      chosen[#chosen + 1], chosenSet[id] = id, true
      return true
    end
    return false
  end

  for _, displayId in ipairs(wanted) do
    if #chosen >= quota then break end
    local id = liveId(data, "moves", displayId)
    if id and (currentSet[id] or levelMoves[id]) then
      add(id)
    elseif id and not chosenSet[id] and rival.canTmLearn
       and rival:canTmLearn(slot.species, id)
       and (tonumber(rival.money) or 0) >= 900 then
      if rival:spend(300, "TRAINING") > 0 and add(id) then trained = trained + 1 end
    end
  end
  if not (rival.forgettableHmsEnabled and rival:forgettableHmsEnabled()) then
    for _, id in ipairs(current) do if rival.hms and rival.hms[id] then add(id) end end
  end
  for _, id in ipairs(current) do add(id) end
  local levelIds = {}
  for id in pairs(levelMoves) do levelIds[#levelIds + 1] = id end
  table.sort(levelIds)
  for _, id in ipairs(levelIds) do add(id) end
  if #chosen == 0 then return false end
  local changed = table.concat(chosen, ",") ~= table.concat(slot.moves or {}, ",")
  if changed then slot.moves = chosen end

  local itemPool = role and role.items or row.items
  if literacy >= 60 and not slot.heldItem and type(itemPool) == "table" then
    for _, itemName in ipairs(itemPool) do
      local item = liveId(data, "items", itemName)
      if item and rival.itemCount and rival:itemCount(item) > 0
         and rival:takeItem(item) then slot.heldItem = item; break end
    end
  end
  if changed or trained > 0 then
    slot.competitiveRole = role and role.name or "Smogon set"
    slot.competitivePrepared = (tonumber(slot.competitivePrepared) or 0) + 1
  end
  return changed or trained > 0
end

function Competitive.prepare(rival)
  if not rival or not Competitive.consults(rival) then return 0 end
  local changed = 0
  for _, slot in ipairs(rival.party or {}) do
    if Competitive.prepareSlot(rival, slot) then changed = changed + 1 end
  end
  rival.competitiveTeamsBuilt = (tonumber(rival.competitiveTeamsBuilt) or 0)
    + (changed > 0 and 1 or 0)
  return changed
end

function Competitive.usage(data, species)
  local row = Competitive.entry(data, species)
  return tonumber(row and row.usage) or 0
end

function Competitive.synergy(data, a, b)
  local row = Competitive.entry(data, a)
  local t = row and row.teammates
  return tonumber(t and (t[b] or t[canonical(b)])) or 0
end

return Competitive
