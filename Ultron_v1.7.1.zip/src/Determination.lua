local Util=require("mods.ultron.src.Util")
local Determination={}

function Determination.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {
    version=1,
    value=Util.clamp(tonumber(saved.value) or 0,0,100),
    losses=math.max(0,math.floor(tonumber(saved.losses) or 0)),
    revengeWins=math.max(0,math.floor(tonumber(saved.revengeWins) or 0)),
    focusUntil=tonumber(saved.focusUntil) or 0,
    lastLossTick=tonumber(saved.lastLossTick) or -1,
    lastLossMap=saved.lastLossMap,
    lastDecayTick=tonumber(saved.lastDecayTick) or 0,
    counterPreps=math.max(0,math.floor(tonumber(saved.counterPreps) or 0)),
    lastCounterPreparedTick=tonumber(saved.lastCounterPreparedTick) or -1,
  }
end

function Determination.apply(saved,rival)
  local s=Determination.new(saved)
  if rival then
    rival._ultronDetermination=s.value
    rival._ultronDeterminedUntil=s.focusUntil
  end
  return s
end

function Determination.recordPlayerBattle(saved,rival,outcome,career)
  local s=Determination.new(saved)
  local tick=tonumber(rival and rival.ticks) or 0
  if outcome and outcome.playerWon==true then
    s.losses=s.losses+1
    local stage=career and career.rivalry and career.rivalry.stage or "UNKNOWN"
    local stageBonus=(stage=="NEMESIS" or stage=="LEGENDARY_RIVAL") and 8 or 0
    local gain=24+math.min(18,(s.losses-1)*3)+stageBonus
    s.value=Util.clamp(s.value+gain,0,100)
    s.focusUntil=math.max(s.focusUntil,tick+480)
    s.lastLossTick=tick
    s.lastLossMap=rival and rival._ultronBlackoutFrom or rival and rival.map
    if rival then
      -- This uses only Rival:rememberOpponent knowledge from a battle Ultron
      -- actually fought. It grants no species, moves, items, money or levels.
      rival.counterTarget="player"
      rival._ultronCounterPrepWanted=true
    end
    return s,{kind="determination",value=s.value,reason="lost_to_player",map=s.lastLossMap}
  elseif outcome and outcome.rivalWon==true then
    if s.value>0 then s.revengeWins=s.revengeWins+1 end
    s.value=Util.clamp(s.value-18,0,100)
    s.focusUntil=math.min(s.focusUntil,tick+90)
    return s,{kind="determination",value=s.value,reason="beat_player"}
  end
  return s,nil
end

function Determination.noteCounterPrepared(saved,rival)
  local s=Determination.new(saved)
  if rival and rival._ultronCounterPrepWanted and rival.counterPreparedFor=="player" then
    local tick=tonumber(rival.ticks) or 0
    s.counterPreps=s.counterPreps+1
    s.lastCounterPreparedTick=tick
    rival._ultronCounterPrepWanted=nil
  end
  return s
end

function Determination.tick(saved,rival)
  local s=Determination.new(saved)
  local tick=tonumber(rival and rival.ticks) or 0
  if tick>s.focusUntil and s.value>0 and tick-s.lastDecayTick>=60 then
    local steps=math.max(1,math.floor((tick-s.lastDecayTick)/60))
    s.value=Util.clamp(s.value-steps*2,0,100)
    s.lastDecayTick=tick
  elseif s.lastDecayTick==0 then s.lastDecayTick=tick end
  return Determination.apply(s,rival)
end

function Determination.summary(saved)
  local s=Determination.new(saved)
  return table.concat({
    "DETERMINATION: "..tostring(math.floor(s.value)).."/100",
    "LOSSES LEARNED FROM: "..tostring(s.losses),
    "COUNTER PREPARATIONS: "..tostring(s.counterPreps),
    "REVENGE WINS: "..tostring(s.revengeWins),
    "LAST LOSS: "..tostring(s.lastLossMap or "none"):gsub("_"," "),
  },"\n")
end

return Determination
