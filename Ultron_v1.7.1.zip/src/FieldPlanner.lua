local Util=require("mods.ultron.src.Util")
local FieldPlanner={}
local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function FieldPlanner.new(saved) saved=type(saved)=="table" and saved or {}; return {version=1,lastMap=saved.lastMap,moves=copy(saved.moves),plans=math.max(0,tonumber(saved.plans) or 0),lastTick=tonumber(saved.lastTick) or 0} end
function FieldPlanner.tick(saved,rival,engine)
  local s=FieldPlanner.new(saved); if not(rival and engine and rival.destination and rival.map~=rival.destination) then return s,nil end
  if not rival.route then rival.route=rival:routeTo(rival.destination) end
  local nextMap=rival.nextHop and rival:nextHop() or nil; if not nextMap then return s,nil end
  local required=rival.requiredHMsForMap and rival:requiredHMsForMap(nextMap) or {}
  if #required==0 then return s,nil end
  local changed=false; local missing
  for _,move in ipairs(required) do
    if rival.canUseHM and not rival:canUseHM(move) then
      local taught=false
      if rival.hms and rival.hms[move] and rival.teachHM then local ok,res=pcall(function() return rival:teachHM(move) end); taught=ok and res==true end
      if taught then changed=true else missing=move; break end
    end
  end
  s.lastMap=nextMap; s.moves=copy(required); s.lastTick=engine.tick
  if changed then s.plans=s.plans+1; return s,{kind="field_plan",map=nextMap,moves=copy(required)} end
  if missing then return s,{kind="field_blocked",map=nextMap,move=missing} end
  return s,nil
end
function FieldPlanner.summary(saved)
  local s=FieldPlanner.new(saved); return "FIELD TEAM PLANS: "..tostring(s.plans).."\nNEXT FIELD MAP: "..tostring(s.lastMap or "None"):gsub("_"," ")
end
return FieldPlanner
