local Gen2Talk={handlers={},installed=false}; local SENTINEL="__ultronTalkRouterV100"
function Gen2Talk.register(id,fn,priority) if type(id)~="string" or type(fn)~="function" then return false end; Gen2Talk.handlers[id]={fn=fn,priority=tonumber(priority) or 50}; return true end
local function sorted() local a={}; for id,h in pairs(Gen2Talk.handlers) do a[#a+1]={id=id,fn=h.fn,priority=h.priority} end; table.sort(a,function(x,y) if x.priority==y.priority then return x.id<y.id end return x.priority<y.priority end); return a end
local function key(npc) return type(npc)=="table" and ((npc.def and (npc.def.name or npc.def.id)) or npc.name or npc.id) or nil end
function Gen2Talk.npcKey(npc) return key(npc) end
function Gen2Talk.install()
  local ok,OW=pcall(require,"src.world.OverworldController"); if not(ok and type(OW)=="table") then return false end
  local old=OW[SENTINEL]; if type(old)=="table" then old.state.handlers=Gen2Talk.handlers; Gen2Talk.installed=true; return true end
  local previousInteract,previousTalkTo=OW.interact,OW.talkTo; local state={handlers=Gen2Talk.handlers}
  local function dispatch(world,npc) for _,h in ipairs(sorted()) do local consumed=false; local okh=pcall(function() consumed=h.fn(world,npc) end); if okh and consumed==true then return true end end return false end
  local function facingNpc(world)
    local p=world and world.player; if not p then return nil end; local d=({up={0,-1},down={0,1},left={-1,0},right={1,0}})[p.facing]; if not d then return nil end
    local x,y=(p.cellX or 0)+d[1],(p.cellY or 0)+d[2]; if type(world.npcAt)=="function" then local okn,n=pcall(world.npcAt,world,x,y); if okn and n then return n end end
    for _,list in ipairs({world.npcs or {},world.entities or {}}) do for _,n in ipairs(list) do local nx=n.cellX or (n.def and n.def.x); local ny=n.cellY or (n.def and n.def.y); if nx==x and ny==y then return n end end end
  end
  OW.interact=function(world) local n=facingNpc(world); if n and dispatch(world,n) then return true end; return type(previousInteract)=="function" and previousInteract(world) or false end
  OW.talkTo=function(world,npc) if dispatch(world,npc) then return true end; return type(previousTalkTo)=="function" and previousTalkTo(world,npc) or false end
  OW[SENTINEL]={state=state}; Gen2Talk.installed=true; return true
end
return Gen2Talk
