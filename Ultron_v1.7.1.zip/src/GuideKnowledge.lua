local Guide={}

local GYMS={
  gen1={
    BROCK={roles={"WATER","GRASS","FIGHTING"},notes="Use special Water/Grass pressure or Fighting coverage; avoid relying on Normal damage."},
    MISTY={roles={"ELECTRIC","GRASS","STATUS"},notes="Answer Starmie's Speed with Electric/Grass damage or reliable status."},
    SURGE={roles={"GROUND","STATUS"},notes="Ground Pokemon and Ground moves deny Electric pressure."},
    ERIKA={roles={"FIRE","FLYING","PSYCHIC","ICE"},notes="Use super-effective coverage and carry status recovery."},
    KOGA={roles={"PSYCHIC","GROUND","STATUS"},notes="Prepare for poison, accuracy disruption and Selfdestruct."},
    SABRINA={roles={"PHYSICAL","BUG","GHOST","STATUS"},notes="Use strong physical pressure and sleep/paralysis rather than trading special attacks."},
    BLAINE={roles={"WATER","GROUND","ROCK"},notes="Water, Ground and Rock coverage control the Fire matchup."},
    GIOVANNI={roles={"WATER","GRASS","ICE"},notes="Water/Grass coverage and Ice for Ground teams."},
  },
  gen2={
    FALKNER={roles={"ELECTRIC","ROCK","ICE"},notes="Bring accurate anti-Flying coverage."},
    BUGSY={roles={"FIRE","FLYING","ROCK"},notes="Prepare for Scyther's speed and Fury Cutter snowball."},
    WHITNEY={roles={"FIGHTING","ROCK","GHOST","STATUS"},notes="Catch or train a Fighting answer, a Rock wall, a Ghost immunity, or reliable status before Miltank."},
    MORTY={roles={"PSYCHIC","DARK","GROUND","NORMAL"},notes="Use sleep protection and a Normal pivot against Ghost attacks."},
    CHUCK={roles={"PSYCHIC","FLYING","ELECTRIC"},notes="Pressure Fighting types and do not let Poliwrath set up."},
    JASMINE={roles={"FIRE","FIGHTING","GROUND","WATER"},notes="Carry a real Steelix answer rather than neutral chip."},
    PRYCE={roles={"FIGHTING","ROCK","ELECTRIC","FIRE"},notes="Exploit Ice weaknesses while respecting Water coverage."},
    CLAIR={roles={"ICE","DRAGON","STATUS"},notes="Ice coverage and paralysis are the practical answers to Dragonair and Kingdra."},
  }
}

local function upper(v) return tostring(v or ""):upper() end
local function types(def)
  local out={}
  for _,v in ipairs(def and (def.types or def.type) or {}) do out[upper(v)]=true end
  if def and type(def.type)=="string" then out[upper(def.type)]=true end
  if def then out[upper(def.type1)]=true; out[upper(def.type2)]=true end
  return out
end

function Guide.new(generation,data)
  local state={generation=generation==2 and 2 or 1,data=data,lastBadge=nil,lastTarget=nil,species={}}
  -- The live registries are authoritative and include species injected by
  -- other mods. Keep complete references to their stats, learnsets,
  -- evolutions, TM/HM compatibility and optional competitive annotations;
  -- never freeze the knowledge to the cartridge's original Pokédex.
  for _,registry in ipairs({data and data.pokemon,data and data.gen2Pokemon,data and data.nationalPokemon,data and data.species}) do
    for id,def in pairs(type(registry)=="table" and registry or {}) do
      if type(id)=="string" and type(def)=="table" then state.species[id]=def end
    end
  end
  return state
end

function Guide.strategy(state,rival)
  local gym,badge=rival and rival.nextGym and rival:nextGym() or nil
  if not gym then return nil end
  local hay=upper((gym.leader or "").." "..(gym.class or "").." "..(badge or ""))
  for key,row in pairs(GYMS[state.generation==2 and "gen2" or "gen1"]) do
    if hay:find(key,1,true) then return row,key,badge end
  end
end

function Guide.apply(state,rival,engine)
  local plan,key,badge=Guide.strategy(state,rival); if not plan then return state end
  rival.guidePlan={gym=key,badge=badge,roles=plan.roles,notes=plan.notes}
  rival.teamPlan=rival.teamPlan or {}; rival.teamPlan.guideRoles=plan.roles; rival.teamPlan.guideGym=key
  local owned={}
  for _,slot in ipairs(rival.party or {}) do for t in pairs(types(rival:speciesDef(slot.species))) do owned[t]=true end end
  local covered=false; for _,role in ipairs(plan.roles) do if owned[role] then covered=true break end end
  if not covered and not rival.huntTarget and engine and engine.encounterCandidatesForMap then
    local best
    for map in pairs(engine.graph and engine.graph.nodes or {}) do
      if rival.routeTo and rival:routeTo(map) then
        for _,enc in ipairs(engine:encounterCandidatesForMap(map) or {}) do
          local def=rival:speciesDef(enc.species); local ts=types(def)
          for _,role in ipairs(plan.roles) do if ts[role] then
            local score=(tonumber(enc.weight) or 1)-math.abs((tonumber(enc.level) or 5)-(rival:averageLevel() or 5))*0.05
            if not best or score>best.score then best={species=enc.species,map=map,score=score,role=role} end
          end end
        end
      end
    end
    if best then rival.huntTarget=best.species; rival.huntMap=best.map; rival.guidePlan.target=best.species; rival.guidePlan.targetRole=best.role end
  end
  state.lastBadge=badge; state.lastTarget=rival.guidePlan.target
  return state
end

return Guide
