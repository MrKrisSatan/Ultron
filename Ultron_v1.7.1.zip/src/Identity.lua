local Util = require("mods.ultron.src.Util")
local Identity = {}

local GEN1={"BULBASAUR","CHARMANDER","SQUIRTLE"}
local GEN2={"CHIKORITA","CYNDAQUIL","TOTODILE"}
local STARTER_KEYS={"world_player_starter_base_choice","world_wx_starter_post_gift_base","world_wx_starter_variant_base"}

local FAMILY_OF={
  BULBASAUR="BULBASAUR",IVYSAUR="BULBASAUR",VENUSAUR="BULBASAUR",
  CHARMANDER="CHARMANDER",CHARMELEON="CHARMANDER",CHARIZARD="CHARMANDER",
  SQUIRTLE="SQUIRTLE",WARTORTLE="SQUIRTLE",BLASTOISE="SQUIRTLE",
  CHIKORITA="CHIKORITA",BAYLEEF="CHIKORITA",MEGANIUM="CHIKORITA",
  CYNDAQUIL="CYNDAQUIL",QUILAVA="CYNDAQUIL",TYPHLOSION="CYNDAQUIL",
  TOTODILE="TOTODILE",CROCONAW="TOTODILE",FERALIGATR="TOTODILE",
  PIKACHU="PIKACHU",RAICHU="PIKACHU",CLEFAIRY="CLEFAIRY",CLEFABLE="CLEFAIRY",
}
local DEX_BASE={
  [1]="BULBASAUR",[2]="BULBASAUR",[3]="BULBASAUR",
  [4]="CHARMANDER",[5]="CHARMANDER",[6]="CHARMANDER",
  [7]="SQUIRTLE",[8]="SQUIRTLE",[9]="SQUIRTLE",
  [25]="PIKACHU",[26]="PIKACHU",[35]="CLEFAIRY",[36]="CLEFAIRY",
  [152]="CHIKORITA",[153]="CHIKORITA",[154]="CHIKORITA",
  [155]="CYNDAQUIL",[156]="CYNDAQUIL",[157]="CYNDAQUIL",
  [158]="TOTODILE",[159]="TOTODILE",[160]="TOTODILE",
}
local FAMILY_MEMBERS={
  BULBASAUR={"BULBASAUR","IVYSAUR","VENUSAUR",1,2,3},
  CHARMANDER={"CHARMANDER","CHARMELEON","CHARIZARD",4,5,6},
  SQUIRTLE={"SQUIRTLE","WARTORTLE","BLASTOISE",7,8,9},
  CHIKORITA={"CHIKORITA","BAYLEEF","MEGANIUM",152,153,154},
  CYNDAQUIL={"CYNDAQUIL","QUILAVA","TYPHLOSION",155,156,157},
  TOTODILE={"TOTODILE","CROCONAW","FERALIGATR",158,159,160},
}

local function truthy(v) return v==true or v==1 or v=="1" or v=="true" or v=="on" end
local function speciesDef(data,species)
  if not(data and species) then return nil end
  return (data.gen2Pokemon and data.gen2Pokemon[species]) or (data.pokemon and data.pokemon[species])
end
local function cleanSpecies(value)
  if type(value)=="number" then return DEX_BASE[math.floor(value)] end
  if type(value)=="table" then value=value.id or value.species or value.speciesId or value.name or value.dex end
  if type(value)=="number" then return DEX_BASE[math.floor(value)] end
  local s=tostring(value or ""):upper():gsub("[^A-Z0-9_]","_")
  if s=="" then return nil end
  return s
end
local function normaliseSpecies(data,species)
  local s=cleanSpecies(species); if not s then return nil end
  if FAMILY_OF[s] then return FAMILY_OF[s] end
  local seen={}
  for _=1,5 do
    if seen[s] then break end; seen[s]=true
    local d=speciesDef(data,s); local base=d and (d.baseSpecies or d.base_species or d.base or d.originalSpecies)
    local nextId=cleanSpecies(base)
    if not nextId then break end
    s=nextId
    if FAMILY_OF[s] then return FAMILY_OF[s] end
  end
  for base in pairs(FAMILY_MEMBERS) do if s==base or s:find(base,1,true) then return base end end
  if s=="PIKACHU" or s:find("PIKACHU",1,true) then return "PIKACHU" end
  if s=="CLEFAIRY" or s:find("CLEFAIRY",1,true) then return "CLEFAIRY" end
  return FAMILY_OF[s] or s
end
local function inList(id,list) for i,v in ipairs(list) do if id==v then return i end end end
local function trioFor(engine) return engine and engine.versionKey=="gen2" and GEN2 or GEN1 end
local function optionalWorldSave(mod,key)
  if not(mod and mod.find) then return nil end
  local ok,h=pcall(function() return mod:find("the_world") end)
  if not(ok and h and h.save and type(h.save.get)=="function") then return nil end
  local ok2,v=pcall(function() return h.save:get(key) end); return ok2 and v or nil
end
local function anyPartyMon(save)
  local party=save and (save.party or (save.player and save.player.party))
  if type(party)~="table" then return false end
  if #party>0 then return true end
  for _,mon in pairs(party) do if type(mon)=="table" then return true end end
  return false
end
local function badgeCount(save)
  if not save then return 0 end
  local n=0
  local candidates={}
  local function add(v) if type(v)=="table" then candidates[#candidates+1]=v end end
  add(save.badges); add(save.player and save.player.badges); add(save.player and save.player.kantoBadges); add(save.player and save.player.johtoBadges)
  for _,badges in ipairs(candidates) do
    if type(badges)=="table" then
      local c=0; for _,v in pairs(badges) do if truthy(v) then c=c+1 end end
      if c>n then n=c end
    end
  end
  return n
end
local function progressedPastStarter(game,engine)
  local save=game and game.save or {}
  local flags=save.flags
  if type(flags)=="table" and truthy(flags.EVENT_GOT_STARTER) then return true,"EVENT_GOT_STARTER" end
  if badgeCount(save)>0 then return true,"badges" end
  if truthy(save.pokedexReceived) or (type(flags)=="table" and truthy(flags.EVENT_GOT_POKEDEX)) then return true,"pokedex" end
  if anyPartyMon(save) then return true,"party" end
  -- A restored Ultron should never be sent back to staging merely because a
  -- total-conversion save decoder omitted EVENT_GOT_STARTER on an old slot.
  if engine and engine.rival and engine.rival._ultronDormant==false and engine.rival.map and engine.rival.map~="__ULTRON_STAGING__" then return true,"restored_ultron" end
  return false,"opening"
end

local function rootsForStorage(save)
  if type(save)~="table" then return {} end
  local out={}
  local function add(v) if type(v)=="table" then out[#out+1]=v end end
  add(save.party); add(save.player and save.player.party); add(save.boxes); add(save.pcBoxes); add(save.currentBox); add(save.box); add(save.storage); add(save.pc)
  return out
end
local function starterFamiliesFromStorage(save,data,trio)
  local found={}; local seen={}; local budget=1200
  local function walk(v,depth)
    if budget<=0 or depth>5 or type(v)~="table" or seen[v] then return end
    seen[v]=true; budget=budget-1
    local id=normaliseSpecies(data,v.species or v.speciesId or v.id)
    if inList(id,trio) then found[id]=true end
    for k,child in pairs(v) do
      if type(child)=="table" and k~="data" and k~="moves" and k~="stats" and k~="statExp" and k~="dvs" then walk(child,depth+1) end
    end
  end
  for _,root in ipairs(rootsForStorage(save)) do walk(root,0) end
  return found
end
local function starterFamiliesFromDex(save,trio)
  local found={}; if type(save)~="table" then return found end
  local dexes={}
  if type(save.pokedex)=="table" then dexes[#dexes+1]=save.pokedex end
  if type(save.dex)=="table" then dexes[#dexes+1]=save.dex end
  for _,dex in ipairs(dexes) do
    if type(dex)=="table" then
      for _,bucketName in ipairs({"owned","caught"}) do
        local bucket=dex[bucketName]
        if type(bucket)=="table" then
          for _,base in ipairs(trio) do
            for _,key in ipairs(FAMILY_MEMBERS[base] or {}) do
              if truthy(bucket[key]) then found[base]=true break end
            end
          end
        end
      end
    end
  end
  return found
end
local function onlyFamily(found,trio)
  local hit
  for _,base in ipairs(trio) do if found[base] then if hit then return nil,"ambiguous" end; hit=base end end
  return hit,hit and "single" or "none"
end
local function explicitStarter(save,data,trio)
  if type(save)~="table" then return nil end
  local player=type(save.player)=="table" and save.player or {}
  local fields={}
  local function add(v) if v~=nil then fields[#fields+1]=v end end
  add(save.playerStarter); add(save.starterSpecies); add(save.starter); add(save.chosenStarter); add(player.playerStarter); add(player.starterSpecies); add(player.starter)
  for _,v in ipairs(fields) do local id=normaliseSpecies(data,v); if inList(id,trio) then return id,"save_field" end end
  return nil
end
local function fromRivalStarter(save,data,trio)
  if type(save)~="table" then return nil end
  local player=type(save.player)=="table" and save.player or {}
  local rid=normaliseSpecies(data,save.rivalStarter or player.rivalStarter)
  local idx=inList(rid,trio)
  if not idx then return nil end
  -- Canon rival takes the next type-advantaged starter. Invert that mapping.
  return trio[((idx+1)%3)+1],"rival_starter"
end
local function stableFallback(game,engine,trio)
  local save=game and game.save or {}; local player=type(save.player)=="table" and save.player or {}
  local raw=table.concat({tostring(save.trainerId or save.trainerID or player.id or 0),tostring(save.playerName or player.name or "PLAYER"),tostring(engine and engine.versionKey or "gen1")},":")
  local h=0; for i=1,#raw do h=(h*131+raw:byte(i))%2147483647 end
  return trio[(h%3)+1],"legacy_fallback"
end

function Identity.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {starterRuleVersion=tonumber(saved.starterRuleVersion) or 0,starterSpecies=saved.starterSpecies,
    playerStarterSpecies=saved.playerStarterSpecies,playerStarterSource=saved.playerStarterSource,
    starterAssigned=saved.starterAssigned==true,firstEconomyInitialised=saved.firstEconomyInitialised==true,
    staged=saved.staged~=false,partySnapshot=type(saved.partySnapshot)=="table" and Util.copy(saved.partySnapshot) or nil,
    appearanceSprite=type(saved.appearanceSprite)=="string" and saved.appearanceSprite or nil,
    appearanceChosen=saved.appearanceChosen==true,activationReason=saved.activationReason,
    existingSaveRecovered=saved.existingSaveRecovered==true}
end

function Identity.playerStarter(game,engine,mod,state)
  local data=game and game.data or engine and engine.data; local trio=trioFor(engine); state=type(state)=="table" and state or {}
  local remembered=normaliseSpecies(data,state.playerStarterSpecies); if inList(remembered,trio) then return remembered,state.playerStarterSource or "remembered" end
  for _,key in ipairs(STARTER_KEYS) do local id=normaliseSpecies(data,optionalWorldSave(mod,key)); if inList(id,trio) then return id,"the_world" end end
  local layout=optionalWorldSave(mod,"world_alternative_starter_ball_layout")
  local chosen=normaliseSpecies(data,optionalWorldSave(mod,"world_player_starter_base_choice"))
  if chosen and type(layout)=="table" then for canonical,mapped in pairs(layout) do if normaliseSpecies(data,mapped)==chosen then local c=normaliseSpecies(data,canonical); if inList(c,trio) then return c,"the_world_layout" end end end end
  local save=game and game.save or {}
  local id,source=explicitStarter(save,data,trio); if id then return id,source end
  id,source=fromRivalStarter(save,data,trio); if id then return id,source end
  local storage=starterFamiliesFromStorage(save,data,trio); id=onlyFamily(storage,trio); if id then return id,"party_or_pc" end
  local dex=starterFamiliesFromDex(save,trio); id=onlyFamily(dex,trio); if id then return id,"pokedex" end
  local progressed,reason=progressedPastStarter(game,engine)
  if progressed then local fallback,src=stableFallback(game,engine,trio); return fallback,src..":"..tostring(reason) end
  return nil,"opening"
end

function Identity.playerHasStarter(game,engine,mod,state)
  if engine and engine.versionKey=="yellow" then
    local progressed,reason=progressedPastStarter(game,engine)
    if progressed then return true,reason end
    for _,mon in pairs(game and game.save and game.save.party or {}) do if normaliseSpecies(game and game.data,mon and (mon.species or mon.speciesId))=="PIKACHU" then return true,"pikachu" end end
    return false,"opening"
  end
  local progressed,reason=progressedPastStarter(game,engine); if progressed then return true,reason end
  local starter,source=Identity.playerStarter(game,engine,mod,state); return starter~=nil,source
end

function Identity.expectedStarter(game,engine,mod,state)
  if not engine then return nil,nil end
  if engine.versionKey=="yellow" then return "CLEFAIRY","yellow" end
  local player,source=Identity.playerStarter(game,engine,mod,state); if not player then return nil,source end
  local trio=trioFor(engine); local idx=inList(player,trio); if not idx then return nil,source end
  return trio[((idx+1)%3)+1],source
end

local function safeStartMap(engine)
  local candidates=engine and engine.versionKey=="gen2" and {"ROUTE_29","NEW_BARK_TOWN","CHERRYGROVE_CITY"} or {"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"}
  for _,id in ipairs(candidates) do if engine.graph and engine.graph.has and engine.graph:has(id) then return id end end
  return engine and engine.graph and engine.graph.nodes and next(engine.graph.nodes) or nil
end
function Identity.stage(rival)
  if not rival then return end
  rival._ultronDormant=true; rival.map="__ULTRON_STAGING__"; rival.x,rival.y=nil,nil
  rival.destination,rival.route,rival.path=nil,nil,nil; rival.routeIndex=1; rival.localWalkGoal,rival.walkTarget=nil,nil
  if rival.setState then pcall(function() rival:setState("IDLE","waiting for player starter") end) end
end
local function replaceStarter(rival,expected,modules)
  if not(rival and expected) then return false end
  local slot,index
  for i,m in ipairs(rival.party or {}) do if type(m)=="table" and m.origin=="starter" then slot,index=m,i break end end
  if not slot and #(rival.party or {})>0 then slot,index=rival.party[1],1 end
  if not slot then local ok,m=pcall(function() return rival:addPokemon(expected,5) end); if not(ok and type(m)=="table") then return false end; m.origin="starter"; if rival.markStarter then pcall(function() rival:markStarter(m) end) end; return true end
  if slot.species==expected then slot.origin="starter"; return false end
  local level=math.max(5,math.min(100,tonumber(slot.level) or 5)); slot.species=expected; slot.level=level
  slot.moves=rival:movesFor(expected,level); slot.hp=rival:maxHpOf(slot); slot.origin="starter"
  local R=modules and modules.Rival
  if R and R.expForLevel then local ok,e=pcall(R.expForLevel,rival:speciesDef(expected),level); if ok and e then slot.exp=e end end
  rival.party[index]=slot; if rival.registerDex then pcall(function() rival:registerDex(expected) end) end; if rival.refreshAce then pcall(function() rival:refreshAce() end) end
  return true
end
local function chooseAppearance(state,rival,engine)
  if state.appearanceChosen and state.appearanceSprite and state.appearanceSprite~="" then rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite; return false end
  if not(engine and engine.sprites and rival) then return false end
  local def=Util.copy(rival.def or {}); def.overworldSprite=nil; def.sprite=nil; def.spriteId=nil; def.fallbackSprite=nil
  local sprite=engine.sprites:assignWalker(def,engine.data,(engine.worldSeed and engine:worldSeed() or 1)+0x554C5452)
  if not sprite then sprite=engine.sprites:walkerFor(def,engine.data,{"SPRITE_COOLTRAINER_M","SPRITE_BLUE","SPRITE_SILVER","SPRITE_YOUNGSTER"}) end
  if not sprite then return false end
  state.appearanceSprite=tostring(sprite); state.appearanceChosen=true; rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite; return true
end
function Identity.initialiseEconomy(state,rival,restored)
  state=Identity.new(state); if not rival or restored or state.firstEconomyInitialised then return state end
  rival.money=3000; rival.inventory={}; rival.balls=0; rival.tms={}; rival.hms={}; rival.hmUses={}; rival.pcBoxes={{}}
  if rival.ensureInventory then pcall(function() rival:ensureInventory() end) end
  state.firstEconomyInitialised=true; return state
end
function Identity.ensure(state,rival,game,engine,mod)
  state=Identity.new(state); if not(rival and engine) then return state,false end
  rival.id="ultron"; rival.name="Ultron"; rival.personalityId="ULTRON"; rival.competitiveLiteracy=100
  if rival.def then rival.def.id="ultron"; rival.def.name="Ultron"; rival.def.fixedName=true end
  local ready,readyReason=Identity.playerHasStarter(game,engine,mod,state)
  if not ready then if not state.starterAssigned then Identity.stage(rival); state.staged=true end; state.activationReason=readyReason; return state,false end
  local expected,source=Identity.expectedStarter(game,engine,mod,state); if not expected then state.activationReason="starter unresolved"; return state,false end
  if engine.versionKey~="yellow" and not state.playerStarterSpecies then
    local player,playerSource=Identity.playerStarter(game,engine,mod,state); state.playerStarterSpecies=player; state.playerStarterSource=playerSource
  end
  local changed=false
  if state.starterRuleVersion<3 or not state.starterAssigned or state.starterSpecies~=expected or #(rival.party or {})==0 then
    changed=replaceStarter(rival,expected,engine.modules) or changed; state.starterRuleVersion=3; state.starterSpecies=expected; state.starterAssigned=true
  end
  if state.staged or rival.map=="__ULTRON_STAGING__" or not rival.map then
    local start=safeStartMap(engine)
    if start then
      rival.map=start; rival.x,rival.y=nil,nil; rival.destination,rival.route,rival.path=nil,nil,nil; rival.routeIndex=1
      rival._ultronDormant=false; rival._ultronNeedsInitialPlacement=true; state.staged=false; state.existingSaveRecovered=true; changed=true
      if rival.visitMap then pcall(function() rival:visitMap(start) end) end
    end
  else rival._ultronDormant=false end
  state.activationReason="active:"..tostring(source or readyReason or "starter")
  changed=chooseAppearance(state,rival,engine) or changed
  if state.appearanceSprite then rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite end
  if #(rival.party or {})>0 then state.partySnapshot=Util.copy(rival.party) end
  return state,changed
end
function Identity.snapshot(state,rival)
  state=Identity.new(state)
  if rival then if #(rival.party or {})>0 then state.partySnapshot=Util.copy(rival.party) end; if state.appearanceChosen and state.appearanceSprite then rival.appearanceSprite=state.appearanceSprite; rival.spriteOverride=state.appearanceSprite end end
  return state
end
function Identity.status(state,game,engine,mod)
  state=Identity.new(state); local ready,reason=Identity.playerHasStarter(game,engine,mod,state)
  return {starterReady=ready,starterReadyReason=reason,playerStarter=state.playerStarterSpecies,starterSource=state.playerStarterSource,
    ultronStarter=state.starterSpecies,starterAssigned=state.starterAssigned,staged=state.staged,activationReason=state.activationReason,
    existingSaveRecovered=state.existingSaveRecovered}
end
return Identity
