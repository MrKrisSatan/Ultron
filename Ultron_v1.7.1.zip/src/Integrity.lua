local Integrity={}
local function checksum(text)
  local h=2166136261
  for i=1,#tostring(text or "") do h=(h + text:byte(i)*16777619)%4294967296; h=(h*31+7)%4294967296 end
  return string.format("%08x",h)
end
function Integrity.check(mod)
  local ok,seal=pcall(require,"mods.ultron.src.IntegritySeal")
  if not(ok and type(seal)=="table" and type(seal.files)=="table") then return false,{{path="integrity seal",reason="missing"}} end
  local bad={}
  for path,row in pairs(seal.files) do
    local text; local rok,r=pcall(function() return mod:read(path) end); if rok then text=r end
    if type(text)~="string" then bad[#bad+1]={path=path,reason="missing"}
    else
      local got=checksum(text); if got~=row.sum or #text~=tonumber(row.size) then bad[#bad+1]={path=path,reason="modified"} end
    end
  end
  return #bad==0,bad
end
Integrity.checksum=checksum
return Integrity
