local Util=require("mods.ultron.src.Util")
local Research={}
local LEGENDARY={ARTICUNO=true,ZAPDOS=true,MOLTRES=true,MEWTWO=true,MEW=true,RAIKOU=true,ENTEI=true,SUICUNE=true,LUGIA=true,HO_OH=true,CELEBI=true}
local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function Research.new(saved) saved=type(saved)=="table" and saved or {}; return {version=1,ledger=copy(saved.ledger),maps=copy(saved.maps),discoveries=math.max(0,tonumber(saved.discoveries) or 0)} end
local function note(state,species,status,map,tick)
  species=tostring(species or ""):upper(); if not LEGENDARY[species] then return nil end
  local r=state.ledger[species] or {status="UNKNOWN",seen=0}
  local rank={UNKNOWN=0,RUMOURED=1,SEEN=2,CLAIMED_PLAYER=3,CLAIMED_ULTRON=3}
  if (rank[status] or 0)>=(rank[r.status] or 0) then r.status=status end
  r.map=map or r.map; r.lastTick=tonumber(tick) or r.lastTick or 0; r.seen=(tonumber(r.seen) or 0)+1; state.ledger[species]=r; return r
end
function Research.observeNews(saved,event,rival)
  local s=Research.new(saved); event=type(event)=="table" and event or {}; local sp=event.species
  if sp and LEGENDARY[tostring(sp):upper()] and (event.kind=="caught" or event.kind=="catch") then
    local before=s.ledger[tostring(sp):upper()]; note(s,sp,"CLAIMED_ULTRON",event.map or (rival and rival.map),event.tick); if not before then s.discoveries=s.discoveries+1 end
    return s,{kind="legendary_research",species=sp,status="CLAIMED_ULTRON"}
  end
  return s,nil
end
function Research.observeMap(saved,rival,engine)
  local s=Research.new(saved); if not(rival and rival.map and engine) then return s,nil end
  local map=rival.map; if s.maps[map] then return s,nil end; s.maps[map]=true
  for _,row in ipairs(engine:encounterCandidatesForMap(map) or {}) do
    local sp=tostring(row.species or ""):upper()
    if LEGENDARY[sp] then local existed=s.ledger[sp]~=nil; note(s,sp,"RUMOURED",map,engine.tick); if not existed then s.discoveries=s.discoveries+1; return s,{kind="legendary_research",species=sp,status="RUMOURED",map=map} end end
  end
  return s,nil
end
function Research.observePlayerBattle(saved,ev,observerEvent,engine)
  local s=Research.new(saved); if not observerEvent then return s,nil end
  for _,m in ipairs(engine and engine.game and engine.game.save and engine.game.save.party or {}) do
    local sp=tostring((type(m)=="table" and (m.species or m.speciesId)) or ""):upper()
    if LEGENDARY[sp] then local before=s.ledger[sp]; note(s,sp,"SEEN",engine:playerMapId(),engine.tick); if not before then s.discoveries=s.discoveries+1; return s,{kind="legendary_research",species=sp,status="SEEN"} end end
  end
  return s,nil
end
function Research.summary(saved)
  local s=Research.new(saved); local rows={}
  for sp,r in pairs(s.ledger) do rows[#rows+1]=sp..": "..tostring(r.status) end; table.sort(rows)
  if #rows==0 then return "LEGENDARY RESEARCH: No confirmed leads." end
  while #rows>8 do table.remove(rows) end
  return "LEGENDARY RESEARCH\n"..table.concat(rows,"\n")
end
Research.LEGENDARY=LEGENDARY
return Research
