local Util = require("mods.ultron.src.Util")
local Micro = {}

local INTENTS = {
  greeting = {"hello", "hi", "hey", "morning", "evening"},
  badges = {"badge", "badges", "gym", "gyms", "leader", "league", "champion"},
  team = {"team", "pokemon", "party", "moves", "smogon", "vgc", "strategy", "build"},
  battle = {"battle", "fight", "challenge", "rematch", "win", "loss", "beat"},
  catch = {"catch", "caught", "hunt", "wild", "dex", "pokedex"},
  location = {"where", "map", "route", "location", "go", "going", "stuck"},
  memory = {"remember", "said", "last time", "history", "before"},
  feeling = {"happy", "happiness", "feel", "mood", "want", "goal"},
  compliment = {"good", "great", "clever", "smart", "impressive", "well done", "nice"},
  taunt = {"bad", "weak", "stupid", "terrible", "trash", "useless", "loser"},
  rivalry = {"rival", "rivalry", "nemesis", "respect", "relationship"},
  partner = {"partner", "signature", "ace", "favourite", "favorite", "nickname", "nicknamed", "name"},
  legacy = {"legacy", "hall of fame", "champion team", "notebook", "record book"},
  collective = {"collective", "training data", "other ultrons", "sources", "shared knowledge"},
  journey = {"routine", "schedule", "route", "dungeon", "hm", "surf", "cut", "strength", "flash"},
  legendary = {"legendary", "articuno", "zapdos", "moltres", "mewtwo", "lugia", "ho-oh", "suicune", "raikou", "entei"},
}

local CORPUS = {
  "Every battle is evidence and every route is a problem with a solution.",
  "I prefer a team with answers, not merely six strong names.",
  "A loss is expensive information. I intend to spend it well.",
  "Badges prove progress. Training makes the proof repeatable.",
  "Catching widens the search space; team building turns options into pressure.",
  "I can be cautious without becoming passive, and aggressive without becoming careless.",
  "The map is a graph, but the journey is still made one legal tile at a time.",
  "I remember patterns. Repeating one against me is an invitation.",
}

local INTENT_ORDER = {
  "legendary", "journey", "legacy", "collective", "partner", "rivalry", "memory", "badges", "team", "battle", "catch", "location", "feeling",
  "greeting", "compliment", "taunt",
}

local function classify(text)
  local lower = tostring(text or ""):lower()
  local tokenSet = {}
  for _, w in ipairs(Util.words(lower)) do tokenSet[w] = true end
  local best, bestScore = "default", 0
  for _, intent in ipairs(INTENT_ORDER) do
    local score = 0
    for _, key in ipairs(INTENTS[intent] or {}) do
      if key:find(" ", 1, true) then
        if lower:find(key, 1, true) then score = score + 1 end
      elseif tokenSet[key] then
        score = score + 1
      end
    end
    if score > bestScore then best, bestScore = intent, score end
  end
  return best
end

local function buildModel(extra)
  local nexts = {}
  local function ingest(line)
    local words = Util.words(line)
    local prev = "<s>"
    for _, w in ipairs(words) do
      nexts[prev] = nexts[prev] or {}
      nexts[prev][#nexts[prev] + 1] = w
      prev = w
    end
    nexts[prev] = nexts[prev] or {}
    nexts[prev][#nexts[prev] + 1] = "</s>"
  end
  for _, line in ipairs(CORPUS) do ingest(line) end
  for _, line in ipairs(extra or {}) do ingest(line) end
  return nexts
end

-- Tiny bigram language model. It is intentionally local and bounded: no web,
-- no external inference service, no arbitrary code execution, no giant model.
local function generateTail(rival, model, maxWords)
  local out, prev = {}, "<s>"
  for _ = 1, (maxWords or 7) do
    local choices = model[prev]
    if not choices or #choices == 0 then break end
    local w = Util.choose(rival, choices)
    if not w or w == "</s>" then break end
    out[#out + 1] = w
    prev = w
  end
  if #out < 3 then return nil end
  local s = table.concat(out, " ")
  return s:sub(1,1):upper() .. s:sub(2) .. "."
end

function Micro.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    history = type(saved.history) == "table" and saved.history or {},
    trust = Util.clamp(saved.trust or 0, -100, 100),
    rivalry = Util.clamp(saved.rivalry or 25, 0, 100),
    topics = type(saved.topics) == "table" and saved.topics or {},
  }
end

local function remember(state, row)
  state.history[#state.history + 1] = row
  while #state.history > 40 do table.remove(state.history, 1) end
end

local function previousUser(state)
  for i = #state.history, 1, -1 do
    local u = state.history[i] and state.history[i].user
    if u and u ~= "" then return u end
  end
end

local function mood(rival, drive)
  if rival and rival.moodLabel then
    local ok, label = pcall(function() return rival:moodLabel() end)
    if ok and label then return tostring(label) end
  end
  if (drive or 0) >= 75 then return "driven" end
  if (drive or 0) < 35 then return "restless" end
  return "focused"
end

function Micro.respond(state, text, rival, manager, motivation, brain, atlas, career, training, partnerLegacy)
  state = Micro.new(state)
  text = Util.cleanText(text, 72)
  if text == "" then return state, "Say something I can work with." end
  local intent = classify(text)
  state.topics[intent] = (tonumber(state.topics[intent]) or 0) + 1
  if intent == "compliment" then state.trust = Util.clamp(state.trust + 3, -100, 100) end
  if intent == "taunt" then
    state.trust = Util.clamp(state.trust - 2, -100, 100)
    state.rivalry = Util.clamp(state.rivalry + 4, 0, 100)
  end
  if intent == "battle" then state.rivalry = Util.clamp(state.rivalry + 2, 0, 100) end

  local badges = Util.badgeCount(rival)
  local dex = Util.dexCount(rival)
  local drive = motivation and motivation.drive or 0
  local wins = tonumber(rival and rival.playerWins) or 0
  local losses = tonumber(rival and rival.playerLosses) or 0
  local map = rival and rival.map or "somewhere"
  local known = rival and rival.knownOpponentParty and rival:knownOpponentParty("player") or nil
  local response

  if intent == "greeting" then
    response = Util.choose(rival, {
      "Hello. I was reviewing my next route.",
      "Hello. Good timing. I have work to do.",
      "Hi. If you came to compare progress, I accept the premise.",
    })
  elseif intent == "badges" then
    response = ("I have %d badge%s. The next one is not a trophy; it is a constraint to solve.")
      :format(badges, badges == 1 and "" or "s")
  elseif intent == "team" then
    local knownCount = known and #known or 0
    response = ("My competitive model is fully engaged. I know %d of your revealed team slots and rebuild around legal matchups, coverage and synergy.")
      :format(knownCount)
  elseif intent == "battle" then
    response = ("Our record is %d-%d from my side. %s")
      :format(wins, losses, losses > wins and "That gap is a training target." or "I intend to keep the pressure on.")
  elseif intent == "catch" then
    response = ("My Pokédex memory covers %d species. A catch is useful when it creates a new role, matchup or route option."):format(dex)
  elseif intent == "location" then
    response = ("I am on %s. My atlas currently indexes %d reachable map records, while live collision decides every physical step.")
      :format(tostring(map):gsub("_", " "), tonumber(atlas and atlas.graphCount) or 0)
  elseif intent == "memory" then
    local prev = previousUser(state)
    response = prev and ("I remember you saying: '" .. Util.cleanText(prev, 42) .. "'. I also retain our battle record.")
      or "This is our first stored conversation, but battle memory is already part of my model."
  elseif intent == "feeling" then
    response = ("I feel %s. My drive is %d/100; badges, training, catches and hard battles all feed it.")
      :format(mood(rival, drive), math.floor(drive))
  elseif intent == "rivalry" then
    local rr=career and career.rivalry or {}
    local stage=tostring(rr.stage or "UNKNOWN"):gsub("_"," ")
    response = ("I classify our rivalry as %s. My recorded score against you is %d-%d, and I am still updating the model.")
      :format(stage, tonumber(rr.ultronWins) or wins, tonumber(rr.playerWins) or losses)
  elseif intent == "partner" then
    local species=career and career.signatureSpecies
    local nickname
    if species and rival then
      local function inspect(slot)
        if type(slot)~="table" then return end
        local matches=(career and career.signatureBondId and slot.ultronBondId==career.signatureBondId)
          or (not(career and career.signatureBondId) and slot.species==species)
        if not nickname and matches and type(slot.nickname)=="string" and slot.nickname~="" then nickname=slot.nickname end
      end
      for _,slot in ipairs(rival.party or {}) do inspect(slot) end
      for _,box in ipairs(rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do inspect(slot) end end
    end
    if species then
      local partner=nickname and (nickname.." the "..tostring(species):gsub("_"," ")) or tostring(species):gsub("_"," ")
      local profile
      if rival and partnerLegacy and type(partnerLegacy.profiles)=="table" then
        local function inspectProfile(slot)
          local id=slot and slot.ultronBondId
          local matches=(career and career.signatureBondId and id==career.signatureBondId)
            or (not(career and career.signatureBondId) and slot and slot.species==species)
          if not profile and matches and id then profile=partnerLegacy.profiles[id] end
        end
        for _,slot in ipairs(rival.party or {}) do inspectProfile(slot) end
        for _,box in ipairs(rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do inspectProfile(slot) end end
      end
      if profile then
        response=("My signature partner is %s. We have logged %d battles together, %d wins over you and %d Hall of Fame appearance%s. That history is why I keep bringing this partner back.")
          :format(partner,tonumber(profile.battles) or 0,tonumber(profile.playerWins) or 0,tonumber(profile.hallOfFame) or 0,(tonumber(profile.hallOfFame) or 0)==1 and "" or "s")
      else
        response="My signature partner is "..partner..". That choice came from our shared battle history, not a preset roster."
      end
    else
      response="I have not chosen a permanent signature partner yet. Service in real battles decides it."
    end
  elseif intent == "legacy" then
    local hall=career and career.hallOfFame or {}
    local book=career and career.battles or {}
    local veterans=0; local legends=0
    for _,p in pairs(partnerLegacy and partnerLegacy.profiles or {}) do
      local status=tostring(p.status or "")
      if status=="VETERAN" or status=="HALL_OF_FAMER" or status=="LEGEND" then veterans=veterans+1 end
      if status=="LEGEND" then legends=legends+1 end
    end
    response = ("My battle notebook contains %d player battles, my Hall of Fame preserves %d League-winning team%s, and %d long-term partner%s now count as veterans%s.")
      :format(#book,#hall,#hall==1 and "" or "s",veterans,veterans==1 and "" or "s",legends>0 and (", including "..tostring(legends).." legend"..(legends==1 and "" or "s")) or "")
  elseif intent == "collective" then
    local imports=tonumber(training and training.imports) or 0
    local sources=0; for _ in pairs(training and training.sources or {}) do sources=sources+1 end
    response = ("I have imported knowledge from %d other Ultron source%s. Shared evidence informs confidence; it does not transfer Pokemon, badges or progress.")
      :format(sources,sources==1 and "" or "s")
  elseif intent == "journey" then
    response = "I learn physical routes I have actually travelled. Field moves remain real constraints; I will reorganise my active team for an owned HM rather than bypass the obstacle."
  elseif intent == "legendary" then
    response = "I do not begin with a perfect legendary map. My research ledger advances from places I explore, Pokemon I encounter, and major battles I physically witness."
  elseif intent == "compliment" then
    response = "Praise noted. I prefer evidence, but I am not immune to useful morale."
  elseif intent == "taunt" then
    response = "Good. Keep that confidence. It gives me a cleaner benchmark to dismantle."
  else
    response = "I heard you. I will remember the subject and compare it with what happens next."
  end

  local personaBlurbs = {}
  local p = rival and rival.personality
  if p and p.blurb then personaBlurbs[#personaBlurbs + 1] = p.blurb end
  local tail = generateTail(rival, buildModel(personaBlurbs), 6)
  if tail and #response + #tail < 150 and intent == "default" then response = response .. " " .. tail end

  remember(state, {
    user = text,
    ultron = response,
    intent = intent,
    tick = rival and rival.ticks or 0,
    badges = badges,
    wins = wins,
    losses = losses,
  })
  return state, response
end

return Micro
