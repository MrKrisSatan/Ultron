local Util = require("mods.ultron.src.Util")
local Motivation = {}

function Motivation.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    drive = Util.clamp(saved.drive or 58, 0, 100),
    lifetimeReward = math.max(0, tonumber(saved.lifetimeReward) or 0),
    badges = math.max(0, tonumber(saved.badges) or 0),
    dex = math.max(0, tonumber(saved.dex) or 0),
    levels = math.max(0, tonumber(saved.levels) or 0),
    playerWins = math.max(0, tonumber(saved.playerWins) or 0),
    playerLosses = math.max(0, tonumber(saved.playerLosses) or 0),
    lastReason = saved.lastReason,
    lastHungerTick = tonumber(saved.lastHungerTick) or -1,
  }
end

local function reward(state, amount, reason)
  state.drive = Util.clamp((state.drive or 0) + amount, 0, 100)
  state.lifetimeReward = (state.lifetimeReward or 0) + math.max(0, amount)
  state.lastReason = reason
end

function Motivation.observe(state, rival)
  state = Motivation.new(state)
  if not rival then return state, {} end
  local changes = {}
  local badges = Util.badgeCount(rival)
  local dex = Util.dexCount(rival)
  local levels = Util.partyLevelSum(rival)
  local wins = tonumber(rival.playerWins) or 0
  local losses = tonumber(rival.playerLosses) or 0

  if badges > state.badges then
    local d = badges - state.badges
    reward(state, 14 * d, "badge")
    changes[#changes + 1] = {kind="badge", amount=d}
  end
  if dex > state.dex then
    local d = dex - state.dex
    reward(state, math.min(12, d * 3), "catch")
    changes[#changes + 1] = {kind="catch", amount=d}
  end
  if levels > state.levels then
    local d = levels - state.levels
    reward(state, math.min(8, d), "training")
    changes[#changes + 1] = {kind="training", amount=d}
  end
  if wins > state.playerWins then
    local d = wins - state.playerWins
    reward(state, 7 * d, "beat_player")
    changes[#changes + 1] = {kind="beat_player", amount=d}
  end
  if losses > state.playerLosses then
    local d = losses - state.playerLosses
    -- A loss is information, not pure punishment. Competitive Ultron gets a
    -- smaller rebound incentive to train and counter-build.
    reward(state, 2 * d, "learned_from_loss")
    changes[#changes + 1] = {kind="lost_to_player", amount=d}
  end

  state.badges, state.dex, state.levels = badges, dex, levels
  state.playerWins, state.playerLosses = wins, losses
  return state, changes
end

function Motivation.tick(state, rival)
  state = Motivation.new(state)
  -- Gentle goal hunger. It cannot open gates or grant progress, only make
  -- successful progress more emotionally valuable than inactivity.
  local tick = rival and math.floor(tonumber(rival.ticks) or 0) or 0
  if tick > 0 and Util.badgeCount(rival) < 8 and tick % 240 == 0
      and tick ~= state.lastHungerTick then
    state.drive = Util.clamp(state.drive - 1, 20, 100)
    state.lastReason = "badge_hunger"
    state.lastHungerTick = tick
  end
  return state
end

return Motivation
