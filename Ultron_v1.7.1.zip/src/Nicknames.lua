local Util=require("mods.ultron.src.Util")
local Nicknames={}

local POOLS={
  NORMAL={"Echo","Scout","Lucky","Tempo","Moxie","Orbit","Pixel","Comet"},
  FIRE={"Cinder","Ember","Pyre","Flare","Scorch","Sol","Blaze","Kindle"},
  WATER={"Tide","Ripple","Marina","Current","Delta","Riptide","Brine","Wake"},
  GRASS={"Briar","Fern","Moss","Clover","Thorn","Verdant","Sage","Ivy"},
  ELECTRIC={"Volt","Spark","Amp","Static","Surge","Tesla","Pulse","Arc"},
  ICE={"Frost","Rime","Glacier","Sleet","Boreal","Chill","Flurry","Tundra"},
  FIGHTING={"Valor","Rush","Striker","Kinetic","Knuckle","Rook","Grit","Vigor"},
  POISON={"Venom","Toxin","Miasma","Viper","Nox","Fume","Ichor","Spore"},
  GROUND={"Terra","Dust","Quake","Flint","Dune","Loam","Mesa","Rumble"},
  FLYING={"Gale","Aero","Zephyr","Cirrus","Soar","Wing","Draft","Kite"},
  PSYCHIC={"Oracle","Psi","Muse","Nova","Vision","Synapse","Dream","Halo"},
  BUG={"Chitin","Weaver","Mantis","Silk","Skitter","Cicada","Needle","Web"},
  ROCK={"Onyx","Crag","Quartz","Slate","Flint","Shard","Granite","Cairn"},
  GHOST={"Shade","Wisp","Hex","Specter","Phantom","Haunt","Eidolon","Veil"},
  DRAGON={"Drake","Wyrm","Apex","Mythic","Scale","Talon","Riven","Draco"},
  DARK={"Umbra","Shade","Rogue","Noir","Eclipse","Vanta","Dusk","Sable"},
  STEEL={"Alloy","Chrome","Rivet","Aegis","Titan","Forge","Cog","Vector"},
  FAIRY={"Glimmer","Fable","Pixie","Lumen","Charm","Gleam","Wish","Mirth"},
}
local GENERAL={"Echo","Nova","Scout","Orbit","Moxie","Rook","Tempo","Pixel","Comet","Vector","Lumen","Apex"}

local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function Nicknames.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=1,total=math.max(0,tonumber(saved.total) or 0),history=copy(saved.history)}
end

local function speciesOf(slot) return type(slot)=="table" and (slot.species or slot.speciesId or slot.id) or nil end
local function normType(v)
  v=tostring(v or ""):upper():gsub("_TYPE$",""):gsub("TYPE_","")
  return POOLS[v] and v or nil
end
local function speciesType(rival,species)
  local def
  if rival and type(rival.speciesDef)=="function" then pcall(function() def=rival:speciesDef(species) end) end
  local types=def and (def.types or def.type)
  if type(types)=="table" then
    return normType(types[1] or types.primary or types.type1) or normType(types[2] or types.secondary or types.type2)
  end
  return normType(types)
end
local function hash(text)
  local h=5381
  text=tostring(text or "")
  for i=1,#text do h=(h*33+text:byte(i))%2147483647 end
  return h
end
local function usedNames(rival)
  local out={}
  local function visit(slot)
    local n=type(slot)=="table" and tostring(slot.nickname or "") or ""
    if n~="" then out[n:upper()]=true end
  end
  for _,slot in ipairs(rival and rival.party or {}) do visit(slot) end
  for _,box in ipairs(rival and rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do visit(slot) end end
  return out
end
local function cleanName(v)
  v=tostring(v or ""):gsub("[^A-Za-z0-9]","")
  if #v>10 then v=v:sub(1,10) end
  return v
end
local function chooseName(rival,slot,state,used)
  local species=speciesOf(slot) or "POKEMON"
  local pool=POOLS[speciesType(rival,species)] or GENERAL
  local seed=table.concat({species,tostring(slot.since or 0),tostring(rival and rival.def and rival.def.seed or 0),tostring(state.total or 0)},":")
  local start=(hash(seed)%#pool)+1
  for offset=0,#pool-1 do
    local base=cleanName(pool[((start+offset-1)%#pool)+1])
    if base~="" and not used[base:upper()] then return base end
  end
  local base=cleanName(pool[start])
  for n=2,99 do
    local suffix=tostring(n); local candidate=base:sub(1,math.max(1,10-#suffix))..suffix
    if not used[candidate:upper()] then return candidate end
  end
  return cleanName(species):sub(1,10)
end

local function affinity(career,species)
  local a=career and career.affinity and career.affinity[species]
  return type(a)=="table" and a or {}
end
local function eligibility(slot,career,where)
  local species=speciesOf(slot); if not species then return -1 end
  if type(slot.nickname)=="string" and slot.nickname:gsub("%s+","")~="" then return -1 end
  local a=affinity(career,species)
  local score=tonumber(slot.attachment) or 0
  if slot.ace then score=score+35 end
  local signature = career and ((career.signatureBondId and slot.ultronBondId==career.signatureBondId)
    or (not career.signatureBondId and career.signatureSpecies==species))
  if signature then score=score+120 end
  score=score+math.min(60,(tonumber(a.score) or 0)*2)
  score=score+math.min(35,(tonumber(a.teamBattles) or 0)*3)
  if slot.origin=="starter" then score=score+10 end
  local eligible=(slot.attached==true and (tonumber(slot.attachment) or 0)>=45)
    or signature
    or (where=="party" and (tonumber(a.teamBattles) or 0)>=8)
  return eligible and score or -1
end

function Nicknames.tick(saved,rival,career)
  local state=Nicknames.new(saved)
  if not rival then return state,nil end
  local best,bestScore
  local function visit(slot,where)
    local score=eligibility(slot,career,where)
    if score>=0 and (not bestScore or score>bestScore) then best,bestScore={slot=slot,where=where},score end
  end
  for _,slot in ipairs(rival.party or {}) do visit(slot,"party") end
  for _,box in ipairs(rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do visit(slot,"pc") end end
  if not best then return state,nil end
  local used=usedNames(rival); local species=speciesOf(best.slot); local name=chooseName(rival,best.slot,state,used)
  if not name or name=="" then return state,nil end
  best.slot.nickname=name
  best.slot.ultronNicknamed=true
  best.slot.attached=true
  best.slot.attachment=math.max(tonumber(best.slot.attachment) or 0,65)
  best.slot.nicknameTick=tonumber(rival.ticks) or 0
  state.total=state.total+1
  state.history[#state.history+1]={species=species,nickname=name,tick=best.slot.nicknameTick,attachment=tonumber(best.slot.attachment) or 0}
  while #state.history>48 do table.remove(state.history,1) end
  return state,{kind="nickname",species=species,nickname=name,where=best.where}
end

function Nicknames.summary(saved,rival,career)
  local state=Nicknames.new(saved)
  local rows={"PARTNER BONDS","NICKNAMES GIVEN: "..tostring(state.total)}
  local list={}
  local function visit(slot)
    local species=speciesOf(slot)
    if species then
      local a=affinity(career,species)
      local score=(tonumber(slot.attachment) or 0)+math.min(100,tonumber(a.score) or 0)
      list[#list+1]={slot=slot,species=species,score=score,battles=tonumber(a.teamBattles) or 0}
    end
  end
  for _,slot in ipairs(rival and rival.party or {}) do visit(slot) end
  for _,box in ipairs(rival and rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do visit(slot) end end
  table.sort(list,function(a,b) if a.score~=b.score then return a.score>b.score end return tostring(a.species)<tostring(b.species) end)
  for i=1,math.min(6,#list) do
    local r=list[i]; local nick=tostring(r.slot.nickname or ""):gsub("^%s+",""):gsub("%s+$","")
    local label=nick~="" and (nick.." / "..tostring(r.species):gsub("_"," ")) or tostring(r.species):gsub("_"," ")
    local signature=career and ((career.signatureBondId and r.slot.ultronBondId==career.signatureBondId) or (not career.signatureBondId and career.signatureSpecies==r.species))
    if signature then label=label.." [SIGNATURE]" end
    rows[#rows+1]=label.." - bond "..tostring(math.floor(r.score))..", battles "..tostring(math.floor(r.battles))
  end
  if #list==0 then rows[#rows+1]="No partner history yet." end
  return table.concat(rows,"\n")
end

return Nicknames
