local Util=require("mods.ultron.src.Util")
local Observer={}
local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function Observer.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=1,majorBattles=copy(saved.majorBattles),species=copy(saved.species),observed=math.max(0,tonumber(saved.observed) or 0),lastTick=tonumber(saved.lastTick) or 0}
end
local function species(slot) return type(slot)=="table" and (slot.species or slot.speciesId or slot.id) or nil end
local function opponentText(ev)
  if type(ev)~="table" then return "" end
  local o=ev.opponent or ev.trainer or ev.trainerClass or ev.class or ev.enemy or ev.leader or ev.gym
  if type(o)=="table" then o=o.name or o.id or o.class end
  return tostring(o or "")
end
local function major(ev,engine,map)
  if type(ev)=="table" and (ev.gym or ev.league or ev.champion or ev.eliteFour or ev.major) then return true end
  local t=opponentText(ev):upper()
  if t:find("LEADER",1,true) or t:find("ELITE",1,true) or t:find("CHAMPION",1,true) or t:find("GYM",1,true) then return true end
  for _,badge in ipairs(engine and engine.gyms and engine.gyms.order or {}) do local g=engine.gyms.byBadge and engine.gyms.byBadge[badge]; if g and (g.map==map or g.city==map) then return true end end
  local league=engine and engine.gyms and engine.gyms.league; if league and (league.map==map or league.city==map) then return true end
  return false
end
function Observer.observePlayerBattle(saved,ev,engine)
  local state=Observer.new(saved); if not(engine and engine.rival) then return state,nil end
  local map=engine:playerMapId(); if not map or engine.rival.map~=map then return state,nil end
  if not major(ev,engine,map) then return state,nil end
  local team={}
  for _,m in ipairs(engine.game and engine.game.save and engine.game.save.party or {}) do local sp=species(m); if sp then team[#team+1]={species=sp,level=tonumber(m.level) or 1}; state.species[sp]=(tonumber(state.species[sp]) or 0)+1 end end
  local row={tick=engine.tick,map=map,result=type(ev)=="table" and ev.result or nil,opponent=opponentText(ev),team=team}
  state.majorBattles[#state.majorBattles+1]=row; while #state.majorBattles>32 do table.remove(state.majorBattles,1) end
  state.observed=state.observed+1; state.lastTick=engine.tick
  if engine.rival.rememberOpponent and #team>0 then pcall(function() engine.rival:rememberOpponent("player",team,(type(ev)=="table" and ev.result=="win") or false,engine.tick,false) end) end
  return state,{kind="observed_player_battle",map=map,opponent=row.opponent,count=#team}
end
function Observer.summary(saved)
  local s=Observer.new(saved); local last=s.majorBattles[#s.majorBattles]
  local text="MAJOR PLAYER BATTLES OBSERVED: "..tostring(s.observed)
  if last then text=text.."\nLAST OBSERVED: "..tostring(last.opponent~="" and last.opponent or last.map):gsub("_"," ") end
  return text
end
return Observer
