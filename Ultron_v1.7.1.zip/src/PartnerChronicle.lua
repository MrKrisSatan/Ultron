local Util=require("mods.ultron.src.Util")
local Chronicle={}

local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
local function num(v) return math.max(0,math.floor(tonumber(v) or 0)) end
local function speciesOf(slot) return type(slot)=="table" and (slot.species or slot.speciesId or slot.id) or nil end
local function labelSpecies(s) return tostring(s or "Pokemon"):gsub("_"," ") end
local function normaliseKey(v)
  return tostring(v or "UNKNOWN"):upper():gsub("[^A-Z0-9]+","_"):gsub("^_+",""):gsub("_+$","")
end
local function trim(t,n) while #t>n do table.remove(t,1) end end

function Chronicle.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {
    version=1,
    partners=copy(saved.partners),
    history=copy(saved.history),
    totalMajorWins=num(saved.totalMajorWins),
    totalTitleWins=num(saved.totalTitleWins),
    lastContext=saved.lastContext,
  }
end

local function partner(state,id)
  if type(id)~="string" or id=="" then return nil end
  local p=state.partners[id]
  if type(p)~="table" then
    p={trust={},famousWins={},majorWins=0,titleWins=0,playerWins=0,gymWins=0,leagueWins=0,rematchWins=0}
    state.partners[id]=p
  end
  p.trust=type(p.trust)=="table" and p.trust or {}
  p.famousWins=type(p.famousWins)=="table" and p.famousWins or {}
  return p
end

local function currentRows(rival)
  local out={}
  for _,slot in ipairs(rival and rival.party or {}) do
    if type(slot)=="table" and type(slot.ultronBondId)=="string" then out[#out+1]={slot=slot,id=slot.ultronBondId} end
  end
  return out
end

local function addTrust(p,key,amount)
  key=tostring(key or "UNKNOWN")
  p.trust[key]=math.min(99,num(p.trust[key])+math.max(1,num(amount)))
end

local function famous(state,rows,kind,key,label,map,tick)
  local ids={}
  for _,row in ipairs(rows) do
    local p=partner(state,row.id)
    if p then
      p.majorWins=num(p.majorWins)+1
      if kind=="PLAYER" then p.playerWins=num(p.playerWins)+1 end
      if kind=="GYM" then p.gymWins=num(p.gymWins)+1 end
      if kind=="LEAGUE" then p.leagueWins=num(p.leagueWins)+1 end
      if kind=="TITLE" then p.titleWins=num(p.titleWins)+1 end
      if kind=="REMATCH" then p.rematchWins=num(p.rematchWins)+1 end
      addTrust(p,key,kind=="TITLE" and 5 or kind=="LEAGUE" and 4 or kind=="PLAYER" and 4 or 3)
      p.famousWins[#p.famousWins+1]={kind=kind,key=key,label=label,map=map,tick=tonumber(tick) or 0,species=speciesOf(row.slot),nickname=row.slot.nickname}
      trim(p.famousWins,10)
      ids[#ids+1]=row.id
    end
  end
  state.history[#state.history+1]={kind=kind,key=key,label=label,map=map,tick=tonumber(tick) or 0,bonds=ids}
  trim(state.history,64)
  state.totalMajorWins=state.totalMajorWins+1
  if kind=="TITLE" then state.totalTitleWins=state.totalTitleWins+1 end
  return {kind="famous_victory",victoryKind=kind,label=label,key=key,bonds=ids}
end

local function gymKey(event)
  local gym=event and event.gym or nil
  local who=type(gym)=="table" and (gym.leader or gym.badge or gym.class) or nil
  who=who or (event and event.badge)
  return "GYM:"..normaliseKey(who)
end

function Chronicle.observeNews(saved,rival,event)
  local state=Chronicle.new(saved); event=type(event)=="table" and event or {}
  local rows=currentRows(rival); if #rows==0 then return state,nil end
  local kind=tostring(event.kind or "")
  local map=event.map or event.from or (rival and rival.map)
  local tick=rival and rival.ticks or 0
  if event.gym and event.won==true then
    local leader=event.gym.leader or event.badge or event.gym.class or "Gym Leader"
    local key=gymKey(event)
    return state,famous(state,rows,"GYM",key,"Defeated "..labelSpecies(leader),map,tick)
  elseif kind=="league" and event.won==true then
    return state,famous(state,rows,"LEAGUE","LEAGUE","Won the Pokemon League",map,tick)
  elseif kind=="title_match" then
    local won
    if tostring(event.holder or "")==tostring(rival and rival.id or "") then won=event.won==false else won=event.won==true end
    if won then
      local opponent=(tostring(event.holder or "")==tostring(rival and rival.id or "")) and (event.challengerName or event.challenger) or (event.holderName or event.holder)
      return state,famous(state,rows,"TITLE","TITLE","Defended the Championship against "..labelSpecies(opponent),map,tick)
    end
  elseif kind=="rematch" and event.won==true then
    local trainer=event.trainer or "trainer"
    local key="TRAINER:"..normaliseKey(trainer)
    return state,famous(state,rows,"REMATCH",key,"Won a rematch against "..labelSpecies(trainer),map,tick)
  end
  return state,nil
end

function Chronicle.recordPlayerBattle(saved,rival,outcome,ctx)
  local state=Chronicle.new(saved)
  if not(outcome and outcome.rivalWon==true) then return state,nil end
  local rows=currentRows(rival); if #rows==0 then return state,nil end
  return state,famous(state,rows,"PLAYER","PLAYER","Defeated the player",ctx and ctx.map or (rival and rival.map),ctx and ctx.tick or (rival and rival.ticks))
end

local function allSlots(rival)
  local out={}
  for _,slot in ipairs(rival and rival.party or {}) do out[#out+1]=slot end
  for _,box in ipairs(rival and rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do out[#out+1]=slot end end
  return out
end

function Chronicle.apply(saved,rival)
  local state=Chronicle.new(saved)
  for _,slot in ipairs(allSlots(rival)) do
    local p=partner(state,slot and slot.ultronBondId)
    if p then
      slot.ultronOpponentTrust=copy(p.trust)
      slot.ultronFamousWins=#p.famousWins
      slot.ultronMajorWins=num(p.majorWins)
      slot.ultronTitleWins=num(p.titleWins)
    end
  end
  return state
end

local function nameForProfile(legacy,id,fallback)
  local p=legacy and legacy.profiles and legacy.profiles[id]
  if p then return (p.nickname and p.nickname~="" and p.nickname) or labelSpecies(p.species) end
  return fallback or "Pokemon"
end

function Chronicle.summary(saved,rival,legacy)
  local state=Chronicle.new(saved); local rows={}
  local active={}; for _,slot in ipairs(rival and rival.party or {}) do if slot.ultronBondId then active[slot.ultronBondId]=true end end
  for id,p in pairs(state.partners) do rows[#rows+1]={id=id,p=p} end
  table.sort(rows,function(a,b)
    if num(a.p.majorWins)~=num(b.p.majorWins) then return num(a.p.majorWins)>num(b.p.majorWins) end
    return tostring(a.id)<tostring(b.id)
  end)
  local out={"PARTNER CHRONICLE","MAJOR TEAM WINS: "..state.totalMajorWins,"TITLE DEFENCES: "..state.totalTitleWins}
  for i=1,math.min(8,#rows) do
    local row=rows[i]; local p=row.p; local name=nameForProfile(legacy,row.id)
    out[#out+1]=name..(active[row.id] and " [PARTY]" or " [PC]").." - famous wins "..num(p.majorWins)
    local trusts={}; for key,value in pairs(p.trust or {}) do trusts[#trusts+1]={key=key,value=num(value)} end
    table.sort(trusts,function(a,b) return a.value>b.value end)
    if trusts[1] then out[#out+1]="  trusted vs "..trusts[1].key:gsub("_"," ").." ("..trusts[1].value..")" end
    local last=p.famousWins and p.famousWins[#p.famousWins]
    if last then out[#out+1]="  remembered: "..tostring(last.label) end
  end
  if #rows==0 then out[#out+1]="No famous victories recorded yet." end
  return table.concat(out,"\n")
end

function Chronicle.hallOfFameSummary(saved,career,legacy)
  local state=Chronicle.new(saved); local hall=career and career.hallOfFame or {}
  local out={"ULTRON HALL OF FAME","CHAMPIONSHIP TEAMS: "..tostring(#hall)}
  if #hall==0 then out[#out+1]="Ultron has not entered the Hall of Fame yet."; return table.concat(out,"\n") end
  for i,entry in ipairs(hall) do
    out[#out+1]="TEAM #"..tostring(i).." - badges "..tostring(entry.badges or "?")..", rivalry "..tostring(entry.ultronWins or 0).."-"..tostring(entry.playerWins or 0)
    for _,slot in ipairs(entry.team or {}) do
      local name=(slot.nickname and slot.nickname~="" and slot.nickname) or nameForProfile(legacy,slot.bondId,labelSpecies(slot.species))
      local suffix=slot.bondId and (" ["..slot.bondId.."]") or ""
      out[#out+1]="  "..name.." ("..labelSpecies(slot.species)..") Lv"..tostring(slot.level or "?")..suffix
    end
  end
  return table.concat(out,"\n")
end

function Chronicle.bestTrust(saved,bondId,key)
  local state=Chronicle.new(saved); local p=state.partners[bondId]
  return num(p and p.trust and p.trust[key])
end

return Chronicle
