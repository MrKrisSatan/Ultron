local Util=require("mods.ultron.src.Util")
local Legacy={}

local STATUS_ORDER={ROOKIE=1,TRUSTED=2,VETERAN=3,HALL_OF_FAMER=4,LEGEND=5}
local STATUS_LABELS={ROOKIE="Rookie",TRUSTED="Trusted Partner",VETERAN="Veteran",HALL_OF_FAMER="Hall of Famer",LEGEND="Ultron Legend"}

local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
local function speciesOf(slot) return type(slot)=="table" and (slot.species or slot.speciesId or slot.id) or nil end
local function number(v) return math.max(0,math.floor(tonumber(v) or 0)) end
local function nameOf(slot)
  local nick=type(slot)=="table" and tostring(slot.nickname or "") or ""
  if nick~="" then return nick end
  return tostring(speciesOf(slot) or "Pokemon"):gsub("_"," ")
end
local function clampHistory(t,max)
  while #t>max do table.remove(t,1) end
end

function Legacy.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {
    version=1,
    nextId=math.max(1,number(saved.nextId)>0 and number(saved.nextId) or 1),
    profiles=copy(saved.profiles),
    lastPlayerOutcome=saved.lastPlayerOutcome,
    lastHallCount=number(saved.lastHallCount),
    totalComebacks=number(saved.totalComebacks),
    totalMajorWins=number(saved.totalMajorWins),
  }
end

local function newProfile(id,slot,tick)
  local species=speciesOf(slot)
  return {
    id=id,species=species,speciesHistory=species and {species} or {},nickname=slot and slot.nickname or nil,
    firstSeenTick=tonumber(tick) or 0,lastSeenTick=tonumber(tick) or 0,lastMap=nil,
    battles=0,wins=0,losses=0,trainerWins=0,gymWins=0,leagueWins=0,
    playerBattles=0,playerWins=0,playerLosses=0,comebacks=0,hallOfFame=0,blackouts=0,
    notable={},status="ROOKIE",score=0,
  }
end

local function profileFor(state,slot,tick)
  if type(slot)~="table" then return nil end
  local id=slot.ultronBondId
  if type(id)~="string" or id=="" then
    id=string.format("U%05d",state.nextId)
    state.nextId=state.nextId+1
    slot.ultronBondId=id
  end
  local p=state.profiles[id]
  if type(p)~="table" then p=newProfile(id,slot,tick); state.profiles[id]=p end
  p.id=id
  p.species=p.species or speciesOf(slot)
  p.speciesHistory=type(p.speciesHistory)=="table" and p.speciesHistory or {}
  p.notable=type(p.notable)=="table" and p.notable or {}
  local species=speciesOf(slot)
  if species and species~=p.species then
    local seen=false
    for _,s in ipairs(p.speciesHistory) do if s==species then seen=true break end end
    if not seen then p.speciesHistory[#p.speciesHistory+1]=species end
    p.species=species
  elseif species and #p.speciesHistory==0 then p.speciesHistory[1]=species end
  if type(slot.nickname)=="string" and slot.nickname~="" then p.nickname=slot.nickname end
  p.lastSeenTick=tonumber(tick) or p.lastSeenTick or 0
  return p
end

local function statusFor(p)
  if number(p.hallOfFame)>=2 and (number(p.playerWins)>=2 or number(p.leagueWins)>=2) then return "LEGEND" end
  if number(p.hallOfFame)>=1 then return "HALL_OF_FAMER" end
  if number(p.battles)>=12 or number(p.gymWins)>=2 or number(p.playerWins)>=2 then return "VETERAN" end
  if number(p.battles)>=5 or number(p.wins)>=4 then return "TRUSTED" end
  return "ROOKIE"
end

local function scoreFor(p)
  return math.min(9999,
    number(p.battles)*2+number(p.wins)*3+number(p.trainerWins)*2+number(p.gymWins)*10+
    number(p.leagueWins)*25+number(p.playerWins)*14+number(p.comebacks)*12+number(p.hallOfFame)*22)
end

local function syncSlot(p,slot)
  p.score=scoreFor(p)
  p.status=statusFor(p)
  slot.ultronLegacyScore=p.score
  slot.ultronPlayerWins=number(p.playerWins)
  slot.ultronComebacks=number(p.comebacks)
  slot.ultronHallOfFame=number(p.hallOfFame)
  slot.ultronVeteran=(STATUS_ORDER[p.status] or 0)>=STATUS_ORDER.VETERAN
  if slot.ultronVeteran then
    slot.attached=true
    slot.attachment=math.max(tonumber(slot.attachment) or 0,math.min(105,65+math.floor(p.score/8)))
  end
end

local function allSlots(rival)
  local rows={}
  for _,slot in ipairs(rival and rival.party or {}) do rows[#rows+1]={slot=slot,where="party"} end
  for _,box in ipairs(rival and rival.pcBoxes or {}) do for _,slot in ipairs(box or {}) do rows[#rows+1]={slot=slot,where="pc"} end end
  return rows
end

function Legacy.ensure(saved,rival)
  local state=Legacy.new(saved)
  local tick=tonumber(rival and rival.ticks) or 0
  local events={}
  for _,row in ipairs(allSlots(rival)) do
    local p=profileFor(state,row.slot,tick)
    if p then
      p.lastMap=rival and rival.map or p.lastMap
      local old=p.status or "ROOKIE"
      syncSlot(p,row.slot)
      if old~=p.status then events[#events+1]={kind="partner_status",id=p.id,species=p.species,nickname=p.nickname,status=p.status,label=STATUS_LABELS[p.status]} end
    end
  end
  return state,events
end

local function activeProfiles(state,rival)
  local rows={}
  for _,slot in ipairs(rival and rival.party or {}) do
    local p=profileFor(state,slot,rival and rival.ticks)
    if p then rows[#rows+1]={p=p,slot=slot} end
  end
  return rows
end

local function notable(p,kind,label,map,tick)
  p.notable=type(p.notable)=="table" and p.notable or {}
  p.notable[#p.notable+1]={kind=kind,label=label,map=map,tick=tonumber(tick) or 0}
  clampHistory(p.notable,16)
end

local function recordBattle(rows,won,kind,event,rival)
  local map=event and (event.map or event.from) or (rival and rival.map)
  for _,row in ipairs(rows) do
    local p=row.p
    p.battles=number(p.battles)+1
    if won then p.wins=number(p.wins)+1 else p.losses=number(p.losses)+1 end
    if kind=="trainer" and won then p.trainerWins=number(p.trainerWins)+1 end
    if kind=="gym" and won then p.gymWins=number(p.gymWins)+1; notable(p,"GYM_WIN",event and event.gym and (event.gym.leader or event.badge) or "Gym victory",map,rival and rival.ticks) end
    if kind=="league" and won then p.leagueWins=number(p.leagueWins)+1; notable(p,"LEAGUE_WIN","Pokemon League",map,rival and rival.ticks) end
  end
end

function Legacy.observeNews(saved,rival,event)
  local state=Legacy.new(saved); event=type(event)=="table" and event or {}; local events={}
  state,events=Legacy.ensure(state,rival)
  local kind=tostring(event.kind or "")
  local isGym=event.gym~=nil
  local won=event.won==true
  local rows=activeProfiles(state,rival)
  if isGym then
    recordBattle(rows,won,"gym",event,rival)
    if won then state.totalMajorWins=state.totalMajorWins+1 end
  elseif kind=="trainer" or kind=="rematch" or kind=="duel" then
    recordBattle(rows,won,"trainer",event,rival)
  elseif kind=="league" then
    recordBattle(rows,won,"league",event,rival)
    if won then state.totalMajorWins=state.totalMajorWins+1 end
  elseif kind=="blackout" then
    for _,row in ipairs(rows) do row.p.blackouts=number(row.p.blackouts)+1 end
  end
  local refreshed,more=Legacy.ensure(state,rival); state=refreshed
  for _,e in ipairs(more or {}) do events[#events+1]=e end
  return state,events
end

function Legacy.recordPlayerBattle(saved,rival,outcome,ctx)
  local state=Legacy.new(saved); local events={}; state=select(1,Legacy.ensure(state,rival))
  local won=outcome and outcome.rivalWon==true
  local rows=activeProfiles(state,rival)
  local wasLoss=state.lastPlayerOutcome=="LOSS"
  for _,row in ipairs(rows) do
    local p=row.p
    p.battles=number(p.battles)+1; p.playerBattles=number(p.playerBattles)+1
    if won then
      p.wins=number(p.wins)+1; p.playerWins=number(p.playerWins)+1
      notable(p,"PLAYER_WIN","Defeated the player",ctx and ctx.map or (rival and rival.map),ctx and ctx.tick)
      if wasLoss then
        p.comebacks=number(p.comebacks)+1; state.totalComebacks=state.totalComebacks+1
        notable(p,"COMEBACK","Won a rematch after a loss",ctx and ctx.map or (rival and rival.map),ctx and ctx.tick)
        events[#events+1]={kind="partner_comeback",id=p.id,species=p.species,nickname=p.nickname}
      end
    else
      p.losses=number(p.losses)+1; p.playerLosses=number(p.playerLosses)+1
    end
  end
  if won then state.totalMajorWins=state.totalMajorWins+1 end
  state.lastPlayerOutcome=won and "WIN" or "LOSS"
  local refreshed,more=Legacy.ensure(state,rival); state=refreshed
  for _,e in ipairs(more or {}) do events[#events+1]=e end
  return state,events
end

function Legacy.syncHallOfFame(saved,rival,career)
  local state=Legacy.new(saved); local events={}; state=select(1,Legacy.ensure(state,rival))
  local hall=career and career.hallOfFame or {}
  if state.lastHallCount>#hall then state.lastHallCount=#hall end
  for i=state.lastHallCount+1,#hall do
    local entry=hall[i]
    for _,slot in ipairs(entry and entry.team or {}) do
      local id=slot.bondId
      local p=id and state.profiles[id]
      if p then
        p.hallOfFame=number(p.hallOfFame)+1
        notable(p,"HALL_OF_FAME","League-winning team #"..tostring(i),nil,entry.tick)
      end
    end
  end
  state.lastHallCount=#hall
  local refreshed,more=Legacy.ensure(state,rival); state=refreshed
  for _,e in ipairs(more or {}) do events[#events+1]=e end
  return state,events
end

function Legacy.profileForSlot(saved,slot)
  local state=Legacy.new(saved); local id=slot and slot.ultronBondId
  return id and state.profiles[id] or nil
end

function Legacy.summary(saved,rival)
  local state=Legacy.new(saved); state=select(1,Legacy.ensure(state,rival))
  local rows={}
  local inParty={}
  for _,slot in ipairs(rival and rival.party or {}) do if slot.ultronBondId then inParty[slot.ultronBondId]=true end end
  for id,p in pairs(state.profiles) do
    p.score=scoreFor(p); p.status=statusFor(p)
    rows[#rows+1]={id=id,p=p,active=inParty[id]==true}
  end
  table.sort(rows,function(a,b) if a.p.score~=b.p.score then return a.p.score>b.p.score end return tostring(a.id)<tostring(b.id) end)
  local out={"PARTNER LEGACY","KNOWN PARTNERS: "..tostring(#rows),"COMEBACKS: "..tostring(state.totalComebacks)}
  for i=1,math.min(8,#rows) do
    local r=rows[i]; local p=r.p
    local label=(p.nickname and p.nickname~="" and p.nickname or tostring(p.species or "Pokemon"):gsub("_"," "))
    local location=r.active and " [PARTY]" or ((number(p.hallOfFame)>0) and " [RESTING VETERAN]" or " [PC]")
    out[#out+1]=label.." - "..tostring(STATUS_LABELS[p.status] or p.status)..location
    out[#out+1]="  battles "..number(p.battles)..", wins "..number(p.wins)..", gyms "..number(p.gymWins)..", player wins "..number(p.playerWins)..", HOF "..number(p.hallOfFame)
    if number(p.comebacks)>0 then out[#out+1]="  comeback wins "..number(p.comebacks) end
  end
  if #rows==0 then out[#out+1]="No individual partner history yet." end
  return table.concat(out,"\n")
end

function Legacy.countStatus(saved,wanted)
  local state=Legacy.new(saved); local n=0
  local threshold=STATUS_ORDER[wanted] or 999
  for _,p in pairs(state.profiles) do if (STATUS_ORDER[statusFor(p)] or 0)>=threshold then n=n+1 end end
  return n
end

Legacy.STATUS_LABELS=STATUS_LABELS
return Legacy
