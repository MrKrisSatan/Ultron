local Util = require("mods.ultron.src.Util")
local Fusion = {}

local NUMERIC = {
  "levelMargin", "gymConfidence", "retryPatience", "challengeChance",
  "playerConfidence", "trainRate", "wanderChance", "catchChance",
  "partyTarget", "healAt", "ghostChance", "rivalFightChance",
  "duelChance", "trainerBattleChance",
}

-- Borda-style merge of every personality inherited from the AI Rivals corpus. Ultron does not randomly pick
-- one mask: the full catalogue becomes one trait vector and one ranked set of
-- impulses, then the competitive drive below sharpens the result.
function Fusion.build(personalities)
  local out = {
    label = "ULTRON",
    blurb = "A synthesis of every AI Rival personality: curious, competitive, theatrical, cautious, loyal, analytical and relentlessly adaptive.",
    sourcePersonalities = {},
    teamPlan = "balanced",
  }
  local sums, counts, ranks = {}, {}, {}
  local personalityCount = 0
  for id, p in pairs(type(personalities) == "table" and personalities or {}) do
    if type(p) == "table" then
      personalityCount = personalityCount + 1
      out.sourcePersonalities[#out.sourcePersonalities + 1] = id
      for _, key in ipairs(NUMERIC) do
        if type(p[key]) == "number" then
          sums[key] = (sums[key] or 0) + p[key]
          counts[key] = (counts[key] or 0) + 1
        end
      end
      for rank, objective in ipairs(p.priorities or {}) do
        local r = ranks[objective] or {score = 0, n = 0}
        r.score, r.n = r.score + rank, r.n + 1
        ranks[objective] = r
      end
    end
  end
  table.sort(out.sourcePersonalities)
  for _, key in ipairs(NUMERIC) do
    if counts[key] and counts[key] > 0 then out[key] = sums[key] / counts[key] end
  end

  local priorities = {}
  for objective, row in pairs(ranks) do
    local avg = row.score / math.max(1, row.n)
    -- Competitive goal biases without erasing the source personalities.
    if objective == "GYM" then avg = avg - 1.35 end
    if objective == "TRAIN" then avg = avg - 1.10 end
    if objective == "CHALLENGE_PLAYER" then avg = avg - 0.75 end
    priorities[#priorities + 1] = {id = objective, score = avg}
  end
  table.sort(priorities, function(a, b)
    if a.id == "HEAL" then return true end
    if b.id == "HEAL" then return false end
    if a.score ~= b.score then return a.score < b.score end
    return a.id < b.id
  end)
  out.priorities = {}
  for _, row in ipairs(priorities) do out.priorities[#out.priorities + 1] = row.id end

  -- Championship temperament. These are deliberately still within the ranges
  -- used by The World rather than inventing an unrelated AI ruleset.
  out.gymConfidence = math.max(1.02, tonumber(out.gymConfidence) or 1.02)
  out.retryPatience = math.min(5, math.max(2, math.floor(tonumber(out.retryPatience) or 5)))
  out.challengeChance = math.max(0.74, tonumber(out.challengeChance) or 0.74)
  out.playerConfidence = 0.90
  out.trainRate = math.max(1.22, tonumber(out.trainRate) or 1.22)
  out.wanderChance = math.max(0.24, tonumber(out.wanderChance) or 0.24)
  out.catchChance = math.max(0.26, tonumber(out.catchChance) or 0.26)
  out.partyTarget = 6
  out.healAt = math.max(0.45, tonumber(out.healAt) or 0.45)
  out.rivalFightChance = 0
  out.duelChance = 0
  out.trainerBattleChance = math.max(0.14, tonumber(out.trainerBattleChance) or 0.14)
  out.levelMargin = math.max(2, math.floor(tonumber(out.levelMargin) or 2))
  out.personalityCount = personalityCount
  return out
end

-- Happiness/drive changes the order of legal goals, not the legality of maps.
-- This keeps all badge, HM and story gates in Ultron's vendored Rival core authoritative.
function Fusion.motivate(personality, drive, badgeCount, partySize)
  if type(personality) ~= "table" then return end
  local base = personality._ultronBasePriorities or Util.copy(personality.priorities or {})
  personality._ultronBasePriorities = base
  local wanted = {}
  local function add(id)
    for _, x in ipairs(wanted) do if x == id then return end end
    wanted[#wanted + 1] = id
  end
  add("HEAL")
  if (partySize or 0) < 6 then add("TRAIN") end
  if (badgeCount or 0) < 8 and (drive or 0) >= 35 then add("GYM") end
  if (drive or 0) >= 55 then add("CHALLENGE_PLAYER") end
  local legal={HEAL=true,GYM=true,TRAIN=true,CHALLENGE_PLAYER=true,EXPLORE=true,CATCH=true,WANDER=true}
  for _, id in ipairs(base) do if legal[id] then add(id) end end
  personality.priorities = wanted
end

return Fusion
