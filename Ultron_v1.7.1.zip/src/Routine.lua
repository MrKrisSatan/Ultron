local Util=require("mods.ultron.src.Util")
local Routine={}

local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
function Routine.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=1,current=saved.current or "JOURNEY",since=tonumber(saved.since) or 0,lastChoice=tonumber(saved.lastChoice) or -9999,history=copy(saved.history),cycles=math.max(0,tonumber(saved.cycles) or 0)}
end
local function healthyRatio(rival)
  local hp,max=0,0
  for _,m in ipairs(rival and rival.party or {}) do
    local mh=(rival.maxHpOf and rival:maxHpOf(m)) or tonumber(m.maxHp) or tonumber(m.hp) or 1
    hp=hp+math.max(0,tonumber(m.hp) or mh); max=max+math.max(1,mh)
  end
  return max>0 and hp/max or 1
end
local function balls(r)
  if r and r.itemCount then return (r:itemCount("POKE_BALL") or 0)+(r:itemCount("GREAT_BALL") or 0)+(r:itemCount("ULTRA_BALL") or 0) end
  return tonumber(r and r.balls) or 0
end
local function idle(r)
  local s=tostring(r and r.state or "IDLE"); local o=tostring(r and r.objective or "IDLE")
  return (s=="IDLE" or s=="EXPLORING" or s=="TRAINING") and (o=="IDLE" or o=="EXPLORE" or o=="TRAIN") and not r._ultronPursuit and not r._ultronBlackout
end
local function remember(state,kind,tick,map)
  state.current=kind; state.since=tick; state.lastChoice=tick; state.cycles=state.cycles+1
  state.history[#state.history+1]={kind=kind,tick=tick,map=map}; while #state.history>24 do table.remove(state.history,1) end
end
local function nearestTraining(engine,from)
  local list=engine and engine.gyms and engine.gyms.training or {}
  if engine and engine.graph and engine.graph.nearest then return engine.graph:nearest(from,list) end
end
local function exploreTarget(engine,rival)
  local best
  for id in pairs(engine and engine.graph and engine.graph.nodes or {}) do
    local name=tostring(id)
    if (name:find("ROUTE",1,true) or name:find("CAVE",1,true) or name:find("FOREST",1,true) or name:find("TUNNEL",1,true)) and not (rival.visitedMaps and rival.visitedMaps[id]) then
      local route=rival.routeTo and rival:routeTo(id)
      if type(route)=="table" and #route>0 then best=id; break end
    end
  end
  return best
end
function Routine.tick(saved,rival,engine,career,determination)
  local state=Routine.new(saved); if not(rival and engine) then return state,nil end
  local tick=tonumber(engine.tick) or tonumber(rival.ticks) or 0
  if not idle(rival) or tick-state.lastChoice<120 then return state,nil end
  local kind,target
  local resolve=tonumber(determination and determination.value) or tonumber(rival._ultronDetermination) or 0
  if healthyRatio(rival)<0.62 and rival.lastPokemonCenter then kind="RECOVER"; target=rival.lastPokemonCenter
  elseif rival.counterTarget=="player" and resolve>=25 and engine.nearestCenter then kind="PREPARE"; target=engine:nearestCenter(rival.map)
  elseif balls(rival)<=3 and engine.nearestMart then kind="RESTOCK"; target=engine:nearestMart(rival.map)
  else
    local stage=career and career.rivalry and career.rivalry.stage
    local slot=(math.floor(tick/120)+(tonumber(rival.def and rival.def.seed) or 0))%4
    if stage=="NEMESIS" or stage=="LEGENDARY_RIVAL" then slot=(slot+1)%4 end
    if resolve>=60 and slot==1 then slot=0 end -- train/prep instead of wandering after a painful loss
    if slot==0 then kind="TRAIN"; target=nearestTraining(engine,rival.map)
    elseif slot==1 then kind="EXPLORE"; target=exploreTarget(engine,rival)
    elseif slot==2 then kind="PREPARE"; target=rival.lastPokemonCenter
    else kind="JOURNEY" end
  end
  if kind=="RECOVER" and target and target~=rival.map then rival.objective="HEAL"; rival.destination=target; rival.route=nil; rival:setState("TRAVELLING","routine recovery")
  elseif kind=="RESTOCK" and target and target~=rival.map then rival.objective="SHOP"; rival.destination=target; rival.route=nil; rival:setState("TRAVELLING","routine supply run")
  elseif kind=="TRAIN" and target and target~=rival.map then rival.objective="TRAIN"; rival.destination=target; rival.route=nil; rival:setState("TRAVELLING","scheduled training")
  elseif kind=="EXPLORE" and target and target~=rival.map then rival.objective="EXPLORE"; rival.destination=target; rival.route=nil; rival:setState("TRAVELLING","scheduled exploration")
  elseif kind=="PREPARE" and target and target~=rival.map then rival.objective="HEAL"; rival.destination=target; rival.route=nil; rival:setState("TRAVELLING","team preparation stop")
  end
  remember(state,kind,tick,rival.map)
  return state,{kind="routine",routine=kind,target=target}
end
function Routine.summary(saved)
  local s=Routine.new(saved); return "CURRENT ROUTINE: "..tostring(s.current):gsub("_"," ").."\nROUTINE CYCLES: "..tostring(s.cycles)
end
return Routine
