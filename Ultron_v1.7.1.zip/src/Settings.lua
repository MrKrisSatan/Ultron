local Settings={}

local DEFS={
  catchLegendaries={label="CATCH LEGENDARIES",default=true,desc="Allow Ultron to pursue and catch legendary Pokemon."},
  forgettableHms={label="FORGETTABLE HMs",default=true,desc="Allow owned HMs to be forgotten and retaught for field travel."},
  reusableTms={label="REUSABLE TMs",default=true,desc="Owned TMs remain available after Ultron teaches them."},
  periodicChallenges={label="PERIODIC CHALLENGES",default=true,desc="Allow Ultron to periodically challenge the player on the same map."},
  newsTicker={label="NEWS TICKER",default=true,desc="Show or merge Ultron's live news ticker updates."},
  nameTag={label="NAME TAG",default=true,desc="Show Ultron's name above his visible overworld sprite."},
  observePlayerBattles={label="WATCH MAJOR BATTLES",default=true,desc="Allow physically present Ultron to learn from major player battles."},
  routines={label="DAILY ROUTINES",default=true,desc="Allow recovery, restocking, training, exploration and preparation routines."},
  nicknamePokemon={label="NICKNAME PARTNERS",default=true,desc="Allow Ultron to nickname Pokemon after a strong personal bond develops."},
}
local ORDER={"catchLegendaries","forgettableHms","reusableTms","periodicChallenges","newsTicker","nameTag","observePlayerBattles","routines","nicknamePokemon"}

local function bool(v,default)
  if v==nil then return default==true end
  if type(v)=="string" then local s=v:lower(); return not(s=="false" or s=="off" or s=="0" or s=="no") end
  return v==true or v==1
end

function Settings.new(saved)
  saved=type(saved)=="table" and saved or {}
  local out={version=1}
  for key,def in pairs(DEFS) do out[key]=bool(saved[key],def.default) end
  return out
end
function Settings.get(saved,key)
  local s=Settings.new(saved); local def=DEFS[key]; if not def then return nil end; return s[key]
end
function Settings.set(saved,key,value)
  local s=Settings.new(saved); if not DEFS[key] then return s,false end; s[key]=bool(value,DEFS[key].default); return s,true
end
function Settings.toggle(saved,key)
  local s=Settings.new(saved); if not DEFS[key] then return s,nil end; s[key]=not s[key]; return s,s[key]
end
function Settings.rows(saved)
  local s=Settings.new(saved); local out={}
  for _,key in ipairs(ORDER) do local def=DEFS[key]; out[#out+1]={key=key,label=def.label,value=s[key],desc=def.desc} end
  return out
end
function Settings.summary(saved)
  local s=Settings.new(saved); local out={"ULTRON SETTINGS"}
  for _,key in ipairs(ORDER) do local def=DEFS[key]; out[#out+1]=def.label..": "..(s[key] and "ON" or "OFF") end
  return table.concat(out,"\n")
end
Settings.DEFS=DEFS
Settings.ORDER=ORDER
return Settings
