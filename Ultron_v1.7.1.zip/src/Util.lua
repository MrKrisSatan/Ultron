local Util = {}

function Util.copy(value, seen)
  if type(value) ~= "table" then return value end
  seen = seen or {}
  if seen[value] then return seen[value] end
  local out = {}
  seen[value] = out
  for k, v in pairs(value) do out[Util.copy(k, seen)] = Util.copy(v, seen) end
  return out
end

function Util.clamp(v, lo, hi)
  v = tonumber(v) or 0
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

function Util.count(t)
  local n = 0
  for _ in pairs(type(t) == "table" and t or {}) do n = n + 1 end
  return n
end

function Util.badgeCount(rival)
  local n = 0
  for _, yes in pairs((rival and rival.badges) or {}) do if yes then n = n + 1 end end
  return n
end

function Util.partyLevelSum(rival)
  local n = 0
  for _, mon in ipairs((rival and rival.party) or {}) do n = n + (tonumber(mon.level) or 0) end
  return n
end

function Util.dexCount(rival)
  local n = 0
  for _, yes in pairs((rival and rival.dex) or {}) do if yes then n = n + 1 end end
  return n
end

function Util.cleanText(s, maxLen)
  s = tostring(s or ""):gsub("[%c]", " "):gsub("%s+", " ")
  s = s:gsub("^%s+", ""):gsub("%s+$", "")
  if maxLen and #s > maxLen then s = s:sub(1, maxLen) end
  return s
end

function Util.words(s)
  local out = {}
  s = tostring(s or ""):lower()
  for w in s:gmatch("[%a%d']+") do out[#out + 1] = w end
  return out
end

function Util.hasAny(text, words)
  text = " " .. tostring(text or ""):lower() .. " "
  for _, w in ipairs(words or {}) do
    local needle = tostring(w):lower()
    if text:find(needle, 1, true) then return true end
  end
  return false
end

function Util.resolveGame(candidate, current, modGame)
  -- Gen 1 usually exposes stack/overworld; Gen 2 and some host revisions can
  -- expose game.world directly. Requiring stack made valid existing saves
  -- permanently fail bootstrap in those builds.
  local function valid(g)
    return type(g)=="table" and type(g.data)=="table"
      and (type(g.save)=="table" or g.stack~=nil or g.overworld~=nil or g.world~=nil)
  end
  local seen={}
  local function probe(v,depth)
    if depth>3 or type(v)~="table" or seen[v] then return nil end
    seen[v]=true
    if valid(v) then return v end
    for _,k in ipairs({"game","source","owner","state","payload"}) do
      local hit=probe(v[k],depth+1); if hit then return hit end
    end
    return nil
  end
  return probe(candidate,0) or probe(current,0) or probe(modGame,0)
end

function Util.choose(rival, list)
  if type(list) ~= "table" or #list == 0 then return nil end
  local i = 1
  if rival and rival.rng and type(rival.rng.int) == "function" then
    i = rival.rng:int(1, #list)
  else
    i = math.random(1, #list)
  end
  return list[i]
end

return Util
