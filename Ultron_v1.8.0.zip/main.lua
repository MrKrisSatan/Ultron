return function(mod)
  local Util=require("mods.ultron.src.Util")
  local Engine=require("mods.ultron.src.Engine")
  local Fusion=require("mods.ultron.src.PersonalityFusion")
  local Motivation=require("mods.ultron.src.Motivation")
  local Atlas=require("mods.ultron.src.Atlas")
  local Brain=require("mods.ultron.src.ChampionshipBrain")
  local Micro=require("mods.ultron.src.MicroLLM")
  local Identity=require("mods.ultron.src.Identity")
  local Challenge=require("mods.ultron.src.Challenge")
  local Exchange=require("mods.ultron.src.TrainingExchange")
  local News=require("mods.ultron.src.News")
  local Tamper=require("mods.ultron.src.Tamper")
  local Integrity=require("mods.ultron.src.Integrity")
  local UI=require("mods.ultron.src.UI")
  local Gen2Talk=require("mods.ultron.src.Gen2Talk")
  local Career=require("mods.ultron.src.CareerMemory")
  local Routine=require("mods.ultron.src.Routine")
  local Observer=require("mods.ultron.src.Observer")
  local RouteMemory=require("mods.ultron.src.RouteMemory")
  local FieldPlanner=require("mods.ultron.src.FieldPlanner")
  local Research=require("mods.ultron.src.LegendaryResearch")
  local Settings=require("mods.ultron.src.Settings")
  local Achievements=require("mods.ultron.src.Achievements")
  local NameTag=require("mods.ultron.src.NameTag")
  local Nicknames=require("mods.ultron.src.Nicknames")
  local PartnerLegacy=require("mods.ultron.src.PartnerLegacy")
  local PartnerChronicle=require("mods.ultron.src.PartnerChronicle")
  local Determination=require("mods.ultron.src.Determination")

  local game,engine,news
  local buildStatus="not attempted"
  local chatPending,chatOpening=false,false
  local pulse=0
  local state={}

  local function log(level,msg)
    local l=mod.log and mod.log[level or "info"]; if l then pcall(l,mod.log,"[Ultron] "..tostring(msg)) end
  end
  local function normalise(saved)
    saved=type(saved)=="table" and saved or {}
    return {version=180,rival=saved.rival,motivation=Motivation.new(saved.motivation),determination=Determination.new(saved.determination),atlas=Atlas.new(saved.atlas),brain=Brain.new(saved.brain),chat=Micro.new(saved.chat),identity=Identity.new(saved.identity),challenge=Challenge.new(saved.challenge),training=Exchange.new(saved.training),career=Career.new(saved.career),routine=Routine.new(saved.routine),observer=Observer.new(saved.observer),routeMemory=RouteMemory.new(saved.routeMemory),fieldPlanner=FieldPlanner.new(saved.fieldPlanner),research=Research.new(saved.research),settings=Settings.new(saved.settings),achievements=Achievements.new(saved.achievements),nicknames=Nicknames.new(saved.nicknames),partnerLegacy=PartnerLegacy.new(saved.partnerLegacy),partnerChronicle=PartnerChronicle.new(saved.partnerChronicle),tamper=Tamper.new(saved.tamper),news=saved.news}
  end
  local function loadState() local s; pcall(function() s=mod.save:get("state") end); state=normalise(s); mod._ultronSettings=state.settings; news=News.new(mod,state.news); news:setEnabled(state.settings.newsTicker) end
  local function saveState()
    if engine and engine.rival then state.rival=engine:serializeRival(); state.identity=Identity.snapshot(state.identity,engine.rival); state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity); state.routeMemory=engine.routeMemory or state.routeMemory end
    if news then state.news=news:serialize() end
    pcall(function() mod.save:set("state",state) end)
  end
  local function say(text) return UI.say(mod,game,Util.cleanText(text,260)) end
  local function rewardHappiness(changes)
    local H=engine and engine.modules and engine.modules.Happiness; local r=engine and engine.rival
    if not(H and H.adjust and r) then return end
    for _,c in ipairs(changes or {}) do local d=0
      if c.kind=="badge" then d=4*(c.amount or 1) elseif c.kind=="catch" then d=math.min(3,c.amount or 1) elseif c.kind=="training" then d=math.min(2,c.amount or 1) elseif c.kind=="beat_player" then d=2*(c.amount or 1) elseif c.kind=="lost_to_player" then d=1 end
      if d>0 then pcall(H.adjust,r,d,"Ultron drive",{kind="ULTRON_DRIVE"}) end
    end
  end
  local function announceChanges(changes)
    if not news then return end
    for _,c in ipairs(changes or {}) do
      if c.kind=="badge" then news:add("Ultron earned a badge. Drive increased.","badge")
      elseif c.kind=="catch" then news:add("Ultron expanded his roster with a new catch.","catch")
      elseif c.kind=="training" and (c.amount or 0)>=2 then news:add("Ultron completed another training cycle.","train")
      elseif c.kind=="beat_player" then news:add("Ultron defeated the player and updated his battle model.","battle")
      elseif c.kind=="lost_to_player" then news:add("Ultron lost to the player and began counter-analysis.","battle") end
    end
  end
  local function announceCareer(events)
    if not news then return end
    for _,e in ipairs(events or {}) do
      if e.kind=="rivalry_stage" then news:add("Rivalry status changed: "..tostring(e.label or e.to):gsub("_"," ")..".","rivalry")
      elseif e.kind=="signature_chosen" then news:add("Ultron chose "..tostring(e.species or "a Pokemon"):gsub("_"," ").." as his permanent signature partner.","partner")
      elseif e.kind=="hall_of_fame" then news:add("Ultron archived a League-winning team in his personal Hall of Fame.","legacy")
      elseif e.kind=="post_champion_goal" then news:add("Ultron selected a new post-Champion objective: "..tostring(e.label or e.goal)..".","goal")
      elseif e.kind=="champion_reign_lost" then news:add("Ultron lost the Champion title. The old reign remains in his history.","legacy") end
    end
  end
  local function announceJourney(event)
    if not(news and event) then return end
    if event.kind=="routine" and event.routine~="JOURNEY" then news:add("Ultron routine: "..tostring(event.routine):gsub("_"," "):lower()..".","routine")
    elseif event.kind=="observed_player_battle" then news:add("Ultron watched one of the player's major battles and updated his scouting model.","scout")
    elseif event.kind=="field_plan" then news:add("Ultron reorganised his field team for "..table.concat(event.moves or {},"/")..".","field")
    elseif event.kind=="field_blocked" then news:add("Ultron's route requires "..tostring(event.move)..". He will not bypass the field move requirement.","field")
    elseif event.kind=="legendary_research" then
      local status=tostring(event.status or "LEAD"):gsub("_"," "):lower()
      news:add("Ultron legendary research: "..tostring(event.species):gsub("_"," ").." is now "..status..".","legendary")
    end
  end

  local function tamperCallout()
    local line; state.tamper,line=Tamper.callout(state.tamper); if line then if news then news:add("INTEGRITY ALERT: "..line,"integrity") end; say("Ultron: "..line); saveState(); return true end
    return false
  end
  local function announceAchievements(events)
    if not news then return end
    for _,e in ipairs(events or {}) do if e.kind=="achievement" then news:add("Achievement unlocked: "..tostring(e.label or e.id)..".","achievement") end end
  end
  local function announceNickname(event)
    if not(event and event.kind=="nickname") then return end
    if news then news:add("Ultron nicknamed "..tostring(event.species or "a Pokemon"):gsub("_"," ").." "..tostring(event.nickname or "").." after their bond deepened.","partner") end
  end
  local function announcePartner(events)
    if not news then return end
    for _,e in ipairs(events or {}) do
      local who=tostring(e.nickname or e.species or "a partner"):gsub("_"," ")
      if e.kind=="partner_status" then
        news:add(who.." reached partner status: "..tostring(e.label or e.status)..".","partner")
      elseif e.kind=="partner_comeback" then
        news:add(who.." helped Ultron win a comeback rematch against the player.","partner")
      end
    end
  end
  local function announceChronicle(event)
    if not(news and event) then return end
    if event.kind=="famous_victory" then news:add("Partner chronicle: "..tostring(event.label or "major victory")..".","partner") end
  end
  local function announceDetermination(event)
    if not(news and event) then return end
    if event.reason=="lost_to_player" then
      news:add("Ultron recovered from defeat with determination "..tostring(math.floor(event.value or 0)).."/100 and began an honest counter-plan.","battle")
    elseif event.reason=="beat_player" and (event.value or 0)>0 then
      news:add("Ultron converted part of his rematch determination into a victory over the player.","battle")
    end
  end
  local function latest() return news and news:latest() or (engine and engine:latestNews()) or "No update." end
  local function integrityText() return state.tamper and state.tamper.detected and ("TAMPER EVENTS: "..tostring(state.tamper.count)..". Ultron remembers unauthorised changes.") or "CORE INTEGRITY: VERIFIED" end

  local function openChat() chatPending=true end
  local function actuallyOpenChat()
    if not(chatPending and game and engine and engine.rival) or chatOpening then return end
    chatPending=false
    if tamperCallout() then return end
    chatOpening=true; local okS,Screens=pcall(require,"src.ui.Screens")
    if not(okS and Screens and Screens.push) then chatOpening=false; say("Ultron: Text input is unavailable on this host build."); return end
    local isGen2=engine.generation==2
    local screen=isGen2 and "Gen2NamingScreen" or "NamingScreen"
    local chatScreen
    local function closeChatScreen()
      local stack=game and game.stack
      if not(stack and chatScreen and type(stack.top)=="function" and type(stack.pop)=="function") then return end
      local ok,top=pcall(stack.top,stack)
      if ok and top==chatScreen then pcall(stack.pop,stack) end
    end
    local function cancelChat(pop)
      if pop then closeChatScreen() end
      chatOpening=false
      chatPending=false
    end
    local opts={title="MESSAGE (B=EXIT)",prompt="MESSAGE (B=EXIT)",type="player",
      maxLen=72,maxLength=72,default="",initial="",
      onCancel=function() cancelChat(true) end,
      onClose=function() cancelChat(true) end,
      onDone=function(value)
        -- Gen 1 pops itself before onDone; Gen 2 intentionally leaves that to
        -- its caller. Only pop when this exact keyboard is still on top.
        closeChatScreen()
        chatOpening=false
        value=tostring(value or "")
        if value:match("^%s*$") then chatPending=false; return end
        local response
        state.chat,response=Micro.respond(state.chat,value,engine.rival,engine,state.motivation,state.brain,state.atlas,state.career,state.training,state.partnerLegacy)
        saveState(); say("Ultron: "..tostring(response))
      end}
    local ok=pcall(function()
      chatScreen=Screens.push(game,screen,opts)
      -- The stock keyboards reserve B for delete and do not call onCancel.
      -- For message composition, an empty field gives B the conventional
      -- cancel meaning while retaining delete whenever text exists.
      if chatScreen and type(chatScreen.update)=="function" then
        local originalUpdate=chatScreen.update
        chatScreen.update=function(self,dt)
          local input=self.game and self.game.input
          local empty
          if isGen2 then empty=tostring(self.text or "")==""
          else empty=#(self.glyphs or {})==0 end
          if empty and input and input.wasPressed and input:wasPressed("b") then
            cancelChat(true)
            return
          end
          return originalUpdate(self,dt)
        end
      end
    end)
    if not ok then chatOpening=false; say("Ultron: This build refused the text keyboard.") end
  end
  local function applyTrainingImport(ok,msg)
    if ok and engine and engine.rival then
      engine.training=state.training
      state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"shared training import",state.training,state.career)
      if news then news:add("Ultron imported collective training knowledge into persistent user data.","training") end
    end
    saveState()
    if msg and msg~="" then say(msg) end
  end
  local function exportTraining()
    if not(engine and engine.rival) then return end
    local ok,msg; state.training,ok,msg=Exchange.exportFile(state.training,engine.rival,state.atlas,engine,game)
    saveState(); say(msg)
  end
  local function importTraining()
    if not(engine and engine.rival) then return end
    local ok,msg,pending
    state.training,state.atlas,ok,msg,pending=Exchange.importFile(state.training,engine.rival,state.atlas,engine,game)
    if pending then saveState(); return end
    applyTrainingImport(ok,msg)
  end
  local uiCtx={}
  uiCtx.badges=function() return engine and Util.badgeCount(engine.rival) or 0 end
  uiCtx.drive=function() return state.motivation and state.motivation.drive or 0 end
  uiCtx.latest=latest; uiCtx.chat=openChat; uiCtx.export=exportTraining; uiCtx.import=importTraining; uiCtx.integrity=integrityText
  uiCtx.battle=function()
    if not(engine and engine.rival) then return false,"Ultron is not active yet." end
    local ok,msg=engine:challengePlayerNow()
    if ok then
      state.challenge=Challenge.new(state.challenge); state.challenge.remaining=math.max(state.challenge.remaining,90); state.challenge.pursuing=false
      if news then news:add("The player challenged Ultron to an immediate battle.","challenge") end
      saveState()
    end
    return ok,msg
  end
  uiCtx.career=function() return Career.summary(state.career).."\n\n"..Determination.summary(state.determination) end
  uiCtx.chronicle=function() return PartnerChronicle.summary(state.partnerChronicle,engine and engine.rival,state.partnerLegacy) end
  uiCtx.hallOfFame=function() return PartnerChronicle.hallOfFameSummary(state.partnerChronicle,state.career,state.partnerLegacy) end
  uiCtx.journey=function() return table.concat({Routine.summary(state.routine),Determination.summary(state.determination),RouteMemory.summary(state.routeMemory),FieldPlanner.summary(state.fieldPlanner),Observer.summary(state.observer),Research.summary(state.research)},"\n\n") end
  uiCtx.training=function() return Exchange.summary(state.training).."\n\n"..Exchange.storageDescription() end
  uiCtx.bonds=function() return PartnerLegacy.summary(state.partnerLegacy,engine and engine.rival).."\n\n"..Nicknames.summary(state.nicknames,engine and engine.rival,state.career) end
  uiCtx.achievements=function() return Achievements.summary(state.achievements) end
  uiCtx.settingsRows=function() return Settings.rows(state.settings) end
  uiCtx.toggleSetting=function(key)
    local value; state.settings,value=Settings.toggle(state.settings,key); mod._ultronSettings=state.settings
    if engine and engine.setSettings then engine:setSettings(state.settings) end
    if news then news:setEnabled(state.settings.newsTicker) end
    saveState(); return value
  end
  setmetatable(uiCtx,{__index=function(_,k) if k=="engine" then return engine end end})

  local function registerInteraction()
    if not engine then return end
    if engine.generation==2 then
      Gen2Talk.register("ultron:talk",function(world,npc)
        if Gen2Talk.npcKey(npc)~="ULTRON" then return false end
        game=(world and world.game) or game or mod.game; if not tamperCallout() then UI.open(mod,game,uiCtx) end; return true
      end,20); Gen2Talk.install(); return
    end
    if not(mod.content and mod.content.map_scripts) then return end
    engine._talkMaps=engine._talkMaps or {}
    for id in pairs(engine.graph and engine.graph.nodes or {}) do if not engine._talkMaps[id] then
      local ok=pcall(function() mod.content.map_scripts:register(id,{priority=-7,talk={ULTRON_TALK=function(g,world,obj,done)
        game=g or game; if not tamperCallout() then UI.open(mod,game,uiCtx) end; if done then done() end
      end}}) end); if ok then engine._talkMaps[id]=true end
    end end
  end

  local function diagnosticText()
    if not engine then return "ULTRON DIAGNOSTICS\nEngine: NOT ACTIVE\nBootstrap: "..tostring(buildStatus).."\nIf this persists after entering the overworld, report this text with the save." end
    local id=Identity.status(state.identity,game,engine,mod)
    local sp=engine:spawnDiagnostics()
    local lines={
      "ULTRON DIAGNOSTICS",
      "Activation: "..tostring(id.activationReason or "unknown"),
      "Starter ready: "..tostring(id.starterReady).." ("..tostring(id.starterReadyReason or "?")..")",
      "Player starter: "..tostring(id.playerStarter or "unresolved").." via "..tostring(id.starterSource or "n/a"),
      "Ultron starter: "..tostring(id.ultronStarter or "unassigned"),
      "Player map: "..tostring(sp.playerMap or "unknown"),
      "Ultron map: "..tostring(sp.ultronMap or "unknown"),
      "Same map: "..tostring(sp.sameMap),
      "Dormant: "..tostring(sp.dormant),
      "Visible NPC: "..tostring(sp.live),
      "Spawn path: "..tostring(sp.spawnPath or "not used yet"),
      "World spawn API: "..tostring(sp.hasWorldSpawn),
      "Runtime spawn API: "..tostring(sp.hasRuntimeSpawn),
      "Physical position: "..tostring(sp.positionReady),
      "Colosseum UI: "..tostring((function() local f; pcall(function() f=mod.find and mod.find("colosseum_ui_overhaul") end); return f~=nil end)()),
    }
    if sp.positionError then lines[#lines+1]="Position error: "..tostring(sp.positionError) end
    if sp.spawnError then lines[#lines+1]="Spawn error: "..tostring(sp.spawnError) end
    if not sp.sameMap then lines[#lines+1]="Ultron is active off-map. He must physically reach your map before becoming visible." end
    return table.concat(lines,"\n")
  end
  uiCtx.diagnostics=diagnosticText

  local function build()
    if not(game and game.data) then buildStatus="waiting for a valid live Game/data object"; return false end
    buildStatus="building standalone engine"
    if not news then news=News.new(mod,state.news) end
    -- Audit the serialized state BEFORE Rival.restore reasserts immutable fields.
    if type(state.rival)=="table" then state.tamper=Tamper.auditLoaded(state.tamper,state.rival,state.identity) end
    local okCore,core=pcall(Engine.loadCore,mod)
    if not okCore then buildStatus="core load failed: "..tostring(core); log("warn",buildStatus); return false end
    local fused=Fusion.build(core.personalities)
    mod._ultronSettings=state.settings
    local okEngine,built=pcall(Engine.new,mod,fused,state.rival,{news=function(line,entry)
      if news then news:add(line,(entry and entry.kind) or "progress") end
      local events; state.career,events=Career.observeNews(state.career,engine and engine.rival,entry,state.chat); announceCareer(events)
      local partnerEvents; state.partnerLegacy,partnerEvents=PartnerLegacy.observeNews(state.partnerLegacy,engine and engine.rival,entry); announcePartner(partnerEvents)
      local chronicleEvent; state.partnerChronicle,chronicleEvent=PartnerChronicle.observeNews(state.partnerChronicle,engine and engine.rival,entry); announceChronicle(chronicleEvent)
      local researchEvent; state.research,researchEvent=Research.observeNews(state.research,entry,engine and engine.rival); announceJourney(researchEvent)
    end,error=function(e) log("warn",e) end},game)
    if not okEngine then buildStatus="engine construction failed: "..tostring(built); log("warn",buildStatus); engine=nil; return false end
    engine=built; if engine.setSettings then engine:setSettings(state.settings) end; if news then news:setEnabled(state.settings.newsTicker) end
    if not engine:isReady() then buildStatus="engine constructed without a rival/map graph"; return false end
    state.identity=Identity.initialiseEconomy(state.identity,engine.rival,engine.restored)
    local okIntegrity,bad=Integrity.check(mod); if not okIntegrity then for _,row in ipairs(bad or {}) do state.tamper=Tamper.flag(state.tamper,"protected file "..tostring(row.path)) end end
    local identityChanged
    state.identity,identityChanged=Identity.ensure(state.identity,engine.rival,game,engine,mod)
    if identityChanged and state.identity.existingSaveRecovered and news then
      news:add("Ultron recovered activation on this existing save and began his journey from "..tostring(engine.rival.map or "the starting route"):gsub("_"," ")..".","boot")
    end
    state.training=Exchange.ensureSource(state.training,engine.rival,engine,game); state.atlas=Atlas.index(state.atlas,engine.graph); engine.atlas=state.atlas; engine.routeMemory=state.routeMemory; engine.training=state.training
    local partnerEvents; state.partnerLegacy,partnerEvents=PartnerLegacy.ensure(state.partnerLegacy,engine.rival); announcePartner(partnerEvents)
    state.partnerChronicle=PartnerChronicle.apply(state.partnerChronicle,engine.rival)
    state.determination=Determination.apply(state.determination,engine.rival)
    state.career=Career.apply(state.career,engine.rival)
    local careerEvents; state.career,careerEvents=Career.observeProgress(state.career,engine.rival,state.chat); state.career=Career.apply(state.career,engine.rival); announceCareer(careerEvents)
    state.partnerLegacy,partnerEvents=PartnerLegacy.syncHallOfFame(state.partnerLegacy,engine.rival,state.career); announcePartner(partnerEvents)
    local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes)
    engine.rival.competitiveLiteracy=100; Fusion.motivate(engine.rival.personality,math.min(100,(state.motivation.drive or 0)+(state.determination.value or 0)*0.35),Util.badgeCount(engine.rival),#(engine.rival.party or {}))
    state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"load",state.training,state.career); registerInteraction(); engine:spawnIfPresent(); state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity)
    if news and #news.history==0 then
      news:add("Ultron is online at "..tostring(engine.rival.map or "his starting area"):gsub("_"," ").." and pursuing the Pokemon League.","boot")
    end
    buildStatus="active"
    saveState(); log("info","standalone engine active; maps="..tostring(state.atlas.graphCount)); return true
  end

  UI.installStartMenu(mod,uiCtx)
  mod.hooks:wrap("trainer.party",function(next,oppClass,partyIndex,party)
    local vanilla=next(oppClass,partyIndex,party); if engine and engine:trainerClassMatches(oppClass) and engine.rival then engine.pending=engine.rival; return engine.rival:battleParty() end; return vanilla
  end)
  mod.hooks:wrap("battle.enemy_action",function(next,battle)
    if engine and engine.generation==1 then
      local action=engine:chooseGen1BattleItem(battle)
      if action then return action end
    end
    return next(battle)
  end)
  mod.hooks:wrap("input.step",function(next,g,dt)
    local result=next(g,dt); game=Util.resolveGame(g,game,mod.game) or game; if engine and game then engine.game=game end; if news then news:update(dt) end
    if engine and engine.rival then
      local importOk,importMsg
      state.training,state.atlas,importOk,importMsg=Exchange.pollImport(state.training,engine.rival,state.atlas,engine,game)
      if importOk~=nil then applyTrainingImport(importOk,importMsg) end
    end
    if not engine then if game and game.data then build() end; return result end
    pulse=pulse+(tonumber(dt) or 0); engine:update(dt)
    if pulse>=0.50 then local step=pulse; pulse=0
      local learnedWorld=engine:worldView() or {}
      local routeEvent; state.routeMemory,routeEvent=RouteMemory.observePlayer(engine.routeMemory or state.routeMemory,engine:playerMapId(),learnedWorld.playerX,learnedWorld.playerY,engine.tick); engine.routeMemory=state.routeMemory; announceJourney(routeEvent)
      state.tamper=Tamper.auditLive(state.tamper,engine.rival)
      state.identity=Identity.ensure(state.identity,engine.rival,game,engine,mod)
      if state.identity.starterAssigned then
        local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes); announceChanges(changes); state.motivation=Motivation.tick(state.motivation,engine.rival)
        Fusion.motivate(engine.rival.personality,math.min(100,(state.motivation.drive or 0)+(state.determination.value or 0)*0.35),Util.badgeCount(engine.rival),#(engine.rival.party or {})); state.atlas=Atlas.observe(state.atlas,engine.rival,engine,step); engine.atlas=state.atlas
        local partnerEvents; state.partnerLegacy,partnerEvents=PartnerLegacy.ensure(state.partnerLegacy,engine.rival); announcePartner(partnerEvents)
        state.partnerChronicle=PartnerChronicle.apply(state.partnerChronicle,engine.rival)
        state.determination=Determination.noteCounterPrepared(state.determination,engine.rival)
        local careerEvents; state.career,careerEvents=Career.observeProgress(state.career,engine.rival,state.chat); state.career=Career.apply(state.career,engine.rival); announceCareer(careerEvents)
        state.partnerLegacy,partnerEvents=PartnerLegacy.syncHallOfFame(state.partnerLegacy,engine.rival,state.career); announcePartner(partnerEvents)
        if state.settings.nicknamePokemon then local nicknameEvent; state.nicknames,nicknameEvent=Nicknames.tick(state.nicknames,engine.rival,state.career); announceNickname(nicknameEvent) end
        if state.settings.routines then local routineEvent; state.routine,routineEvent=Routine.tick(state.routine,engine.rival,engine,state.career,state.determination); announceJourney(routineEvent) end
        local fieldEvent; state.fieldPlanner,fieldEvent=FieldPlanner.tick(state.fieldPlanner,engine.rival,engine); announceJourney(fieldEvent)
        local researchEvent; state.research,researchEvent=Research.observeMap(state.research,engine.rival,engine); announceJourney(researchEvent)
        if state.settings.periodicChallenges then state.challenge=Challenge.tick(state.challenge,engine.rival,engine,step,state.motivation,state.chat,engine.modules,state.career,state.determination) else state.challenge=Challenge.new(state.challenge); state.challenge.pursuing=false; engine.rival._ultronPursuit=nil end
        local achievementEvents; state.achievements,achievementEvents=Achievements.tick(state.achievements,{career=state.career,routeMemory=state.routeMemory,research=state.research,trainingSources=Exchange.sourceCount(state.training),nicknames=state.nicknames,partnerLegacy=state.partnerLegacy,tick=engine.tick}); announceAchievements(achievementEvents)
        if Brain.shouldPrepare(state.brain,engine.rival,changes,state.career) then state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"progress",state.training,state.career) end
        state.routeMemory=engine.routeMemory or state.routeMemory
      end
      state.tamper=Tamper.trust(state.tamper,engine.rival,state.identity)
    end
    actuallyOpenChat(); return result
  end)
  -- Draw after presentation overhauls such as Colosseum UI (its final HUD
  -- layers occupy priorities 10000-11000). This prevents the overhaul from
  -- covering Ultron's attached name tag/news after we draw them.
  mod.hooks:wrap("render.hud",function(next,g,viewport) local result=next(g,viewport); if engine then result=NameTag.draw(engine,state.settings.nameTag,result,viewport) end; return news and news:draw(g,result) or result end,20000)

  mod.events:on("game.ready",function(ev) game=Util.resolveGame(ev,game,mod.game) or game; loadState(); build() end)
  mod.events:on("save.loaded",function(ev)
    game=Util.resolveGame(ev,game,mod.game) or game; loadState(); engine=nil; build()
  end)
  mod.events:on("save.created",function(ev)
    state=normalise(nil); mod._ultronSettings=state.settings; news=News.new(mod,nil); news:setEnabled(state.settings.newsTicker); engine=nil; game=Util.resolveGame(ev,game,mod.game) or game
    if game then build() end
  end)
  mod.events:on("save.writing",saveState)
  mod.events:on("battle.ended",function(ev)
    if not engine then return end
    local battleCtx={tick=engine.tick,map=engine.rival and engine.rival.map,ultronParty=Util.copy(engine.rival and engine.rival.party or {}),playerParty=Util.copy(engine.pendingBattleStartParty or {})}
    local outcome=engine:settleBattle(ev); if not outcome then
      local observeEvent; if state.settings.observePlayerBattles then state.observer,observeEvent=Observer.observePlayerBattle(state.observer,ev,engine); announceJourney(observeEvent) end
      if observeEvent then
        local researchEvent; state.research,researchEvent=Research.observePlayerBattle(state.research,ev,observeEvent,engine); announceJourney(researchEvent)
        state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,"observed player battle",state.training,state.career); saveState()
      end
      return
    end
    local careerEvents; state.career,careerEvents=Career.recordPlayerBattle(state.career,engine.rival,outcome,battleCtx,state.chat); state.career=Career.apply(state.career,engine.rival); announceCareer(careerEvents)
    local partnerEvents; state.partnerLegacy,partnerEvents=PartnerLegacy.recordPlayerBattle(state.partnerLegacy,engine.rival,outcome,battleCtx); announcePartner(partnerEvents)
    local chronicleEvent; state.partnerChronicle,chronicleEvent=PartnerChronicle.recordPlayerBattle(state.partnerChronicle,engine.rival,outcome,battleCtx); announceChronicle(chronicleEvent)
    local determinationEvent; state.determination,determinationEvent=Determination.recordPlayerBattle(state.determination,engine.rival,outcome,state.career); announceDetermination(determinationEvent)
    state.determination=Determination.apply(state.determination,engine.rival)
    local changes; state.motivation,changes=Motivation.observe(state.motivation,engine.rival); rewardHappiness(changes); announceChanges(changes)
    state.challenge=Challenge.new(state.challenge); state.challenge.remaining=math.max(state.challenge.remaining,90); state.challenge.pursuing=false; engine.rival._ultronPursuit=nil
    state.brain=Brain.prepare(state.brain,engine.rival,engine.modules,outcome.playerWon and "loss to player" or "victory over player",state.training,state.career); saveState()
  end)
  mod.events:on("world.interacted",function(ev)
    if not(engine and ev and ev.target) then return end; local n=ev.target; local name=n.name or (n.def and n.def.name) or n.id
    if tostring(name)=="ULTRON" then if not tamperCallout() then UI.open(mod,game or mod.game,uiCtx) end end
  end)

  mod.exports.status=function()
    local identity=Identity.status(state.identity,game,engine,mod); local spawn=engine and engine:spawnDiagnostics() or {}
    return {version="1.8.0",standalone=true,worldOptional=true,integrity=not(state.tamper and state.tamper.detected),latest=latest(),rival=engine and engine.rival or nil,
      identity=identity,spawn=spawn,rivalryStage=state.career and state.career.rivalry and state.career.rivalry.stage,signatureSpecies=state.career and state.career.signatureSpecies,
      postChampionGoal=state.career and state.career.postChampion and state.career.postChampion.goal,trainingSources=Exchange.sourceCount(state.training),routine=state.routine and state.routine.current,
      learnedPaths=state.routeMemory and state.routeMemory.learned,majorBattlesObserved=state.observer and state.observer.observed,legendaryResearch=state.research and state.research.discoveries,settings=Settings.new(state.settings),achievements=Achievements.new(state.achievements),nicknames=Nicknames.new(state.nicknames),partnerLegacy=PartnerLegacy.new(state.partnerLegacy),partnerChronicle=PartnerChronicle.new(state.partnerChronicle),determination=Determination.new(state.determination),trainingStorage=Exchange.storageDescription()}
  end
  mod.exports.career=function() return Career.new(state.career) end
  mod.exports.trainingSummary=function() return Exchange.summary(state.training) end
  mod.exports.settings=function() return Settings.new(state.settings) end
  mod.exports.achievements=function() return Achievements.new(state.achievements) end
  mod.exports.nicknames=function() return Nicknames.new(state.nicknames) end
  mod.exports.partnerLegacy=function() return PartnerLegacy.new(state.partnerLegacy) end
  mod.exports.partnerChronicle=function() return PartnerChronicle.new(state.partnerChronicle) end
  mod.exports.determination=function() return Determination.new(state.determination) end
  mod.exports.journeySummary=function() return uiCtx.journey() end
  mod.exports.rival=function() return engine and engine.rival or nil end
  mod.exports.latestNews=latest
end
