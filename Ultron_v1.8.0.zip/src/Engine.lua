local U = require("mods.ultron.src.Util")
local PhysicalWorld = require("mods.ultron.src.PhysicalWorld")
local RouteMemory = require("mods.ultron.src.RouteMemory")
local GuideKnowledge = require("mods.ultron.src.GuideKnowledge")
local Activities = require("mods.ultron.src.Activities")
local Engine = {}
Engine.__index = Engine
local LEGENDARY={ARTICUNO=true,ZAPDOS=true,MOLTRES=true,MEWTWO=true,MEW=true,RAIKOU=true,ENTEI=true,SUICUNE=true,LUGIA=true,HO_OH=true,CELEBI=true}
local BATTLE_ITEM_ORDER={"FULL_RESTORE","HYPER_POTION","SUPER_POTION","POTION","FULL_HEAL"}

local function compileModule(mod, cache, loading, name)
  if cache[name] ~= nil then return cache[name] end
  if loading[name] then error("Ultron core circular require: " .. tostring(name), 0) end
  loading[name] = true
  local path = "engine/" .. name .. ".lua"
  local source = mod:read(path)
  if not source then error("Ultron core missing " .. path, 0) end
  local chunk, err
  if type(loadstring) == "function" then
    local ok, c, e = pcall(loadstring, source, "@ultron/" .. path)
    if ok then chunk, err = c, e else err = c end
  end
  if not chunk and type(load) == "function" then
    local ok, c, e = pcall(load, source, "@ultron/" .. path)
    if ok then chunk, err = c, e or err else err = c end
  end
  if not chunk then error("Ultron core compile failed: " .. tostring(err), 0) end
  local function req(child) return compileModule(mod, cache, loading, child) end
  local value = chunk(req, mod)
  loading[name] = nil
  cache[name] = value == nil and true or value
  return cache[name]
end

local function loadCore(mod)
  local cache, loading = {}, {}
  local function req(name) return compileModule(mod, cache, loading, name) end
  return {
    req=req,
    Util=req("src/Util"), MapGraph=req("src/MapGraph"), Pathfinder=req("src/Pathfinder"),
    BattleSim=req("src/BattleSim"), Rival=req("src/Rival"), AI=req("src/AI"),
    Simulation=req("src/Simulation"), EncounterData=req("src/EncounterData"),
    Sprites=req("src/Sprites"), Happiness=req("src/Happiness"),
    Competitive=req("src/Competitive"), League=req("src/League"),
    Version=req("src/Version"), TrainerClasses=req("src/TrainerClasses"),
    personalities=req("data/personalities"), rawGyms=req("data/gyms"),
  }
end

Engine.loadCore=loadCore

local function mapsTable(data, versionKey)
  if versionKey == "gen2" then return data and (data.gen2Maps or data.maps) or {} end
  return data and (data.maps or data.gen2Maps) or {}
end

local function hasMap(graph, id)
  return id and graph and graph.has and graph:has(id) or false
end

local function buildGyms(raw, versionKey, graph)
  local src = versionKey == "gen2" and raw.gen2 or raw
  local out = {order={},byBadge={},centers={},training={},trainingPrefixes=U.copy(src.trainingPrefixes or {})}
  for _, badge in ipairs(src.order or {}) do
    local row = src.byBadge and src.byBadge[badge]
    if row and (hasMap(graph,row.map) or hasMap(graph,row.city)) then
      out.order[#out.order+1] = badge
      out.byBadge[badge] = U.copy(row)
    end
  end
  if src.league and (hasMap(graph,src.league.map) or hasMap(graph,src.league.city)) then
    out.league = U.copy(src.league)
  end
  for _, id in ipairs(src.centers or {}) do if hasMap(graph,id) then out.centers[#out.centers+1]=id end end
  local seen = {}
  for _, prefix in ipairs(src.trainingPrefixes or {}) do
    local matches = graph.matching and graph:matching({prefix}) or {}
    for _, id in ipairs(matches or {}) do if not seen[id] then seen[id]=true; out.training[#out.training+1]=id end end
  end
  if #out.training==0 then
    for id in pairs(graph.nodes or {}) do
      if tostring(id):find("ROUTE",1,true) then out.training[#out.training+1]=id end
    end
    table.sort(out.training)
  end
  return out
end

local function serviceMaps(graph, token)
  local out={}
  for id in pairs(graph and graph.nodes or {}) do
    if tostring(id):find(token,1,true) then out[#out+1]=id end
  end
  table.sort(out); return out
end

local function hashText(text)
  local h = 2166136261
  for i=1,#tostring(text or "") do
    h = (h + text:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

local function makeCompat(mod)
  local C = {}
  local positive = {}
  local function findAny(ids)
    if not mod or not mod.find then return nil end
    for _,id in ipairs(ids) do
      if positive[id] then return positive[id] end
      local ok,h = pcall(function() return mod:find(id) end)
      if ok and h then positive[id]=h; return h end
    end
  end
  function C:krAllows() return true end
  function C:silph() return false end
  function C:ghosts() return nil end
  function C:girlMode() return false end
  function C:weather()
    return findAny({"weather_fx","weather-fx","WeatherFx"}) ~= nil
  end
  local function weatherExports()
    local h=findAny({"weather_fx","weather-fx","WeatherFx"}); return h and h.exports or nil
  end
  function C:weatherId()
    local e=weatherExports(); if not(e and type(e.weather)=="function") then return nil end
    local ok,v=pcall(e.weather); return ok and v or nil
  end
  function C:battleWeather()
    local e=weatherExports(); if not(e and type(e.battleWeather)=="function") then return nil end
    local ok,v=pcall(e.battleWeather); return ok and v or nil
  end
  return C
end

local function choosePlayerHome(graph, versionKey)
  local candidates
  if versionKey=="gen2" then
    candidates={"PLAYERS_HOUSE_2F","J2_PLAYERS_HOUSE_2F","KRIS_HOUSE_2F","PLAYERS_HOUSE_1F","J2_PLAYERS_HOUSE_1F","KRIS_HOUSE_1F","NEW_BARK_TOWN","J2_NEW_BARK_TOWN"}
  else
    candidates={"REDS_HOUSE_2F","REDS_HOUSE_2","REDS_HOUSE_1F","REDS_HOUSE_1","PALLET_TOWN"}
  end
  for _,id in ipairs(candidates) do if hasMap(graph,id) then return id,candidates end end
  return nil,candidates
end

local function coreDef(versionKey)
  return {
    id="ultron", slot=997, trainerClass="OPP_ULTRON", name="Ultron", fixedName=true,
    gender="male", personality="ULTRON", seed=0x554C5452,
    fallbackSprite="SPRITE_COOLTRAINER_M", basePic="OPP_COOLTRAINER_M",
    aiClass="OPP_COOLTRAINER_M", baseMoney=80,
    homeMaps={
      default={"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"},
      yellow={"ROUTE_1","PALLET_TOWN","VIRIDIAN_CITY"},
      gen2={"ROUTE_29","NEW_BARK_TOWN","CHERRYGROVE_CITY"},
    },
  }
end

local function chooseShellSpecies(data, versionKey)
  local reg = (versionKey=="gen2" and data and data.gen2Pokemon) or (data and data.pokemon) or {}
  local list = versionKey=="gen2" and {"TOTODILE","CHIKORITA","CYNDAQUIL","PIKACHU"}
    or {"CLEFAIRY","SQUIRTLE","CHARMANDER","BULBASAUR","PIKACHU"}
  for _,id in ipairs(list) do if reg[id] then return id end end
  return next(reg)
end

local function safeListCopy(party)
  local out={}
  for _,slot in ipairs(type(party)=="table" and party or {}) do
    if type(slot)=="table" then out[#out+1]=U.copy(slot) end
  end
  return out
end

function Engine.new(mod, fusedPersonality, savedRival, callbacks, game)
  local self=setmetatable({},Engine)
  self.mod=mod; self.game=game or (mod and mod.game) or nil; self.modules=loadCore(mod); self.callbacks=callbacks or {}; self.settings=(mod and mod._ultronSettings) or {}
  self.data=self.game and self.game.data or nil
  if type(self.data)~="table" then return self end
  self.versionKey=self.modules.Version.starterKey(self.data)
  self.generation=self.versionKey=="gen2" and 2 or 1
  self.graph=self.modules.MapGraph.build(mapsTable(self.data,self.versionKey))
  self.gyms=buildGyms(self.modules.rawGyms,self.versionKey,self.graph)
  self.marts=serviceMaps(self.graph,"MART")
  self.compat=makeCompat(mod)
  self.news={}; self.tick=0; self.accumulator=0; self.walkAccumulator=0; self.spawned={}
  self.guideKnowledge=GuideKnowledge.new(self.generation,self.data)
  self.activities=Activities.new()
  self.pending=nil; self.pendingBattle=false; self.pendingBattleStartParty=nil; self.walkMapCache=nil
  self.sprites=self.modules.Sprites.new(mod)
  self.modules.personalities.ULTRON=fusedPersonality
  local seed=self:worldSeed()
  local playerHome,playerHomeFallbacks=choosePlayerHome(self.graph,self.versionKey)
  self.rivalContext={
    data=self.data, personalities=self.modules.personalities, generation=self.generation,
    graph=self.graph, gyms=self.gyms, trainingMaps=self.gyms.training, healingMaps=self.gyms.centers,
    playerHomeMap=playerHome, playerHomeFallbacks=playerHomeFallbacks,
    versionKey=self.versionKey, compat=self.compat, save=mod.save, mod=mod, ultronSettings=self.settings,
    starterSeed=seed, roster={}, assignedNames={ultron="Ultron"}, manager=self,
    relationships=false, badgePacingEnabled=false,
    speciesAllowed=function(species)
      local reg=(self.data.gen2Pokemon or self.data.pokemon or {})
      if reg[species] then return true end
      return self.data.pokemon and self.data.pokemon[species] ~= nil or false
    end,
    encounterCandidates=function(mapId) return self:encounterCandidatesForMap(mapId) end,
    catchAllowed=function(species) local sp=tostring(species or ""):upper(); if LEGENDARY[sp] and self.settings.catchLegendaries==false then return false end; return true end,
    simulateUnvisitedRegions=function() return true end,
    startingRegion=function() return self.versionKey=="gen2" and "johto" or "kanto" end,
    newGamePlusActive=function() return false end, newGamePlusCycle=function() return 1 end,
  }
  local def=coreDef(self.versionKey)
  self.rival=self.modules.Rival.new(def,self.rivalContext)
  self.rival.personality=fusedPersonality; self.rival.personalityId="ULTRON"; self.rival.competitiveLiteracy=100
  self.rival.def=def; self.rival.name="Ultron"; self.rival.id="ultron"
  local restored=false
  if type(savedRival)=="table" and self.rival.restore then
    local ok,res=pcall(function() return self.rival:restore(savedRival) end)
    restored=ok and res~=false
    self.rival.ctx=self.rivalContext; self.rival.def=def; self.rival.name="Ultron"; self.rival.id="ultron"
    self.rival.personality=fusedPersonality; self.rival.personalityId="ULTRON"; self.rival.competitiveLiteracy=100
  end
  self.rivals={self.rival}; self.byId={ultron=self.rival}; self.restored=restored
  self:registerTrainerShell()
  PhysicalWorld.attach(self,nil)
  return self
end

function Engine:isReady() return self.rival~=nil and self.graph~=nil end
function Engine:setSettings(settings)
  self.settings=type(settings)=="table" and settings or {}
  if self.rivalContext then self.rivalContext.ultronSettings=self.settings end
  if self.rival and self.rival.ctx then self.rival.ctx.ultronSettings=self.settings end
  if self.rival and self.settings.catchLegendaries==false and LEGENDARY[tostring(self.rival.huntTarget or ""):upper()] then
    self.rival.huntTarget=nil; self.rival.huntMap=nil; self.rival.huntFailedAttempts=0
  end
  return self.settings
end

function Engine:worldSeed()
  local save=self.game and self.game.save or {}
  local player=save.player or {}
  local raw=table.concat({tostring(save.trainerId or save.trainerID or save.tid or player.trainerId or 0),
    tostring(save.playerName or player.name or "PLAYER"), tostring(self.versionKey or "gen1")},":")
  return 1 + (hashText(raw) % 2147483646)
end

function Engine:gauntletDone() return true end
function Engine:gauntletActive() return false end
function Engine:relationshipsEnabled() return false end
function Engine:fullNameOf(r) return (r and r.name) or "Ultron" end

function Engine:playerBadgeCount()
  local save=self.game and self.game.save or {}
  local n=0
  local badges=save.badges
  if type(badges)=="table" then for _,v in pairs(badges) do if v==true or tonumber(v)==1 then n=n+1 end end end
  if n>0 then return n end
  local flags=save.flags
  if type(flags)=="table" then
    local order=self.gyms and self.gyms.order or {}
    for _,id in ipairs(order) do if flags[id] or flags["BADGE_"..id] then n=n+1 end end
  end
  return n
end

function Engine:playerHealthyCount()
  local n=0
  for _,m in ipairs(self.game and self.game.save and self.game.save.party or {}) do
    if type(m)=="table" and (tonumber(m.hp) or 1)>0 then n=n+1 end
  end
  return n
end

function Engine:playerMapId()
  local where
  pcall(function() if self.mod.world and self.mod.world.current then where=self.mod.world:current() end end)
  if where and where.mapId then return where.mapId end
  local ow=self:activeMap(); local map=ow and ow.map
  return (map and (map.id or map.mapId)) or (ow and ow.mapId) or nil
end

function Engine:worldView()
  local where
  pcall(function() if self.mod.world and self.mod.world.current then where=self.mod.world:current() end end)
  if not(where and where.mapId) then
    pcall(function() if self.game and self.game.world and self.game.world.current then where=self.game.world:current() end end)
  end
  if not(where and where.mapId) then
    local ow=self:activeMap(); local map=ow and ow.map; local p=(ow and ow.player) or (self.game and self.game.player)
    local id=(map and (map.id or map.mapId)) or (ow and (ow.mapId or ow.id))
    if id then where={mapId=id,x=(p and (p.cellX or p.x)) or (ow and ow.playerX),y=(p and (p.cellY or p.y)) or (ow and ow.playerY)} end
  end
  return {playerMap=where and where.mapId or nil,playerX=where and where.x,playerY=where and where.y,
    playerParty=self.game and self.game.save and self.game.save.party or {},playerBadges=self:playerBadgeCount(),
    compat=self.compat,rivals=self.rivals,companionId=nil,relationships=false,playerChampion=false,tick=self.tick,
    log=function(r,e) self:addNews(r,e) end}
end

function Engine:encounterCandidatesForMap(mapId)
  local rows={}; local total,n=0,0
  self.modules.EncounterData.each(self.data,mapId,function(species,level,weight)
    if type(species)=="string" then
      level=math.max(2,math.floor(tonumber(level) or 5)); weight=math.max(1,tonumber(weight) or 1)
      rows[#rows+1]={species=species,level=level,weight=weight}; total=total+level; n=n+1
    end
  end)
  if #rows==0 then return rows end
  table.sort(rows,function(a,b) if a.species~=b.species then return a.species<b.species end return a.level<b.level end)
  return rows
end

local function newsLine(rival,event)
  local name="Ultron"; event=event or {}; local kind=event.kind
  if event.text then return tostring(event.text) end
  if event.gym then return event.won and (name.." beat "..tostring(event.gym.leader or "a Gym Leader").."!")
    or (name.." lost to "..tostring(event.gym.leader or "a Gym Leader")..".") end
  if kind=="caught" or kind=="catch" then return name.." caught "..tostring(event.species or "a Pokemon").."." end
  if kind=="level" then return name.." trained "..tostring(event.species or "a Pokemon").." to Lv"..tostring(event.level or "?").."." end
  if kind=="evolve" then return name.." evolved "..tostring(event.from or "a Pokemon").." into "..tostring(event.into or "something").."." end
  if kind=="league" then return event.won and (name.." conquered the Pokemon League!") or (name.." fell short at the Pokemon League.") end
  if kind=="champion" then return name.." became Champion." end
  if kind=="trainer" then return event.won and (name.." defeated a trainer.") or (name.." lost a trainer battle.") end
  if kind=="career" or kind=="chapter" or kind=="milestone" then return name.." learned from another stage of the journey." end
  if kind=="hm" or kind=="hm_hunt" then return name.." is working on "..tostring(event.move or "field progress").."." end
  return name.." update: "..tostring(kind or "progress").."."
end

function Engine:addNews(rival,event)
  local line=newsLine(rival,event)
  local entry=type(event)=="table" and U.copy(event) or {}
  entry.text=line; entry.tick=self.tick; entry.kind=entry.kind or "news"
  self.news[#self.news+1]=entry; while #self.news>48 do table.remove(self.news,1) end
  if self.callbacks and self.callbacks.news then pcall(self.callbacks.news,line,entry) end
end

function Engine:latestNews() return self.news[#self.news] and self.news[#self.news].text or "Ultron is calculating his next move." end

function Engine:registerTrainerShell()
  local mod,data=self.mod,self.data
  if not(mod and mod.content and mod.content.trainers and data) then return nil end
  local species=chooseShellSpecies(data,self.versionKey); if not species then return nil end
  local id="OPP_ULTRON"
  if self.generation==2 and data.gen2Trainers and type(data.gen2Trainers.classes)=="table" then
    local classes=data.gen2Trainers.classes
    if classes[id] then self.gen2Class=tonumber(classes[id].index); return self.gen2Class end
    local used={}; for _,c in pairs(classes) do if type(c)=="table" and tonumber(c.index) then used[math.floor(c.index)]=true end end
    local idx; for i=255,1,-1 do if not used[i] then idx=i break end end; if not idx then return nil end
    local record={id=id,name="Ultron",index=idx,baseMoney=80,trainers={{index=1,id="ultron1",name="Ultron",party={{species=species,level=5}}}}}
    pcall(function() mod.content.trainers:register(id,record) end); self.gen2Class=idx; return idx
  end
  local trainers=data.trainers or {}; if trainers[id] then return id end
  local record={id=id,name="Ultron",parties={{{species=species,level=5}}},baseMoney=80}
  if trainers.OPP_COOLTRAINER_M then record.basePic="OPP_COOLTRAINER_M" end
  if data.ai_classes and data.ai_classes.OPP_COOLTRAINER_M then record.aiClass="OPP_COOLTRAINER_M" end
  pcall(function() mod.content.trainers:register(id,record) end); return id
end

function Engine:trainerClassMatches(oppClass)
  if not(self.pendingBattle and self.pending==self.rival) then return false end
  if self.generation==2 and type(oppClass)=="number" and self.gen2Class then return tonumber(oppClass)==tonumber(self.gen2Class) end
  return tostring(oppClass)==tostring(self.activeBattleClass or "OPP_ULTRON")
end

function Engine:gen2BattleParty()
  local okMon,Mon=pcall(require,"src.battle.gen2.Mon")
  if not(okMon and Mon and type(Mon.new)=="function") then return {} end
  local out={}
  for _,slot in ipairs(self.rival.party or {}) do
    local species=slot.species or slot.speciesId
    if species then
      local dvs=slot.dvs and U.copy(slot.dvs) or {attack=10,defense=10,speed=10,special=10}
      local opts={dvs=dvs,item=slot.heldItem or slot.item,shiny=slot.shiny==true,happiness=tonumber(slot.happiness) or 70}
      local ok,m=pcall(Mon.new,self.data,species,math.max(1,math.min(100,math.floor(tonumber(slot.level) or 5))),opts)
      if ok and type(m)=="table" then out[#out+1]=m end
    end
  end
  return out
end

function Engine:battleItemList()
  local out={}
  local r=self.rival
  for _,item in ipairs(BATTLE_ITEM_ORDER) do
    local count=r and r.itemCount and math.floor(r:itemCount(item)) or 0
    for _=1,math.max(0,count) do out[#out+1]=item end
  end
  return out
end

function Engine:chooseGen1BattleItem(battle)
  local r=self.rival
  if not(self.pendingBattle and self.pending==r and battle and battle.enemy and r and r.takeItem) then return nil end
  -- A charge/trap/bide/recharge continuation is mandatory and cannot be
  -- interrupted by opening the bag.
  if type(battle.lockedAction)=="function" then
    local ok,locked=pcall(battle.lockedAction,battle,battle.enemy)
    if ok and locked then return nil end
  end
  local enemy=battle.enemy
  local mon=enemy.mon or enemy
  local hp=tonumber(mon.hp or enemy.hp) or 0
  local stats=mon.stats or enemy.stats or {}
  local maxHp=tonumber(mon.maxHp or enemy.maxHp or stats.hp) or hp
  local status=mon.status or enemy.status
  local item
  if (status or (maxHp>0 and hp<=maxHp*0.25)) and r:itemCount("FULL_RESTORE")>0 then item="FULL_RESTORE"
  elseif maxHp>0 and hp<=maxHp*0.30 and r:itemCount("HYPER_POTION")>0 then item="HYPER_POTION"
  elseif maxHp>0 and hp<=maxHp*0.40 and r:itemCount("SUPER_POTION")>0 then item="SUPER_POTION"
  elseif maxHp>0 and hp<=maxHp*0.50 and r:itemCount("POTION")>0 then item="POTION"
  elseif status and r:itemCount("FULL_HEAL")>0 then item="FULL_HEAL" end
  if item and r:takeItem(item) then return {special="aiItem",item=item,_ultronInventory=true} end
  return nil
end

function Engine:reconcileGen2BattleItems()
  local before=self.pendingBattleItemCounts
  local remaining=self.pendingBattleItems
  local r=self.rival
  self.pendingBattleItems=nil; self.pendingBattleItemCounts=nil
  if not(type(before)=="table" and type(remaining)=="table" and r and r.takeItem) then return 0 end
  local left={}
  for _,item in ipairs(remaining) do left[item]=(left[item] or 0)+1 end
  local used=0
  for item,count in pairs(before) do
    local spent=math.max(0,(tonumber(count) or 0)-(left[item] or 0))
    for _=1,spent do if r:takeItem(item) then used=used+1 end end
  end
  return used
end

local function battleStateFactory()
  for _,name in ipairs({"src.battle.BattleState","battle.BattleState","BattleState"}) do
    local ok,v=pcall(require,name); if ok and v then return v end
  end
end

function Engine:pushBattle()
  local r=self.rival; if not r or self.pendingBattle then return false end
  self.lastBattleError=nil
  r:prepareForBattle(); self.pending=r; self.pendingBattle=true; self.pendingBattleStartParty=safeListCopy(self.game and self.game.save and self.game.save.party)
  local function refused(reason)
    self.lastBattleError=tostring(reason or "battle launch refused")
    self.pendingBattle=false; self.pending=nil; self.pendingBattleStartParty=nil; self.activeBattleClass=nil
    self.pendingBattleItems=nil; self.pendingBattleItemCounts=nil
    return false
  end
  if self.generation==2 then
    local ow=self:activeMap()
    local party=self:gen2BattleParty()
    if not ow then return refused("no live Gen 2 overworld") end
    if type(ow.startBattle)~="function" then return refused("live Gen 2 overworld has no startBattle API") end
    if #party==0 then return refused("Ultron's party could not be converted for Gen 2") end
    local items=self:battleItemList(); local counts={}
    for _,item in ipairs(items) do counts[item]=(counts[item] or 0)+1 end
    self.pendingBattleItems=items; self.pendingBattleItemCounts=counts
    local ok,result=pcall(function() return ow:startBattle({trainer={name="Ultron",class="OPP_ULTRON",classId="OPP_ULTRON",index=1,memberId=1,party=party,items=items,worldPreferVoxelBattleUI=true}},function() end) end)
    if not ok then return refused(result) end
    if result==false then return refused("Gen 2 startBattle returned false") end
    return true
  end
  -- Current Gen1Recomp keeps OverworldState on game.stack; game.overworld is
  -- absent on that host. activeMap() already resolves the live stack state,
  -- WorldAPI facade and older game.overworld layouts in the correct order.
  local controller=self:activeMap(); local BS=battleStateFactory()
  if not controller then return refused("no live Gen 1 overworld") end
  if type(controller.pushBattle)~="function" then return refused("live Gen 1 overworld has no pushBattle API") end
  if not(BS and type(BS.newTrainer)=="function") then return refused("Gen 1 BattleState is unavailable") end
  local trainers=self.game and self.game.data and self.game.data.trainers or {}
  local battleClass=trainers.OPP_ULTRON and "OPP_ULTRON" or
    (trainers.OPP_COOLTRAINER_M and "OPP_COOLTRAINER_M") or
    (trainers.OPP_RIVAL1 and "OPP_RIVAL1") or next(trainers)
  if not battleClass then return refused("no usable Gen 1 trainer class") end
  self.activeBattleClass=battleClass
  local ok,result=pcall(function()
    local battle=BS.newTrainer(self.game,battleClass,1); if not battle or battle.dead then error("trainer battle refused") end
    if type(battle.trainer)=="table" then battle.trainer=setmetatable({name="Ultron",id="OPP_ULTRON"},{__index=battle.trainer}) end
    battle.introText="Ultron wants\nto fight!"
    if not battle.onFinish then battle.onFinish=function(value) if controller.afterBattle then controller:afterBattle(value,battle) end end end
    controller:pushBattle(battle)
    return true
  end)
  if not ok then return refused(result) end
  if result==false then return refused("Gen 1 pushBattle returned false") end
  return true
end

local function healthyRivalCount(rival)
  local n=0
  for _,mon in ipairs(rival and rival.party or {}) do
    local hp=tonumber(mon.hp)
    if hp==nil and rival and rival.maxHpOf then
      local ok,v=pcall(function() return rival:maxHpOf(mon) end)
      if ok then hp=tonumber(v) end
    end
    if (hp or 1)>0 then n=n+1 end
  end
  return n
end

function Engine:challengeAvailability()
  local r=self.rival
  if not r then return false,"Ultron is not active yet." end
  if r._ultronDormant then return false,"Ultron has not begun his journey yet." end
  if self.pendingBattle then return false,"A battle is already being prepared." end
  local world=self:worldView()
  local entity=self:liveEntity()
  -- A rendered live entity is stronger evidence than a stale serialized route
  -- map. Runtime object lists can survive a transition one frame longer than
  -- the rival snapshot; direct interaction must trust the NPC the player is
  -- actually standing beside.
  if entity and world and world.playerMap then
    r.map=world.playerMap
    r.x=entity.cellX or entity.x or r.x; r.y=entity.cellY or entity.y or r.y
  elseif not(world and world.playerMap and r.map==world.playerMap) then
    return false,"Ultron is not on the same map."
  end
  if self:playerHealthyCount()<=0 then return false,"Your party needs a Pokemon able to battle." end
  if healthyRivalCount(r)<=0 then return false,"Ultron's party has fainted. He must recover first." end
  local needs,gap=self:playerPreparationNeeded()
  if needs then self:prioritisePlayerPreparation(gap); return false,"Ultron knows your team is stronger and is catching or training before the next battle." end
  local game=self.game
  local top=game and game.stack and game.stack.top and game.stack:top() or nil
  if top and top.isBattle then return false,"A battle is already in progress." end
  return true
end

local function averageLevel(party)
  local total,n,maxLevel=0,0,0
  for _,slot in ipairs(type(party)=="table" and party or {}) do
    local level=tonumber(slot and slot.level)
    if level then total=total+level; n=n+1; maxLevel=math.max(maxLevel,level) end
  end
  return n>0 and total/n or nil,maxLevel,n
end

function Engine:playerPreparationNeeded()
  local r=self.rival; if not r then return false,0 end
  local known=r.knownOpponentParty and r:knownOpponentParty("player") or nil
  local playerAvg,playerMax,count=averageLevel(known)
  if not playerAvg and self.training and type(self.training.playerLevels)=="table" then
    local shared={}; for species,row in pairs(self.training.playerLevels) do shared[#shared+1]={species=species,level=row.level} end
    playerAvg,playerMax,count=averageLevel(shared)
  end
  local ownAvg,ownMax=averageLevel(r.party)
  if not(playerAvg and ownAvg and count>0) then return false,0 end
  local gap=math.max(playerAvg-ownAvg,(playerMax or playerAvg)-(ownMax or ownAvg))
  return gap>2,gap
end

function Engine:prioritisePlayerPreparation(gap)
  local r=self.rival; if not r then return end
  r._ultronPursuit=nil; r.route=nil; r.destination=nil
  local balls=r.itemCount and (r:itemCount("POKE_BALL")+r:itemCount("GREAT_BALL")+r:itemCount("ULTRA_BALL")) or 0
  if #(r.party or {})<6 and balls>0 then r.objective="CATCH"; r:setState("HUNTING","preparing for the player's stronger team")
  else r.objective="TRAIN"; r:setState("TRAINING","closing the player level gap") end
  r.encounterCooldown=math.max(tonumber(r.encounterCooldown) or 0,math.ceil(math.max(3,tonumber(gap) or 3))*12)
end

local function moneyContainer(game)
  local save=game and game.save
  if type(save)~="table" then return nil end
  for _,row in ipairs({{save,"money"},{save,"cash"},{save.player,"money"},{save.player,"cash"}}) do
    if type(row[1])=="table" and tonumber(row[1][row[2]])~=nil then return row[1],row[2] end
  end
  return save,"money"
end

function Engine:transferBattleMoney(playerWon)
  local r=self.rival; if not r then return 0 end
  local box,key=moneyContainer(self.game); if not box then return 0 end
  local player=math.max(0,math.floor(tonumber(box[key]) or 0))
  if playerWon then
    local stake=math.max(20,math.floor((tonumber(r.money) or 0)*0.05))
    local paid=r.forfeit and r:forfeit(stake) or 0
    box[key]=player+paid
    return paid
  end
  local stake=math.min(player,math.max(20,math.floor(player*0.05)))
  box[key]=player-stake
  if r.earn then r:earn(stake) else r.money=(tonumber(r.money) or 0)+stake end
  return stake
end

function Engine:startRivalChallenge(rival)
  if rival~=self.rival then return false end
  local ok=self:challengeAvailability()
  if not ok then return false end
  return self:pushBattle()
end

function Engine:challengePlayerNow()
  local ok,reason=self:challengeAvailability()
  if not ok then return false,reason end
  local r=self.rival
  r._ultronPursuit=nil
  r.objective="CHALLENGE_PLAYER"
  local started=self:pushBattle()
  if not started then return false,"The game client refused to start the battle: "..tostring(self.lastBattleError or "unknown launch error").."." end
  r.encounterCooldown=math.max(tonumber(r.encounterCooldown) or 0,18)
  return true,"Ultron accepted the immediate challenge."
end

function Engine:settleBattle(ev)
  local r=self.pending; if not r then return nil end
  if self.generation==2 then self:reconcileGen2BattleItems() end
  local playerWon=ev and ev.result=="win"
  local tick=self.tick
  if playerWon then
    if r.recordPlayerBattle then pcall(function() r:recordPlayerBattle(false,tick) end) else r.playerLosses=(r.playerLosses or 0)+1 end
    if r.noteDefeat then pcall(function() r:noteDefeat("player",tick) end) end
    local paid=self:transferBattleMoney(true)
    local target,kind
    if r.blackoutToNearestPokemonCenter then pcall(function() local _,c,k=r:blackoutToNearestPokemonCenter("lost to player",true); target,kind=c,k end) end
    local where=(kind=="Pokemon Center" and U.spaced(target or "the last Pokemon Center")) or "the player's home"
    self:addNews(r,{kind="blackout",money=paid,text="Ultron paid the player P"..tostring(paid)..", blacked out and returned to "..where.."."})
  else
    if r.recordPlayerBattle then pcall(function() r:recordPlayerBattle(true,tick) end) else r.playerWins=(r.playerWins or 0)+1 end
    if r.noteVictory then pcall(function() r:noteVictory("player",tick) end) end
    local paid=self:transferBattleMoney(false)
    self:addNews(r,{kind="news",money=paid,text="Ultron defeated the player and received P"..tostring(paid).."."})
  end
  if r.rememberOpponent and type(self.pendingBattleStartParty)=="table" then
    pcall(function() r:rememberOpponent("player",self.pendingBattleStartParty,not playerWon,tick,true) end)
  end
  r.encounterCooldown=math.max(tonumber(r.encounterCooldown) or 0,18)
  if not playerWon then pcall(function() r:setState("IDLE","player battle complete") end) end
  local needs,gap=self:playerPreparationNeeded(); if needs then self:prioritisePlayerPreparation(gap) end
  self.pending=nil; self.pendingBattle=false; self.pendingBattleStartParty=nil
  return {playerWon=playerWon,rivalWon=not playerWon}
end

function Engine:activeMap()
  local ow
  pcall(function() if self.mod.world and self.mod.world.overworld then ow=self.mod.world:overworld() end end)
  if ow then return ow end
  local game=self.game
  if game and game.overworld and (game.overworld.map or game.overworld.mapId) then return game.overworld end
  if game and game.world then
    local w=game.world
    if w.overworld and type(w.overworld)=="function" then local ok,v=pcall(w.overworld,w); if ok and v then return v end end
    if w.map or w.mapId or w.addRuntimeObject or w.spawnNpc then return w end
  end
  local stack=game and game.stack
  if stack and type(stack.top)=="function" then local ok,v=pcall(stack.top,stack); if ok and v and (v.map or v.mapId or v.isOverworld) then return v end end
  local states=stack and stack.states
  if type(states)=="table" then
    for i=#states,1,-1 do if states[i] and (states[i].map or states[i].mapId) and (states[i].isOverworld~=false) then return states[i] end end
  end
  return game and (game.overworld or game.world) or nil
end

function Engine:liveEntity()
  local ow=self:activeMap(); local map=ow and ow.map; local wanted="ULTRON"; local handle=self.spawned.ultron
  local handleId=type(handle)=="table" and (handle.id or handle.index or handle.name) or handle
  for _,list in ipairs({(ow and ow.npcs) or {},(ow and ow.entities) or {},(map and map.npcs) or {}}) do
    for _,npc in ipairs(list) do
      local id=npc.id or npc.index or (npc.def and npc.def.index); local name=npc.name or (npc.def and npc.def.name)
      if npc==handle or (handleId~=nil and tostring(id)==tostring(handleId)) or name==wanted or name=="AIR_ultron" then return npc end
    end
  end
end

function Engine:despawn()
  local h=self.spawned.ultron
  if h then pcall(function() if self.mod.world and self.mod.world.removeNpc then self.mod.world:removeNpc(h) end end) end
  self.spawned.ultron=nil; self.rival.spawnedAt=nil; self.rival.walking=false
end

function Engine:overview()
  local o
  pcall(function() if self.mod.world and self.mod.world.mapOverview then o=self.mod.world:mapOverview() end end)
  if not o then pcall(function() if self.game and self.game.world and self.game.world.mapOverview then o=self.game.world:mapOverview() end end) end
  if o and o.rows then return o end
  local ow=self:activeMap(); local map=ow and ow.map
  if not map then return nil end
  local ok,MapOverview=pcall(require,"src.world.MapOverview")
  if ok and MapOverview and type(MapOverview.build)=="function" then
    local builtOk,built=pcall(MapOverview.build,map,{})
    if builtOk and built and built.rows then return built end
  end
  return nil
end

function Engine:isTransitCell(mapId,overview,x,y)
  if not(x and y) then return false end
  for _,m in ipairs((overview and overview.markers) or {}) do if m.kind=="warp" and m.x==x and m.y==y then return true end end
  local def=mapsTable(self.data,self.versionKey)[mapId]
  for _,w in ipairs((def and def.warps) or {}) do if w.x==x and w.y==y then return true end end
  return false
end

function Engine:validRivalCell(rival,overview,x,y,allowTransit)
  local grid=self.modules.Pathfinder.grid(overview)
  local walkable
  if grid then walkable=self.modules.Pathfinder.walkable(grid,x,y)
  else
    grid=PhysicalWorld.grid(self,rival and rival.map,rival)
    walkable=grid and PhysicalWorld.walkable(grid,x,y) or false
  end
  if not walkable then return false end
  if not allowTransit and self:isTransitCell(rival.map,overview,x,y) then return false end
  local ow=self:activeMap(); local selfEntity=self:liveEntity()
  for _,npc in ipairs((ow and ow.npcs) or {}) do
    if npc~=selfEntity and npc.cellX==x and npc.cellY==y then return false end
  end
  local w=self:worldView(); if w.playerMap==rival.map and w.playerX==x and w.playerY==y then return false end
  return true
end

function Engine:safePlacement(overview)
  local grid=self.modules.Pathfinder.grid(overview)
  local static=false
  if not grid then grid=PhysicalWorld.grid(self,self.rival and self.rival.map,self.rival); static=true end
  if not grid then return nil end
  local w=self:worldView(); local sx=self.rival.rng:int(0,math.max(0,(grid.w or 1)-1)); local sy=self.rival.rng:int(0,math.max(0,(grid.h or 1)-1))
  for dy=0,(grid.h or 1)-1 do for dx=0,(grid.w or 1)-1 do
    local x=(sx+dx)%(grid.w or 1); local y=(sy+dy)%(grid.h or 1)
    local d=w.playerX and w.playerY and math.abs(x-w.playerX)+math.abs(y-w.playerY) or 4
    local okCell=static and PhysicalWorld.walkable(grid,x,y) or self:validRivalCell(self.rival,overview,x,y,false)
    if d>=2 and okCell and not self:isTransitCell(self.rival.map,overview,x,y) then return x,y end
  end end
end

function Engine:spawnIfPresent()
  local r=self.rival; local w=self:worldView()
  if not(r and w.playerMap and r.map==w.playerMap) then if self.spawned.ultron then self:despawn() end; return false end
  local existing=self:liveEntity()
  if self.spawned.ultron and existing then return true end
  -- Runtime object lists can be rebuilt across map transitions without telling
  -- the mod. A stale handle must never permanently suppress rematerialisation.
  if self.spawned.ultron and not existing then self.spawned.ultron=nil; r.spawnedAt=nil; r.walking=false; r.walkTarget=nil end
  local overview=self:overview(); local x,y=r.x,r.y
  if not(x and y and self:validRivalCell(r,overview,x,y,false)) then x,y=self:safePlacement(overview) end
  if not(x and y) then self.lastSpawnError="no proven walkable placement"; self.lastSpawnAttemptMap=r.map; return false end
  local sprite=r.appearanceSprite or r.spriteOverride
  if not(sprite and self.sprites:exists(sprite,self.data)) then sprite=self.sprites:walkerFor(r.def,self.data,{"SPRITE_COOLTRAINER_M","SPRITE_BLUE","SPRITE_SILVER","SPRITE_YOUNGSTER"}) end
  if not sprite then self.lastSpawnError="no usable NPC sprite"; self.lastSpawnAttemptMap=r.map; return false end
  local obj={index=247,name="ULTRON",sprite=sprite,x=x,y=y,movement=self.generation==2 and 6 or "STAY",range="DOWN",solid=false,passable=true,through=true,text=self.generation==1 and "ULTRON_TALK" or nil}
  local h,err,path
  if self.mod.world and type(self.mod.world.spawnNpc)=="function" then
    local ok,a,b=pcall(function() return self.mod.world:spawnNpc(r.map,obj) end)
    if ok and a then h=a; path="WorldAPI.spawnNpc" else err=tostring(b or a or "spawnNpc refused") end
  end
  if not h and self.game and self.game.world and type(self.game.world.spawnNpc)=="function" then
    local ok,a,b=pcall(function() return self.game.world:spawnNpc(r.map,obj) end)
    if ok and a then h=a; path="GameWorld.spawnNpc" else err=tostring(b or a or err or "game.world spawnNpc refused") end
  end
  if not h and self.game and self.game.world and type(self.game.world.addRuntimeObject)=="function" then
    local ok,a,b=pcall(function() return self.game.world:addRuntimeObject(r.map,obj,self.mod.id or "ultron") end)
    if ok and a then h=a; path="GameWorld.addRuntimeObject" else err=tostring(a or b or err or "game.world addRuntimeObject refused") end
  end
  if not h then
    local ow=self:activeMap()
    if ow and type(ow.addRuntimeObject)=="function" then
      local ok,a,b=pcall(function() return ow:addRuntimeObject(r.map,obj,self.mod.id or "ultron") end)
      if ok and a then h=a; path="OverworldState.addRuntimeObject" else err=tostring(a or b or err or "addRuntimeObject refused") end
    end
  end
  if h then
    self.spawned.ultron=h; r.x,r.y=x,y; r.spawnedAt={x,y}; self.lastSpawnError=nil; self.lastSpawnPath=path; self.lastSpawnAttemptMap=r.map; return true
  end
  self.lastSpawnError=err or "no runtime NPC spawn path"; self.lastSpawnAttemptMap=r.map
  if self.callbacks and self.callbacks.error then pcall(self.callbacks.error,"Ultron spawn failed on "..tostring(r.map)..": "..tostring(self.lastSpawnError)) end
  return false
end

function Engine:moveRivalNpc(rival,x,y,facing,onDone)
  if rival.walking then return false end
  local entity=self:liveEntity()
  local ex=entity and math.abs((entity.cellX or rival.x or x)-x) or 0; local ey=entity and math.abs((entity.cellY or rival.y or y)-y) or 0
  if entity and ex+ey==1 then
    rival.walking=true; rival.walkAge=0; rival.facing=facing or rival.facing
    entity.facing=facing or entity.facing; entity.targetX=x; entity.targetY=y; entity.moving=true; entity.progress=0
    rival.walkTarget={x=x,y=y,onDone=onDone}; return true
  end
  -- No setPosition/teleport fallback. If the live engine cannot animate one
  -- adjacent step, Ultron waits and replans rather than cheating across cells.
  return false
end

local function adjacentTargets(px,py) return {{px,py+1},{px-1,py},{px+1,py},{px,py-1}} end

-- Some interiors encode their return staircase as LAST_MAP. MapGraph can
-- prove the reverse route from the destination's incoming warp, but that
-- synthetic reverse edge deliberately has no coordinates. Resolve the live
-- room's own exit tile here so the local walker heads for the door instead of
-- falling back to an idle wander while a strategic destination is pending.
function Engine:localExitFor(nextMap,edge,overview)
  if edge and edge.x~=nil and edge.y~=nil then return edge.x,edge.y end
  local def=mapsTable(self.data,self.versionKey)[self.rival and self.rival.map]
  local fallback
  for _,warp in ipairs((def and def.warps) or {}) do
    if warp.x~=nil and warp.y~=nil then
      if warp.destMap==nextMap then return warp.x,warp.y end
      if warp.destMap=="LAST_MAP" and not fallback then fallback={warp.x,warp.y} end
    end
  end
  if fallback then return fallback[1],fallback[2] end
  for _,marker in ipairs((overview and overview.markers) or {}) do
    if marker.kind=="warp" and marker.x~=nil and marker.y~=nil then
      local dest=marker.destMap or marker.map or marker.targetMap
      if dest==nextMap then return marker.x,marker.y end
      if not fallback then fallback={marker.x,marker.y} end
    end
  end
  return fallback and fallback[1],fallback and fallback[2]
end

function Engine:recoverInteriorRoute(destination)
  local r,graph=self.rival,self.graph
  local def=mapsTable(self.data,self.versionKey)[r and r.map]
  if not(r and destination and def and graph) then return nil,nil end
  local best,bestRoute
  for _,warp in ipairs(def.warps or {}) do
    local candidate=warp.destMap
    if candidate and candidate~="LAST_MAP" and candidate~=r.map then
      local route
      if graph.routeAllowed then
        route=graph:routeAllowed(candidate,destination,function(id)
          return not r.canEnterMap or r:canEnterMap(id)
        end)
      elseif graph.route then route=graph:route(candidate,destination) end
      if candidate==destination then route={candidate} end
      if route and (not bestRoute or #route<#bestRoute) then best,bestRoute=candidate,route end
    end
  end
  -- A graph may know the reverse interior edge even when the route cache
  -- could not start from this LAST_MAP room. Consider those neighbours too.
  for _,edge in ipairs(graph.neighbours and graph:neighbours(r.map) or {}) do
    local candidate=edge.to
    local route=graph.routeAllowed and graph:routeAllowed(candidate,destination,function(id)
      return not r.canEnterMap or r:canEnterMap(id)
    end) or (graph.route and graph:route(candidate,destination))
    if candidate==destination then route={candidate} end
    if route and (not bestRoute or #route<#bestRoute) then best,bestRoute=candidate,route end
  end
  if not best then return nil,nil end
  local rebuilt={r.map}; for _,id in ipairs(bestRoute) do rebuilt[#rebuilt+1]=id end
  r.route=rebuilt; r.routeIndex=1
  return best,graph.edgeBetween and graph:edgeBetween(r.map,best) or nil
end

function Engine:travelTarget(overview,world)
  local r=self.rival
  if r._ultronGuideFollow and world.playerMap==r.map and world.playerX and world.playerY then
    local best,dist
    for _,c in ipairs(adjacentTargets(world.playerX,world.playerY)) do if self:validRivalCell(r,overview,c[1],c[2],false) then
      local d=math.abs(r.x-c[1])+math.abs(r.y-c[2]); if not dist or d<dist then best,dist=c,d end
    end end
    if best then return best[1],best[2],nil end
  end
  if r._ultronPursuit and world.playerX and world.playerY then
    local best,dist
    for _,c in ipairs(adjacentTargets(world.playerX,world.playerY)) do if self:validRivalCell(r,overview,c[1],c[2],false) then
      local d=math.abs((r.x or c[1])-c[1])+math.abs((r.y or c[2])-c[2]); if not dist or d<dist then best,dist=c,d end
    end end
    if best then return best[1],best[2],nil end
  end
  if r.destination and r.map~=r.destination then
    if not r.route then r.route=r:routeTo(r.destination) end
    local nextMap=r:nextHop(); local edge
    if not nextMap then nextMap,edge=self:recoverInteriorRoute(r.destination) end
    if not nextMap and world.playerMap==r.map then r._ultronGuideFollow=true end
    if nextMap then
      edge=edge or self.graph:edgeBetween(r.map,nextMap)
      local exitX,exitY=self:localExitFor(nextMap,edge,overview)
      if exitX~=nil and exitY~=nil then
        local best,dist
        for _,c in ipairs(adjacentTargets(exitX,exitY)) do if self:validRivalCell(r,overview,c[1],c[2],false) then
          local d=math.abs(r.x-c[1])+math.abs(r.y-c[2]); if not dist or d<dist then best,dist=c,d end
        end end
        if best then return best[1],best[2],nextMap end
      end
      -- A known next map without a resolvable physical exit is not an idle
      -- state. Wait and retry against refreshed live map data; random walking
      -- here produces the visible circles reported in small interiors.
      return nil
    end
  end
  local goal=r.localWalkGoal
  if goal and self:validRivalCell(r,overview,goal[1],goal[2],false) then return goal[1],goal[2],nil end
  local grid=self.modules.Pathfinder.grid(overview); if not grid then return nil end
  for _=1,48 do local x=r.rng:int(0,math.max(0,grid.w-1)); local y=r.rng:int(0,math.max(0,grid.h-1)); local d=math.abs(r.x-x)+math.abs(r.y-y)
    if d>=2 and d<=8 and self:validRivalCell(r,overview,x,y,false) then r.localWalkGoal={x,y}; return x,y,nil end end
end

function Engine:walk(dt)
  self.walkAccumulator=self.walkAccumulator+(tonumber(dt) or 0); if self.walkAccumulator<0.30 then return end; self.walkAccumulator=self.walkAccumulator-0.30
  local r=self.rival; local world=self:worldView(); if not(r and r.map==world.playerMap and self:spawnIfPresent()) then return end
  if r.walking then
    r.walkAge=(tonumber(r.walkAge) or 0)+0.30; local e=self:liveEntity()
    if e and not e.moving then
      r.x,r.y=e.cellX or r.x,e.cellY or r.y; local t=r.walkTarget; r.walking=false; r.walkTarget=nil; r.walkAge=0
      if t and t.onDone and r.x==t.x and r.y==t.y then pcall(t.onDone) end
    elseif r.walkAge>1.4 then r.walking=false; r.walkTarget=nil; r.walkAge=0 end
    return
  end
  local overview=self:overview(); local grid=self.modules.Pathfinder.grid(overview); if not grid or not(r.x and r.y) then return end
  local tx,ty,nextMap=self:travelTarget(overview,world); if not(tx and ty) then return end
  if r.x==tx and r.y==ty and nextMap then
    self:despawn(); r.arrivedFrom=r.map; r.map,r.x,r.y=nextMap,nil,nil; r.spawnedAt=nil; r.localWalkGoal=nil; r.hopClock=nil
    if r.useHMsForMap then pcall(function() r:useHMsForMap(nextMap) end) end; if r.visitMap then pcall(function() r:visitMap(nextMap) end) end
    if r.map==r.destination then pcall(function() self.modules.AI.onArrive(r,world) end) end; return
  end
  local blocked={}; if world.playerX and world.playerY then blocked[world.playerX..","..world.playerY]=true end
  local path=self.modules.Pathfinder.find(grid,r.x,r.y,tx,ty,{budget=180,blocked=blocked}); local one=type(path)=="table" and path[1] or nil
  if one then self:moveRivalNpc(r,one.x,one.y,one.dir) else
    r._ultronPathFails=(r._ultronPathFails or 0)+1; r.localWalkGoal=nil
    if r._ultronPathFails>=5 then r.route=nil; r.path=nil; r._ultronPathFails=0 end
  end
end

function Engine:nearestMart(from)
  return self.graph and self.graph.nearest and self.graph:nearest(from,self.marts or {}) or nil
end

function Engine:nearestCenter(from)
  local centers=self.gyms and self.gyms.centers or (self.rival and self.rival.ctx and self.rival.ctx.healingMaps) or {}
  return self.graph and self.graph.nearest and self.graph:nearest(from,centers) or nil
end

function Engine:serviceTick(world)
  local r=self.rival; if not r or r._ultronDormant then return end
  -- Emergency blackout route always has priority and can never be interrupted by shopping.
  if r._ultronBlackout then return end
  if r.destination and r.map~=r.destination and world and world.playerMap==r.map then
    local hop=r.nextHop and r:nextHop() or nil
    if not hop or (tonumber(r.stuckTicks) or 0)>=2 or (tonumber(r._ultronPathFails) or 0)>=3 then r._ultronGuideFollow=true end
  elseif world and world.playerMap~=r.map and not r.destination then r._ultronGuideFollow=nil end
  if self.guideKnowledge then GuideKnowledge.apply(self.guideKnowledge,r,self) end
  if self.activities then
    local event; self.activities,event=Activities.tick(self.activities,r,self)
    if event then self:addNews(r,event) end
  end
  if r.objective=="CHALLENGE_PLAYER" or r._ultronPursuit then
    local needs,gap=self:playerPreparationNeeded(); if needs then self:prioritisePlayerPreparation(gap) end
  end
  local balls=(r.itemCount and (r:itemCount("POKE_BALL")+r:itemCount("GREAT_BALL")+r:itemCount("ULTRA_BALL"))) or tonumber(r.balls) or 0
  local atMart=tostring(r.map or ""):find("MART",1,true)~=nil
  if r.objective=="SHOP" and r.map==r.destination and atMart then
    local bought=r.restockBalls and r:restockBalls() or 0
    local tm=r.buyTms and r:buyTms() or nil
    local soldMoney,soldCount=0,0
    if r.sellDuplicates then soldMoney,soldCount=r:sellDuplicates() end
    if bought>0 or tm or (soldMoney or 0)>0 then
      local extra=tm and (" and bought TM "..tostring(tm)) or ""
      if (soldMoney or 0)>0 then extra=extra.."; sold "..tostring(soldCount or 0).." duplicate Pokemon" end
      self:addNews(r,{kind="shop",text="Ultron visited the Pokemart, bought "..tostring(bought).." Poke Balls"..extra.."."})
    end
    local resume=r._ultronResume or {}; r.objective=resume.objective or "IDLE"; r.destination=resume.destination; r.state=resume.state or "IDLE"; r.route=nil; r.routeIndex=1; r._ultronResume=nil
    return
  end
  if balls<=1 and not atMart and r.objective~="HEAL" and r.state~="HEALING" then
    local mart=self:nearestMart(r.map)
    if mart and mart~=r.map then
      r._ultronResume={objective=r.objective,destination=r.destination,state=r.state}
      r.objective="SHOP"; r.destination=mart; r.route=nil; r.routeIndex=1; r:setState("TRAVELLING","walking to a Pokemart for supplies")
      self:addNews(r,{kind="shop",text="Ultron is walking to a Pokemart to restock."})
    end
  end
end

function Engine:physicalTravelTick(rival,ctx)
  if rival and rival._ultronGuideFollow and self.routeMemory then
    local updated,row=RouteMemory.playerExit(self.routeMemory,rival.map); self.routeMemory=updated
    if not row and self.training and type(self.training.routes)=="table" then
      for _,candidate in pairs(self.training.routes) do if candidate.from==rival.map then row=candidate break end end
    end
    if row and row.to and row.exitX~=nil and row.exitY~=nil then
      local arrived=PhysicalWorld.stepTo(self,rival,row.exitX,row.exitY)
      if arrived then
        local from=rival.map; rival.map=row.to; rival.x,rival.y=row.entryX,row.entryY; rival.route=nil; rival.path=nil; rival.localWalkGoal=nil; rival.stuckTicks=0
        if rival.visitMap then pcall(function() rival:visitMap(row.to) end) end
        self.routeMemory=RouteMemory.transition(self.routeMemory,from,row.to,row.exitX,row.exitY,row.entryX,row.entryY,self.tick,"player")
        return "followed player through learned exit"
      end
      return "following player's learned exit"
    end
  end
  return PhysicalWorld.step(self,rival,ctx)
end

function Engine:physicalTrainerTick(rival,foe,ctx)
  if not(rival and foe and foe.x~=nil and foe.y~=nil) then return true end
  if not PhysicalWorld.ensurePosition(self,rival) then return false end
  local distance=math.abs((rival.x or 0)-foe.x)+math.abs((rival.y or 0)-foe.y)
  if distance==1 then return true end
  local world=self:worldView()
  if world.playerMap==rival.map and self:spawnIfPresent() then
    if rival.walking then return false end
    local overview=self:overview(); local grid=self.modules.Pathfinder.grid(overview)
    if not grid then return false end
    local blocked={}; if world.playerX and world.playerY then blocked[world.playerX..","..world.playerY]=true end
    local candidates={{foe.x,foe.y-1},{foe.x,foe.y+1},{foe.x-1,foe.y},{foe.x+1,foe.y}}
    local bestPath
    for _,c in ipairs(candidates) do
      if self:validRivalCell(rival,overview,c[1],c[2],false) then
        local path=self.modules.Pathfinder.find(grid,rival.x,rival.y,c[1],c[2],{budget=240,blocked=blocked})
        if type(path)=="table" and #path>0 and (not bestPath or #path<#bestPath) then bestPath=path end
      end
    end
    local one=bestPath and bestPath[1]
    if one then self:moveRivalNpc(rival,one.x,one.y,one.dir) end
    return false
  end
  local arrived=PhysicalWorld.stepTo(self,rival,foe.x,foe.y,{adjacent=true})
  return arrived==true
end

function Engine:update(dt)
  if not self:isReady() then return end
  self:spawnIfPresent(); self:walk(dt)
  self.accumulator=self.accumulator+(tonumber(dt) or 0); if self.accumulator<1.5 then return end; self.accumulator=self.accumulator-1.5; self.tick=self.tick+1
  if self.rival._ultronDormant or self.rival.map=="__ULTRON_STAGING__" then return end
  -- Blackout relocation/healing has already happened. Clear only the blackout
  -- guard BEFORE the normal HEALING simulation tick so AI.evaluate can choose
  -- the next real destination. The old post-tick cleanup overwrote that fresh
  -- decision back to IDLE, which stranded Ultron in the player's house.
  if self.rival._ultronBlackout and not self.rival:isFainted() then
    self.rival._ultronBlackout=nil
  end
  local world=self:worldView(); self:serviceTick(world)
  local ctx={playerMap=world.playerMap,playerParty=world.playerParty,playerBadges=world.playerBadges,compat=self.compat,rivals=self.rivals,tick=self.tick,companionId=nil,log=world.log,ecology=nil,allowGymBattle=true,gymBattleUsed=false,near=world.playerMap~=nil and self.rival.map==world.playerMap}
  ctx.physicalTravelTick=function(r,c) return self:physicalTravelTick(r,c) end
  ctx.physicalTrainerTick=function(r,foe,c) return self:physicalTrainerTick(r,foe,c) end
  local ok,res=pcall(self.modules.Simulation.tickRival,self.rival,ctx)
  if not ok and self.callbacks and self.callbacks.error then pcall(self.callbacks.error,tostring(res)) end
end

function Engine:overworldIdle()
  if self.pendingBattle then return false end
  local top=self.game and self.game.stack and self.game.stack.top and self.game.stack:top()
  if self.generation==1 then return top==nil or top.isOverworld==true end
  local w=self.game and self.game.world
  return w~=nil and not w.transitioning and not w.mapSetup and not w.textbox and not w.choicebox
end

function Engine:repairRivalPosition(rival,reason)
  if not rival then return false end
  -- Historical API retained for Atlas callers, but repair is now a pure replan.
  -- It never moves Ultron to a different coordinate.
  rival.localWalkGoal=nil; rival.path=nil; rival.walkTarget=nil; rival.route=nil
  rival.stuckTicks=(rival.stuckTicks or 0)+1
  return true
end

function Engine:spawnDiagnostics()
  local w=self:worldView(); local r=self.rival
  local positionReady=false; local positionError
  if r and r.map and r.map~="__ULTRON_STAGING__" then
    local g=PhysicalWorld.grid(self,r.map,r)
    if g then
      if r.x~=nil and r.y~=nil then positionReady=PhysicalWorld.walkable(g,r.x,r.y) else positionReady=r._ultronNeedsInitialPlacement==true end
    else positionError="no authoritative collision grid for "..tostring(r.map) end
  end
  return {playerMap=w.playerMap,ultronMap=r and r.map or nil,sameMap=r and w.playerMap==r.map or false,
    dormant=r and r._ultronDormant==true or false,live=self:liveEntity()~=nil,spawnPath=self.lastSpawnPath,
    spawnError=self.lastSpawnError,spawnAttemptMap=self.lastSpawnAttemptMap,positionReady=positionReady,positionError=positionError,
    hasWorldSpawn=self.mod.world and type(self.mod.world.spawnNpc)=="function" or false,
    hasRuntimeSpawn=(function() local ow=self:activeMap(); return (ow and type(ow.addRuntimeObject)=="function") or (self.game and self.game.world and (type(self.game.world.addRuntimeObject)=="function" or type(self.game.world.spawnNpc)=="function")) or false end)()}
end

function Engine:serializeRival() return self.rival and self.rival.serialize and self.rival:serialize() or nil end

return Engine
