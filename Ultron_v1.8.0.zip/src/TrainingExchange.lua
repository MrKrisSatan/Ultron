local Util = require("mods.ultron.src.Util")
local ClientFiles = require("mods.ultron.src.ClientFiles")
local Exchange = {}
local FORMAT = "ULTRON_TRAINING_V1"
local DEFAULT_FILE = "Ultron_training_data.txt"

local function esc(s)
  return (tostring(s or ""):gsub("([^A-Za-z0-9_%.:%-])", function(c)
    return string.format("%%%02X", string.byte(c))
  end))
end
local function unesc(s)
  return (tostring(s or ""):gsub("%%(%x%x)", function(h) return string.char(tonumber(h,16)) end))
end
local function split(line)
  local out = {}
  for part in (tostring(line or "").."|"):gmatch("(.-)|") do out[#out+1] = unesc(part) end
  return out
end
local function portableChecksum(s)
  local h = 2166136261
  for i=1,#s do h = (h + s:byte(i) * 16777619) % 4294967296; h = (h * 31 + 7) % 4294967296 end
  return string.format("%08x", h)
end

function Exchange.new(saved)
  saved = type(saved) == "table" and saved or {}
  return {
    storageVersion = 2,
    sourceId = saved.sourceId,
    imports = math.max(0, tonumber(saved.imports) or 0),
    sources = type(saved.sources) == "table" and saved.sources or {},
    species = type(saved.species) == "table" and saved.species or {},
    moves = type(saved.moves) == "table" and saved.moves or {},
    leads = type(saved.leads) == "table" and saved.leads or {},
    encounters = type(saved.encounters) == "table" and saved.encounters or {},
    playerLevels = type(saved.playerLevels) == "table" and saved.playerLevels or {},
    routes = type(saved.routes) == "table" and saved.routes or {},
    visits = type(saved.visits) == "table" and saved.visits or {},
    provenance = type(saved.provenance) == "table" and saved.provenance or {species={},moves={},leads={},visits={}},
  }
end

function Exchange.ensureSource(state, rival, manager, game)
  state = Exchange.new(state)
  if state.sourceId and state.sourceId ~= "" then return state end
  local seed = 1
  pcall(function() seed = tonumber(manager and manager:worldSeed()) or seed end)
  local save = game and game.save or {}
  local player = save.player or {}
  local tid = save.trainerId or save.trainerID or save.tid or player.trainerId or player.tid or "0"
  state.sourceId = "U" .. portableChecksum(tostring(seed)..":"..tostring(tid)..":"..tostring(rival and rival.def and rival.def.seed or 0))
  return state
end

local function rowsFromCounts(prefix, counts, rows, limit)
  local list = {}
  for id,n in pairs(type(counts)=="table" and counts or {}) do
    n=math.max(0,math.floor(tonumber(n) or 0)); if n>0 then list[#list+1]={id=id,n=n} end
  end
  table.sort(list,function(a,b) if a.n~=b.n then return a.n>b.n end return tostring(a.id)<tostring(b.id) end)
  for i=1,math.min(limit or #list,#list) do
    local r=list[i]; rows[#rows+1]=table.concat({prefix,esc(r.id),r.n},"|")
  end
end

function Exchange.encode(state, rival, atlas, manager, game)
  state = Exchange.ensureSource(state,rival,manager,game)
  local body = {FORMAT, "SOURCE|"..esc(state.sourceId)}
  local pm = rival and rival.memory and rival.memory.player or {}
  rowsFromCounts("SPECIES",pm.species,body,64)
  rowsFromCounts("MOVE",pm.moves,body,64)
  rowsFromCounts("LEAD",pm.leads,body,32)
  rowsFromCounts("VISIT",rival and rival.visitedMaps,body,96)
  rowsFromCounts("BLOCK",atlas and atlas.blocked,body,96)
  local known=rival and rival.knownOpponentParty and rival:knownOpponentParty("player") or {}
  for _,slot in ipairs(known or {}) do
    if slot.species and tonumber(slot.level) then body[#body+1]=table.concat({"PLAYERMON",esc(slot.species),math.floor(slot.level)} ,"|") end
  end
  for k,row in pairs(manager and manager.routeMemory and manager.routeMemory.transitions or {}) do
    if type(row)=="table" and (row.source=="player" or row.source=="shared") and row.exitX~=nil and row.exitY~=nil then
      local from,to=tostring(k):match("^(.-)>(.*)$")
      if from and to then body[#body+1]=table.concat({"ROUTE",esc(from),esc(to),row.exitX,row.exitY,row.entryX or "",row.entryY or "",math.max(1,tonumber(row.count) or 1)},"|") end
    end
  end
  local encounterRows={}
  for map,bySpecies in pairs((rival and rival.encounterHistory) or {}) do
    for species,e in pairs(type(bySpecies)=="table" and bySpecies or {}) do
      local seen=math.max(0,math.floor(tonumber(e and e.seen) or 0))
      local caught=math.max(0,math.floor(tonumber(e and e.caught) or 0))
      if seen>0 or caught>0 then encounterRows[#encounterRows+1]={map=map,species=species,seen=seen,caught=caught} end
    end
  end
  table.sort(encounterRows,function(a,b)
    local aa,bb=a.seen+a.caught*3,b.seen+b.caught*3
    if aa~=bb then return aa>bb end
    if tostring(a.map)~=tostring(b.map) then return tostring(a.map)<tostring(b.map) end
    return tostring(a.species)<tostring(b.species)
  end)
  for i=1,math.min(192,#encounterRows) do local r=encounterRows[i]
    body[#body+1]=table.concat({"ENCOUNTER",esc(r.map),esc(r.species),r.seen,r.caught},"|")
  end
  local raw=table.concat(body,"\n")
  return raw.."\nCHECK|"..portableChecksum(raw).."\n",state
end

local function bump(t,k,n)
  if type(k)~="string" or k=="" then return end
  t[k]=math.min(9999,(tonumber(t[k]) or 0)+math.max(0,tonumber(n) or 0))
end
local function trimCounts(t, limit)
  local rows={}; for k,n in pairs(t or {}) do rows[#rows+1]={k,n=tonumber(n) or 0} end
  table.sort(rows,function(a,b) if a.n~=b.n then return a.n>b.n end return tostring(a[1])<tostring(b[1]) end)
  for i=(limit or 128)+1,#rows do t[rows[i][1]]=nil end
end

function Exchange.decode(text)
  if type(text)~="string" then return nil,"not text" end
  local lines={}; for line in text:gmatch("[^\r\n]+") do lines[#lines+1]=line end
  if lines[1]~=FORMAT then return nil,"not Ultron training data" end
  local checkLine=lines[#lines]; local cp=split(checkLine)
  if cp[1]~="CHECK" or not cp[2] then return nil,"missing checksum" end
  local rawLines={}
  for i=1,#lines-1 do rawLines[#rawLines+1]=lines[i] end
  local raw=table.concat(rawLines,"\n")
  if portableChecksum(raw)~=cp[2] then return nil,"checksum mismatch" end
  local out={species={},moves={},leads={},visits={},blocked={},encounters={},playerLevels={},routes={}}
  for i=2,#lines-1 do
    local p=split(lines[i]); local kind=p[1]
    if kind=="SOURCE" then out.source=p[2]
    elseif kind=="SPECIES" then bump(out.species,p[2],p[3])
    elseif kind=="MOVE" then bump(out.moves,p[2],p[3])
    elseif kind=="LEAD" then bump(out.leads,p[2],p[3])
    elseif kind=="VISIT" then bump(out.visits,p[2],p[3])
    elseif kind=="BLOCK" then bump(out.blocked,p[2],p[3])
    elseif kind=="PLAYERMON" and p[2] then
      local level=math.max(1,math.min(100,math.floor(tonumber(p[3]) or 1)))
      local row=out.playerLevels[p[2]] or {level=0,count=0}; row.level=math.max(row.level,level); row.count=row.count+1; out.playerLevels[p[2]]=row
    elseif kind=="ROUTE" and p[2] and p[3] then
      out.routes[p[2]..">"..p[3]]={from=p[2],to=p[3],exitX=tonumber(p[4]),exitY=tonumber(p[5]),entryX=tonumber(p[6]),entryY=tonumber(p[7]),count=math.max(1,tonumber(p[8]) or 1),source="shared"}
    elseif kind=="ENCOUNTER" and p[2] and p[3] then
      out.encounters[p[2]]=out.encounters[p[2]] or {}
      local e=out.encounters[p[2]][p[3]] or {seen=0,caught=0}; out.encounters[p[2]][p[3]]=e
      e.seen=math.min(9999,e.seen+math.max(0,tonumber(p[4]) or 0)); e.caught=math.min(9999,e.caught+math.max(0,tonumber(p[5]) or 0))
    end
  end
  if not out.source or out.source=="" then return nil,"missing source id" end
  out.checksum=cp[2]
  return out
end

local function ensureProvenance(state)
  state.provenance=type(state.provenance)=="table" and state.provenance or {}
  for _,kind in ipairs({"species","moves","leads","visits"}) do
    state.provenance[kind]=type(state.provenance[kind])=="table" and state.provenance[kind] or {}
  end
end

local function markSource(state,kind,counts)
  ensureProvenance(state)
  local dst=state.provenance[kind]
  for id,n in pairs(type(counts)=="table" and counts or {}) do
    if (tonumber(n) or 0)>0 then dst[id]=math.min(9999,(tonumber(dst[id]) or 0)+1) end
  end
end

function Exchange.merge(state, pack, rival, atlas)
  state=Exchange.new(state)
  if type(pack)~="table" or not pack.source then return state,atlas,false,"invalid training package" end
  if pack.source==state.sourceId then return state,atlas,false,"That file was exported by this Ultron." end
  if state.sources[pack.source] then return state,atlas,false,"Training from that Ultron has already been imported." end
  state.imports=state.imports+1
  state.sources[pack.source]=pack.checksum or true
  markSource(state,"species",pack.species); markSource(state,"moves",pack.moves); markSource(state,"leads",pack.leads); markSource(state,"visits",pack.visits)
  for k,n in pairs(pack.species or {}) do bump(state.species,k,n) end
  for k,n in pairs(pack.moves or {}) do bump(state.moves,k,n) end
  for k,n in pairs(pack.leads or {}) do bump(state.leads,k,n) end
  for k,n in pairs(pack.visits or {}) do bump(state.visits,k,n) end
  for species,row in pairs(pack.playerLevels or {}) do
    local dst=state.playerLevels[species] or {level=0,count=0}
    dst.level=math.max(tonumber(dst.level) or 0,tonumber(row.level) or 0); dst.count=math.min(9999,(tonumber(dst.count) or 0)+(tonumber(row.count) or 0)); state.playerLevels[species]=dst
  end
  for k,row in pairs(pack.routes or {}) do
    local dst=state.routes[k]
    if not dst or (tonumber(row.count) or 0)>(tonumber(dst.count) or 0) then state.routes[k]=Util.copy(row) end
  end
  trimCounts(state.species,128); trimCounts(state.moves,128); trimCounts(state.leads,64); trimCounts(state.visits,128)

  if rival then
    rival.visitedMaps=rival.visitedMaps or {}
    for map,n in pairs(pack.visits or {}) do
      rival.visitedMaps[map]=math.max(tonumber(rival.visitedMaps[map]) or 0,math.min(8,tonumber(n) or 0))
    end
    rival.encounterHistory=rival.encounterHistory or {}
    for map,bySpecies in pairs(pack.encounters or {}) do
      rival.encounterHistory[map]=rival.encounterHistory[map] or {}
      for species,e in pairs(bySpecies) do
        local dst=rival.encounterHistory[map][species] or {seen=0,caught=0}; rival.encounterHistory[map][species]=dst
        dst.seen=math.min(9999,(tonumber(dst.seen) or 0)+(tonumber(e.seen) or 0))
        dst.caught=math.min(9999,(tonumber(dst.caught) or 0)+(tonumber(e.caught) or 0))
      end
    end
  end
  atlas=type(atlas)=="table" and atlas or {}
  atlas.blocked=type(atlas.blocked)=="table" and atlas.blocked or {}
  for k,n in pairs(pack.blocked or {}) do atlas.blocked[k]=math.max(tonumber(atlas.blocked[k]) or 0,tonumber(n) or 0) end
  return state,atlas,true,"Imported training from another Ultron. Collective sources: "..tostring(state.imports).."."
end

function Exchange.sourceCount(state)
  state=Exchange.new(state); local n=0; for _ in pairs(state.sources or {}) do n=n+1 end; return n
end

function Exchange.confidence(state,kind,id)
  state=Exchange.new(state); ensureProvenance(state)
  local counts=state[kind] or {}
  local sources=state.provenance[kind] or {}
  local observations=math.max(0,tonumber(counts[id]) or 0)
  local sourceN=math.max(0,tonumber(sources[id]) or 0)
  local obsScore=observations>0 and math.min(40,math.floor((math.log(observations+1)/math.log(2))*7)) or 0
  local score=math.min(100,sourceN*18+obsScore)
  return score,sourceN,observations
end

function Exchange.collectiveParty(state, data, maxSlots)
  state=Exchange.new(state); local rows={}
  for species,n in pairs(state.species or {}) do
    local exists=(data and data.gen2Pokemon and data.gen2Pokemon[species]) or (data and data.pokemon and data.pokemon[species])
    if exists then
      local confidence,sources=Exchange.confidence(state,"species",species)
      rows[#rows+1]={species=species,n=tonumber(n) or 0,confidence=confidence,sources=sources}
    end
  end
  table.sort(rows,function(a,b)
    if a.confidence~=b.confidence then return a.confidence>b.confidence end
    if a.n~=b.n then return a.n>b.n end
    return a.species<b.species
  end)
  local out={}; for i=1,math.min(maxSlots or 6,#rows) do
    out[#out+1]={species=rows[i].species,level=100,moves={},collectiveConfidence=rows[i].confidence,collectiveSources=rows[i].sources}
  end
  return out
end

function Exchange.summary(state)
  state=Exchange.new(state)
  local rows={}
  for species,n in pairs(state.species or {}) do
    local confidence,sources=Exchange.confidence(state,"species",species)
    rows[#rows+1]={species=species,n=tonumber(n) or 0,confidence=confidence,sources=sources}
  end
  table.sort(rows,function(a,b) if a.confidence~=b.confidence then return a.confidence>b.confidence end if a.n~=b.n then return a.n>b.n end return a.species<b.species end)
  local lines={"COLLECTIVE SOURCES: "..tostring(Exchange.sourceCount(state)),"IMPORTS: "..tostring(state.imports)}
  for i=1,math.min(3,#rows) do local r=rows[i]; lines[#lines+1]=tostring(r.species):gsub("_"," ")..": "..tostring(r.confidence).."% confidence from "..tostring(r.sources).." source(s)" end
  if #rows==0 then lines[#lines+1]="No shared species evidence imported yet." end
  return table.concat(lines,"\n")
end

local function importText(state,rival,atlas,manager,game,text)
  state=Exchange.ensureSource(state,rival,manager,game)
  local pack,why=Exchange.decode(text)
  if not pack then return state,atlas,false,"Import failed: "..tostring(why) end
  return Exchange.merge(state,pack,rival,atlas)
end

-- Opens the game/client file picker. On desktop this is synchronous. On
-- Android/iOS the engine-owned native picker resumes asynchronously and
-- pollImport() consumes its selected document from the user-data staging area.
-- Imported knowledge is merged into mod.save by main.lua, so updating/replacing
-- the mod directory cannot overwrite the learned collective data.
function Exchange.importFile(state,rival,atlas,manager,game)
  state=Exchange.ensureSource(state,rival,manager,game)
  local osName=ClientFiles.osName()
  if osName=="Android" or osName=="iOS" then
    local ok,why=ClientFiles.beginMobileImport()
    if not ok then return state,atlas,false,"Import failed: "..tostring(why),false end
    return state,atlas,false,"Choose an Ultron training-data file in the system picker.",true
  end
  local path=ClientFiles.chooseOpen("Import Ultron Training Data",{"txt"},"Ultron training data")
  if not path then return state,atlas,false,"Import cancelled.",false end
  local text,err=ClientFiles.readExternal(path)
  if not text then return state,atlas,false,"Import failed: "..tostring(err),false end
  local ns,na,ok,msg=importText(state,rival,atlas,manager,game,text)
  return ns,na,ok,msg,false
end

function Exchange.pollImport(state,rival,atlas,manager,game)
  local status,payload=ClientFiles.pollMobileImport()
  if not status then return state,atlas,nil,nil end
  if status~="picked" then return state,atlas,false,tostring(payload or "Import cancelled.") end
  return importText(state,rival,atlas,manager,game,payload)
end

-- Export uses a Save-As dialog on desktop so the user chooses the exact
-- destination. No release/update file is written into mods/ultron. If a mobile
-- client does not expose a writable document/save picker, fail clearly rather
-- than pretending that a fixed sandbox path satisfies a user-selected export.
function Exchange.exportFile(state,rival,atlas,manager,game)
  local text,newState=Exchange.encode(state,rival,atlas,manager,game)
  local path=ClientFiles.chooseSave("Export Ultron Training Data",DEFAULT_FILE,"Ultron training data")
  if not path then
    local osName=ClientFiles.osName()
    if osName=="Android" or osName=="iOS" then
      return newState,false,"Export needs a client Save-As picker. This mobile Gen1Recomp build does not expose one yet; no file was written into the mod directory."
    end
    return newState,false,"Export cancelled or no client Save-As dialog is available."
  end
  local ok,err=ClientFiles.writeExternal(path,text)
  if not ok then return newState,false,"Export failed: "..tostring(err) end
  return newState,true,"Exported Ultron training data to your chosen location: "..tostring(path)
end

function Exchange.storageDescription() return ClientFiles.storageDescription() end
Exchange.DEFAULT_FILE=DEFAULT_FILE
return Exchange
