local Util = require("mods.ultron.src.Util")
local RouteMemory = {}

local function copy(v) return type(v)=="table" and Util.copy(v) or {} end
local function key(map,sx,sy,tx,ty)
  return table.concat({tostring(map or "?"),math.floor(tonumber(sx) or -1),math.floor(tonumber(sy) or -1),math.floor(tonumber(tx) or -1),math.floor(tonumber(ty) or -1)},":")
end
local function tkey(from,to) return tostring(from or "?")..">"..tostring(to or "?") end

function RouteMemory.new(saved)
  saved=type(saved)=="table" and saved or {}
  return {version=2,paths=copy(saved.paths),transitions=copy(saved.transitions),maps=copy(saved.maps),playerLast=copy(saved.playerLast),playerTrails=copy(saved.playerTrails),learned=math.max(0,tonumber(saved.learned) or 0),uses=math.max(0,tonumber(saved.uses) or 0)}
end

local function trim(state)
  local rows={}
  for k,v in pairs(state.paths or {}) do rows[#rows+1]={k=k,t=tonumber(v.lastTick) or 0} end
  if #rows<=128 then return end
  table.sort(rows,function(a,b) return a.t<b.t end)
  for i=1,#rows-128 do state.paths[rows[i].k]=nil end
end

function RouteMemory.rememberPath(saved,map,sx,sy,tx,ty,path,tick)
  local state=RouteMemory.new(saved)
  if type(path)~="table" or #path==0 then return state end
  local steps={}
  for i=1,math.min(#path,160) do local p=path[i]; if p and p.x~=nil and p.y~=nil then steps[#steps+1]={x=p.x,y=p.y,dir=p.dir} end end
  if #steps==0 then return state end
  local k=key(map,sx,sy,tx,ty); local existing=state.paths[k]
  if not existing then state.learned=state.learned+1 end
  state.paths[k]={map=map,sx=sx,sy=sy,tx=tx,ty=ty,steps=steps,lastTick=tonumber(tick) or 0,uses=existing and (tonumber(existing.uses) or 0) or 0}
  local m=state.maps[tostring(map or "?")] or {learnedPaths=0,steps=0}
  if not existing then m.learnedPaths=(tonumber(m.learnedPaths) or 0)+1 end
  m.steps=(tonumber(m.steps) or 0)+#steps; m.lastTick=tonumber(tick) or 0; state.maps[tostring(map or "?")]=m
  trim(state); return state
end

function RouteMemory.path(saved,map,sx,sy,tx,ty,walkable,blocked)
  local state=RouteMemory.new(saved); local row=state.paths[key(map,sx,sy,tx,ty)]
  if not(row and type(row.steps)=="table" and #row.steps>0) then return state,nil end
  local px,py=sx,sy
  for _,p in ipairs(row.steps) do
    if math.abs((tonumber(p.x) or -999)-px)+math.abs((tonumber(p.y) or -999)-py)~=1 then return state,nil end
    if walkable and not walkable(p.x,p.y) then return state,nil end
    if blocked and blocked[tostring(p.x)..","..tostring(p.y)] then return state,nil end
    px,py=p.x,p.y
  end
  row.uses=(tonumber(row.uses) or 0)+1; state.uses=state.uses+1
  return state,Util.copy(row.steps)
end

function RouteMemory.transition(saved,from,to,exitX,exitY,entryX,entryY,tick,source,confidence)
  local state=RouteMemory.new(saved); local k=tkey(from,to); local row=state.transitions[k] or {count=0}
  source=source or row.source or "self"
  row.count=(tonumber(row.count) or 0)+1; row.exitX=exitX; row.exitY=exitY; row.entryX=entryX; row.entryY=entryY; row.lastTick=tonumber(tick) or 0
  row.sources=type(row.sources)=="table" and row.sources or {}; row.sources[source]=(tonumber(row.sources[source]) or 0)+1
  if source=="player" or not row.source or row.source=="shared" then row.source=source end
  local base=tonumber(confidence) or (source=="player" and 0.92 or source=="shared" and 0.65 or 0.85)
  if base>1 then base=base/100 end
  row.confidence=math.min(0.99,math.max(tonumber(row.confidence) or 0,base)+math.min(0.06,(row.count-1)*0.01))
  state.transitions[k]=row
  return state
end

function RouteMemory.observePlayer(saved,map,x,y,tick)
  local state=RouteMemory.new(saved); x,y=tonumber(x),tonumber(y)
  if not(map and x and y) then return state,nil end
  x,y=math.floor(x),math.floor(y); local last=state.playerLast
  local event
  local age=(tonumber(tick) or 0)-(tonumber(last.tick) or 0)
  if last.map and last.map~=map and last.x~=nil and last.y~=nil and age>=0 and age<=20 then
    state=RouteMemory.transition(state,last.map,map,last.x,last.y,x,y,tick,"player")
    event={kind="player_route_learned",from=last.map,to=map,confidence=92}
  end
  local trail=state.playerTrails[map] or {}
  local tail=trail[#trail]
  if not tail or tail.x~=x or tail.y~=y then
    if not tail or math.abs(tail.x-x)+math.abs(tail.y-y)<=1 then trail[#trail+1]={x=x,y=y,tick=tonumber(tick) or 0}
    else trail={{x=x,y=y,tick=tonumber(tick) or 0}} end
    while #trail>96 do table.remove(trail,1) end
    state.playerTrails[map]=trail
  end
  state.playerLast={map=map,x=x,y=y,tick=tonumber(tick) or 0}
  return state,event
end

function RouteMemory.playerExit(saved,map)
  local state=RouteMemory.new(saved); local best
  for k,row in pairs(state.transitions) do
    local from,to=tostring(k):match("^(.-)>(.*)$")
    if from==tostring(map) and row and row.exitX~=nil and row.exitY~=nil and (row.source=="player" or row.source=="shared") then
      local confidence=tonumber(row.confidence) or (row.source=="player" and 0.92 or 0.65)
      local bestConfidence=best and (tonumber(best.confidence) or (best.source=="player" and 0.92 or 0.65)) or -1
      if not best or confidence>bestConfidence or (confidence==bestConfidence and (tonumber(row.lastTick) or 0)>(tonumber(best.lastTick) or 0)) then best=copy(row); best.from=from; best.to=to end
    end
  end
  return state,best
end

function RouteMemory.summary(saved)
  local state=RouteMemory.new(saved); local maps=0; for _ in pairs(state.maps or {}) do maps=maps+1 end
  local transitions=0; for _ in pairs(state.transitions or {}) do transitions=transitions+1 end
  return table.concat({"LEARNED LOCAL PATHS: "..tostring(state.learned),"REMEMBERED TRANSITIONS: "..tostring(transitions),"MAPS WITH ROUTE MEMORY: "..tostring(maps),"LEARNED PATH REUSES: "..tostring(state.uses)},"\n")
end
return RouteMemory
