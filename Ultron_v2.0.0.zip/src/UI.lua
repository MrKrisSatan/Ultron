local UI={}

-- Gen1Recomp's ListMenu:close() only pops when that menu is actually the
-- current stack top. Keep every transition close-then-push. The old v1.3.0
-- UI.open() also popped the stack unconditionally because it assumed it was
-- always replacing the game's Start menu. Returning from a child page meant
-- the child had already popped, so that extra pop could remove OverworldState
-- itself and leave the game on a white screen.
local function closeStart(game)
  local s=game and game.stack
  if s and type(s.pop)=="function" then pcall(s.pop,s) end
end
local function closeMenu(m)
  if m and type(m.close)=="function" then pcall(m.close,m) end
end
local function push(menu,game)
  if not(menu and game and game.stack and type(game.stack.push)=="function") then return false end
  game.stack:push(menu); return true
end

local function pushText(mod,game,text,onDone)
  text=tostring(text or "")
  -- Prefer TextBox when available because its completion callback lets nested
  -- Ultron pages return to their parent without manipulating the stack early.
  if mod and mod.ui and mod.ui.TextBox and type(mod.ui.TextBox.new)=="function" and game and game.stack then
    local ok,b=pcall(mod.ui.TextBox.new,game,text,onDone)
    if ok and b then game.stack:push(b); return true end
  end
  -- Older/alternate hosts expose only overworld showText. It is safe, but has
  -- no portable completion callback, so closing it returns to the overworld.
  local world
  pcall(function() world=mod.world and mod.world.overworld and mod.world:overworld() end)
  if world and type(world.showText)=="function" then
    local ok=pcall(world.showText,world,text)
    if ok then return true end
  end
  return false
end

local function speciesLabel(slot)
  if type(slot)~="table" then return "?" end
  local species=tostring(slot.species or "?"):gsub("_"," ")
  local nick=tostring(slot.nickname or ""):gsub("^%s+",""):gsub("%s+$","")
  if nick~="" and nick:upper()~=species:upper() then return nick.." ("..species..")" end
  return nick~="" and nick or species
end
local function partyText(r)
  local out={}
  for i,m in ipairs(r and r.party or {}) do
    local bond=tonumber(m.attachment) or 0
    local suffix=m.ultronNicknamed and " *" or ""
    if bond>=60 then suffix=suffix.." [bond "..tostring(math.floor(bond)).."]" end
    out[#out+1]=string.format("%d. %s Lv%d%s",i,speciesLabel(m),tonumber(m.level) or 0,suffix)
  end
  return #out>0 and table.concat(out,"\n") or "Ultron has no active Pokemon yet."
end

local function reopenRoot(mod,game,ctx)
  return function() UI.open(mod,game,ctx) end
end
local function reopenStart(mod,game,ctx)
  return function() UI.openStart(mod,game,ctx,{resume=true}) end
end

function UI.openRoster(mod,game,ctx,opts)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  opts=type(opts)=="table" and opts or {}; local back=opts.back or reopenStart(mod,game,ctx); local rows={}
  for _,agent in ipairs(ctx.agents and ctx.agents() or {}) do rows[#rows+1]={label=tostring(agent.name or agent.id):upper(),right=tostring(agent.map or "PENDING"):gsub("_"," "),value=tostring(agent.id)} end
  rows[#rows+1]={label="BACK",value="back"}
  local menu; menu=mod.ui.ListMenu.new(game,"ROBOT RIVALS",rows,{onChoose=function(item,m)
    if not item then return end
    if item.value=="back" then closeMenu(m); back(); return end
    if ctx.selectAgent then ctx.selectAgent(item.value) end; closeMenu(m); UI.open(mod,game,ctx)
  end,onCancel=function() back() end})
  return push(menu,game)
end

function UI.openAgentCount(mod,game,onChoose)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  local rows={}; for i=1,4 do rows[#rows+1]={label=tostring(i)..(i==1 and " ROBOT" or " ROBOTS"),value=i} end
  local menu; menu=mod.ui.ListMenu.new(game,"NUMBER OF ROBOT RIVALS",rows,{onChoose=function(item,m)
    if not item then return end; closeMenu(m); if onChoose then onChoose(math.max(1,math.min(4,tonumber(item.value) or 1))) end
  end,onCancel=function() if onChoose then onChoose(1) end end})
  return push(menu,game)
end

function UI.openSettings(mod,game,ctx,opts)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  opts=type(opts)=="table" and opts or {}
  local back=opts.back or reopenRoot(mod,game,ctx)
  local rows={}
  for _,row in ipairs(ctx.settingsRows and ctx.settingsRows() or {}) do
    rows[#rows+1]={label=row.label,right=row.value and "ON" or "OFF",value="setting:"..tostring(row.key)}
  end
  rows[#rows+1]={label="BACK",value="back"}
  local menu
  menu=mod.ui.ListMenu.new(game,"ULTRON SETTINGS",rows,{
    onChoose=function(item,m)
      if not item then return end
      local v=tostring(item.value or "")
      if v=="back" then closeMenu(m); back(); return end
      local key=v:match("^setting:(.+)$")
      if key and ctx.toggleSetting then
        ctx.toggleSetting(key)
        -- Refresh values by rebuilding only this menu. Parent is already gone;
        -- do not touch any other stack screen.
        closeMenu(m)
        UI.openSettings(mod,game,ctx,{back=back})
      end
    end,
    -- ListMenu pops itself before onCancel on current Gen1Recomp builds.
    onCancel=function() back() end,
  })
  return push(menu,game)
end

function UI.openTraining(mod,game,ctx,opts)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  opts=type(opts)=="table" and opts or {}
  local back=opts.back or reopenRoot(mod,game,ctx)
  local rows={{label="IMPORT DATA",value="import"},{label="EXPORT DATA",value="export"},{label="TRAINING SOURCES",value="training"},{label="BACK",value="back"}}
  local menu
  menu=mod.ui.ListMenu.new(game,"ULTRON TRAINING DATA",rows,{
    onChoose=function(item,m)
      if not item then return end
      local v=item.value
      if v=="back" then closeMenu(m); back(); return end
      closeMenu(m)
      if v=="import" and ctx.import then ctx.import()
      elseif v=="export" and ctx.export then ctx.export()
      elseif v=="training" then
        pushText(mod,game,ctx.training and ctx.training() or "Collective training data unavailable.",back)
      end
    end,
    onCancel=function() back() end,
  })
  return push(menu,game)
end

function UI.open(mod,game,ctx,opts)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  opts=type(opts)=="table" and opts or {}
  local r=ctx.engine and ctx.engine.rival
  local rows={}
  if r then
    -- Keep the immediate battle action at the top. Colosseum UI intentionally
    -- renders short hanging ListMenu viewports, so core actions must not depend
    -- on scrolling through status-only rows.
    rows[#rows+1]={label="BATTLE ME NOW",value="battle_now"}
    rows[#rows+1]={label="LOCATION",right=tostring(r.map or "PENDING"):gsub("_"," "),value="line"}
    rows[#rows+1]={label="BADGES",right=tostring(ctx.badges and ctx.badges() or 0),value="line"}
    rows[#rows+1]={label="DRIVE",right=tostring(math.floor(ctx.drive and ctx.drive() or 0)).."/100",value="line"}
    rows[#rows+1]={label="MONEY",right="P"..tostring(math.floor(tonumber(r.money) or 0)),value="line"}
    rows[#rows+1]={label="PARTY",value="party"}
    if ctx.bonds then rows[#rows+1]={label="PARTNER BONDS",value="bonds"} end
  else
    rows[#rows+1]={label="STATUS",right="NOT ACTIVE",value="line"}
  end
  rows[#rows+1]={label="SETTINGS",value="settings"}
  rows[#rows+1]={label="LOCATION / DIAGNOSTICS",value="diagnostics"}
  if r then
    rows[#rows+1]={label="RIVALRY / LEGACY",value="career"}
    if ctx.chronicle then rows[#rows+1]={label="PARTNER CHRONICLE",value="chronicle"} end
    if ctx.hallOfFame then rows[#rows+1]={label="HALL OF FAME",value="hall"} end
    rows[#rows+1]={label="ACHIEVEMENTS",value="achievements"}
    rows[#rows+1]={label="THOUGHTS",value="thoughts"}
    rows[#rows+1]={label="KNOWLEDGE",value="knowledge"}
    rows[#rows+1]={label="JOURNEY INTEL",value="journey"}
    rows[#rows+1]={label="TRAINING DATA",value="training_menu"}
    rows[#rows+1]={label="LATEST UPDATE",value="news"}
    rows[#rows+1]={label="MESSAGE",value="chat"}
  end
  rows[#rows+1]={label="INTEGRITY",value="integrity"}
  rows[#rows+1]={label="CLOSE",value="close"}
  local menu
  local back=reopenRoot(mod,game,ctx)
  menu=mod.ui.ListMenu.new(game,tostring(r and r.name or "ULTRON"):upper(),rows,{
    onChoose=function(item,m)
      if not item then return end
      local v=item.value
      if v=="close" then closeMenu(m); if opts.onClose then opts.onClose() end; return end
      if v=="line" then return end
      closeMenu(m)
      if v=="party" then pushText(mod,game,partyText(r),back)
      elseif v=="battle_now" then
        local ok,msg=false,"Ultron cannot battle right now."
        if ctx.battle then ok,msg=ctx.battle() end
        if not ok then pushText(mod,game,msg or "Ultron cannot battle right now.",back) end
      elseif v=="bonds" then pushText(mod,game,ctx.bonds and ctx.bonds() or "Partner bond data unavailable.",back)
      elseif v=="settings" then UI.openSettings(mod,game,ctx,{back=back})
      elseif v=="diagnostics" then pushText(mod,game,ctx.diagnostics and ctx.diagnostics() or "Ultron diagnostics unavailable.",back)
      elseif v=="career" then pushText(mod,game,ctx.career and ctx.career() or "Rivalry history unavailable.",back)
      elseif v=="chronicle" then pushText(mod,game,ctx.chronicle and ctx.chronicle() or "Partner chronicle unavailable.",back)
      elseif v=="hall" then pushText(mod,game,ctx.hallOfFame and ctx.hallOfFame() or "Hall of Fame unavailable.",back)
      elseif v=="achievements" then pushText(mod,game,ctx.achievements and ctx.achievements() or "Achievements unavailable.",back)
      elseif v=="thoughts" then pushText(mod,game,ctx.thoughts and ctx.thoughts() or "Ultron thoughts unavailable.",back)
      elseif v=="knowledge" then pushText(mod,game,ctx.knowledge and ctx.knowledge() or "Ultron knowledge unavailable.",back)
      elseif v=="journey" then pushText(mod,game,ctx.journey and ctx.journey() or "Journey intelligence unavailable.",back)
      elseif v=="training_menu" then UI.openTraining(mod,game,ctx,{back=back})
      elseif v=="news" then pushText(mod,game,tostring(r and r.name or "Ultron")..": "..tostring(ctx.latest and ctx.latest() or "No update."),back)
      elseif v=="chat" and ctx.chat then ctx.chat()
      elseif v=="integrity" then pushText(mod,game,ctx.integrity and ctx.integrity() or "Integrity status unavailable.",back) end
    end,
    onCancel=function() if opts.onClose then opts.onClose() end end,
  })
  return push(menu,game)
end

function UI.openStart(mod,game,ctx,opts)
  if not(mod and mod.ui and mod.ui.ListMenu and game and game.stack) then return false end
  opts=type(opts)=="table" and opts or {}
  -- Only the first entry comes from the game's Start menu. Child pages return
  -- with resume=true and MUST NOT pop the overworld a second time.
  if not opts.resume then closeStart(game) end
  local rows={
    {label="ROBOT RIVALS",value="roster"},{label="RELATIONSHIP NETWORK",value="relationships"},{label="STATUS / PARTY",value="full"},{label="THOUGHTS",value="thoughts"},{label="KNOWLEDGE",value="knowledge"},{label="PARTNER LEGACY",value="bonds"},{label="PARTNER CHRONICLE",value="chronicle"},{label="HALL OF FAME",value="hall"},{label="SETTINGS",value="settings"},{label="IMPORT TRAINING DATA",value="import"},{label="EXPORT TRAINING DATA",value="export"},
    {label="MESSAGE ULTRON",value="chat"},{label="LATEST UPDATE",value="news"},{label="ACHIEVEMENTS",value="achievements"},{label="CLOSE",value="close"},
  }
  local menu
  local back=reopenStart(mod,game,ctx)
  menu=mod.ui.ListMenu.new(game,"ULTRON",rows,{
    onChoose=function(item,m)
      if not item then return end
      local v=item.value
      if v=="close" then closeMenu(m); return end
      closeMenu(m)
      if v=="roster" then UI.openRoster(mod,game,ctx,{back=back})
      elseif v=="relationships" then pushText(mod,game,ctx.relationships and ctx.relationships() or "Relationship data unavailable.",back)
      elseif v=="full" then UI.open(mod,game,ctx)
      elseif v=="thoughts" then pushText(mod,game,ctx.thoughts and ctx.thoughts() or "Ultron thoughts unavailable.",back)
      elseif v=="knowledge" then pushText(mod,game,ctx.knowledge and ctx.knowledge() or "Ultron knowledge unavailable.",back)
      elseif v=="bonds" then pushText(mod,game,ctx.bonds and ctx.bonds() or "Partner legacy unavailable.",back)
      elseif v=="chronicle" then pushText(mod,game,ctx.chronicle and ctx.chronicle() or "Partner chronicle unavailable.",back)
      elseif v=="hall" then pushText(mod,game,ctx.hallOfFame and ctx.hallOfFame() or "Hall of Fame unavailable.",back)
      elseif v=="settings" then UI.openSettings(mod,game,ctx,{back=back})
      elseif v=="import" and ctx.import then ctx.import()
      elseif v=="export" and ctx.export then ctx.export()
      elseif v=="chat" and ctx.chat then ctx.chat()
      elseif v=="news" then pushText(mod,game,"Ultron: "..tostring(ctx.latest and ctx.latest() or "No update."),back)
      elseif v=="achievements" then pushText(mod,game,ctx.achievements and ctx.achievements() or "Achievements unavailable.",back) end
    end,
  })
  return push(menu,game)
end

function UI.installStartMenu(mod,ctx)
  if not(mod and mod.hooks and mod.hooks.wrap) then return false end
  mod.hooks:wrap("ui.start_menu.items",function(next,game,items)
    local out=next(game,items)
    if type(out)~="table" then return out end
    for _,it in ipairs(out) do if type(it)=="table" and it._ultronMenu then return out end end
    local row={label="ULTRON",desc={"Status / settings","Import / export data"},_ultronMenu=true,onSelect=function(selected) UI.openStart(mod,selected or game,ctx) end}
    local at=#out+1
    for i,it in ipairs(out) do if type(it)=="table" and (it.label=="SAVE" or it.label=="OPTION") then at=i; break end end
    table.insert(out,at,row)
    return out
  end)
  return true
end

UI.say=pushText
UI._closeStart=closeStart
return UI
