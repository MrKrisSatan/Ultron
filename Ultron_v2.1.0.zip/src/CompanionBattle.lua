local CompanionBattle={}

local SPREAD_FOES={SURF=true,BLIZZARD=true,ROCK_SLIDE=true}
local SPREAD_OTHERS={EARTHQUAKE=true,EXPLOSION=true,SELFDESTRUCT=true}

local function alive(b) return b and b.mon and (tonumber(b.mon.hp) or 0)>0 end
local function moveId(row) return type(row)=="table" and (row.id or row.move) or row end
local function healthFraction(b)
  if not alive(b) then return 0 end
  local max=(b.curStats and b.curStats.hp) or (b.mon.stats and b.mon.stats.hp) or b.mon.maxHp or 1
  return (tonumber(b.mon.hp) or 0)/math.max(1,tonumber(max) or 1)
end

local Controller={}; Controller.__index=Controller

function Controller:buildMon(game,slot)
  local Pokemon=require("src.pokemon.Pokemon")
  local opts={moves=slot.moves,dvs=slot.dvs,item=slot.heldItem or slot.item,
    shiny=slot.shiny==true,nickname=slot.nickname}
  local mon=Pokemon.new(game.data,slot.species or slot.speciesId,
    math.max(1,math.min(100,math.floor(tonumber(slot.level) or 5))),opts)
  local max=(mon.stats and mon.stats.hp) or mon.maxHp or mon.hp
  mon.hp=math.max(0,math.min(tonumber(max) or 1,
    tonumber(slot.hp) or tonumber(max) or 1))
  self.slotByMon[mon]=slot; self.used[slot]=true
  self.owner.party[#self.owner.party+1]=mon
  return mon,self.owner
end

function Controller:firstMon(game)
  self.game=game; self.used={}; self.slotByMon={}; self.owner={party={}}
  for _,slot in ipairs(self.rival.party or {}) do
    local hp=tonumber(slot.hp)
    if hp==nil and self.rival.maxHpOf then hp=self.rival:maxHpOf(slot) end
    if (hp or 0)>0 then return self:buildMon(game,slot) end
  end
end

function Controller:nextMon()
  for _,slot in ipairs(self.rival.party or {}) do
    local hp=tonumber(slot.hp)
    if hp==nil and self.rival.maxHpOf then hp=self.rival:maxHpOf(slot) end
    if not self.used[slot] and (hp or 0)>0 then return self:buildMon(self.game,slot) end
  end
end

function Controller:syncBattler(b)
  local mon=b and b.mon; local slot=mon and self.slotByMon[mon]
  if slot then slot.hp=math.max(0,math.floor(tonumber(mon.hp) or 0)) end
end

function Controller:onFaint(_,b) self:syncBattler(b) end

local function targetScore(target)
  if not alive(target) then return -100000 end
  return (1-healthFraction(target))*60
end

local BALL_ORDER={"MASTER_BALL","ULTRA_BALL","GREAT_BALL","POKE_BALL","SAFARI_BALL"}

function Controller:availableBall()
  if not (self.rival and self.rival.itemCount) then return nil end
  for _,ball in ipairs(BALL_ORDER) do
    if self.rival:itemCount(ball)>0 then return ball end
  end
end

-- A companion may only throw once a doubles encounter has collapsed to one
-- living wild target.  This keeps the absorbed doubles rule (no unaimed ball
-- with two targets) and makes the ball belong to the companion, not the
-- player's Bag.
function Controller:catchAction(battle,targets)
  if battle.kind~="wild" or #targets~=1 or battle.ghost or battle.noCatch then return nil end
  local ball=self:availableBall()
  if not ball then return nil end
  return {ultronCatch=true,ball=ball},targets[1]
end

function Controller:attemptCatch(battle,target,ball)
  if not (alive(target) and self.rival:takeItem(ball)) then return false end
  local Strings=require("src.core.Strings")
  local Runtime=require("src.mods.Runtime")
  local item=battle.data.items and battle.data.items[ball]
  battle:sayNext(Strings("%s used\n%s!",self.rival.name,
    item and item.name or ball:gsub("_"," ")))
  pcall(function() require("src.core.Sound").play(battle.data,"Ball_Toss") end)

  -- catchAttempt reads battle.enemy.  Borrow that slot only for the normal
  -- generation-specific calculation, then put the doubles layout back.
  local lead=battle.enemy
  battle.enemy=target
  local ok,caught,shakes=pcall(battle.catchAttempt,battle,ball)
  battle.enemy=lead
  if not ok then return false end
  battle.lastBall=ball
  Runtime.emit("battle.ball_thrown",{battle=battle,ball=ball,caught=caught,
    shakes=shakes,trainer=self.rival,companion=true})
  if battle.ballChain and battle.tossAnimFor then
    battle:ballChain(battle:tossAnimFor(ball),caught,shakes,ball)
  end
  if not caught then
    if battle.ballMissMessage then battle:sayNext(battle:ballMissMessage(shakes))
    else battle:sayNext(Strings("The POKéMON\nbroke free!")) end
    return false
  end

  battle:sayNext(Strings("All right!\n%s caught\n%s!",self.rival.name,target.name))
  battle:actNext(function()
    local mon=target.mon
    local slot,destination=self.rival:capturePokemon(mon.species,mon.level)
    if slot then
      slot.origin="caught"
      slot.caughtWith=ball
      slot.caughtAlongsidePlayer=true
    end
    Runtime.emit("pokemon.caught",{battle=battle,mon=mon,species=mon.species,
      ball=ball,destination=destination,trainer=self.rival,companion=true})
    battle.result="caught"
    battle.afterQueue="finish"
  end)
  return true
end

function Controller:chooseAction(battle,user)
  local targets={}; if alive(battle.enemy) then targets[#targets+1]=battle.enemy end
  if alive(battle.enemy2) then targets[#targets+1]=battle.enemy2 end
  local catch,target=self:catchAction(battle,targets)
  if catch then return catch,target end
  local bestAction,bestTarget,best=nil,nil,-math.huge
  for _,row in ipairs(user.moves or {}) do
    local id=moveId(row); local def=id and battle.data.moves[id]
    if id and def then
      for _,target in ipairs(targets) do
        local power=math.max(0,tonumber(def.power) or 0)
        local accuracy=tonumber(def.accuracy) or 100
        local score=power*accuracy/100+targetScore(target)
        if SPREAD_FOES[id] and #targets>1 then score=score+power*0.65 end
        if SPREAD_OTHERS[id] then
          score=score-90
          if id=="EXPLOSION" or id=="SELFDESTRUCT" then score=score-healthFraction(user)*120 end
        end
        if power==0 then
          score=18
          if self.rival.personalityId=="SCHOLAR" then score=score+10 end
          if self.rival.personalityId=="COLLECTOR" and healthFraction(user)<0.4 then score=score-12 end
        end
        if self.rival.personalityId=="EXPLORER" and SPREAD_FOES[id] then score=score+8 end
        if score>best then best,bestAction,bestTarget=score,{id=id},target end
      end
    end
  end
  return bestAction or {id=moveId(user.moves and user.moves[1])},bestTarget or targets[1]
end

function Controller:finish(battle,ev)
  self:syncBattler(battle.player2)
  for mon,slot in pairs(self.slotByMon or {}) do
    slot.hp=math.max(0,math.floor(tonumber(mon.hp) or slot.hp or 0))
  end
  local result=ev and ev.result
  if result=="win" and self.rival.gainExp then
    local levels=0
    for _,b in ipairs({battle.enemy,battle.enemy2}) do
      if b and b.mon then levels=levels+(tonumber(b.mon.level) or 1) end
    end
    self.rival:gainExp(math.max(10,math.floor(levels*12)))
  end
  self.rival.companionJourney=self.rival.companionJourney or {}
  local j=self.rival.companionJourney
  j.battles=(tonumber(j.battles) or 0)+1
  if result=="win" then j.wins=(tonumber(j.wins) or 0)+1 end
end

function CompanionBattle.context(engine)
  local rival=engine and engine.companionId and engine.byId and engine.byId[engine.companionId]
  if not rival then return nil end
  return setmetatable({active=true,name=rival.name,rival=rival,engine=engine,
    used={},slotByMon={},owner={party={}}},Controller)
end

return CompanionBattle
