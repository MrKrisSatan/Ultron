local Voice={}

local BASE={
  ultron={analysis=82,boldness=78,warmth=18,humor=12},
  data={analysis=96,boldness=48,warmth=58,humor=20},
  r2d2={analysis=62,boldness=72,warmth=72,humor=74},
  walle={analysis=44,boldness=36,warmth=94,humor=38},
}

local function clamp(v) return math.max(0,math.min(100,math.floor(tonumber(v) or 0))) end

function Voice.ensure(rival)
  local base=BASE[tostring(rival and rival.id or "ultron")] or BASE.ultron
  local v=type(rival.voiceProfile)=="table" and rival.voiceProfile or {}
  v.analysis=clamp(v.analysis or base.analysis); v.boldness=clamp(v.boldness or base.boldness)
  v.warmth=clamp(v.warmth or base.warmth); v.humor=clamp(v.humor or base.humor)
  v.battles=math.max(0,math.floor(tonumber(v.battles) or 0))
  v.wins=math.max(0,math.floor(tonumber(v.wins) or 0)); v.losses=math.max(0,math.floor(tonumber(v.losses) or 0))
  v.playerMeetings=math.max(0,math.floor(tonumber(v.playerMeetings) or 0))
  rival.voiceProfile=v; return v
end

function Voice.afterPlayerBattle(rival,rivalWon)
  local v=Voice.ensure(rival); v.battles=v.battles+1
  if rivalWon then
    v.wins=v.wins+1; v.boldness=clamp(v.boldness+2); v.analysis=clamp(v.analysis+1)
  else
    v.losses=v.losses+1; v.analysis=clamp(v.analysis+2); v.boldness=clamp(v.boldness-1); v.warmth=clamp(v.warmth+1)
  end
  if v.battles%4==0 then v.humor=clamp(v.humor+1) end
  return v
end

local function phase(v)
  if v.battles>=16 then return "seasoned" end
  if v.battles>=7 then return "formed" end
  if v.battles>=2 then return "developing" end
  return "new"
end

local function lineFor(rival,v)
  local id=tostring(rival.id or "ultron")
  local state=phase(v); local objective=tostring(rival.objective or "battle"):gsub("_"," "):lower()
  if id=="data" then
    if state=="seasoned" then return "I have modelled our history. Your strongest habit is also the opening I intend to test."
    elseif v.losses>v.wins then return "My previous hypothesis failed. This battle will test the corrected model."
    else return "The evidence is incomplete. A controlled battle should improve it." end
  elseif id=="r2d2" then
    if state=="seasoned" then return "Bweep-bweep! I know that look. You have a plan, and I have three noisy answers."
    elseif v.losses>v.wins then return "Bwooo... recalibrated! I am not making the same mistake twice."
    else return "Beep-boop! Adventure first, battle immediately after!" end
  elseif id=="walle" then
    if state=="seasoned" then return "I kept every lesson. We can be friends and still give this battle everything."
    elseif v.wins>v.losses then return "WALL-E is ready. I will be careful with my team... and brave with you."
    else return "I found something worth protecting: the courage to try again." end
  end
  if state=="seasoned" then return "I remember every adjustment you forced me to make. Now you face the person those battles created."
  elseif v.losses>v.wins then return "Defeat refined me. I have rebuilt the plan around what you revealed."
  elseif v.boldness>85 then return "I have calculated the likely result. Fight anyway; surprise is the only variable you have left."
  else return "Current objective: "..objective..". Current thought: your team is the most useful test in this region." end
end

function Voice.preBattle(rival)
  local v=Voice.ensure(rival); v.playerMeetings=v.playerMeetings+1
  return tostring(rival.name or "Ultron")..": "..lineFor(rival,v)
end

function Voice.summary(rival)
  local v=Voice.ensure(rival)
  return string.format("VOICE: %s\nAnalysis %d | Boldness %d\nWarmth %d | Humor %d\nDeveloped across %d player battles.",
    phase(v):upper(),v.analysis,v.boldness,v.warmth,v.humor,v.battles)
end

return Voice
