local NameTag={}

-- render.hud draws in window units while overworld entities/cameras use the
-- Game Boy's 160x144 logical pixel space. Never treat drawX/drawY as screen
-- coordinates: on current Gen1Recomp builds those values are still world
-- pixels and doing so leaves the plaque floating near the top-left corner.
local function cameraOf(ow)
  if type(ow)~="table" then return nil,nil end
  local cam=ow.camera or ow.cam or ow.scroll
  if type(cam)=="table" then
    return tonumber(cam.x or cam.scrollX or cam[1]) or 0,
      tonumber(cam.y or cam.scrollY or cam[2]) or 0
  end
  local x=tonumber(ow.cameraX or ow.scrollX)
  local y=tonumber(ow.cameraY or ow.scrollY)
  if x~=nil or y~=nil then return x or 0,y or 0 end
  return nil,nil
end

local function renderingOverworld(engine)
  local game=engine and engine.game
  local stack=game and game.stack
  -- WorldAPI:overworld() may be a public facade containing entities but no
  -- camera. The sprite is rendered by the real OverworldState on the screen
  -- stack, so its camera is authoritative for screen projection.
  if stack and type(stack.top)=="function" then
    local ok,top=pcall(stack.top,stack)
    if ok and top then local x=cameraOf(top); if x~=nil then return top end end
  end
  local states=stack and stack.states
  if type(states)=="table" then
    for i=#states,1,-1 do local x=cameraOf(states[i]); if x~=nil then return states[i] end end
  end
  local candidate=game and game.world
  local x=cameraOf(candidate); if x~=nil then return candidate end
  candidate=game and game.overworld
  x=cameraOf(candidate); if x~=nil then return candidate end
  local active
  if engine and type(engine.activeMap)=="function" then pcall(function() active=engine:activeMap() end) end
  x=cameraOf(active); if x~=nil then return active end
  return nil
end

local function visualWorldPixel(engine,entity)
  if not(entity and engine) then return nil end
  -- px/py are the renderer's live interpolated overworld coordinates on both
  -- Gen1 and Gen2 hosts. drawPx/drawPy are used by a few compatibility layers.
  local wx=tonumber(entity.px or entity.drawPx or entity.pixelX)
  local wy=tonumber(entity.py or entity.drawPy or entity.pixelY)
  local cellX=tonumber(entity.cellX or entity.x or (engine.rival and engine.rival.x))
  local cellY=tonumber(entity.cellY or entity.y or (engine.rival and engine.rival.y))
  if not wx and cellX then wx=cellX*16 end
  if not wy and cellY then wy=cellY*16 end
  if not(wx and wy) then return nil end
  return wx,wy
end

local function project(engine,entity,viewport)
  local wx,wy=visualWorldPixel(engine,entity); if not wx then return nil end
  local ow=renderingOverworld(engine); if not ow then return nil end
  local cx,cy=cameraOf(ow); if cx==nil then return nil end
  -- Ask the live renderer for the exact frame origin. This follows custom,
  -- taller and re-anchored overworld sheets instead of assuming every NPC is
  -- a stock 16x16 walker whose tile coordinate is its visible top-left.
  local logicalX,logicalY
  local sprite,facing,phase,flip=entity.sprite,entity.facing,0,false
  if type(entity.pose)=="function" then
    local ok,s,px,py,f,p,fl=pcall(entity.pose,entity)
    if ok then sprite=s or sprite; wx=tonumber(px) or wx; wy=tonumber(py) or wy; facing=f or facing; phase=p or phase; flip=fl or flip end
  end
  if sprite and type(sprite.getScreenOrigin)=="function" then
    local ok,sx,sy=pcall(sprite.getScreenOrigin,sprite,wx,wy,cx,cy)
    if ok and tonumber(sx) and tonumber(sy) then
      local width=tonumber(sprite.frameWidth) or 16
      if type(sprite.getPoseGeometry)=="function" then
        local gok,geo=pcall(sprite.getPoseGeometry,sprite,facing,phase,flip)
        if gok and type(geo)=="table" then width=tonumber(geo.width or geo.w) or width end
      end
      logicalX=sx+width/2
      logicalY=sy-1
    end
  end
  if not logicalX then
    logicalX=math.floor(wx-cx)+8
    logicalY=math.floor(wy-cy)-4
  end
  local vp=type(viewport)=="table" and viewport or {}
  -- The overworld is composed through its own full playfield canvas. On a
  -- wide window or survey zoom that canvas is larger than the 160x144 UI
  -- canvas described by gameX/gameWidth. Mapping a world coordinate through
  -- the UI rectangle is what left the tag parked at the right edge in the
  -- real client. Use the renderer's world view and final playfield rectangle
  -- whenever they are available.
  local renderer=engine.game and engine.game.renderer
  local worldW,worldH
  if renderer and type(renderer.worldViewSize)=="function" then
    local ok,w,h=pcall(renderer.worldViewSize,renderer)
    if ok then worldW,worldH=tonumber(w),tonumber(h) end
  end
  local viewX=tonumber(vp.viewX)
  local viewY=tonumber(vp.viewY)
  local viewW=tonumber(vp.viewWidth)
  local viewH=tonumber(vp.viewHeight)
  if worldW and worldH and worldW>0 and worldH>0 and viewW and viewH and viewW>0 and viewH>0 then
    return (viewX or 0)+logicalX*(viewW/worldW),(viewY or 0)+logicalY*(viewH/worldH)
  end
  local rect=type(vp.gameRect)=="table" and vp.gameRect or type(vp.game)=="table" and vp.game or {}
  local ox=tonumber(vp.gameX or vp.x or rect.x)
  local oy=tonumber(vp.gameY or vp.y or rect.y)
  local gw=tonumber(vp.gameWidth or vp.width or vp.w or rect.width or rect.w)
  local gh=tonumber(vp.gameHeight or vp.height or vp.h or rect.height or rect.h)
  local dpiX=tonumber(vp.dpiX) or 1
  local dpiY=tonumber(vp.dpiY) or dpiX
  local sx,sy
  if gw and gh and gw>0 and gh>0 then
    ox,oy=ox or 0,oy or 0; sx,sy=gw/160,gh/144
  elseif tonumber(vp.scale) and vp.scale>0 then
    ox,oy=ox or 0,oy or 0; sx,sy=vp.scale/dpiX,vp.scale/dpiY
  elseif love and love.graphics and love.graphics.getDimensions then
    -- Colosseum UI owns its final HUD canvas and may not populate Gen1Recomp's
    -- usual gameX/gameWidth viewport fields. Reconstruct the centered 160x144
    -- game rectangle from the actual output window rather than treating logical
    -- pixels as window pixels (the old top-left floating-name failure).
    local ww,wh=love.graphics.getDimensions()
    local sc=math.min((tonumber(ww) or 160)/160,(tonumber(wh) or 144)/144)
    sx,sy=sc,sc; gw,gh=160*sc,144*sc
    ox=((tonumber(ww) or gw)-gw)/2; oy=((tonumber(wh) or gh)-gh)/2
  else
    ox,oy=ox or 0,oy or 0; sx,sy=1,1
  end
  return ox+logicalX*sx,oy+logicalY*sy
end

function NameTag.draw(engine,enabled,result,viewport)
  if enabled==false or not(engine and engine.rival and love and love.graphics) then return result end
  -- render.hud also runs behind menus, text boxes and naming keyboards. The
  -- tag is an overworld label, never a global overlay.
  if type(engine.overworldIdle)=="function" then
    local ok,idle=pcall(engine.overworldIdle,engine)
    if not ok or not idle then return result end
  end
  local w=engine:worldView(); if not(w and w.playerMap) then return result end
  local selected=engine.rival; local g=love.graphics; local font=g.getFont and g.getFont(); if not font then return result end
  for _,rival in ipairs(engine.rivals or {selected}) do if rival.map==w.playerMap then
    engine.rival=rival
    local entity=engine:liveEntity(); local x,y=project(engine,entity,viewport)
    if x and y then
      local text=tostring(rival.name or "Ultron"); local tw=font:getWidth(text); local th=font:getHeight()
      local px=math.floor(x-tw/2+0.5); local py=math.floor(y-th-4+0.5)
      local or_,og,ob,oa=g.getColor(); local scx,scy,scw,sch=g.getScissor()
      g.push(); g.setColor(0,0,0,.76); g.rectangle("fill",px-3,py-2,tw+6,th+4)
      g.setColor(1,1,1,1); g.print(text,px,py); g.pop()
      g.setScissor(scx,scy,scw,sch); g.setColor(or_,og,ob,oa)
    end
  end end
  engine.rival=selected
  return result
end

NameTag._project=project
NameTag._renderingOverworld=renderingOverworld
return NameTag
