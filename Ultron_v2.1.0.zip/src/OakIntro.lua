local OakIntro={}

OakIntro.STEP_ID="ultron_robot_count"

function OakIntro.insert(steps)
  if type(steps)~="table" then return steps end
  for _,step in ipairs(steps) do
    if type(step)=="table" and step.id==OakIntro.STEP_ID then return steps end
  end
  local afterName,afterConfirmation
  for i,step in ipairs(steps) do
    if type(step)=="table" and step.id=="name_player" then afterName=i+1 end
    if type(step)=="table" and step.id=="confirm_player_name" then afterConfirmation=i+1 end
  end
  local at=afterConfirmation or afterName or (#steps+1)
  table.insert(steps,at,{
    id=OakIntro.STEP_ID,kind="choice",pic="oak",
    text="OAK: One more thing!\nHow many robot rivals\vwill share this world?",
    choices={"ONE","TWO","THREE","FOUR"},values={1,2,3,4},
    saveKey="ultronAgentCount",cancelable=false,tx=4,ty=0,tw=12,
  })
  return steps
end

function OakIntro.answer(ev)
  local step=type(ev)=="table" and ev.step or nil
  if type(step)~="table" or step.id~=OakIntro.STEP_ID then return nil end
  local value=math.floor(tonumber(ev.value) or 0)
  if value<1 or value>4 then return nil end
  return value
end

return OakIntro
