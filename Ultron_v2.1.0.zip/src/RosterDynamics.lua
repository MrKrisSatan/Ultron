local Util=require("mods.ultron.src.Util")
local Dynamics={}

local function badges(r) return r and r.badgeCount and r:badgeCount() or 0 end
local function avg(r) return r and r.averageLevel and r:averageLevel() or 0 end
local function copyMissing(dst,src,sharedBy)
  local changed=0; dst=type(dst)=="table" and dst or {}
  for k,v in pairs(type(src)=="table" and src or {}) do if dst[k]==nil then
    dst[k]=Util.copy(v); if type(dst[k])=="table" then dst[k].sharedBy=sharedBy end; changed=changed+1
  end end
  return dst,changed
end
local function noteShared(receiver,source,tick)
  receiver.sharedKnowledge=type(receiver.sharedKnowledge)=="table" and receiver.sharedKnowledge or {}
  for id in pairs(source.opponentKnowledge or {}) do local k="opponent:"..tostring(id); if not receiver.sharedKnowledge[k] then receiver.sharedKnowledge[k]={by=source.id,tick=tick,confidence=0.70} end end
  for map in pairs(source.visitedMaps or {}) do local k="map:"..tostring(map); if not receiver.sharedKnowledge[k] then receiver.sharedKnowledge[k]={by=source.id,tick=tick,confidence=0.65} end end
end

local function exchange(a,b,tick)
  local learned,n=0,0
  a.opponentKnowledge,n=copyMissing(a.opponentKnowledge,b.opponentKnowledge,b.id); learned=learned+n
  b.opponentKnowledge,n=copyMissing(b.opponentKnowledge,a.opponentKnowledge,a.id); learned=learned+n
  a.visitedMaps,n=copyMissing(a.visitedMaps,b.visitedMaps,b.id); learned=learned+n
  b.visitedMaps,n=copyMissing(b.visitedMaps,a.visitedMaps,a.id); learned=learned+n
  noteShared(a,b,tick); noteShared(b,a,tick)
  if a.recordRelationship then a:recordRelationship(b.id,"SHARED_JOURNEY",{tick=tick}) end
  if b.recordRelationship then b:recordRelationship(a.id,"SHARED_JOURNEY",{tick=tick}) end
  a.lastKnowledgeExchange=tick; b.lastKnowledgeExchange=tick
  return learned
end

local function pressure(leader,follower)
  local badgeGap=badges(leader)-badges(follower); local levelGap=avg(leader)-avg(follower)
  if badgeGap<=0 and levelGap<3 then return false end
  follower.peerPressure=math.min(100,(tonumber(follower.peerPressure) or 0)+math.max(2,badgeGap*8+math.floor(math.max(0,levelGap))))
  if follower.state=="IDLE" or follower.state=="EXPLORING" then
    follower.objective=(#(follower.party or {})<4 and "CATCH" or "TRAIN")
    if follower.setState then follower:setState(follower.objective=="CATCH" and "HUNTING" or "TRAINING","driven by "..tostring(leader.name).." pulling ahead") end
  end
  return true
end

function Dynamics.tick(rivals,tick,log)
  if type(rivals)~="table" or #rivals<2 or (tonumber(tick) or 0)%20~=0 then return nil end
  local events={}
  for i=1,#rivals-1 do for j=i+1,#rivals do local a,b=rivals[i],rivals[j]
    if a.map and a.map==b.map and not a._ultronDormant and not b._ultronDormant then
      local last=math.max(tonumber(a.lastKnowledgeExchange) or -9999,tonumber(b.lastKnowledgeExchange) or -9999)
      local learned=0; if (tonumber(tick) or 0)-last>=120 then learned=exchange(a,b,tick) end
      local driven=pressure(a,b); if pressure(b,a) then driven=true end
      if learned>0 or driven then
        local event={kind="robot_exchange",a=a.id,b=b.id,learned=learned,driven=driven,text=tostring(a.name).." and "..tostring(b.name).." compared discoveries"..(driven and " and intensified their League rivalry." or ".")}
        events[#events+1]=event; if log then log(a,event) end
      end
    end
  end end
  return #events>0 and events or nil
end

function Dynamics.summary(rivals,tick)
  local lines={"ROBOT RELATIONSHIPS"}
  for i=1,#(rivals or {})-1 do for j=i+1,#rivals do local a,b=rivals[i],rivals[j]
    local state=a.pairStateWith and a:pairStateWith(b,tick) or "NONE"
    lines[#lines+1]=tostring(a.name).." / "..tostring(b.name)..": "..tostring(state):gsub("_"," ")
    lines[#lines+1]="  Record "..tostring((a.memory and a.memory.rivals and a.memory.rivals[b.id] and a.memory.rivals[b.id].wins) or 0).." wins; pressure "..tostring(tonumber(a.peerPressure) or 0).."/"..tostring(tonumber(b.peerPressure) or 0)
  end end
  if #lines==1 then lines[#lines+1]="Only one robot is active in this save." end
  return table.concat(lines,"\n")
end

return Dynamics
