local Thoughts={}

local function label(v) return tostring(v or "UNKNOWN"):gsub("_"," ") end
local function count(t) local n=0; for _ in pairs(type(t)=="table" and t or {}) do n=n+1 end; return n end
local function avg(party)
  local total,n,highest=0,0,0
  for _,m in ipairs(type(party)=="table" and party or {}) do
    local level=tonumber(m and m.level)
    if level then total=total+level; n=n+1; highest=math.max(highest,level) end
  end
  return n>0 and total/n or nil,highest,n
end
local function percent(row,default)
  local value=tonumber(row and row.confidence)
  if not value then value=default or 0 end
  if value<=1 then value=value*100 end
  return math.max(0,math.min(100,math.floor(value+0.5)))
end

local WHY={
  CATCH="Building a broader team with a legitimate catch.",
  TRAIN="Closing a known level or matchup gap.",
  SHOP="Restocking with money earned in the world.",
  HEAL="Recovering before taking another risk.",
  CHALLENGE_PLAYER="Preparing to challenge the player.",
  GYM="Preparing for the next Gym with known counters.",
  EXPLORE="Learning an unfamiliar part of the world.",
  TRAVEL="Moving physically towards the current destination.",
}

function Thoughts.summary(engine,state)
  local r=engine and engine.rival
  if not r then return "ULTRON THOUGHTS\nUltron is not active yet." end
  state=type(state)=="table" and state or {}
  local objective=tostring(r.objective or r.state or "IDLE"):upper()
  local lines={"ULTRON THOUGHTS","GOAL: "..label(objective)}
  if r.destination then lines[#lines+1]="DESTINATION: "..label(r.destination) end
  local reason=tostring(r.stateReason or r.reason or "")
  if reason~="" then lines[#lines+1]="CURRENT REASON: "..label(reason) end
  local needs,gap=false,0
  if engine and engine.playerPreparationNeeded then pcall(function() needs,gap=engine:playerPreparationNeeded() end) end
  if needs then
    lines[#lines+1]=string.format("REMATCH: WAIT - known level gap %.1f",tonumber(gap) or 0)
    lines[#lines+1]="WHY: The player's known team is stronger; catching or training has priority."
  else
    lines[#lines+1]="REMATCH: ALLOWED when both teams and the game client are ready."
    lines[#lines+1]="WHY: "..(WHY[objective] or "Following the highest-priority legitimate objective currently available.")
  end
  if r._ultronGuideFollow then lines[#lines+1]="NAVIGATION: Following the player and watching for a usable exit." end
  local stuck=tonumber(r.stuckTicks) or 0; local fails=tonumber(r._ultronPathFails) or 0
  if stuck>0 or fails>0 then lines[#lines+1]="NAVIGATION PRESSURE: stuck "..stuck..", path failures "..fails end
  local ownAvg,ownMax,ownN=avg(r.party)
  local known=r.knownOpponentParty and r:knownOpponentParty("player") or nil
  local playerAvg,playerMax,playerN=avg(known)
  local source="witnessed"
  if not playerAvg then
    local shared={}; for species,row in pairs(state.training and state.training.playerLevels or {}) do shared[#shared+1]={species=species,level=row.level} end
    playerAvg,playerMax,playerN=avg(shared); source="shared"
  end
  lines[#lines+1]=string.format("OWN TEAM: %d known, average %s, highest %d",ownN,ownAvg and string.format("%.1f",ownAvg) or "?",ownMax)
  if playerAvg then lines[#lines+1]=string.format("PLAYER MODEL: %d known, average %.1f, highest %d (%s)",playerN,playerAvg,playerMax,source)
  else lines[#lines+1]="PLAYER MODEL: insufficient observed level evidence" end
  return table.concat(lines,"\n")
end

function Thoughts.knowledge(engine,state)
  state=type(state)=="table" and state or {}
  local memory=state.routeMemory or (engine and engine.routeMemory) or {}
  local training=state.training or (engine and engine.training) or {}
  local observer=state.observer or {}
  local routes={}; local witnessed,shared=0,0
  for key,row in pairs(memory.transitions or {}) do
    local from,to=tostring(key):match("^(.-)>(.*)$")
    if from and to then
      local source=row.source or "self"
      if source=="player" then witnessed=witnessed+1 elseif source=="shared" then shared=shared+1 end
      routes[#routes+1]={from=from,to=to,row=row,confidence=percent(row,source=="player" and 92 or source=="shared" and 65 or 85)}
    end
  end
  for key,row in pairs(training.routes or {}) do
    if not (memory.transitions or {})[key] then routes[#routes+1]={from=row.from,to=row.to,row=row,confidence=percent(row,65),sharedOnly=true}; shared=shared+1 end
  end
  table.sort(routes,function(a,b) if a.confidence~=b.confidence then return a.confidence>b.confidence end return (tonumber(a.row.lastTick) or 0)>(tonumber(b.row.lastTick) or 0) end)
  local lines={"ULTRON KNOWLEDGE","ROUTES: "..#routes.." (witnessed "..witnessed..", shared "..shared..")"}
  for i=1,math.min(5,#routes) do local r=routes[i]
    lines[#lines+1]=label(r.from).." -> "..label(r.to)..": "..r.confidence.."% ["..(r.sharedOnly and "shared" or tostring(r.row.source or "self")).."]"
  end
  if #routes==0 then lines[#lines+1]="No route exits learned yet." end
  lines[#lines+1]="PLAYER BATTLES OBSERVED: "..tostring(tonumber(observer.observed) or 0)
  lines[#lines+1]="PLAYER SPECIES WITH SHARED LEVELS: "..tostring(count(training.playerLevels))
  lines[#lines+1]="COLLECTIVE SOURCES: "..tostring(count(training.sources))
  local shared={}; for fact,row in pairs(engine and engine.rival and engine.rival.sharedKnowledge or {}) do shared[#shared+1]={fact=fact,row=row} end
  table.sort(shared,function(a,b) return (tonumber(a.row.tick) or 0)>(tonumber(b.row.tick) or 0) end)
  lines[#lines+1]="ROBOT-SHARED FACTS: "..tostring(#shared)
  for i=1,math.min(3,#shared) do local row=shared[i]; lines[#lines+1]=label(row.fact).." via "..label(row.row.by).." ("..percent(row.row,65).."%)" end
  lines[#lines+1]="CONFIDENCE KEY: witnessed > self-discovered > imported; repeated confirmation raises confidence."
  return table.concat(lines,"\n")
end

Thoughts.percent=percent
return Thoughts
