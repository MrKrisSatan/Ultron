local req=...
local Util=req("src/Util")
local Competitive=req("src/Competitive")
local EggMoves=req("data/Gen2EggMoves")

local DayCare={}
local DITTO="DITTO"

local function canon(v) return tostring(v or ""):upper():gsub("[^A-Z0-9]","") end
local function registry(rival)
  local d=rival and rival.ctx and rival.ctx.data or {}
  return d.gen2Pokemon or d.pokemon or {}
end
local function liveId(rows,wanted)
  local key=canon(wanted)
  for id in pairs(rows or {}) do if canon(id)==key then return id end end
end
local function defOf(rival,species) return registry(rival)[species] end
local function moveId(row) return type(row)=="table" and (row.id or row.move) or row end
local function movesOf(slot)
  local out={}
  for _,row in ipairs(slot and slot.moves or {}) do out[#out+1]=moveId(row) end
  return out
end
local function knows(slot,move)
  local c=canon(move)
  for _,id in ipairs(movesOf(slot)) do if canon(id)==c then return true end end
  return false
end
local function ensureDvs(rival,slot)
  if type(slot.dvs)~="table" then
    slot.dvs={attack=rival.rng:int(0,15),defense=rival.rng:int(0,15),
      speed=rival.rng:int(0,15),special=rival.rng:int(0,15)}
  end
  return slot.dvs
end
local function gender(rival,slot)
  if slot.species==DITTO then return "unknown" end
  local def=defOf(rival,slot.species); local ratio=def and def.genderRatio
  if ratio==nil or ratio==0xff then return "unknown" end
  return (ensureDvs(rival,slot).attack or 0)<math.floor(ratio/16) and "female" or "male"
end
local function groups(def)
  local g=def and (def.eggGroups or def.egg_groups)
  return type(g)=="table" and g or {}
end
local function noEggs(def)
  local g=groups(def)
  return #g==0 or (canon(g[1])=="EGGNONE" and canon(g[2])=="EGGNONE")
end
local function shareGroup(a,b)
  for _,x in ipairs(groups(a)) do for _,y in ipairs(groups(b)) do
    if canon(x)~="EGGNONE" and canon(x)==canon(y) then return true end
  end end
  return false
end
local function compatible(rival,a,b)
  local da,db=defOf(rival,a.species),defOf(rival,b.species)
  if not(da and db) or noEggs(da) or noEggs(db) then return false end
  if a.species~=DITTO and b.species~=DITTO and not shareGroup(da,db) then return false end
  if a.species==DITTO and b.species==DITTO then return false end
  if a.species~=DITTO and b.species~=DITTO and gender(rival,a)==gender(rival,b) then return false end
  local av,bv=ensureDvs(rival,a),ensureDvs(rival,b)
  if (av.defense or 0)%16==(bv.defense or 0)%16
     and (av.special or 0)%8==(bv.special or 0)%8 then return false end
  return true
end
local function breedingRoles(rival,a,b)
  if a.species==DITTO or b.species==DITTO then
    local ditto=a.species==DITTO and a or b; local other=a.species==DITTO and b or a
    -- Gen 2's move donor is the non-Ditto partner when it is male or
    -- genderless; a female partner makes Ditto the father-side move list.
    local donor=gender(rival,other)=="female" and ditto or other
    return other,donor,ditto
  end
  if gender(rival,a)=="female" then return a,b,a end
  return b,a,b
end
local function baseForm(rival,species)
  local rows=registry(rival); local current=species
  for _=1,2 do
    local prior
    for id,def in pairs(rows) do for _,e in ipairs(def.evolutions or {}) do
      if e.into==current then prior=id break end
    end; if prior then break end end
    if not prior then break end
    current=prior
  end
  return current
end
local function finalForm(rival,species)
  local current=species
  for _=1,2 do
    local def=defOf(rival,current); local into=def and def.evolutions and def.evolutions[1] and def.evolutions[1].into
    if not(into and defOf(rival,into)) then break end
    current=into
  end
  return current
end
local function eggMoveSet(rival,species)
  local def=defOf(rival,species); local source=def and def.eggMoves
  if type(source)~="table" or #source==0 then source=EggMoves[canon(species)] or {} end
  local out={}; for _,id in ipairs(source) do out[canon(id)]=id end
  return out
end
local function levelMoveSet(def)
  local out={}; for _,row in ipairs(def and (def.levelMoves or def.moves) or {}) do
    local id=type(row)=="table" and (row.move or row.id) or nil
    if id then out[canon(id)]=true end
  end; return out
end
local function tmMoveSet(def)
  local out={}; for _,id in ipairs(def and (def.tmhm or def.tmhmMoves or def.tmMoves) or {}) do out[canon(id)]=true end
  return out
end
local function wantedSet(rival,species)
  local row=Competitive.entry(rival.ctx.data,finalForm(rival,species)); local out={}
  local moves=row and row.roles and row.roles[1] and row.roles[1].moves or row and row.moves or {}
  for _,id in ipairs(moves or {}) do out[canon(id)]=true end
  return out
end
local function inherited(rival,baby,sharedParent,father)
  local def=defOf(rival,baby); local egg=eggMoveSet(rival,baby)
  local level,tm=levelMoveSet(def),tmMoveSet(def); local out,reasons={},{}
  for _,id in ipairs(movesOf(father)) do
    local c=canon(id); local reason
    if egg[c] then reason="eggMove"
    elseif level[c] and knows(sharedParent,id) then reason="sharedLevelMove"
    elseif tm[c] then reason="tmhm" end
    if reason then out[#out+1]=liveId(rival.ctx.data.moves,id) or id; reasons[c]=reason end
    if #out>=4 then break end
  end
  return out,reasons
end
local function owned(rival)
  local out={}
  for i,s in ipairs(rival.party or {}) do out[#out+1]={slot=s,where="party",index=i} end
  for bi,box in ipairs(rival.pcBoxes or {}) do for i,s in ipairs(box) do
    out[#out+1]={slot=s,where="pc",box=bi,index=i}
  end end
  return out
end
local function pairScore(rival,a,b)
  local leaving=(a.where=="party" and 1 or 0)+(b.where=="party" and 1 or 0)
  if #(rival.party or {})-leaving<2 then return nil end
  if not compatible(rival,a.slot,b.slot) then return nil end
  local speciesParent,father,shared=breedingRoles(rival,a.slot,b.slot); local baby=baseForm(rival,speciesParent.species)
  local moves,reasons=inherited(rival,baby,shared,father); local wanted=wantedSet(rival,baby)
  local score,eggCount=0,0
  for _,id in ipairs(moves) do
    local c=canon(id); if reasons[c]=="eggMove" then eggCount=eggCount+1; score=score+20 end
    if wanted[c] then score=score+35 end
  end
  if eggCount==0 then return nil end
  score=score+(Competitive.teamScore(rival,finalForm(rival,baby),{},{}) or 0)
  return score,{speciesParent=speciesParent,father=father,shared=shared,baby=baby,moves=moves,reasons=reasons,a=a,b=b}
end
local function bestPair(rival)
  local rows=owned(rival); local best,plan
  for i=1,#rows-1 do for j=i+1,#rows do
    local score,p=pairScore(rival,rows[i],rows[j])
    if score and (not best or score>best) then best,plan=score,p end
  end end
  return plan
end
local function removeOwned(rival,ref)
  if ref.where=="party" then return table.remove(rival.party,ref.index) end
  return table.remove(rival.pcBoxes[ref.box],ref.index)
end
local function removePair(rival,plan)
  local refs={plan.a,plan.b}; table.sort(refs,function(x,y)
    if x.where~=y.where then return x.where=="pc" end
    if x.where=="pc" and x.box~=y.box then return x.box>y.box end
    return x.index>y.index
  end)
  for _,ref in ipairs(refs) do removeOwned(rival,ref) end
end
local function daycareMap(rival)
  local graph=rival.ctx and rival.ctx.graph
  for _,id in ipairs({"ROUTE_34","J2_ROUTE_34","DAY_CARE","DAYCARE"}) do
    if graph and graph.has and graph:has(id) and rival:routeTo(id) then return id end
  end
end
local function returnParent(rival,slot)
  if #rival.party<6 then rival.party[#rival.party+1]=slot else rival:storePokemon(slot) end
end
local function makeBaby(rival,dc)
  local def=defOf(rival,dc.baby); if not def then return nil end
  local slot,where=rival:capturePokemon(dc.baby,5)
  if not slot then return nil end
  slot.origin="bred"; slot.hatchedAt=dc.map; slot.bredBy=rival.id
  slot.parents={dc.parent1.species,dc.parent2.species}; slot.moves=rival:movesFor(dc.baby,5)
  local inheritedMoves={}
  for _,id in ipairs(dc.moves or {}) do
    local duplicate=false; for _,known in ipairs(slot.moves) do if canon(known)==canon(id) then duplicate=true end end
    if not duplicate then if #slot.moves>=4 then table.remove(slot.moves,1) end; slot.moves[#slot.moves+1]=id end
    if dc.reasons and dc.reasons[canon(id)]=="eggMove" then inheritedMoves[#inheritedMoves+1]=id end
  end
  local rolledAttack=rival.rng:int(0,15); local rolledDefense=rival.rng:int(0,15)
  local rolledSpeed=rival.rng:int(0,15); local rolledSpecial=rival.rng:int(0,15)
  local source
  if dc.parent1.species==DITTO then source=dc.parent1
  elseif dc.parent2.species==DITTO then source=dc.parent2
  else
    local probe={species=dc.baby,dvs={attack=rolledAttack}}
    local eggGender=gender(rival,probe)
    if eggGender=="male" then source=dc.speciesParent
    elseif eggGender=="female" then source=dc.father end
  end
  local sd=source and ensureDvs(rival,source) or {}
  slot.dvs={attack=rolledAttack,defense=source and sd.defense or rolledDefense,speed=rolledSpeed,
    special=source and (rolledSpecial-(rolledSpecial%8)+(sd.special or 0)%8) or rolledSpecial}
  slot.eggMoves=inheritedMoves; slot.competitiveBred=true
  return slot,where
end

function DayCare.tick(rival,ctx)
  if not rival or not rival.ctx or rival.ctx.generation~=2 then return nil end
  rival.privateDayCare=type(rival.privateDayCare)=="table" and rival.privateDayCare or {cooldown=0,hatched=0}
  local dc=rival.privateDayCare; dc.cooldown=math.max(0,(tonumber(dc.cooldown) or 0)-1)
  if dc.active then
    dc.steps=(tonumber(dc.steps) or 0)+64
    if dc.steps>=(tonumber(dc.stepsToHatch) or 5120) then dc.ready=true end
    if not dc.ready then return nil end
    if rival.map~=dc.map then
      rival.objective="COLLECT_COMPETITIVE_EGG"
      rival:setState("TRAVELLING","Returning to the Day-Care for an Egg")
      rival:setDestination(dc.map)
      return "returning to private daycare"
    end
    local baby,where=makeBaby(rival,dc)
    returnParent(rival,dc.parent1); returnParent(rival,dc.parent2)
    rival:spend(math.min(tonumber(rival.money) or 0,200),"DAYCARE")
    dc.active=false; dc.ready=nil; dc.hatched=(tonumber(dc.hatched) or 0)+(baby and 1 or 0); dc.cooldown=160
    dc.lastSpecies=baby and baby.species or dc.baby; dc.lastEggMoves=baby and Util.copy(baby.eggMoves) or {}
    dc.parent1,dc.parent2,dc.speciesParent,dc.father,dc.moves,dc.reasons=nil,nil,nil,nil,nil,nil
    if baby then
      rival.objective="TRAIN"; rival.trainingTicks=math.max(tonumber(rival.trainingTicks) or 0,8)
      if ctx and ctx.log then ctx.log(rival,{kind="bred",species=baby.species,eggMoves=dc.lastEggMoves,destination=where}) end
      return "competitive egg hatched"
    end
    return "daycare hatch failed"
  end
  if dc.cooldown>0 or (rival.badgeCount and rival:badgeCount()<2) then return nil end
  local plan=bestPair(rival); if not plan then dc.cooldown=32; return nil end
  local map=daycareMap(rival); if not map then dc.cooldown=80; return nil end
  if rival.map~=map then
    rival.objective="BREED_COMPETITIVE"; rival:setState("TRAVELLING","Taking compatible parents to the Day-Care")
    rival:setDestination(map); return "travelling to private daycare"
  end
  removePair(rival,plan)
  if canon(plan.baby)=="NIDORANF" and rival.rng:int(0,255)>=128 then
    plan.baby=liveId(registry(rival),"NIDORANM") or plan.baby
    plan.moves,plan.reasons=inherited(rival,plan.baby,plan.shared,plan.father)
  end
  dc.active=true; dc.map=map; dc.steps=0
  dc.stepsToHatch=math.max(256,tonumber(defOf(rival,plan.baby).eggSteps or 20)*256)
  dc.parent1=plan.a.slot; dc.parent2=plan.b.slot
  dc.speciesParent=plan.speciesParent; dc.father=plan.father; dc.baby=plan.baby
  dc.moves=plan.moves; dc.reasons=plan.reasons
  rival.objective="JOURNEY"; rival.destination=nil; rival.route=nil
  rival:setState("IDLE","Compatible parents are raising an Egg at the Day-Care")
  if ctx and ctx.log then ctx.log(rival,{kind="daycare",species=plan.baby,eggMoves=plan.moves}) end
  return "parents deposited at private daycare"
end

DayCare.compatible=compatible
DayCare.bestPair=bestPair
DayCare.inherited=inherited
return DayCare
