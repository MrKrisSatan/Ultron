local RobotStarters={}

-- Ultron keeps the unused/counter starter chosen by Identity. The remaining
-- three robots use a second Fire/Water/Grass triangle so four-robot saves do
-- not simply clone the laboratory trio. Every listed species has an actual
-- same-type damaging move in its level-5 starting learnset in the target game.
local PLANS={
  default={data="VULPIX",r2d2="HORSEA",walle="BELLSPROUT"},
  yellow ={data="VULPIX",r2d2="HORSEA",walle="BELLSPROUT"},
  gen2   ={data="HOUNDOUR",r2d2="HORSEA",walle="BELLSPROUT"},
}
local FALLBACK={
  data={"VULPIX","GROWLITHE","HOUNDOUR","PONYTA"},
  r2d2={"HORSEA","POLIWAG","PSYDUCK","MARILL"},
  walle={"BELLSPROUT","ODDISH","CHIKORITA","HOPPIP"},
}

local function registry(data,key)
  return key=="gen2" and (data.gen2Pokemon or data.pokemon or {}) or (data.pokemon or data.gen2Pokemon or {})
end

function RobotStarters.species(data,key,id)
  key=key=="gen2" and "gen2" or key=="yellow" and "yellow" or "default"
  local reg=registry(data or {},key)
  local preferred=PLANS[key][id]
  if preferred and reg[preferred] then return preferred end
  for _,species in ipairs(FALLBACK[id] or {}) do if reg[species] then return species end end
  return nil
end

function RobotStarters.plan(key)
  key=key=="gen2" and "gen2" or key=="yellow" and "yellow" or "default"
  local out={}; for id,species in pairs(PLANS[key]) do out[id]=species end; return out
end

return RobotStarters
